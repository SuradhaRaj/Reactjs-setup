/* eslint-disable @typescript-eslint/no-empty-function */
import React from 'react';
import { mount } from 'enzyme';
import { CircularProgress } from '@material-ui/core';
import { Identifiers } from '../components/molecules/MediaIndexer/Identifiers';
import ArtifactType from '../interfaces/enums/ArtifactType';

describe('Identifiers Typedown Tests', () => {
  it('loading wheel should react to loading flag changes', () => {
    const wp = mount((
      <Identifiers
        selectedIdentifiers={[]}
        keyName="ident"
        onChangeFunction={() => { }}
        disabled={false}
        error={false}
        classes={{}}
        errorSnackbarFunction={() => { }}
        fastAndIdentifierCount={1}
        fastAndIdentifierLimit={6}
        artifactType={ArtifactType.Media}
      />
    ));

    // loading should be hidden
    expect(wp.contains(<CircularProgress color="inherit" size={20} />)).toBe(false);

    // set loading to true
    wp.setState({ loading: true });

    // check is loading is shown
    expect(wp.contains(<CircularProgress color="inherit" size={20} />)).toBe(true);

    // set loading to false
    wp.setState({ loading: false });

    // check is loading is not shown
    expect(wp.contains(<CircularProgress color="inherit" size={20} />)).toBe(false);
  });

  it('should display the number of remaining options that can be selected', () => {
    const wp = mount((
      <Identifiers
        selectedIdentifiers={[]}
        keyName="ident"
        onChangeFunction={() => undefined}
        disabled={false}
        error={false}
        classes={{}}
        errorSnackbarFunction={() => undefined}
        fastAndIdentifierCount={2}
        fastAndIdentifierLimit={6}
        artifactType={ArtifactType.Media}
      />
    ));

    // number of remaining selections should be displayed
    expect(wp.find('[data-remaining]').text()).toBe('4');
  });
});
