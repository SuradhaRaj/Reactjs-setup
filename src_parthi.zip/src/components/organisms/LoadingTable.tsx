import React from 'react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Skeleton from '@material-ui/lab/Skeleton';
import { TableHead } from '@material-ui/core';
import { makeStyles, createStyles } from '@material-ui/core/styles';

const useStyles = makeStyles(createStyles({
  '@global': {
    '.MuiTableCell-body': {
      padding: '3px 16px 3px 16px',
    },
  },
  root: {},
}));

interface Props{
  NumberOfRows: number;
}

const TaskManagementTable: React.FC<Props> = ({ NumberOfRows }) => {
  const columnSize = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;
  const classes = useStyles();

  const rows = [];
  for (let i = 0; i < NumberOfRows; i++) {
    rows.push(
      <TableRow>
        <TableCell><Skeleton variant="text" animation="wave" width={columnSize(400, 600)} /></TableCell>
        <TableCell><Skeleton variant="text" animation="wave" width={columnSize(100, 200)} /></TableCell>
        <TableCell><Skeleton variant="text" animation="wave" width={columnSize(100, 200)} /></TableCell>
      </TableRow>,
    );
  }

  return (
    <>
      <TableContainer component={Paper} className={classes.root}>
        <Table aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell><Skeleton variant="text" animation="wave" width={200} /></TableCell>
              <TableCell><Skeleton variant="text" animation="wave" width={100} /></TableCell>
              <TableCell><Skeleton variant="text" animation="wave" width={200} /></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows}
          </TableBody>
        </Table>
      </TableContainer>
    </>
  );
};

export default TaskManagementTable;
