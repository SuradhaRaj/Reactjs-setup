interface AddAuthorRequest {
  firstName: string;
  middleName: string | null;
  lastName: string;
  orcidCode: string | null;
  affiliation: string | null;
  artifactArticleId: number | null;
  isLegal: boolean;
};

export default AddAuthorRequest;
