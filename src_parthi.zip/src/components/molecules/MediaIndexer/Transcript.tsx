import React from 'react';
import {
  makeStyles, createStyles, Typography, Grid, FormLabel,
} from '@material-ui/core';
import Scrollbars from 'react-custom-scrollbars';
import StringExtensions from '../../../utils/StringExtensions';

const useStyles = makeStyles(() => createStyles({
  transcript: {
    minHeight: '100px',
    fontSize: '14px',
    paddingRight: '15px',
    lineHeight: 2,
  },
  transcriptField: {
    color: '#000054',
    paddingRight: '10px',
  },
  transcriptLabel: {
    fontSize: '14px',
    fontWeight: 600,
    color: '#000054',
  },
}));

interface TranscriptProps {
  labelText: string;
  displayText: string;
}

export default function Transcript(props: TranscriptProps): JSX.Element {
  const classes = useStyles();
  let content = 'No captions available.';
  if (props.displayText !== null && props.displayText !== '') {
    content = StringExtensions.CleanHtmlString(props.displayText);
  }

  return (
    <div className={classes.transcriptField}>
      <Grid item xs={12}>
        <FormLabel className={classes.transcriptLabel}>{props.labelText}</FormLabel>
      </Grid>
      <Grid item xs={12}>
        <Scrollbars autoHeight autoHeightMax={250}>
          <Typography className={classes.transcript} variant="body1">{content}</Typography>
        </Scrollbars>
      </Grid>
    </div>
  );
}
