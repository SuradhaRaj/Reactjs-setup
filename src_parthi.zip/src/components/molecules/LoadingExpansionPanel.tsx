import React from 'react';
import {
  ExpansionPanel, ExpansionPanelSummary, createStyles, makeStyles, Theme,
} from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Skeleton from '@material-ui/lab/Skeleton';
import { random } from 'lodash';
import classnames from 'classnames';

const useStyles = makeStyles((theme: Theme) => createStyles({
  expandIcon: {
    color: theme.palette.grey[300],
  },
  expansionPanel: {
    '& *': {
      cursor: 'initial',
      pointerEvents: 'none',
    },
    width: '100%',
  },
}));

interface Props{
 className: string;
}

const LoadingExpansionPanel = ({ className }: Props) => {
  const classes = useStyles();

  const width = random(60, 80);

  return (
    <ExpansionPanel className={classnames(className, classes.expansionPanel)}>
      <ExpansionPanelSummary
        expandIcon={<ExpandMoreIcon className={classes.expandIcon} />}
      >
        <Skeleton width={`${width}%`} animation="wave" />
      </ExpansionPanelSummary>
    </ExpansionPanel>
  );
};

export default LoadingExpansionPanel;
