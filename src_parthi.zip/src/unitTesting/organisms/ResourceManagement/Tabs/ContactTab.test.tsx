import React from 'react';
import { shallow } from 'enzyme';
import ContactTab from '../../../../components/organisms/ResourceManagement/Tabs/ContactTab';
import fakeContact from '../../../testObjects/Organisation/OrganisationContact';

describe('Contact Tab', () => {
  it('should show the correct error when there are no contacts', () => {
    const wrapper = shallow(<ContactTab contacts={[]} hubspotOrgId={1} />);
    expect(wrapper.find('[data-testid="noContacts"]')).toHaveLength(1);
  });
  it('should not show an error when there are', () => {
    const wrapper = shallow(<ContactTab contacts={[fakeContact()]} hubspotOrgId={1} />);
    expect(wrapper.find('[data-testid="noContacts"]')).toHaveLength(0);
  });
});
