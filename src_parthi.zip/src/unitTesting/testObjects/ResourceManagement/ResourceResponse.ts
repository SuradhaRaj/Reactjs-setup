import ResourceResponse from '../../../interfaces/ResourceManagement/ResourceResponse';
import Resource from './Resource';
import fakeContact from '../Organisation/OrganisationContact';
import fakeOrganisation from './Organisation';

const response: ResourceResponse = {
  issueYears: [],
  organisation: fakeOrganisation(),
  resource: Resource,
  contacts: [fakeContact(), fakeContact(), fakeContact()],
};

export default response;
