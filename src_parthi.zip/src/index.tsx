import 'bootstrap/dist/css/bootstrap.css';
import './styling/index.css';
import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter } from 'react-router-dom';
import { PublicClientApplication } from '@azure/msal-browser';
import App from './App';
import msalConfig from './authConfig';
// import { StyledEngineProvider } from '@mui/material/styles';

const rootElement = document.getElementById('root');
const msalInstance = new PublicClientApplication(msalConfig);
ReactDOM.render(
  <BrowserRouter>
    <App msalInstance={msalInstance} />
  </BrowserRouter>,
  rootElement,
);

export default msalInstance;
