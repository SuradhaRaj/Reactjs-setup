import React from 'react';
import { mount } from 'enzyme';
import Axios from 'axios';
import MockAdapter from 'axios-mock-adapter';
import { act } from 'react-dom/test-utils';
import Skeleton from '@material-ui/lab/Skeleton';
import ResourcesList from '../../components/pages/ResourcesList';
import ResourceListResponseObj from '../testObjects/ResourceManagement/ResourceListResponse';
import TitleSearchResultObj from '../testObjects/Search/TitleSearchResult';
import TitleResult from '../../components/organisms/Search/TitleResult';

const axiosMock = new MockAdapter(Axios);
jest.mock('react-router-dom', () => ({
  useParams: () => ({ partnerId: 1 }),
  useLocation: () => undefined,
  useHistory: () => undefined,
}));

describe('Resource List', () => {
  it('should show the correct error when data received is not in the correct format', async () => {
    axiosMock.onGet('/api/resource/list').reply(200, {});
    const wrapper = mount(<ResourcesList />);

    await act(async () => {
      await Promise.resolve(wrapper);
    });
    wrapper.update();

    expect(wrapper.find('[data-testid="dataError"]')).toHaveLength(1);
  });
  it('should show the correct error when a http error is received', async () => {
    axiosMock.onGet('/api/resource/list').reply(404, {});
    const wrapper = mount(<ResourcesList />);

    await act(async () => {
      await Promise.resolve(wrapper);
    });
    wrapper.update();

    expect(wrapper.find('[data-testid="genericError"]')).toHaveLength(1);
  });
  it('should show the correct message when there are no resources to display', async () => {
    const response = ResourceListResponseObj;
    response.resources = [];

    axiosMock.onGet('/api/resource/list').reply(200, response);
    const wrapper = mount(<ResourcesList />);

    await act(async () => {
      await Promise.resolve(wrapper);
    });
    wrapper.update();

    expect(wrapper.find('[data-testid="noResources"]').length).toBeGreaterThan(0);
  });
  it('should render the correct number of results', async () => {
    axiosMock.onGet('/api/resource/list').reply(200, ResourceListResponseObj);
    const wrapper = mount(<ResourcesList />);

    await act(async () => {
      await Promise.resolve(wrapper);
    });
    wrapper.update();

    expect(wrapper.find(TitleResult)).toHaveLength(ResourceListResponseObj.resources.length);
  });
  it('should show the correct number of items rendered in the counter', async () => {
    const response = { ...ResourceListResponseObj };
    response.resources = Array(100).fill(TitleSearchResultObj);
    axiosMock.onGet('/api/resource/list').reply(200, response);
    const wrapper = mount(<ResourcesList />);

    await act(async () => {
      await Promise.resolve(wrapper);
    });
    wrapper.update();

    const resultsShowing = wrapper.find(TitleResult).length;
    expect(wrapper.find('[data-testid="showingCount"]').text()).toEqual(resultsShowing.toString());
  });
  it('should show the correct number of total items received in the counter', async () => {
    const response = { ...ResourceListResponseObj };
    response.resources = Array(100).fill(TitleSearchResultObj);
    axiosMock.onGet('/api/resource/list').reply(200, response);
    const wrapper = mount(<ResourcesList />);

    await act(async () => {
      await Promise.resolve(wrapper);
    });
    wrapper.update();

    expect(wrapper.find('[data-testid="totalCount"]').text()).toEqual(response.resources.length.toString());
  });
  it('should show the load more button when there are more items to display', async () => {
    const response = { ...ResourceListResponseObj };
    response.resources = Array(100).fill(TitleSearchResultObj);
    axiosMock.onGet('/api/resource/list').reply(200, response);
    const wrapper = mount(<ResourcesList />);

    await act(async () => {
      await Promise.resolve(wrapper);
    });
    wrapper.update();

    expect(wrapper.find('button[data-testid="showMore"]')).toHaveLength(1);
  });
  it('should not show the load more button all the results are being displayed', async () => {
    axiosMock.onGet('/api/resource/list').reply(200, ResourceListResponseObj);
    const wrapper = mount(<ResourcesList />);

    await act(async () => {
      await Promise.resolve(wrapper);
    });
    wrapper.update();

    expect(wrapper.find('button[data-testid="showMore"]')).toHaveLength(0);
  });
  it('should show the loading screen when loading', async () => {
    axiosMock.onGet('/api/resource/list').reply(200, ResourceListResponseObj);
    const wrapper = mount(<ResourcesList />);

    await act(async () => {
      await Promise.resolve(wrapper);
    });

    expect(wrapper.find(Skeleton).length).toBeGreaterThan(0);
  });
  it('should not show the loading screen when not loading', async () => {
    axiosMock.onGet('/api/resource/list').reply(200, ResourceListResponseObj);
    const wrapper = mount(<ResourcesList />);

    await act(async () => {
      await Promise.resolve(wrapper);
    });
    wrapper.update();

    expect(wrapper.find(Skeleton).length).toBe(0);
  });
  it('should show relevant items when the filter is used', async () => {
    const response = { ...ResourceListResponseObj };
    response.resources = Array(3).fill(TitleSearchResultObj);
    response.resources[0] = { ...TitleSearchResultObj, resourceTitle: 'ExampleTitle' };
    axiosMock.onGet('/api/resource/list').reply(200, response);
    const wrapper = mount(<ResourcesList />);

    await act(async () => {
      await Promise.resolve(wrapper);
    });
    wrapper.update();

    await act(async () => {
      wrapper.find('[data-testid="filter"] input').getDOMNode<HTMLInputElement>().value = 'ExampleTitle';
      await wrapper.find('[data-testid="filter"] input').simulate('change');
    });
    wrapper.update();

    expect(wrapper.find(TitleResult)).toHaveLength(1);
  });
  it('should render more results when the show more button is clicked', async () => {
    const response = { ...ResourceListResponseObj };
    response.resources = Array(100).fill(TitleSearchResultObj);
    axiosMock.onGet('/api/resource/list').reply(200, response);
    const wrapper = mount(<ResourcesList />);

    await act(async () => {
      await Promise.resolve(wrapper);
    });
    wrapper.update();
    const initialResults = wrapper.find(TitleResult).length;

    await act(async () => {
      await wrapper.find('button[data-testid="showMore"]').simulate('click');
    });
    wrapper.update();
    const updatedResults = wrapper.find(TitleResult).length;

    expect(updatedResults).toBeGreaterThan(initialResults);
  });
});
