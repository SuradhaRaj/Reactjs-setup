/*eslint-disable*/
import React from 'react';
import { mount, shallow } from 'enzyme';
import NotesButton from '../components/molecules/MediaIndexer/NotesButton';
import DoucmentNote from '../interfaces/MediaIndexer/DocumentNote';
import {TextField} from '@material-ui/core';

interface WrapperProps{
  notes: DoucmentNote[],
  noteChangeFunction: Function
}

function Wrapper(FooProps: WrapperProps) {
  return (
    <NotesButton
      isReadOnly={false}
      notes={FooProps.notes}
      noteChangeFunction={FooProps.noteChangeFunction}
    />
  );
}

describe('Notes Button Tests', function() {
  it('should display notes passed in from props', function() {
    const wrapper = mount((
      <Wrapper
        notes={[{ note: 'Test Note 1', createdBy: 'Test Name', createdDate: '0001-01-01' }, { note: 'Test Note 2', createdBy: 'CurrentUser', createdDate: '0001-01-02' }]}
        noteChangeFunction={(notes: DoucmentNote[]) => {wrapper.setProps(notes)}}
      />
    ));

    wrapper.find('.MuiButtonBase-root').simulate('click');

    expect(
      wrapper.contains("Test Note 1")
    ).toBe(true);

    expect(
        wrapper.contains("Test Note 2")
    ).toBe(true);
  });

  it('should be able to add new notes', function() {
    const wrapper = mount((
      <Wrapper
        notes={[{ note: 'Test Note 1', createdBy: 'Test Name', createdDate: '0001-01-01' }, { note: 'Test Note 2', createdBy: 'CurrentUser', createdDate: '0001-01-02' }]}
        noteChangeFunction={(notes: DoucmentNote[]) => {wrapper.setProps(notes, () => {})}}
      />
    ));

    wrapper.find('.MuiButtonBase-root').simulate('click');
    
    const props: WrapperProps = {
      notes: [{ note: 'Test Note 1', createdBy: 'Test Name', createdDate: '0001-01-01' }, { note: 'Test Note 2', createdBy: 'CurrentUser', createdDate: '0001-01-02' }, { note: 'Test Note 3', createdBy: 'CurrentUser', createdDate: '0001-01-03' }],
      noteChangeFunction: () => {}
    }

    wrapper.setProps(props);

    expect(
      wrapper.contains("Test Note 1")
    ).toBe(true);

    expect(
      wrapper.contains("Test Note 2")
    ).toBe(true);

    expect(
      wrapper.contains("Test Note 3")
    ).toBe(true);
  });

  it('should be able to remove notes', function() {
    const wrapper = mount((
      <Wrapper
        notes={[{ note: 'Test Note 1', createdBy: 'Test Name', createdDate: '0001-01-01' }, { note: 'Test Note 2', createdBy: 'CurrentUser', createdDate: '0001-01-02' }, { note: 'Test Note 3', createdBy: 'CurrentUser', createdDate: '0001-01-03' }]}
        noteChangeFunction={(notes: DoucmentNote[]) => {wrapper.setProps(notes, () => {})}}
      />
    ));

    wrapper.find('.MuiButtonBase-root').simulate('click');
    
    const props: WrapperProps = {
      notes: [{ note: 'Test Note 1', createdBy: 'Test Name', createdDate: '0001-01-01' }, { note: 'Test Note 2', createdBy: 'CurrentUser', createdDate: '0001-01-02' }],
      noteChangeFunction: () => {}
    }

    wrapper.setProps(props);

    expect(
      wrapper.contains("Test Note 1")
    ).toBe(true);

    expect(
      wrapper.contains("Test Note 2")
    ).toBe(true);

    expect(
      wrapper.contains("Test Note 3")
    ).toBe(false);
  });

  it('should be able to add notes when read only', () =>{
    
    const wrapper = shallow(<NotesButton 
        isReadOnly={false}
        notes={[{ note: 'Test Note 1', createdBy: 'Test Name', createdDate: '0001-01-01' }, { note: 'Test Note 2', createdBy: 'CurrentUser', createdDate: '0001-01-02' }, { note: 'Test Note 3', createdBy: 'CurrentUser', createdDate: '0001-01-03' }]}
        noteChangeFunction={(notes: DoucmentNote[]) => {wrapper.setProps(notes, () => {})}}
        />
    );

    expect(wrapper.find(TextField)).toHaveLength(1);

  })

  it('should not be able to add notes when read only', () =>{
    
    const wrapper = shallow(<NotesButton 
        isReadOnly
        notes={[{ note: 'Test Note 1', createdBy: 'Test Name', createdDate: '0001-01-01' }, { note: 'Test Note 2', createdBy: 'CurrentUser', createdDate: '0001-01-02' }, { note: 'Test Note 3', createdBy: 'CurrentUser', createdDate: '0001-01-03' }]}
        noteChangeFunction={(notes: DoucmentNote[]) => {wrapper.setProps(notes, () => {})}}
        />
    );

    expect(wrapper.find(TextField)).toHaveLength(0);
    

  })
});