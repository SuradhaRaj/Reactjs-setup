import React from 'react';
import {
  createStyles, Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, Button, makeStyles, Theme, Typography,
} from '@material-ui/core';
import WarningIcon from '@material-ui/icons/Warning';
import ResourceStringHelper from '../../../utils/ResourceStringHelper';
import IndexerValidationStrings from '../../../res/IndexerValidationStrings';

const useStyles = makeStyles((theme: Theme) => createStyles({
  typography: {
    display: 'inline',
    marginLeft: theme.spacing(1),
  },
  errorContainer: {
    marginTop: theme.spacing(2),
  },
  errorRoot: {
    marginBottom: theme.spacing(1),
  },
  warningIcon: {
    color: theme.palette.warning.main,
  },
}));

interface Props {
  errors: Array<number>;
  onProceed(): void;
  onReturn(): void;
  isOpen: boolean;
}

interface ErrorProps {
  Error: string;
}

export const ValidationError: React.FC<{error: number}> = ({ error }) => {
  const classes = useStyles();

  return (
    <div className={classes.errorRoot}>
      <WarningIcon className={classes.warningIcon} />
      <Typography className={classes.typography}>{ResourceStringHelper.MapNumberToString(IndexerValidationStrings, error)}</Typography>
    </div>
  );
};

export const ValidationDialog: React.FC<Props> = (props) => {
  const classes = useStyles();

  let errorContent: Array<JSX.Element> = [];
  errorContent = props.errors.map((error) => <ValidationError key={error} error={error} />);

  return (
    <Dialog
      open={props.isOpen}
      keepMounted
      aria-labelledby="alert-dialog-slide-title"
      aria-describedby="alert-dialog-slide-description"
    >
      <DialogTitle id="alert-dialog-slide-title">Are you sure you want to submit this?</DialogTitle>
      <DialogContent>
        <DialogContentText id="alert-dialog-slide-description">
          <Typography>We found some things we think you might want to double check:</Typography>
          <div className={classes.errorContainer}>
            {errorContent}
          </div>
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button onClick={props.onReturn} variant="text" color="primary">
          Return
        </Button>
        <Button onClick={props.onProceed} variant="outlined" color="primary">
          Submit
        </Button>
      </DialogActions>
    </Dialog>
  );
};
