import {
  Record,
  Array,
  String,
  Static,
} from 'runtypes';

export const SubmitFilesErrorResponseValidator = Record({
  fileNames: Array(String),
});

export type SubmitFilesErrorResponse = Static<typeof SubmitFilesErrorResponseValidator>;
