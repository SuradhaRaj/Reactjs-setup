interface ExtraRequest {
    fileType: string | null;
    filename: string;
    pageCount: number;
    fileSize: number;
}

export default ExtraRequest;
