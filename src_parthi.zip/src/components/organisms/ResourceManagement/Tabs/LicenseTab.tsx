import React from 'react';
import {
  Grid, makeStyles, Theme, createStyles, Typography,
} from '@material-ui/core';

import SmallChip from '../../../molecules/SmallChip';

const useStyles = makeStyles((theme: Theme) => createStyles({
  licenseStatus: {
    color: theme.palette.success.contrastText,
    background: theme.palette.success.main,
    marginLeft: theme.spacing(1),
  },
}));

export default () => {
  const classes = useStyles();
  return (
    <Grid container style={{ position: 'relative' }}>
      <Grid item xs={12}>
        <Typography variant="overline">LICENSE INFORMATION</Typography>
        <SmallChip label="ACTIVE" className={classes.licenseStatus} />
        <div>
          Coming soon...
        </div>
      </Grid>
    </Grid>
  );
};
