import ConvertResourceTypes from '../../utils/ConvertResourceTypesHelper';
import TextResourceType from '../../interfaces/TextIndexer/ReferenceData/TextResourceType';
import ResourceTypeDropdownOption from '../../interfaces/TextIndexer/ResourceTypeDropdownOption';

describe('Should correctly order and indent provided list', () => {
  it('should correctly order and indent provided list', () => {
    const originalList: TextResourceType[] = [
      {
        resourceTypeID: 1,
        name: 'Test 1',
        displayOrder: 1,
        children: [
          {
            resourceTypeID: 3,
            name: 'Test 3',
            displayOrder: 2,
            children: [
              {
                resourceTypeID: 4, name: 'Test 4', displayOrder: 3, children: [],
              },
            ],
          },
        ],
      },
      {
        resourceTypeID: 2, name: 'Test 2', displayOrder: 4, children: [],
      },
    ];

    const expectedList: ResourceTypeDropdownOption[] = [
      {
        display: 'Test 1',
        value: {
          id: 1,
          stringValue: 'Test 1',
        },
      },
      {
        display: '\tTest 3',
        value: {
          id: 3,
          stringValue: 'Test 3',
        },
      },
      {
        display: '\t\tTest 4',
        value: {
          id: 4,
          stringValue: 'Test 4',
        },
      },
      {
        display: 'Test 2',
        value: {
          id: 2,
          stringValue: 'Test 2',
        },
      },
    ];

    const returnedList = ConvertResourceTypes.ConvertResourceTypes(originalList);

    expect(returnedList).toEqual(expectedList);
  });

  it('should filter by issueresourcetypeid', () => {
    const originalList: TextResourceType[] = [
      {
        resourceTypeID: 1,
        name: 'Test 1',
        displayOrder: 1,
        children: [
          {
            resourceTypeID: 3,
            name: 'Test 3',
            displayOrder: 2,
            children: [
              {
                resourceTypeID: 4, name: 'Test 4', displayOrder: 3, children: [],
              },
            ],
          },
        ],
      },
      {
        resourceTypeID: 2, name: 'Test 2', displayOrder: 4, children: [],
      },
    ];

    const expectedList: ResourceTypeDropdownOption[] = [
      {
        display: 'Test 1',
        value: {
          id: 1,
          stringValue: 'Test 1',
        },
      },
      {
        display: '\tTest 3',
        value: {
          id: 3,
          stringValue: 'Test 3',
        },
      },
      {
        display: '\t\tTest 4',
        value: {
          id: 4,
          stringValue: 'Test 4',
        },
      },
    ];

    const returnedList = ConvertResourceTypes.ConvertResourceTypes(originalList, 1);

    expect(returnedList).toEqual(expectedList);
  });

  it('should correctly handle receiving an empty list', () => {
    const originalList: TextResourceType[] = [];

    const expectedList: ResourceTypeDropdownOption[] = [];

    const returnedList = ConvertResourceTypes.ConvertResourceTypes(originalList);

    expect(returnedList).toEqual(expectedList);
  });
});
