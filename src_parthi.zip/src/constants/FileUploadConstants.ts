export const MaxFileSize = 100 * 1000000; // bytes
export const MaxFiles = 100;
export const ErrorMessages = {
  0: 'File too large',
  1: 'File type not accepted',
  2: 'File has already been added',
  3: 'Max number of files reached',
};

// Dropzone
export const AcceptedIssueFileTypes = [
  'application/pdf',
  'text/html',
];

export const AcceptedExtraFileTypes = [
  'application/pdf',
  'text/html',
  'text/plain',
  'image/png',
  'image/jpeg',
  'audio/wave',
  'audio/wav',
  'application/ogg',
];

export const DisplayMessages = {
  0: 'Drop files here',
  1: 'Please add only PDFs or HTML files. All other files types will be rejected.',
  2: '',
  3: 'Drop files here or click to select files',
};
