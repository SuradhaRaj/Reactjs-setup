import React from 'react';
import {
  Typography,
  Grid,
  Card,
  makeStyles,
} from '@material-ui/core';
import TextInputField from '../../Shared/TextInputField';
import InlineDatePicker from '../../Shared/Datepicker';
import DropdownOption from '../../../interfaces/MediaIndexer/DropdownOption';
import LookupOption from '../../../interfaces/LookupOption';

export interface SelectedOptionState {
  grouping: string[];
  publisher: string[];
  title: string[];
  id: string[];
  article: string[];
  documentNumber: string[];
  resource: string[];
  hasIndexerNotes?: boolean;
  hasPublisherNotes?: boolean;
  includeRelated?: boolean;
  broadcastdate: Array<string>;

}

export interface SelectedFilter {
    broadcastdate: Array<string>;
}

interface FilterAreaState {
  isAdvanceView: boolean;
}

interface TextInputFieldState {
  inputText: string;
}
type NewType = boolean;

interface Props {
  isLoading: NewType;
}

  interface StateResource {
    resource: DropdownOption[];
    search: string;
    resourcetype: LookupOption[];
  }

const useStyles = makeStyles({
  resourceIdeContainer: {
    paddingBottom: '20',
  },

  heading: {
    'font-size': '13px',
    'font-weight': '500',
    'text-transform': 'none',
    color: '#000000',
    float: 'left',
  },
  cardheader: {},
  Lgroup: {
    fontSize: '12px',
    marginRight: '20px',
    color: '#000000',
    paddingTop: '15',
    paddingBottom: '15',
  },
  Lname: {
    fontSize: '12px',
    'font-weight': '600',
    color: '#000000',
    marginRight: '8px',
    marginBottom: '0px',
  },
});

function Contractdate(props: Props): JSX.Element {
  const classes = useStyles();

  return (
    <Card
      variant="outlined"
      className="resourceIdeContainer"
      style={{
        marginLeft: 0,
        marginRight: 0,
        paddingBottom: 20,
        marginTop: 0,
        paddingTop: 0,
      }}
    >
      <Grid container xs={12}>
        <Typography
          className={classes.heading}
          variant="overline"
          style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
        >
          Contract Dates
        </Typography>
      </Grid>
      <Grid
        xs={12}
        spacing={2}
        container
        style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
      >
        <Grid item xs={3}>
          <div className="customdatepicker">
            <InlineDatePicker
              labelText="Contract Start Date"
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="customdatepicker">
            <InlineDatePicker
              labelText="Contract End Date"
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="customdatepicker">
            <InlineDatePicker
              labelText="Notice Provided"
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custominput mt0">
            <TextInputField
              keyName="eissn"
              labelText="Notice Period"
              inputText=""
              onChangeFunction={(e: any) => e}
              // onBlur={() => {}}
              error={false}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="customdatepicker">
            <InlineDatePicker
              labelText="Embargo period End Date"
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="customdatepicker">
            <InlineDatePicker
              labelText="Withdrawal Date"
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="customdatepicker">
            <InlineDatePicker
              labelText="Archival Period start Date"
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custominput mt0">
            <TextInputField
              keyName="eissn"
              labelText="Archival Period"
              inputText=""
              onChangeFunction={(e: any) => e}
              // onBlur={() => {}}
              error={false}
            />
          </div>
        </Grid>
      </Grid>
    </Card>
  );
}

export default Contractdate;
