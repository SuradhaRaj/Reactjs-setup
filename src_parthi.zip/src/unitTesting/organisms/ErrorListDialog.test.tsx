/* eslint-disable @typescript-eslint/no-empty-function */
import React from 'react';
import { mount } from 'enzyme';
import ErrorListDialog from '../../components/organisms/ErrorListDialog';

describe('Error list dialog', () => {
  const wrapper = mount(
    <ErrorListDialog
      open
      handleClose={() => {}}
      title="Dialog Title"
      errors={['error1', 'error2']}
    />,
  );

  it('should display the title', () => {
    expect(wrapper.contains('Dialog Title'));
  });

  it('should display all errors', () => {
    expect(wrapper.contains('error1'));
    expect(wrapper.contains('error2'));
  });
});
