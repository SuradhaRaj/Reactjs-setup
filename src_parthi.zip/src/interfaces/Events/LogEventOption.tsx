interface LogEventOption {
    eventTypeId: number;
    eventType: string;
    workflowStatusId: number | undefined;
    workflowStatus: string | undefined;
    timestamp: string;
}

export default LogEventOption;
