import React from 'react';
import {
  Typography, createStyles, makeStyles, Theme,
} from '@material-ui/core';

const useStyles = makeStyles((theme: Theme) => createStyles({
  heading: {
    fontWeight: 600,
    marginRight: theme.spacing(1),
  },

}));

interface MetadataItemProps {
    title: string;
    value: string | null | number;
    alwaysDisplay?: boolean;

}
;
export const MetadataItem = (props: MetadataItemProps) => {
  const classes = useStyles();
  const alwaysDisplay = (props.alwaysDisplay ?? false);

  return (
    <>
      {(props.value || alwaysDisplay) && (
      <Typography>
        <span className={classes.heading}>{props.title}</span>
        <span>{props.value}</span>
      </Typography>
      )}
    </>
  );
};

export default MetadataItem;
