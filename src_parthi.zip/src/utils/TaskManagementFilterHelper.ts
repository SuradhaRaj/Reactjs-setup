import { uniqWith, orderBy } from 'lodash';

const GetValues = (values: string[]) => {
  const valuesCleaned = values.map((value) => value.trim());
  const valuesDistinct = uniqWith(valuesCleaned, (val1, val2) => val1.toUpperCase() === val2.toUpperCase());
  const valuesOrdered = orderBy(valuesDistinct);
  return valuesOrdered;
};

export default {
  GetValues,
};
