abstract class Filters<T> {
  data: T;

  constructor(filterData: T) {
    this.data = filterData;
  }

  updateFilter<U extends keyof T>(propertyName: U, value: T[U]) {
    this.data[propertyName] = value;
    return Object.create(this);
  }

  getQueryString() {
    const jsonString = JSON.stringify(this.data, (_, value) => {
      if (value.length === 0) { return undefined; }
      return value;
    });

    if (jsonString === '{}') {
      return '';
    }

    return jsonString;
  }
}

export default Filters;
