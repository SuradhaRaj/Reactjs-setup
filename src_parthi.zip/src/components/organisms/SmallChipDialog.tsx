import React, { useState } from 'react';
import {
  Dialog, ChipProps, Typography, makeStyles,
} from '@material-ui/core';
import SmallChip from '../molecules/SmallChip';

interface State {
  dialogOpen: boolean;
}

interface Props extends ChipProps {
  dialogTitle: string;
  dialogContent: string;
}

const useStyles = makeStyles({
  dialogRoot: {
    padding: 24,
  },
});

export default (props: Props) => {
  const [state, setState] = useState<State>({
    dialogOpen: false,
  });

  const classes = useStyles();

  const { dialogTitle, dialogContent, ...chipProps } = props;

  const openDialog = () => {
    setState((prevState) => ({
      ...prevState,
      dialogOpen: true,
    }));
  };

  const closeDialog = () => {
    setState((prevState) => ({
      ...prevState,
      dialogOpen: false,
    }));
  };

  return (
    <>
      <SmallChip {...chipProps} onClick={openDialog} />
      <Dialog onClose={closeDialog} open={state.dialogOpen}>
        <div className={classes.dialogRoot}>
          <Typography variant="overline">{dialogTitle}</Typography>
          <Typography>{dialogContent}</Typography>
        </div>
      </Dialog>
    </>
  );
};
