/* eslint-disable @typescript-eslint/no-explicit-any */
import React from 'react';
import parse from 'html-react-parser';

import {
  makeStyles, Theme, createStyles, Grid, Typography, Box, FormControl, TextField,
} from '@material-ui/core';
import { FormikConfig, useFormik } from 'formik';
import { useSnackbar } from 'notistack';
import Resource from '../../../interfaces/ResourceManagement/Resource';
import Dropdown from '../../Shared/Dropdown';
import SingleCheckbox from '../../molecules/SingleCheckbox';
import { useTypedSelector } from '../../../store/store';
import RepeatableTextInputField from '../../molecules/RepeatableTextInputField';
import BroadAndNarrowSubjects from '../../molecules/MediaIndexer/BroadAndNarrowSubjects';
import * as Constants from '../../../constants/ResourceConstants';
import GeolocationsTypedown from '../../molecules/MediaIndexer/GeolocationsTypedown';
import TermsTypedown from '../../molecules/MediaIndexer/TermsTypedown';
import Identifiers from '../../molecules/MediaIndexer/Identifiers';
import ArtifactType from '../../../interfaces/enums/ArtifactType';
import Typedown from '../Typedown';
import FastTextField from '../../molecules/FastTextField';
import DocumentFastNode from '../../../interfaces/MediaIndexer/DocumentFastNode';
import DocumentNodeStateEnum from '../../../interfaces/MediaIndexer/DocumentNodeStateEnum';
import DocumentItemNode from '../../../interfaces/MediaIndexer/DocumentItemNode';
import DocumentBroadSubject from '../../../interfaces/MediaIndexer/DocumentBroadSubject';
import CheckboxGroup from '../Forms/CheckboxGroup';
import ResourceTypesDropdown from '../TextIndexer/ResourceTypesDropdown';
import ResourceTypesHelper from '../../../utils/ConvertResourceTypesHelper';
import TypedownAsync from '../TypedownAsync';
import ConfirmationDialog from '../../molecules/ConfirmationDialog';
import ReadOnlyTextField from '../../Shared/ReadOnlyTextField';
import TextInputField from '../../Shared/TextInputField';
import DateExtensions from '../../../utils/DateExtensions';
import Dropzone from './Dropzone';
import RejectedFile from '../../../interfaces/TextIndexer/RejectedFile';

function useFormikTyped(config: FormikConfig<Resource>) {
  return useFormik<Resource>(config);
}

const convertToDocumentFastNode = (data: {Key: number; Value: string}[]): DocumentFastNode[] => data.map((x): DocumentFastNode => ({
  id: x.Key,
  createdBy: '',
  createdDate: '',
  isNew: true,
  name: x.Value,
  state: DocumentNodeStateEnum.UserAdded,
}));

const convertToDocumentItemNode = (data: {Key: number; Value: string}[]): DocumentItemNode[] => data.map((x): DocumentItemNode => ({
  id: x.Key,
  createdBy: '',
  createdDate: '',
  name: x.Value,
}));

const convertFromDocumentNode = (data: DocumentItemNode[]): {key: number; value: string}[] => data.map((x) => ({
  key: x.id,
  value: x.name,
}));

const translateBroadSubjects = (data: number[], lookup: DocumentBroadSubject[]) => lookup.filter((x) => data.includes(x.broadSubjectID)).map((x) => ({
  Key: x.broadSubjectID, Value: x.name,
}));

const translateNarrowSubjects = (data: number[], lookup: DocumentBroadSubject[]) => {
  const results: {Key: number; Value: string}[] = [];

  lookup.forEach((b) => b.narrowSubjects.forEach((n) => {
    if (data.includes(n.Key)) {
      results.push(n);
    }
  }));
  return results;
};

export type RootResourceFormik = ReturnType<typeof useFormikTyped>;

interface RootResourceFormState {
  openConfirmDialog: boolean;
  propertyName: string;
  dateOrig: string | null;
  dateNew: string | null;
}

const FilterableItem = (props: React.PropsWithChildren<{filterValue: string; showValues: string[]}>) => {
  let show = false;
  const filterValueUpper = props.filterValue.toLocaleUpperCase().replace(/ /g, '');
  props.showValues.forEach((element) => {
    if (element.toLocaleUpperCase().indexOf(filterValueUpper) > -1) {
      show = true;
    }
  });
  if (!show) {
    return null;
  }
  return (<>{props?.children}</>);
};

const FormGroup = (props: React.PropsWithChildren<{groupName: string; isFirst?: boolean}>) => {
  const useStyles = makeStyles((theme: Theme) => createStyles({
    groupingTitle: {
      borderRight: 'solid 2px #e6e6e6',
      borderTop: () => (!props.isFirst ? 'solid 2px #e6e6e6' : 'none'),
      textAlign: 'right',
      paddingTop: theme.spacing(2),
      paddingRight: theme.spacing(2),

    },
    formPanel: {
      padding: theme.spacing(2),
    },
    sticky: {
      position: 'sticky',
      top: 10,
    },
  }));
  const classes = useStyles();

  return (
    <Grid container>
      <Grid item xs={2} className={classes.groupingTitle}>
        <div className={classes.sticky}>
          <Typography variant="overline">{props.groupName}</Typography>
        </div>
      </Grid>
      <Grid item xs={10} className={classes.formPanel}>
        {props.children}
      </Grid>
    </Grid>
  );
};

const RootResourceForm = (props: {
    formik: RootResourceFormik;
    filterValue: string;
    onFileDrop(acceptedFiles: File[], rejectedFiles: RejectedFile[]): void;
}) => {
  const useStyles = makeStyles((theme: Theme) => createStyles({
    '@global': {
      input: { display: 'block' },
      '.MuiTextField-root': {
        display: 'block',
      },
      '.MuiInputBase-root': {
        width: '100%',
      },
      '.MuiOutlinedInput-input': {
        padding: '10px 14px',
        fontSize: '0.8rem',
      },
      '.MuiOutlinedInput-multiline': {
        padding: '0px',
        fontSize: '0.8rem',
      },
      '.MuiChip-label': {
        fontSize: '0.7rem',
      },
      '.MuiChip-root': {
        height: 24,
      },
      '.MuiChip-deleteIcon': {
        height: 16,
      },
      '.MuiFormControl-marginNormal': {
        marginTop: 12,
        marginBottom: 0,
      },
      '.MuiAutocomplete-inputRoot[class*="MuiOutlinedInput-root"] .MuiAutocomplete-input': {
        padding: '3px 0',
      },
      '.MuiInputLabel-outlined': {
        transform: 'translate(14px, 14px) scale(1)',
        fontSize: '0.8rem',
      },
      '.MuiOutlinedInput-root legend': {
        fontSize: '0.6rem',
      },
    },
    formField: {
      marginBottom: theme.spacing(2),
      display: 'block',
    },
  }));

  const [state, setState] = React.useState<RootResourceFormState>({
    openConfirmDialog: false,
    propertyName: '',
    dateOrig: props.formik.values.contractEndDate ?? '',
    dateNew: '',
  });
  const referenceData = useTypedSelector((store) => store.ResourceReferenceData.ResourceReferenceData);
  const snackbar = useSnackbar();
  const classes = useStyles();

  // Show/hide controls depend on content type value
  const DisplayItem = (childprops: React.PropsWithChildren<{ controlName: string; controlValue: string[] }>) => {
    let show = false;
    const contentTypevalue = referenceData.contentType.find((lo) => lo.key === props.formik.values.contentTypeId)?.value;
    childprops.controlValue.forEach((element) => {
      if (element.toLocaleUpperCase() === contentTypevalue?.toLocaleUpperCase()) {
        show = true;
      }
    });

    if (!show) {
      return null;
    }
    return (<>{childprops?.children}</>);
  };

  return (
    <form>
      <FormGroup groupName="Image Cover">
        <Box width={3 / 12} m="auto">
          <Dropzone onFileDrop={props.onFileDrop} disabled={false} />
        </Box>

      </FormGroup>
      <FormGroup groupName="Description" isFirst>

        { /* T_001 Resource ID */}
        <Box width={3 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['resourcename']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Resource ID"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.resourceName}
              name="resourceName"
            />
          </FilterableItem>
        </Box>
        { /* T_011 Content Type */}
        <Box width={3 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['contenttype']}>
            <div className={classes.formField}>
              <Dropdown
                id="contentTypeId"
                keyName="contentTypeId"
                options={referenceData.contentType.map((o) => ({
                  display:
                                  o.value,
                  value: o.key,
                }))}
                selectedOption={props.formik.values.contentTypeId ?? null}
                labelText="Content Type"
                onChangeFunction={(key: string, value: string) => props.formik.setFieldValue('contentTypeId',
                  value,
                  true)}
                error={!!props.formik.errors.contentTypeId}
                errorMessage={props.formik.errors.contentTypeId}
                isReadOnly={(props.formik.initialValues.contentTypeId ?? 0) > 0}
              />
            </div>
          </FilterableItem>
        </Box>

        { /* T_012 Resource Type */}
        <Box width={3 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['resourcetype']}>

            <div className={classes.formField}>
              <ResourceTypesDropdown
                labelText="Resource Type"
                options={ResourceTypesHelper.ConvertResourceTypes(referenceData.resourceTypes)}
                id="ResourceType"
                selectedOption={props.formik.values.resourceTypeId}
                keyName="resourceType"
                onChangeFunction={(_,
                  id) => props.formik.setFieldValue('resourceTypeId', id)}
                error={!!props.formik.errors.resourceTypeId}
                errorMessage={props.formik.errors.resourceTypeId}
              />
            </div>
          </FilterableItem>
        </Box>

        { /* T_013 Title Leading Article */}
        <Box width={3 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['titleleadingarticle']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Title Leading Article"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.titleLeadingArticle}
              name="titleLeadingArticle"
            />
          </FilterableItem>
        </Box>

        { /* T_103 Title */}
        <Box width={8 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['title']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Title"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.resourceTitle}
              name="resourceTitle"
              helperText={props.formik.errors.resourceTitle}
              error={!!props.formik.errors.resourceTitle}
            />
          </FilterableItem>
        </Box>

        { /* T_014 Subtitle */}
        <Box width={8 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['subtitle']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Subtitle"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.resourceSubtitle}
              name="resourceSubtitle"
              helperText={props.formik.errors.resourceSubtitle}
              error={!!props.formik.errors.resourceSubtitle}
            />
          </FilterableItem>
        </Box>

        { /* T_077 Alternative Title */}
        <Box width={8 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['alternativetitle']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Aternative Title"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.resourceAlternativeTitle}
              name="resourceAlternativeTitle"
            />
          </FilterableItem>
        </Box>

        { /* T_078 Uniform Title */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['uniformtitle']}>
            <div className={classes.formField}>
              <Typedown
                options={referenceData.uniformTitles.map((x) => ({ id: x.Key, value: x.Value }))}
                selectedValue={props.formik.values.uniformTitleID ? {
                  id: props.formik.values.uniformTitleID,
                  value: referenceData.uniformTitles.find((x) => x.Key === props.formik.values.uniformTitleID)?.Value
                                      ?? '',
                } : null}
                onChange={(data) => props.formik.setFieldValue('uniformTitleID', data.id)}
                label="Uniform Title"
                error={!!props.formik.errors.uniformTitleID}
                errorMessage={props.formik.errors.uniformTitleID}
              />
            </div>
          </FilterableItem>
        </Box>

        { /* T_007 ISBN */}
        <Box width={3 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['isbn']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="ISBN"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.isbn}
              name="isbn"
              helperText={props.formik.errors.isbn}
              error={!!props.formik.errors.isbn}
            />
          </FilterableItem>
        </Box>
        { /* T_008 eISBN */}
        <Box width={3 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['eisbn']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="eISBN"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.eIsbn}
              name="eIsbn"
              helperText={props.formik.errors.eIsbn}
              error={!!props.formik.errors.eIsbn}
            />
          </FilterableItem>
        </Box>
        { /* T_009 ISSN */}
        <Box width={3 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['issn']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="ISSN"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.issn}
              name="issn"
              helperText={props.formik.errors.issn}
              error={!!props.formik.errors.issn}
            />
          </FilterableItem>
        </Box>

        { /* T_010 eISSN */}
        <Box width={3 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['eissn']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="eISSN"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.eIssn}
              name="eIssn"
              helperText={props.formik.errors.eIssn}
              error={!!props.formik.errors.eIssn}
            />
          </FilterableItem>
        </Box>
        { /* T_071 Previous ISSN */}
        <Box width={1}>
          <DisplayItem controlName="prevIssn" controlValue={['Journal']}>
            <FilterableItem filterValue={props.filterValue} showValues={['previousissn', 'previssn']}>
              <FastTextField
                className={classes.formField}
                variant="outlined"
                label="Previous ISSN"
                onUpdate={props.formik.setFieldValue}
                defaultValue={props.formik.values.prevIssn}
                name="prevIssn"
              />
            </FilterableItem>
          </DisplayItem>
        </Box>
        { /* T_064 Later ISSN */}
        <Box width={1}>
          <DisplayItem controlName="laterIssn" controlValue={['Journal']}>
            <FilterableItem filterValue={props.filterValue} showValues={['laterissn']}>
              <FastTextField
                className={classes.formField}
                variant="outlined"
                label="Later ISSN"
                onUpdate={props.formik.setFieldValue}
                defaultValue={props.formik.values.laterIssn}
                name="laterIssn"
              />
            </FilterableItem>
          </DisplayItem>
        </Box>
        { /* T_066 Frequency */}
        <Box width={3 / 12}>
          <DisplayItem controlName="frequencyId" controlValue={['Report', 'Conference', 'Journal']}>
            <FilterableItem filterValue={props.filterValue} showValues={['frequency']}>
              <div className={classes.formField}>
                <Dropdown
                  id="frequencyId"
                  keyName="frequencyId"
                  options={referenceData.frequency.map((o) => ({
                    display:
                                  o.Value,
                    value: o.Key,
                  }))}
                  selectedOption={props.formik.values.frequencyId ?? null}
                  labelText="Frequency"
                  onChangeFunction={(key: string, value: string) => props.formik.setFieldValue('frequencyId', value,
                    true)}
                  helperText={props.formik.errors.frequencyId}
                  error={!!props.formik.errors.frequencyId}
                />
              </div>
            </FilterableItem>
          </DisplayItem>
        </Box>
        { /* Life Start Date T_072 */}
        <Box width={3 / 12}>
          <DisplayItem controlName="lifeStartDate" controlValue={['Report', 'Conference', 'Journal']}>
            <FilterableItem filterValue={props.filterValue} showValues={['lifestartdate']}>
              <FastTextField
                className={classes.formField}
                variant="outlined"
                label="Life Start Date"
                type="number"
                maxLength={4}
                onUpdate={props.formik.setFieldValue}
                defaultValue={props.formik.values.lifeStartDate}
                name="lifeStartDate"
                helperText={props.formik.errors.lifeStartDate}
                error={!!props.formik.errors.lifeStartDate}
              />
            </FilterableItem>
          </DisplayItem>
        </Box>
        { /* Life End Date T_067 */}
        <Box width={3 / 12}>
          <DisplayItem controlName="lifeEndDate" controlValue={['Journal']}>
            <FilterableItem filterValue={props.filterValue} showValues={['lifeenddate']}>
              <FastTextField
                className={classes.formField}
                variant="outlined"
                label="Life End Date"
                type="number"
                maxLength={4}
                onUpdate={props.formik.setFieldValue}
                defaultValue={props.formik.values.lifeEndDate}
                name="lifeEndDate"
                helperText={props.formik.errors.lifeEndDate}
                error={!!props.formik.errors.lifeEndDate}
              />
            </FilterableItem>
          </DisplayItem>
        </Box>

        { /* T_021 Date of Publication */}
        <Box width={3 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['dateofpublication']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Date of Publication"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.dateOfPublication}
              name="dateOfPublication"
              helperText={props.formik.errors.dateOfPublication}
              error={!!props.formik.errors.dateOfPublication}
            />
          </FilterableItem>
        </Box>
        { /* T_006 Publication Year */}
        <Box width={3 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['publicationyear']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Publication Year"
              onUpdate={props.formik.setFieldValue}
              value={props.formik.values.publicationYear}
              name="publicationYear"
              error={!!props.formik.errors.publicationYear}
              helperText={props.formik.errors.publicationYear}
            />
          </FilterableItem>
        </Box>

        { /* T_015 Edition */}
        <Box width={3 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['edition']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Edition"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.edition}
              name="edition"
              helperText={props.formik.errors.edition}
              error={!!props.formik.errors.edition}
            />
          </FilterableItem>
        </Box>

        { /* T_044 Notes */}
        <Box width={9 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['notes']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Notes"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.notes}
              name="notes"
              multiline
              rows={3}
              helperText={props.formik.errors.notes}
              error={!!props.formik.errors.notes}
            />
          </FilterableItem>
        </Box>
        { /* T_037 Extent */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['extent']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Extent"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.extent}
              name="extent"
              helperText={props.formik.errors.extent}
              error={!!props.formik.errors.extent}
            />
          </FilterableItem>
        </Box>

        { /* T_047 Description */}
        <Box width={9 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['description']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Description"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.description}
              name="description"
              multiline
              rows={3}
              helperText={props.formik.errors.description}
              error={!!props.formik.errors.description}
            />
          </FilterableItem>
        </Box>
        { /* T_048 Description Type */}
        <Box width={3 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['descriptiontype']}>
            <div className={classes.formField}>
              <Dropdown
                id="descriptionTypeId"
                keyName="descriptionTypeId"
                labelText="Description Type"
                options={referenceData.descriptionType.map((o) => ({ display: o.Value, value: o.Key }))}
                selectedOption={props.formik.values.descriptionTypeId ?? null}
                onChangeFunction={(key: string, value: string) => props.formik.setFieldValue('descriptionTypeId',
                  value,
                  true)}
                helperText={props.formik.errors.descriptionTypeId}
                error={!!props.formik.errors.descriptionTypeId}
              />
            </div>
          </FilterableItem>
        </Box>

        { /* T_049 Language */}
        <Box width={4 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['language']}>
            <div className={classes.formField}>
              <Typedown
                options={referenceData.languages.map((x) => ({ id: x.Key, value: x.Value }))}
                selectedOptions={props.formik.values.resourceLanguage.map(
                  (x) => ({
                    id: x,
                    value: referenceData.languages.find(
                      (y) => x === y.Key,
                    )?.Value ?? '',
                  }),
                )}
                allowMultiple
                onChangeMultiple={(data) => props.formik.setFieldValue('resourceLanguage', data.map((x) => x.id))}
                label="Language"
                error={!!props.formik.errors.resourceLanguage}
                errorMessage={props.formik.errors.resourceLanguage}
              />
            </div>
          </FilterableItem>
        </Box>

        { /* T_058 Peer Reviewed Indicator */}
        <Box width={1}>
          <FilterableItem filterValue={props.filterValue} showValues={['peerreviewed']}>
            <SingleCheckbox
              label="Peer Reviewed"
              checked={props.formik.values.peerReviewed ?? false}
              onChange={() => props.formik.setFieldValue('peerReviewed', !props.formik.values.peerReviewed, true)}
              onBlur={() => undefined}
              keyName="peerReviewed"
              className={classes.formField}
              error={!!props.formik.errors.peerReviewed}
              helperText={props.formik.errors.peerReviewed}
            />
          </FilterableItem>
        </Box>
      </FormGroup>

      <FormGroup groupName="Publisher">

        { /* T_019 Publisher Name of Publisher */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['nameofpublisher']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Name of Publisher"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.nameOfPublisher}
              name="nameOfPublisher"
            />
          </FilterableItem>
        </Box>

        { /* T_020 Publisher Display */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['publisherdisplayname']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Publisher Display Name"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.nameOfPublisherDisplay}
              name="nameOfPublisherDisplay"
              helperText={props.formik.errors.nameOfPublisherDisplay}
              error={!!props.formik.errors.nameOfPublisherDisplay}
            />
          </FilterableItem>
        </Box>

        { /* T_018 Place of Publication */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['placeofpublication']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Place of Publication"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.placeOfPublication}
              name="placeOfPublication"
              helperText={props.formik.errors.placeOfPublication}
              error={!!props.formik.errors.placeOfPublication}
            />
          </FilterableItem>
        </Box>

        { /* Country of Publication (MARC code) T_106 */}
        <Box width={3 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['countryofpublicationmarc']}>
            <div className={classes.formField}>
              <Dropdown
                id="countryOfPublicationMarc"
                keyName="countryOfPublicationMarc"
                labelText="Country of Publication (MARC code)"
                // eslint-disable-next-line max-len
                options={referenceData.countryOfPublicationMarc.map((o) => ({ display: parse(`<span style="color:blue">${o.key}</span> ${o.value}`), value: o.key }))}
                selectedOption={props.formik.values.countryOfPublicationMarc ?? null}
                onChangeFunction={(key: string, value: string) => props.formik.setFieldValue('countryOfPublicationMarc',
                  value,
                  true)}
                helperText={props.formik.errors.countryOfPublicationMarc}
                error={!!props.formik.errors.countryOfPublicationMarc}
              />
            </div>
          </FilterableItem>
        </Box>
      </FormGroup>

      <FormGroup groupName="Extra Description">
        { /* T_104 DOI */}
        <Box width={4 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['digitalobjectidentifier', 'doi']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Digital Object Identifier (DOI)"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.doi}
              name="doi"
              helperText={props.formik.errors.doi}
              error={!!props.formik.errors.doi}
            />
          </FilterableItem>
        </Box>

        { /* T_057 Persistent Identifier */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['persistentidentifier']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Persistent Identifier"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.persistentIdentifier}
              name="persistentIdentifier"
              helperText={props.formik.errors.persistentIdentifier}
              error={!!props.formik.errors.persistentIdentifier}
            />
          </FilterableItem>
        </Box>

        { /* T_056 Uniform Resource Identifier */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['uri', 'url']}>
            <RepeatableTextInputField
              labelText="URIs"
              addedItems={props.formik.values.urLs}
              keyName="urLs"
              onChangeFunction={(key, value) => props.formik.setFieldValue(key, value)}
              onBlur={props.formik.handleBlur}
              className={classes.formField}
            />
          </FilterableItem>
        </Box>
        <DisplayItem controlName="conferenceInfo" controlValue={['Conference']}>
          <div className={classes.formField}>(Conference Info T_027)</div>

          { /* T_028 Conference Date */}
          <Box width={1}>
            <FilterableItem filterValue={props.filterValue} showValues={['conferencedate']}>
              <FastTextField
                className={classes.formField}
                variant="outlined"
                label="Conference Date"
                onUpdate={props.formik.setFieldValue}
                defaultValue={props.formik.values.dateOfConference}
                name="dateOfConference"
              />
            </FilterableItem>
          </Box>
          { /* T_029 Conference Name */}
          <Box width={1}>
            <FilterableItem filterValue={props.filterValue} showValues={['conferencename']}>
              <FastTextField
                className={classes.formField}
                variant="outlined"
                label="Conference Name"
                onUpdate={props.formik.setFieldValue}
                defaultValue={props.formik.values.nameOfConference}
                name="nameOfConference"
              />
            </FilterableItem>
          </Box>
          { /* T_030 Conference Number */}
          <Box width={1}>
            <FilterableItem filterValue={props.filterValue} showValues={['conferencenumber']}>
              <FastTextField
                className={classes.formField}
                variant="outlined"
                label="Conference Number"
                onUpdate={props.formik.setFieldValue}
                defaultValue={props.formik.values.numberOfConference}
                name="numberOfConference"
              />
            </FilterableItem>
          </Box>
          { /* T_031 Conference Location */}
          <Box width={1}>
            <FilterableItem filterValue={props.filterValue} showValues={['conferencelocation']}>
              <FastTextField
                className={classes.formField}
                variant="outlined"
                label="Conference Location"
                onUpdate={props.formik.setFieldValue}
                defaultValue={props.formik.values.placeOfConference}
                name="placeOfConference"
              />
            </FilterableItem>
          </Box>
          { /* T_032 Conference Sponsor */}
          <Box width={1}>
            <FilterableItem filterValue={props.filterValue} showValues={['conferencesponsor']}>
              <FastTextField
                className={classes.formField}
                variant="outlined"
                label="Conference Sponsor"
                onUpdate={props.formik.setFieldValue}
                value={props.formik.values.sponsorOfConference}
                name="sponsorOfConference"
              />
            </FilterableItem>
          </Box>
          { /* T_033 Conference Theme */}
          <Box width={1}>
            <FilterableItem filterValue={props.filterValue} showValues={['conferencetheme']}>
              <FastTextField
                className={classes.formField}
                variant="outlined"
                label="Conference Theme"
                onUpdate={props.formik.setFieldValue}
                defaultValue={props.formik.values.themeOfConference}
                name="themeOfConference"
              />
            </FilterableItem>
          </Box>
        </DisplayItem>
        { /* T_041 Series title */}
        <Box width={4 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['seriestitle']}>
            <div className={classes.formField}>
              <Dropdown
                id="seriesTitleID"
                keyName="seriesTitleID"
                labelText="Series Title"
                options={referenceData.seriesTitles.map((o) => ({ display: o.value, value: o.key }))}
                selectedOption={props.formik.values.seriesTitleID ?? null}
                onChangeFunction={(key: string, value: string) => props.formik.setFieldValue('seriesTitleID', value,
                  true)}
                helperText={props.formik.errors.seriesTitleID}
                error={!!props.formik.errors.seriesTitleID}
              />
            </div>
          </FilterableItem>
        </Box>
        { /* T_042 Series Volume */}
        <Box width={4 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['series volume']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Series Volume"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.seriesVolume}
              name="seriesVolume"
              helperText={props.formik.errors.seriesVolume}
              error={!!props.formik.errors.seriesVolume}
            />
          </FilterableItem>
        </Box>
        { /* T_043 Series ISSN */}
        <Box width={4 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['series issn']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Series ISSN"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.seriesIssn}
              name="seriesIssn"
              helperText={props.formik.errors.seriesIssn}
              error={!!props.formik.errors.seriesIssn}
            />
          </FilterableItem>
        </Box>
      </FormGroup>

      <FormGroup groupName="Subjects">

        { /* T_050 Broad Subject Category */}
        { /* T_051 Narrow Subject Category */}
        <Box width={1}>
          <FilterableItem
            filterValue={props.filterValue}
            showValues={['broadsubjects', 'narrowsubjects',
              'broadandnarrowsubjects']}
          >
            <BroadAndNarrowSubjects
              broadSubjectLookup={referenceData.broadSubjectLookup}
              selectedBroadSubjects={convertToDocumentItemNode(translateBroadSubjects(props.formik.values.resourceBroadSubject, referenceData.broadSubjectLookup))}
              selectedNarrowSubjects={convertToDocumentItemNode(translateNarrowSubjects(props.formik.values.resourceNarrowSubject, referenceData.broadSubjectLookup))}
              broadSubjectKey="resourceBroadSubject"
              narrowSubjectKey="resourceNarrowSubject"
              onChangeBroadSubjectFunction={(valueList: { id: unknown }[]) => props.formik.setFieldValue('resourceBroadSubject',
                valueList.map((x: { id: unknown }) => x.id))}
              onChangeNarrowSubjectFunction={(valueList: { id: unknown }[]) => props.formik.setFieldValue('resourceNarrowSubject',
                valueList.map((x: { id: unknown }) => x.id))}
              broadSubjectError={!!(props.formik.errors.resourceBroadSubject)}
              broadSubjectErrorText={props.formik.errors.resourceBroadSubject as string}
              narrowSubjectError={!!(props.formik.errors.resourceNarrowSubject)}
              narrowSubjectErrorText={props.formik.errors.resourceNarrowSubject as string}
              broadSubjectTypedownLimit={Constants.BroadSubjectTypedownLimit}
              narrowSubjectTypedownLimit={Constants.NarrowSubjectTypedownLimit}
            />
          </FilterableItem>
        </Box>

        { /* T_052 FAST Terms */}
        <Box width={1}>
          <FilterableItem filterValue={props.filterValue} showValues={['fastterms']}>
            <TermsTypedown
              selectedTerms={convertToDocumentFastNode(props.formik.values.resourceFast)}
              topicSuggestions={[]}
              keyName="resourceFast"
              // eslint-disable-next-line max-len
              onChangeFunction={(key: string, value: { id: number; name: string; createdBy: string; createdDate: string }[]) => props.formik.setFieldValue(key,
                convertFromDocumentNode(value))}
              fastAndIdentifierCount={props.formik.values.resourceFast.length}
              fastAndIdentifierLimit={Constants.FastAndIndentifiersTypedownLimit}
              artifactTypeId={ArtifactType.Text}
              error={!!props.formik.errors.resourceFast}
              errorText={props.formik.errors.resourceFast as string}
            />
          </FilterableItem>
        </Box>

        { /* T_053 SubjectLC */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['subjectlc', 'subjectslc']}>
            <FormControl margin="normal">
              <TypedownAsync
                label="Subject LC"
                key="resourceSubjectLc"
                url={`${process.env.REACT_APP_API_URL}/api/indexing/searchsubjectlc`}
                selectedOptions={props.formik.values.resourceSubjectLc.map((subject) => ({
                  id: subject.Key,
                  value:
                                      subject.Value,
                }))}
                allowMultiple
                errorMessage={props.formik.errors.resourceSubjectLc as string}
                error={!!props.formik.errors.resourceSubjectLc}
                onChangeMultiple={(data) => props.formik.setFieldValue('resourceSubjectLc', data.map((d) => ({
                  key:
                                      d.id,
                  value: d.value,
                })), true)}
              />
            </FormControl>
          </FilterableItem>
        </Box>

        { /* T_054 FAST Geolocation */}
        <Box width={1}>
          <FilterableItem filterValue={props.filterValue} showValues={['fastgeolocation']}>
            <GeolocationsTypedown
              selectedGeolocations={convertToDocumentFastNode(props.formik.values.resourceFastGeo)}
              locationSuggestions={[]}
              keyName="resourceFastGeo"
              // eslint-disable-next-line max-len
              onChangeFunction={(key: string, value:
              // eslint-disable-next-line max-len
              { id: number; name: string; createdBy: string; createdDate: string }[]) => props.formik.setFieldValue(key, convertFromDocumentNode(value))}
              typedownLimit={Constants.GeolocationsTypedownLimit}
              artifactTypeId={ArtifactType.Text}
              error={!!props.formik.errors.resourceFastGeo}
              errorText={props.formik.errors.resourceFastGeo as string}
            />
          </FilterableItem>
        </Box>

        { /* T_055 Identifiers */}
        <Box width={1}>
          <FilterableItem filterValue={props.filterValue} showValues={['identifiers']}>
            <Identifiers
              selectedIdentifiers={convertToDocumentItemNode(props.formik.values.resourceIdentifier)}
              keyName="resourceIdentifier"
              // eslint-disable-next-line max-len
              onChangeFunction={(key: string, value: { id: number; name: string; createdBy: string; createdDate: string }[]) => props.formik.setFieldValue(key,
                convertFromDocumentNode(value))}
              fastAndIdentifierCount={props.formik.values.resourceIdentifier.length}
              fastAndIdentifierLimit={Constants.FastAndIndentifiersTypedownLimit}
              error={!!props.formik.errors.resourceIdentifier}
              errorText={props.formik.errors.resourceIdentifier as string}
              errorSnackbarFunction={(error: React.ReactNode) => snackbar.enqueueSnackbar(error, { variant: 'error' })}
              artifactType={ArtifactType.Text}
            />
          </FilterableItem>
        </Box>

      </FormGroup>

      <FormGroup groupName="Management">
        { /* T_073 Product */}
        <Box width={4 / 12}>
          <DisplayItem controlName="resourceProductCode" controlValue={['Journal']}>
            <FilterableItem filterValue={props.filterValue} showValues={['productLibrary']}>
              <div className={classes.formField}>
                <Typedown
                  options={referenceData.productLibrary.map((x) => ({ id: x.key, value: x.value }))}
                  selectedOptions={props.formik.values.resourceProductCode.map(
                    (x) => ({
                      id: x,
                      value: referenceData.productLibrary.find(
                        (y) => x === y.key,
                      )?.value ?? '',
                    }),
                  )}
                  allowMultiple
                  onChangeMultiple={(data) => props.formik.setFieldValue('resourceProductCode', data.map((x) => x.id))}
                  label="Product"
                  error={!!props.formik.errors.resourceProductCode}
                  errorMessage={props.formik.errors.resourceProductCode}
                />
              </div>
            </FilterableItem>
          </DisplayItem>
        </Box>
        { /* T_068 Management Notes */}
        <Box width={9 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['managementNotes']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Management Notes"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.managementNotes}
              name="managementNotes"
              multiline
              rows={3}
              helperText={props.formik.errors.managementNotes}
              error={!!props.formik.errors.managementNotes}
            />
          </FilterableItem>
        </Box>

        { /* T_080 Resource Manager */}
        <Box width={4 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['resourcemanager']}>
            <div className={classes.formField}>
              <Dropdown
                id="resourceManagerId"
                keyName="resourceManagerId"
                options={referenceData.resourceManager.map((o) => ({ display: o.Value, value: o.Key }))}
                selectedOption={props.formik.values.resourceManagerId ?? null}
                labelText="Resource Manager"
                onChangeFunction={(key: string, value: string) => props.formik.setFieldValue('resourceManagerId',
                  value,
                  true)}
              />
            </div>
          </FilterableItem>
        </Box>

        { /* T_110 Title Website */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['website']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Website"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.website}
              name="website"
              helperText={props.formik.errors.website}
              error={!!props.formik.errors.website}
            />
          </FilterableItem>
        </Box>

        { /* T_083 Title Indexing Status */}
        <Box width={4 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['resourceWorkflowStates']}>
            <div className={classes.formField}>
              <Dropdown
                id="titleIndexingStatusId"
                keyName="titleIndexingStatusId"
                options={referenceData.resourceWorkflowStates.map((o) => ({ display: o.Value, value: o.Key }))}
                selectedOption={props.formik.values.titleIndexingStatusId ?? null}
                labelText="Title Indexing Status"
                onChangeFunction={(key: string, value: string) => props.formik.setFieldValue('titleIndexingStatusId',
                  value,
                  true)}
              />
            </div>
          </FilterableItem>
        </Box>

        { /* T_079 Publish Title */}
        <Box width={1}>
          <FilterableItem filterValue={props.filterValue} showValues={['publishResource', 'publishResource']}>
            <SingleCheckbox
              label="Publish Resource"
              checked={props.formik.values.publishResource ?? false}
              onChange={() => props.formik.setFieldValue('publishResource', !props.formik.values.publishResource, true)}
              onBlur={() => undefined}
              keyName="publishResource"
              className={classes.formField}
              error={!!props.formik.errors.publishResource}
              helperText={props.formik.errors.publishResource}
            />
          </FilterableItem>

        </Box>

        { /* T_111 Active */}
        <Box width={1}>
          <FilterableItem filterValue={props.filterValue} showValues={['active']}>
            <SingleCheckbox
              label="Active"
              checked={props.formik.values.active ?? false}
              onChange={() => props.formik.setFieldValue('active', !props.formik.values.active, true)}
              onBlur={() => undefined}
              keyName="active"
              className={classes.formField}
              error={!!props.formik.errors.active}
              helperText={props.formik.errors.active}
            />
          </FilterableItem>
        </Box>

        { /* T_074 Currently Comprehensive Journal */}
        <Box width={1}>
          <DisplayItem controlName="currentlyComprehensive" controlValue={['Journal']}>
            <FilterableItem filterValue={props.filterValue} showValues={['currentlycomprehensivejournal']}>
              <SingleCheckbox
                label="Currently Comprehensive Journal"
                checked={props.formik.values.currentlyComprehensive
                              ?? false}
                onChange={() => props.formik.setFieldValue('currentlyComprehensive',
                  !props.formik.values.currentlyComprehensive, true)}
                onBlur={() => undefined}
                keyName="currentlyComprehensive"
                className={classes.formField}
              />
            </FilterableItem>
          </DisplayItem>
        </Box>

        { /* T_063 Title Workflow Status */}
        <Box width={3 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['indexingtypes']}>
            <div className={classes.formField}>
              <CheckboxGroup
                label="Special Indexing Requirements"
                name="resourceIndexers"
                onChange={(data) => props.formik.setFieldValue('resourceIndexers', data)}
                options={referenceData.resourceIndexes}
                selectedOptions={props.formik.values.resourceIndexers}
              />
            </div>
          </FilterableItem>
        </Box>

        { /* T_069 Indexing Company */}
        <Box width={4 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['indexer', 'indexingcompany']}>
            <div className={classes.formField}>
              <Dropdown
                id="indexingCompanyId"
                keyName="indexingCompanyId"
                options={referenceData.indexingCompany.map((o) => ({ display: o.Value, value: o.Key }))}
                selectedOption={props.formik.values.indexingCompanyId ?? null}
                labelText="Indexing Company"
                onChangeFunction={(key: string, value: string) => props.formik.setFieldValue('indexingCompanyId',
                  value,
                  true)}
                helperText={props.formik.errors.indexingCompanyId}
                error={!!props.formik.errors.indexingCompanyId}
              />
            </div>
          </FilterableItem>
        </Box>

        { /* T_088 Title Type */}
        <Box width={4 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['titletype']}>
            <div className={classes.formField}>
              <Dropdown
                id="titleTypeId"
                keyName="titleTypeId"
                options={referenceData.titleType.map((o) => ({
                  display:
                                  o.value,
                  value: o.key,
                }))}
                selectedOption={props.formik.values.titleTypeId ?? null}
                labelText="Title Type"
                onChangeFunction={(key: string, value: string) => props.formik.setFieldValue('titleTypeId', value,
                  true)}
              />
            </div>
          </FilterableItem>
        </Box>

        { /* T_075 Management Index Type */}
        <Box width={4 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['indexType']}>
            <div className={classes.formField}>
              <Typedown
                options={referenceData.indexType.map((x) => ({ id: x.key, value: x.value }))}
                selectedOptions={props.formik.values.resourceIndexTypeCode.map(
                  (x) => ({
                    id: x,
                    value: referenceData.indexType.find(
                      (y) => x === y.key,
                    )?.value ?? '',
                  }),
                )}
                allowMultiple
                onChangeMultiple={(data) => props.formik.setFieldValue('resourceIndexTypeCode', data.map((x) => x.id))}
                label="Index Type"
                error={!!props.formik.errors.resourceIndexTypeCode}
                errorMessage={props.formik.errors.resourceIndexTypeCode}
              />
            </div>
          </FilterableItem>
        </Box>
        { /* Date Created T_005 */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['datecreated']}>
            <ReadOnlyTextField
              labelText="Date Created"
              displayText={DateExtensions.convertSQLDateToFormFormat(props.formik.values.dateCreated)}
              oneLine
            />
          </FilterableItem>
        </Box>
        { /* Date Last Modified T_004 */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['lastmodified']}>
            <ReadOnlyTextField
              labelText="Date Last Modified"
              displayText={DateExtensions.convertSQLDateToFormFormat(props.formik.values.lastModified)}
              oneLine
            />
          </FilterableItem>
        </Box>
        { /* Live Date T_081 */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['livedate']}>
            <ReadOnlyTextField
              labelText="Live Date"
              displayText={DateExtensions.convertLiveDateTimeToFormFormat(props.formik.values.liveDate)}
              oneLine
            />
          </FilterableItem>
        </Box>
      </FormGroup>

      <FormGroup groupName="Licence">
        <Box width={9 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['ielcopyright']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Copyright Statement"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.ielcopyright}
              name="ielcopyright"
              multiline
              rows={3}
              helperText={props.formik.errors.ielcopyright}
              error={!!props.formik.errors.ielcopyright}
            />
          </FilterableItem>
        </Box>
        {/* Clearance Status L&R_003 */}
        <Box width={4 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['clearanceStatus']}>
            <div className={classes.formField}>
              <Dropdown
                id="clearanceStatusId"
                keyName="clearanceStatusId"
                options={referenceData.clearanceStatus.map((o) => ({ display: o.value, value: o.key }))}
                selectedOption={props.formik.values.clearanceStatusId ?? null}
                labelText="Clearance Status"
                onChangeFunction={(_key: string, value: string) => props.formik.setFieldValue('clearanceStatusId', value,
                  true)}
                helperText={props.formik.errors.clearanceStatusId}
                error={!!props.formik.errors.clearanceStatusId}
              />
            </div>
          </FilterableItem>
        </Box>
        { /* T_045 Access Rights */}
        <Box width={4 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['indexer', 'accessRight']}>
            <div className={classes.formField}>
              <Dropdown
                id="accessRightID"
                keyName="accessRightID"
                options={referenceData.accessRight.map((o) => ({
                  display: o.Value, value: o.Key,
                }))}
                selectedOption={props.formik.values.accessRightID ?? null}
                labelText="Access Rights"
                onChangeFunction={(key: string, value: number) => {
                  props.formik.setFieldValue('accessRightID', value,
                    true);
                  // autoassign Access type value depend on Access rights value
                  const accessType = value === 1 ? 1 : 2;
                  props.formik.setFieldValue('accessTypeId', accessType,
                    true);
                }}
                helperText={props.formik.errors.accessRightID}
                error={!!props.formik.errors.accessRightID}
              />
            </div>
          </FilterableItem>
        </Box>
        {/* Access Type (KBART) L&R_005 */}
        <Box width={4 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['accessType']}>
            <div className={classes.formField}>
              <Dropdown
                id="accessTypeId"
                keyName="accessTypeId"
                options={referenceData.accessType.map((o) => ({ display: o.value, value: o.key }))}
                value={props.formik.values.accessTypeId ?? null}
                onChangeFunction={(key: string, value: string) => {
                  props.formik.setFieldValue('accessTypeId', value,
                    true);
                }}
                labelText="Access type"
                helperText={props.formik.errors.accessTypeId}
                error={!!props.formik.errors.accessTypeId}
                isReadOnly
              />
            </div>
          </FilterableItem>
        </Box>

        { /* Agreement Number L&R_006 */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['agreementNumber']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Agreement Number"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.agreementNumber}
              name="agreementNumber"
              helperText={props.formik.errors.agreementNumber}
              error={!!props.formik.errors.agreementNumber}
            />
          </FilterableItem>
        </Box>
        { /* Perpetual Access L&R_007 */}
        <Box width={1}>
          <FilterableItem filterValue={props.filterValue} showValues={['perpetualaccess']}>
            <SingleCheckbox
              label="Perpetual Access "
              checked={props.formik.values.perpetualAccess
                              ?? false}
              onChange={() => props.formik.setFieldValue('perpetualAccess',
                !props.formik.values.perpetualAccess, true)}
              onBlur={() => undefined}
              keyName="perpetualAccess"
              className={classes.formField}
            />
          </FilterableItem>
        </Box>
        {/* Contract Start Date */}
        <Box width={1 / 2} display="inline-block" className={classes.formField}>
          <TextField
            value={DateExtensions.convertDateToFormFormat(props.formik.values.contractStartDate)}
            label="Contract Start Date"
            name="contractStartDate"
            type="date"
            InputLabelProps={{
              shrink: true,
            }}
            onChange={(e: any) => {
              setState((prevState) => ({
                ...prevState,
                openConfirmDialog: true,
                propertyName: 'contractStartDate',
                dateNew: e.target.value,
              }));
            }}
            error={!!props.formik.errors?.contractStartDate}
            helperText={props.formik.errors?.contractStartDate}
          />
        </Box>
        {/* Contract End Date */}
        <Box width={1 / 2} display="inline-block" className={classes.formField}>
          <TextField
            value={DateExtensions.convertDateToFormFormat(props.formik.values.contractEndDate)}
            label="Contract End Date"
            name="contractEndDate"
            type="date"
            InputLabelProps={{
              shrink: true,
            }}
            onChange={(e: any) => {
              setState((prevState) => ({
                ...prevState,
                openConfirmDialog: true,
                propertyName: 'contractEndDate',
                dateNew: e.target.value,
              }));
            }}
            error={!!props.formik.errors?.contractEndDate}
            helperText={props.formik.errors?.contractEndDate}
          />
        </Box>
        <ConfirmationDialog
          dialogTitle="Change Date"
          dialogBodyText="Are you sure you want to change the date?"
          successButtonText="Yes"
          onReturn={() => {
            if (state.propertyName === 'contractEndDate') props.formik.setFieldValue('contractEndDate', state.dateOrig, false);
            if (state.propertyName === 'contractStartDate') props.formik.setFieldValue('contractStartDate', state.dateOrig, false);
            setState((prevState) => ({
              ...prevState,
              openConfirmDialog: false,
            }));
          }}
          onProceed={() => {
            if (state.propertyName === 'contractEndDate') props.formik.setFieldValue('contractEndDate', state.dateNew, true);
            if (state.propertyName === 'contractStartDate') props.formik.setFieldValue('contractStartDate', state.dateNew, true);
            setState((prevState) => ({
              ...prevState,
              openConfirmDialog: false,
            }));
          }}
          isOpen={state.openConfirmDialog}
        />
        { /* Embargo Period L&R_010 */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['embargoperiod']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              type="number"
              label="Embargo Period"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.embargoPeriod}
              name="embargoPeriod"
              helperText={props.formik.errors.embargoPeriod}
              error={!!props.formik.errors.embargoPeriod}
            />
          </FilterableItem>
        </Box>
        { /* Royalties Due? */}
        <Box width={1}>
          <FilterableItem filterValue={props.filterValue} showValues={['royaltiesdue']}>
            <SingleCheckbox
              label="Royalties Due"
              checked={props.formik.values.royaltiesDue
                              ?? false}
              onChange={() => props.formik.setFieldValue('royaltiesDue',
                !props.formik.values.royaltiesDue, true)}
              onBlur={() => undefined}
              keyName="royaltiesDue"
              className={classes.formField}
            />
          </FilterableItem>
        </Box>
        { /* L&R_012 Royalties Organisation */}
        <Box width={4 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['royaltyOrganisationId']}>
            <div className={classes.formField}>
              <Dropdown
                id="royaltyOrganisationId"
                keyName="royaltyOrganisationId"
                options={referenceData.royaltyOrganisation.map((o) => ({
                  display: o.value, value: o.key,
                }))}
                selectedOption={props.formik.values.royaltyOrganisationId ?? null}
                labelText="Royalty Organisation"
                onChangeFunction={(key: string, value: string) => props.formik.setFieldValue('royaltyOrganisationId', value,
                  true)}
                helperText={props.formik.errors.royaltyOrganisationId}
                error={!!props.formik.errors.royaltyOrganisationId}
              />
            </div>
          </FilterableItem>
        </Box>

        { /* Cleared By L&R_013 */}
        <Box width={4 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['clearedby']}>
            <div className={classes.formField}>
              <Dropdown
                id="clearedById"
                keyName="clearedById"
                options={referenceData.clearedBy.map((o) => ({
                  display: o.value, value: o.key,
                }))}
                selectedOption={props.formik.values.clearedById ?? null}
                labelText="Cleared By"
                onChangeFunction={(key: string, value: string) => props.formik.setFieldValue('clearedById', value,
                  true)}
                helperText={props.formik.errors.clearedById}
                error={!!props.formik.errors.clearedById}
              />
            </div>
          </FilterableItem>
        </Box>
        { /* Royalty Rate L&R_014 */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['royaltyrate']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              type="decimal"
              label="Royalty Rate"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.royaltyRate}
              name="royaltyRate"
              helperText={props.formik.errors.royaltyRate}
              error={!!props.formik.errors.royaltyRate}
            />
          </FilterableItem>
        </Box>
        { /* Archive Royalty Rate L&R_025 */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['archiveroyaltyrate']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              type="decimal"
              label="Archive Royalty Rate"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.archiveRoyaltyRate}
              name="archiveRoyaltyRate"
              helperText={props.formik.errors.archiveRoyaltyRate}
              error={!!props.formik.errors.archiveRoyaltyRate}
            />
          </FilterableItem>
        </Box>
        { /* L&R_015 Management Notes */}
        <Box width={9 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['licenceManagementNotes']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              label="Management Notes"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.licenceManagementNotes}
              name="licenceManagementNotes"
              multiline
              rows={3}
              helperText={props.formik.errors.licenceManagementNotes}
              error={!!props.formik.errors.licenceManagementNotes}
            />
          </FilterableItem>
        </Box>
        { /* Notice Provided Date L&R_016 */}
        <Box width={1 / 2} display="inline-block" className={classes.formField}>
          <TextInputField
            type="date"
            labelText="Notice Provided Date"
            value={DateExtensions.convertDateToFormFormat(props.formik.values.noticeProvidedDate)}
            keyName="noticeProvidedDate"
            onChangeFunction={props.formik.handleChange}
            onBlur={props.formik.handleBlur}
            error={!!props.formik.errors.noticeProvidedDate}
            errorMessage={props.formik.errors.noticeProvidedDate}
            inputText="Date"
          />
        </Box>

        { /* Notice Period L&R_017 */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['noticePeriod']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              type="number"
              label="Notice Period"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.noticePeriod}
              name="noticePeriod"
              helperText={props.formik.errors.noticePeriod}
              error={!!props.formik.errors.noticePeriod}
            />
          </FilterableItem>
        </Box>
        { /* Archive Period Start Date L&R_018 */}
        <Box width={1 / 2} display="inline-block" className={classes.formField}>
          <TextInputField
            type="date"
            labelText="Archive Period Start Date"
            value={DateExtensions.convertDateToFormFormat(props.formik.values.archivePeriodStartDate)}
            keyName="archivePeriodStartDate"
            onChangeFunction={props.formik.handleChange}
            onBlur={props.formik.handleBlur}
            error={!!props.formik.errors.archivePeriodStartDate}
            errorMessage={props.formik.errors.archivePeriodStartDate}
            inputText="Date"
          />
        </Box>
        { /* Archival Period L&R_019 */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['archivalPeriod']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              type="number"
              label="Archival Period"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.archivalPeriod}
              name="archivalPeriod"
              helperText={props.formik.errors.archivalPeriod}
              error={!!props.formik.errors.archivalPeriod}
            />
          </FilterableItem>
        </Box>
        { /* Withdrawal Date L&R_020 */}
        <Box width={1 / 2} display="inline-block" className={classes.formField}>
          <TextInputField
            type="date"
            labelText="Withdrawal Date"
            value={DateExtensions.convertDateToFormFormat(props.formik.values.withdrawalDate)}
            keyName="withdrawalDate"
            onChangeFunction={props.formik.handleChange}
            onBlur={props.formik.handleBlur}
            error={!!props.formik.errors.withdrawalDate}
            errorMessage={props.formik.errors.withdrawalDate}
            inputText="Date"
          />
        </Box>

        <Box width={1}>
          {/* Individual Subscriptions Available */}
          <SingleCheckbox
            label="Individual Subscriptions Available"
            checked={props.formik.values.individualSubscriptions ?? false}
            onChange={() => props.formik.setFieldValue('individualSubscriptions', !props.formik.values.individualSubscriptions, true)}
            keyName="individualSubscriptions"
            onBlur={() => undefined}
            className={classes.formField}
            error={!!props.formik.errors.individualSubscriptions}
            helperText={props.formik.errors.individualSubscriptions}
          />
        </Box>
        {/* Creative Commons License Type */}
        <Box width={4 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['cclicenceType']}>
            <div className={classes.formField}>
              <Dropdown
                id="cclicenceTypeId"
                keyName="cclicenceTypeId"
                options={referenceData.cclicenceType.map((o) => ({ display: o.value, value: o.key }))}
                selectedOption={props.formik.values.cclicenceTypeId ?? null}
                labelText="Creative Commons License Type"
                onChangeFunction={(key: string, value: string) => props.formik.setFieldValue('cclicenceTypeId', value,
                  true)}
                helperText={props.formik.errors.cclicenceTypeId}
                error={!!props.formik.errors.cclicenceTypeId}
              />
            </div>
          </FilterableItem>
        </Box>
        { /* PPV Available? L&R_023 */}
        <Box width={1}>
          <SingleCheckbox
            label="PPV Available?"
            checked={props.formik.values.ppvavailable ?? false}
            onChange={() => props.formik.setFieldValue('ppvavailable', !props.formik.values.ppvavailable, true)}
            onBlur={() => undefined}
            keyName="ppvavailable"
            className={classes.formField}
            error={!!props.formik.errors.ppvavailable}
            helperText={props.formik.errors.ppvavailable}
          />
        </Box>
        { /* Price L&R_024 */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['price']}>
            <FastTextField
              className={classes.formField}
              variant="outlined"
              type="decimal"
              label="Price"
              onUpdate={props.formik.setFieldValue}
              defaultValue={props.formik.values.price}
              name="price"
              helperText={props.formik.errors.price}
              error={!!props.formik.errors.price}
            />
          </FilterableItem>
        </Box>
      </FormGroup>

      <FormGroup groupName="System Admin">

        { /* Title ID T_062 */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['resourceId']}>
            <ReadOnlyTextField
              labelText="Title ID"
              displayText={props.formik.values.resourceId}
              oneLine
            />
          </FilterableItem>
        </Box>

        { /* Record Number T_002 */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['titleDocumentNumber']}>
            <ReadOnlyTextField
              labelText="Record Number"
              displayText={props.formik.values.titleDocumentNumber}
              oneLine
            />
          </FilterableItem>
        </Box>
        { /* Last Revision Date T_003 */}
        <Box width={1 / 2} display="inline-block" className={classes.formField}>
          <TextInputField
            type="date"
            labelText="Last Revision Date"
            value={DateExtensions.convertDateToFormFormat(props.formik.values.lastRevisiondate)}
            keyName="lastRevisionDate"
            onChangeFunction={props.formik.handleChange}
            onBlur={props.formik.handleBlur}
            error={!!props.formik.errors.lastRevisiondate}
            errorMessage={props.formik.errors.lastRevisiondate}
            inputText="Date"
          />
        </Box>

        { /* T_034 Media Type */}
        <Box width={3 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['mediatype']}>
            <div className={classes.formField}>
              <Dropdown
                id="mediaTypeId"
                keyName="mediaTypeId"
                options={referenceData.mediaType.map((o) => ({
                  display:
                                  o.Value,
                  value: o.Key,
                }))}
                selectedOption={props.formik.values.mediaTypeId ?? null}
                labelText="Media Type"
                onChangeFunction={(key: string, value: string) => props.formik.setFieldValue('mediaTypeId', value,
                  true)}
                error={!!props.formik.errors.mediaTypeId}
                errorMessage={props.formik.errors.mediaTypeId}
              />
            </div>
          </FilterableItem>
        </Box>

        { /* Content Source T_059 */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['source']}>
            <ReadOnlyTextField
              labelText="Content Source"
              displayText={props.formik.values.source}
              oneLine
            />
          </FilterableItem>
        </Box>

        { /* Content Import Date T_060 */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['sourceimportdate']}>
            <ReadOnlyTextField
              labelText="Content Import Date"
              displayText={props.formik.values.sourceImportDate}
              oneLine
            />
          </FilterableItem>
        </Box>
        { /* Content DN T_061 */}
        <Box width={6 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['sourcedocumentnumber']}>
            <ReadOnlyTextField
              labelText="Content DN"
              displayText={props.formik.values.sourceDocumentNumber}
              oneLine
            />
          </FilterableItem>
        </Box>

        { /* Title Ready For Metadata T_084 */}
        <Box width={6 / 12}>
          <TextInputField
            type="date"
            labelText="Title Ready For Metadata"
            value={props.formik.values.readyForMetadataDate}
            keyName="readyForMetadataDate"
            onChangeFunction={props.formik.handleChange}
            onBlur={props.formik.handleBlur}
            error={!!props.formik.errors.readyForMetadataDate}
            errorMessage={props.formik.errors.readyForMetadataDate}
            readOnly
          />
        </Box>
        { /* Title Ready For Files T_085 */}
        <Box width={6 / 12}>
          <TextInputField
            type="date"
            labelText="Title Ready For Files"
            value={props.formik.values.readyForFilesDate}
            keyName="readyForFilesDate"
            onChangeFunction={props.formik.handleChange}
            onBlur={props.formik.handleBlur}
            error={!!props.formik.errors.readyForFilesDate}
            errorMessage={props.formik.errors.readyForFilesDate}
            readOnly
          />
        </Box>
        { /* Title Ready For Cataloguing T_086 */}
        <Box width={6 / 12}>
          <TextInputField
            type="date"
            labelText="Title Ready For Cataloguing"
            value={props.formik.values.readyForCataloguingDate}
            keyName="readyForCataloguingDate"
            onChangeFunction={props.formik.handleChange}
            onBlur={props.formik.handleBlur}
            error={!!props.formik.errors.readyForCataloguingDate}
            errorMessage={props.formik.errors.readyForCataloguingDate}
            readOnly
          />
        </Box>
        { /* Title Ready For QA T_087 */}
        <Box width={6 / 12}>
          <DisplayItem controlName="readyForQaDate" controlValue={['Journal']}>
            <TextInputField
              type="date"
              labelText="Title Ready For QA"
              value={props.formik.values.readyForQaDate}
              keyName="readyForQaDate"
              onChangeFunction={props.formik.handleChange}
              onBlur={props.formik.handleBlur}
              error={!!props.formik.errors.readyForQaDate}
              errorMessage={props.formik.errors.readyForQaDate}
              readOnly
            />
          </DisplayItem>
        </Box>

        {/* <div className={classes.formField}>(File Size T_016)</div> */}
        {/* <div className={classes.formField}>(DOI Indicator T_026)</div> */}
        {/* <div className={classes.formField}>(PI Indicator T_022)</div> */}
        {/* <div className={classes.formField}>(URI Indicator T_023)</div> */}
        {/* <div className={classes.formField}>(Is Full Text T_106)</div> */}
        {/* <div className={classes.formField}>(Has Full Text T_107)</div> */}
        <DisplayItem controlName="conferenceInfo" controlValue={['Conference']}>
          <div className={classes.formField}>(Full Text Indicator T_109)</div>
        </DisplayItem>
      </FormGroup>

      <FormGroup groupName="other">

        <Box width={3 / 12}>
          <FilterableItem filterValue={props.filterValue} showValues={['filetype']}>
            <div className={classes.formField}>
              <Dropdown
                id="fileTypeId"
                keyName="fileTypeId"
                options={referenceData.fileType.map((o) => ({
                  display:
                                  o.value,
                  value: o.key,
                }))}
                selectedOption={props.formik.values.fileTypeId ?? null}
                labelText="File Type"
                onChangeFunction={(key: string, value: string) => props.formik.setFieldValue('fileTypeId', value, true)}
                error={!!props.formik.errors.fileTypeId}
                errorMessage={props.formik.errors.fileTypeId}
              />
            </div>
          </FilterableItem>
        </Box>

      </FormGroup>

    </form>
  );
};

export default RootResourceForm;
