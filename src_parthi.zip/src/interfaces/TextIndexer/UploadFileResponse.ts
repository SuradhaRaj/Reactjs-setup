import {
  Record,
  Number,
  String,
  Array,
  Union,
  Literal,
  Undefined,
  Static,
  Null,
} from 'runtypes';

export const UploadFileResponseValidator = Record({
  fileType: Union(
    Literal('pdf'),
    Literal('html'),
  ).Or(Null),
  pageCount: Number,
  status: Number.Or(Undefined),
  messages: Array(String),
});

export type UploadFileResponse = Static<typeof UploadFileResponseValidator>;
