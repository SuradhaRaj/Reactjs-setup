import React from 'react';
import {
  Typography,
  Grid,
  Card,
  makeStyles,

} from '@material-ui/core';

interface State {
  status: Array<string>;
  publisher: Array<string>;
  title: Array<string>;
  grouping: Array<string>;
  manager: Array<string>;
  broadcastdate: Array<string>;

}

export interface SelectedOptionState {
  grouping: string[];
  publisher: string[];
  title: string[];
  id: string[];
  article: string[];
  documentNumber: string[];
  resource: string[];
  hasIndexerNotes?: boolean;
  hasPublisherNotes?: boolean;
  includeRelated?: boolean;
  broadcastdate: Array<string>;

}

export interface SelectedFilter {
    broadcastdate: Array<string>;
}

type NewType = boolean;

interface Props {
  isLoading: NewType;
}

const useStyles = makeStyles({
  resourceIdeContainer: {
    paddingBottom: '20',
    backgroundColor: '#cacaca',
  },

  heading: {
    'font-size': '13px',
    'font-weight': '500',
    'text-transform': 'none',
    color: '#000000',
  },
  value: {
    'font-size': '13px',
    color: '#666666',
    'font-weight': '500',
  },
  label: {
    'font-size': '13px',
    color: '#000000',
    'font-weight': '500',
  },
});

function OrganisationContactinfo(_props: Props): JSX.Element {
  const classes = useStyles();
  //  const [filterList, setFilterList] = useState<SelectedOptionFilters>(SelectedOptionFilters.empty());

  return (
    <div className="organisation_Container">
      <Card
        variant="outlined"
        className="resourceIdeContainer"
        style={{
          marginLeft: 20,
          marginRight: 20,
          paddingBottom: 20,
          marginTop: 20,
        }}
      >

        <Grid item xs={12} style={{ textAlign: 'left' }}>
          <Typography
            className={classes.heading}
            variant="overline"
            style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
          >
            Organisation & Contact Info (from HubSpot)
          </Typography>
        </Grid>
        <Grid
          container
          spacing={2}
          style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
        >
          <Grid item xs={4}>
            <Grid container>
              <Grid item xs={5}>
                <span className={classes.label}>First Name:</span>
              </Grid>
              <Grid item xs={7}>
                <span className={classes.value}>
                  First Name
                </span>
              </Grid>
            </Grid>
            <Grid container>
              <Grid item xs={5}>
                <span className={classes.label}>Last Name:</span>
              </Grid>
              <Grid item xs={7}>
                <span className={classes.value}>
                  Last Name
                </span>
              </Grid>
            </Grid>
            <Grid container>
              <Grid item xs={5}>
                <span className={classes.label}>Email:</span>
              </Grid>
              <Grid item xs={7}>
                <span className={classes.value}>
                  LastName@gmail.com
                </span>
              </Grid>
            </Grid>
            <Grid container>
              <Grid item xs={5}>
                <span className={classes.label}>Phone Number:</span>
              </Grid>
              <Grid item xs={7}>
                <span className={classes.value}>
                  1234 5678 910
                </span>
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={4}>
            <Grid container>
              <Grid item xs={5}>
                <span className={classes.label}>
                  Organisation Name:
                </span>
              </Grid>
              <Grid item xs={7}>
                <span className={classes.value} />
              </Grid>
            </Grid>
            <Grid container>
              <Grid item xs={5}>
                <span className={classes.label}>Contact Type:</span>
              </Grid>
              <Grid item xs={7}>
                <span className={classes.value} />
              </Grid>
            </Grid>
            <Grid container>
              <Grid item xs={5}>
                <span className={classes.label}>Contact Organisation:</span>
              </Grid>
              <Grid item xs={7}>
                <span className={classes.value} />
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={4}>
            <Grid container>
              <Grid item xs={5}>
                <span className={classes.label}>OrganisationID:</span>
              </Grid>
              <Grid item xs={7}>
                <span className={classes.value} />
              </Grid>
            </Grid>
            <Grid container>
              <Grid item xs={5}>
                <span className={classes.label}>Royalty Organisation Name:</span>
              </Grid>
              <Grid item xs={7}>
                <span className={classes.value} />
              </Grid>
            </Grid>
            <Grid container>
              <Grid item xs={5}>
                <span className={classes.label}>Company Website:</span>
              </Grid>
              <Grid item xs={7}>
                <span className={classes.value} />
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Card>
    </div>
  );
}

export default OrganisationContactinfo;
