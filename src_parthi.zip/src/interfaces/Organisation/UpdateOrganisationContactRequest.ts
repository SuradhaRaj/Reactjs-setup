interface UpdateOrganisationContactRequest {
  organisationId: number;
  contactId: number;
  contactRoleIds: number[];
}

export default UpdateOrganisationContactRequest;
