import {
  Record, String, Static,
} from 'runtypes';

export const CustomStrLookupOptionValidator = Record({
  Key: String,
  Value: String,
});

  type CustomStrLookupOptValidator = Static<typeof CustomStrLookupOptionValidator>;
export default CustomStrLookupOptValidator;
