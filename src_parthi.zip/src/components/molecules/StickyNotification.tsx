import React from 'react';
import { createStyles, makeStyles } from '@material-ui/core/styles';
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';
import {
  Typography, Theme, Grid,
} from '@material-ui/core';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    backgroundColor: '#f8f7b6',
    position: 'sticky',
    top: 0,
    marginBottom: 16,
    marginTop: -64,
    height: 48,
    zIndex: 999,
    textAlign: 'center',
  },
  typography: {
    display: 'inline',
    marginLeft: theme.spacing(2),
  },
}));

interface Props{
  text: string;
}

const StickyNotification = (props: Props): JSX.Element => {
  const classes = useStyles();

  return (
    <Grid container className={classes.root} alignItems="center">
      <Grid item xs={12}>
        <ErrorOutlineIcon />
        {' '}
        <Typography className={classes.typography}>{props.text}</Typography>

      </Grid>
    </Grid>
  );
};

export default StickyNotification;
