import {
  Record, Static, String, Number, Null,
} from 'runtypes';

export const AuthorOptionValidator = Record({
  authorId: Number,
  firstName: String,
  middleName: String.Or(Null),
  lastName: String,
  orcidCode: String.Or(Null),
});

type AuthorOption = Static<typeof AuthorOptionValidator>;

export default AuthorOption;
