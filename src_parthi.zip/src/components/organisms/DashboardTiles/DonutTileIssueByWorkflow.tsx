/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable max-len */
import Axios from 'axios';
import * as React from 'react';
import PlotlyChart from 'react-plotlyjs-ts';

interface State{
  loading: boolean;
  data: Array<any>;
  layout: any;
}

class DonutTileIssueByWorkflow extends React.Component<{}, State> {
  constructor(props: {} | Readonly<{}>) {
    super(props);
    this.state = {
      loading: true,
      data: [{
        values: [],
        labels: [],
        domain: { column: 0 },
        name: 'Issues By Workflow States',
        hoverinfo: 'label+value+percent',
        hole: 0.4,
        type: 'pie',
      }],
      layout: {
        title: '',
        annotations: [
          {
            font: {
              size: 16,
            },
            showarrow: false,
            text: '',
            x: 0.82,
            y: 0.5,
          },
        ],
        height: 400,
        width: 500,
        showlegend: true,
        grid: { rows: 1, columns: 1 },
        legend: {
          x: -4,
          y: -4,
          traceorder: 'reversed',
          // eslint-disable-next-line @typescript-eslint/camelcase
          title_font_family: 'Times New Roman',
          font: {
            family: 'Courier',
            size: 8,
            color: 'black',
          },
        },

      },
    };
  }

  componentDidMount() {
    const iw = Axios.get(`${process.env.REACT_APP_API_URL}/api/dashboard/issuesbyworkflow`, { headers: { 'Content-Type': 'application/json' } });
    Promise.all([iw]).then(([iwResp]) => {
      if (iwResp.status === 200) {
        for (let i = 0; i < iwResp.data.length; i++) {
          this.setState((prevState) => ({
            ...prevState, // copy all other key-value pairs of food object
            data: prevState.data.map(
              (el, ind) => (ind === 0 ? {
                ...el,
                labels: [...prevState.data[0].labels, iwResp.data[i].Key as unknown], // specific object of food object
                values: [...prevState.data[0].values, iwResp.data[i].Value as unknown],
              } : el),
            ), // copy all pizza key-value pairs
            // update value of specific key
          }));
        }
        // this.data[0].labels.push(response.data[i].Key as never);
        // this.data[0].values.push(response.data[i].Key as never);
      }
      this.setState((prevState) => ({ ...prevState, loading: false }));
    })
      .finally(() => undefined);
  }

  public handleClick = (evt: any) => { window.location.href = `search?q=%7B%22text%22%3A%22%5C%22${evt.points[0].label}${'%5C%22%22%2C%22indexRequests%22%3A%5B%7B%22searchIndex%22%3A3%7D%5D%7D'}`; }

    public handleHover = (_evt: any) => undefined

    render() {
      if (this.state.loading) { return (<div />); }
      return (
        <PlotlyChart
          data={this.state.data}
          layout={this.state.layout}
          onClick={this.handleClick}
          onHover={this.handleHover}
        />

      );
    }
}

export default DonutTileIssueByWorkflow;
