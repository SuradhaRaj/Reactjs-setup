// this dropzone for image cover upload.

import React, { useState } from 'react';
import { useDropzone, DropzoneOptions } from 'react-dropzone';
// import FileIcon from '@material-ui/icons/FileCopy';
import {
  createStyles,
  Theme,
  makeStyles,
  Typography,
} from '@material-ui/core';
// eslint-disable-next-line @typescript-eslint/ban-ts-ignore
// @ts-ignore
import FileIcon from 'react-file-icon';
import { useTheme } from '@material-ui/styles';

import RejectedFile from '../../../interfaces/TextIndexer/RejectedFile';

const DisplayMessages = {
  0: 'Drop files here',
  1: 'Please add only Image files. All other files types will be rejected.',
  2: '',
  3: 'Drop files here or click to select files',
};

const AcceptedFileTypes = [
  'image/jpeg',
  'image/png',
  'image/jpg',
];
const MaxFileSize = 100 * 1000000; // bytes

const useStyles = makeStyles((theme: Theme) => createStyles({
  icon: {
    width: 120,
    height: 160,
  },
  neutral: {
    color: theme.palette.primary.main,
    cursor: 'pointer',
  },
  accept: {
    color: 'green',
    cursor: 'pointer',
  },
  reject: {
    color: theme.palette.secondary.main,
    cursor: 'pointer',
  },
  disabled: {
    color: 'grey',
    cursor: 'not-allowed',
  },
  root: {

    borderStyle: 'dashed',
    borderRadius: 10,
    textAlign: 'center',
    padding: theme.spacing(1),
    opacity: 0.8,
  },
  displayMessage: {
    // textAlign: 'center',
    margin: theme.spacing(1),
  },
  image: {
    borderRadius: 10,
    opacity: 0.8,
    width: 100,
    height: 140,
  },

}));

interface DropzoneProps{
  onFileDrop(acceptedFiles: File[], rejectedFiles: RejectedFile[]): void;
  disabled: boolean;
}

const Dropzone = (props: DropzoneProps) => {
  const classes = useStyles();
  const theme: Theme = useTheme();
  const [state, setState] = useState<{ image?: string; file?: File}>({
    image: undefined,
    file: undefined,
  });

  const onDrop = (acceptedFiles: File[], rejectedFiles: File[]) => {
    const rejectedFilesWithReason: RejectedFile[] = [];

    rejectedFiles.forEach((file) => {
      if (file.size >= MaxFileSize) {
        rejectedFilesWithReason.push({ filename: file.name, errorMessageId: 0 });
      } else {
        rejectedFilesWithReason.push({ filename: file.name, errorMessageId: 1 });
      }
    });
    if (acceptedFiles.length > 0) {
      const file = (acceptedFiles[0]);
      const image = URL.createObjectURL(acceptedFiles[0]);
      setState((prevState) => ({
        ...prevState,
        image,
        file,
      }));
    }
    props.onFileDrop(acceptedFiles, rejectedFilesWithReason);
  };

  const dropzoneOptions: DropzoneOptions = {
    onDrop,
    accept: AcceptedFileTypes,
    maxSize: MaxFileSize,
    disabled: props.disabled,
  };

  const {
    getRootProps,
    getInputProps,
    isDragAccept,
    isDragReject,
  } = useDropzone(dropzoneOptions);

  const dropzoneState = () => {
    if (props.disabled) return 'disabled';
    if (isDragAccept) return 'accept';
    if (isDragReject) return 'reject';
    return 'neutral';
  };

  const getDisplayMessage = () => {
    switch (dropzoneState()) {
      case 'accept':
        return DisplayMessages[0];
      case 'reject':
        return DisplayMessages[1];
      case 'disabled':
        return DisplayMessages[2];
      default:
        return DisplayMessages[3];
    }
  };

  const getFileColour = () => {
    switch (dropzoneState()) {
      case 'accept':
        return theme.palette.success.main;
      case 'reject':
        return theme.palette.secondary.main;
      case 'disabled':
        return theme.palette.text.disabled;
      default:
        return theme.palette.primary.main;
    }
  };

  const image = state.image && state.file
    ? (
      <>
        <img alt={state.file.name} src={state.image} className={`${classes.image} ${classes[dropzoneState()]} ${classes.icon}`} />

      </>
    )
    : (
      <FileIcon
        extension=".jpg"
        labelUppercase
        labelColor={getFileColour()}
        size={200}
        type="image"
      />
    );

  return (
    <>
      <div {...getRootProps({ className: `${classes.root} ${classes[dropzoneState()]} ${classes.icon}` })}>
        <input {...getInputProps()} />
        {image}

      </div>
      <Typography
        variant="body1"
        className={`${classes.displayMessage} ${classes[dropzoneState()]}`}
      >
        {getDisplayMessage()}
      </Typography>
    </>
  );
};

export default Dropzone;
