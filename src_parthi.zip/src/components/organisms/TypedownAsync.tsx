import React from 'react';
import Axios, { AxiosResponse } from 'axios';
import { debounce } from 'lodash';
import {
  Array, Static,
} from 'runtypes';
import Typedown, { TypedownProps } from './Typedown';
import TypedownOption, { TypedownOptionValidator } from '../../interfaces/TypedownOption';

export interface TypedownAsyncProps extends Omit<TypedownProps, 'options'|'showLoadingSpinner'|'onInputChange'> {
  url: string;
  debounceTime: number;
  disabled?: boolean;
  error?: boolean;
  errorMessage?: string | undefined;
  additionalUriParameters: {[key: string]: string | number | boolean };
  typedownLimit: number;
}

interface State {
  options: TypedownOption[];
  isCallingApi: boolean;
}

const ResultValidator = Array(TypedownOptionValidator);
type ArrayResult = Static<typeof ResultValidator>;

const TypedownAsync = (props: TypedownAsyncProps): JSX.Element => {
  const [state, setState] = React.useState<State>({
    options: [],
    isCallingApi: false,
  });

  const fetchFromApi = debounce((data: string) => {
    setState((prevState) => ({
      ...prevState,
      isCallingApi: true,
    }));
    Axios.get(`${props.url}?searchTerm=${data}`, { params: props.additionalUriParameters })
      .then((response: AxiosResponse<{results: ArrayResult}>) => {
        if (ResultValidator.guard(response.data.results)) {
          setState((prevState) => ({
            ...prevState,
            options: [...response.data.results],
          }));
        } else {
          console.error('Incorrect format for typedown results');
        }
      }).finally(() => {
        setState((prevState) => ({
          ...prevState,
          isCallingApi: false,
        }));
      });
  }, props.debounceTime);

  return (
    <Typedown
      {...props}
      options={state.options}
      onInputChange={fetchFromApi}
      showLoadingSpinner={state.isCallingApi}
      filterOptions={(x) => x}
      disabled={props.disabled}
      error={props.error}
      errorMessage={props.errorMessage}
      typedownLimit={props.typedownLimit}
    />
  );
};

TypedownAsync.defaultProps = {
  ...Typedown.defaultProps,
  debounceTime: 300,
  additionalUriParameters: {},
} as Partial<TypedownAsyncProps>;

export default TypedownAsync;
