import {
  Static, Record,
} from 'runtypes';
import { ResourceValidator } from './Resource';

export const UpdateResourceResponseValidator = Record({
  resource: ResourceValidator,
});

type UpdateResourceResponse = Static<typeof UpdateResourceResponseValidator>;
export default UpdateResourceResponse;
