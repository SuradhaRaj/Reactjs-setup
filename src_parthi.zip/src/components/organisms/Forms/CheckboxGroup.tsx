import React from 'react';
import {
  Checkbox, FormGroup, FormControl, FormControlLabel, FormLabel, makeStyles, Theme, createStyles,
} from '@material-ui/core';
import classnames from 'classnames';
import LookupOption from '../../../interfaces/LookupOption';

interface Props {
  options: LookupOption[];
  selectedOptions: number[];
  onChange(data: number[]): void;
  label: string;
  name: string;
  className?: string;
}

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    display: 'flex',
    margin: 0,
    '& .MuiFormControlLabel-label,.MuiFormLabel-root': {
      fontSize: '0.8rem',
    },
    '&.MuiFormControlLabel-root': {
      margin: 0,
    },
    '& .MuiCheckbox-root': {
      padding: 0,
      marginRight: theme.spacing(1),
    },
  },
  formControlLabel: {
    margin: 0,
    marginLeft: theme.spacing(2),
    width: 'fit-content',
  },
}));

const CheckboxGroup = (props: Props) => {
  const classes = useStyles();
  const toggleCheckbox = (itemToChange: LookupOption, checked: boolean) => {
    if (checked) { props.onChange([...props.selectedOptions, itemToChange.key]); } else {
      props.onChange(props.selectedOptions.filter((item) => item !== itemToChange.key));
    }
  };
  const isChecked = (item: LookupOption) => props.selectedOptions.includes(item.key);

  return (
    <FormControl component="fieldset" className={classnames(classes.root, props.className)}>
      <FormLabel component="legend">{props.label}</FormLabel>
      <FormGroup>
        {props.options.map((item) => (
          <FormControlLabel
            key={item.key}
            control={<Checkbox color="primary" />}
            label={item.value}
            checked={isChecked(item)}
            // labelPlacement="start"
            className={classes.formControlLabel}
            onChange={(e: React.ChangeEvent<{}>, checked) => { toggleCheckbox(item, checked); }}
          />
        ))}
      </FormGroup>
    </FormControl>
  );
};
export default CheckboxGroup;
