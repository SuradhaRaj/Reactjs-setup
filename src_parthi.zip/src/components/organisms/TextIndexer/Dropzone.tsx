import React from 'react';
import { useDropzone, DropzoneOptions } from 'react-dropzone';
// import FileIcon from '@material-ui/icons/FileCopy';
import {
  createStyles,
  Theme,
  makeStyles,
  Typography,
} from '@material-ui/core';
// eslint-disable-next-line @typescript-eslint/ban-ts-ignore
// @ts-ignore
import FileIcon from 'react-file-icon';
import { useTheme } from '@material-ui/styles';
import {
  MaxFileSize, DisplayMessages, AcceptedIssueFileTypes, AcceptedExtraFileTypes,
} from '../../../constants/FileUploadConstants';
import RejectedFile from '../../../interfaces/TextIndexer/RejectedFile';

const useStyles = makeStyles((theme: Theme) => createStyles({
  icon: {
    width: 120,
    height: 160,
  },
  neutral: {
    color: theme.palette.primary.main,
    cursor: 'pointer',
  },
  accept: {
    color: 'green',
    cursor: 'pointer',
  },
  reject: {
    color: theme.palette.secondary.main,
    cursor: 'pointer',
  },
  disabled: {
    color: 'grey',
    cursor: 'not-allowed',
  },
  root: {
    height: '100%',
    width: '100%',
    borderStyle: 'dashed',
    borderRadius: 10,
    textAlign: 'center',
    padding: theme.spacing(3),
    opacity: 0.8,
  },
  displayMessage: {
    margin: theme.spacing(1),
  },
}));

interface DropzoneProps{
  onFileDrop(acceptedFiles: File[], rejectedFiles: RejectedFile[]): void;
    disabled: boolean;
    icon?: string;

    dropedFileType?: string;

}

const Dropzone = (props: DropzoneProps) => {
  const classes = useStyles();
  const theme: Theme = useTheme();
  const iconType = props.icon === 'doc' ? { ext: '', icon: 'document' } : { ext: '.PDF', icon: 'acrobat' };

  const onDrop = (acceptedFiles: File[], rejectedFiles: File[]) => {
    const rejectedFilesWithReason: RejectedFile[] = [];

    rejectedFiles.forEach((file) => {
      if (file.size >= MaxFileSize) {
        rejectedFilesWithReason.push({ filename: file.name, errorMessageId: 0 });
      } else {
        rejectedFilesWithReason.push({ filename: file.name, errorMessageId: 1 });
      }
    });
    props.onFileDrop(acceptedFiles, rejectedFilesWithReason);
  };

  const DropZoneAcceptedFileTypes: string[] = props.dropedFileType !== 'extra' ? AcceptedIssueFileTypes : AcceptedExtraFileTypes;

  const dropzoneOptions: DropzoneOptions = {
    onDrop,
    accept: DropZoneAcceptedFileTypes,
    maxSize: MaxFileSize,
    disabled: props.disabled,
  };

  const {
    getRootProps,
    getInputProps,
    isDragAccept,
    isDragReject,
  } = useDropzone(dropzoneOptions);

  const dropzoneState = () => {
    if (props.disabled) return 'disabled';
    if (isDragAccept) return 'accept';
    if (isDragReject) return 'reject';
    return 'neutral';
  };

  const getDisplayMessage = () => {
    switch (dropzoneState()) {
      case 'accept':
        return DisplayMessages[0];
      case 'reject':
        return DisplayMessages[1];
      case 'disabled':
        return DisplayMessages[2];
      default:
        return DisplayMessages[3];
    }
  };

  const getFileColour = () => {
    switch (dropzoneState()) {
      case 'accept':
        return theme.palette.success.main;
      case 'reject':
        return theme.palette.secondary.main;
      case 'disabled':
        return theme.palette.text.disabled;
      default:
        return theme.palette.primary.main;
    }
  };

  return (
    <div {...getRootProps({ className: `${classes.root} ${classes[dropzoneState()]}` })}>
      <input {...getInputProps()} />
      <FileIcon
        extension={iconType.ext}
        labelUppercase
        labelColor={getFileColour()}
        size={200}
        type={iconType.icon}
      />
      <Typography
        variant="body1"
        className={`${classes.displayMessage} ${classes[dropzoneState()]}`}
      >
        {getDisplayMessage()}
      </Typography>
    </div>
  );
};

export default Dropzone;
