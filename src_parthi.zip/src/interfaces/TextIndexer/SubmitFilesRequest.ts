interface SubmitFilesRequest {
  issuePath: string;
  issueId: number;

  addingToEndedIssueWorkflow: boolean;
  filenames: string[];
};

export default SubmitFilesRequest;
