import React from 'react';
import { mount, shallow } from 'enzyme';
import { Provider } from 'react-redux';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { MuiThemeProvider } from '@material-ui/core';
import RootResourceForm, { RootResourceFormik } from '../../../components/organisms/ResourceManagement/RootResourceForm';
import ResourceObj from '../../testObjects/ResourceManagement/Resource';
import store from '../../../store/store';
import HookWrapper from '../../hooks/HookWrapper';
import Resource from '../../../interfaces/ResourceManagement/Resource';
import RejectedFile from '../../../interfaces/TextIndexer/RejectedFile';
import theme from '../../../config/theme';

describe('Root Resource Form', () => {
  it('should show validation errors when the form is invalid', async () => {
    const formikHookWrapper = shallow(<HookWrapper hook={() => useFormik<Resource>({
      initialValues: { ...ResourceObj, resourceTitle: '' },
      validationSchema: Yup.object().shape({ resourceTitle: Yup.string().required() }),
      onSubmit: () => undefined,
      initialErrors: { isbn: 'isbn required' },
    })}
    />);

    const formikHook = formikHookWrapper.find('div').prop('data-hook') as RootResourceFormik;
    const wrapper = mount(
      <Provider store={store}>

        <MuiThemeProvider theme={theme}>
          <RootResourceForm formik={formikHook} onFileDrop={(acceptedfiles: File[], rejectfile: RejectedFile[]) => ({ acceptedfiles, rejectfile })} filterValue="" />

        </MuiThemeProvider>
      </Provider>,
    );

    expect(wrapper.find('.Mui-error').length).toBeGreaterThan(0);
  });
  it('should not show validation errors when the form is valid', () => {
    const formikHookWrapper = shallow(<HookWrapper hook={() => useFormik<Resource>({
      initialValues: { ...ResourceObj, resourceTitle: '' },
      onSubmit: () => undefined,
    })}
    />);
    const formikHook = formikHookWrapper.find('div').prop('data-hook') as RootResourceFormik;

    const wrapper = mount(
      <Provider store={store}>

        <MuiThemeProvider theme={theme}>
          <RootResourceForm formik={formikHook} filterValue="" onFileDrop={(acceptedfiles: File[], rejectfile: RejectedFile[]) => ({ acceptedfiles, rejectfile })} />

        </MuiThemeProvider>
      </Provider>,
    );

    expect(wrapper.find('.Mui-error').length).toBe(0);
  });
});
