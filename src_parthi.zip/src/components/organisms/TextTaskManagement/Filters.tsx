/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect, useState } from 'react';
import {
  Typography, Grid, Divider,
} from '@material-ui/core';
import Button from '@material-ui/core/Button';
import { useDispatch } from 'react-redux';
import { useLocation, useHistory } from 'react-router-dom';
import { compact } from 'lodash';
import { useTypedSelector } from '../../../store/store';
import CheckboxFilter from '../CheckboxFilter';
import { updateFilters, clearFilters } from '../../../store/actions/ActnTextTaskManagement';
import { default as FiltersObj } from '../../../classes/TextTaskManagementFilters';
import TaskManagementFilterHelper from '../../../utils/TaskManagementFilterHelper';
import TypedownFilter from '../TypedownFilter';
import WorkflowStatus, { WorkflowStatusDisplayNames, TextWorkflowOrder } from '../../../interfaces/enums/WorkflowStatus';

interface State {
    status: Array<string>;
    publisher: Array<string>;
    title: Array<string>;
    grouping: Array<string>;
    manager: Array<string>;
}

interface Props {
  isLoading: boolean;
}

const Filters = (props: Props) => {
  const dispatch = useDispatch();
  const taskManagement = useTypedSelector((store) => store.TextTaskManagement);
  const [state, setState] = useState<State>({
    status: [],
    publisher: [],
    title: [],
    grouping: [],
    manager: [],
  });

  const history = useHistory();
  const location = useLocation();
  const query = new URLSearchParams(location.search);

  const updateUrl = () => {
    const queryString = taskManagement.Filters.getQueryString();
    if (queryString !== '') {
      query.set('filter', queryString);
      const queryToSet = query.toString();
      history.push(`${location.pathname}?${queryToSet}`);
    } else {
      history.push(location.pathname);
    }
  };

  function changeFilter<T extends keyof State>(filterName: T, value: State[T]) {
    const newFilters = taskManagement.Filters.updateFilter(filterName, value);
    dispatch(updateFilters(newFilters));
    updateUrl();
  }

  const clearAllFilters = (): void => {
    dispatch(clearFilters());
    history.push(location.pathname);
  };
  useEffect(() => {
    const filtersString = query.get('filter');
    if (filtersString != null) {
      const filters = JSON.parse(filtersString);
      dispatch(updateFilters(new FiltersObj(filters)));
    }
  }, [location]);

  useEffect(() => {
    const artifactStatus = taskManagement.AllTasks.map((task) => task.workflowStatusId as WorkflowStatus);
    const allStatuses = [...artifactStatus];
    const filteredStatusIds = TextWorkflowOrder.filter((x) => allStatuses.indexOf(x) >= 0);
    const workflowStatuses = filteredStatusIds.map((status) => WorkflowStatusDisplayNames[status]);

    const artifactPublisher = compact(taskManagement.AllTasks.map((task) => task.nameOfPublisher));
    const distinctPublisher = TaskManagementFilterHelper.GetValues([...artifactPublisher]);

    const artifactTitle = taskManagement.AllTasks.map((task) => task.title || '');
    const distinctTitle = TaskManagementFilterHelper.GetValues([...artifactTitle]);

    const artifactGrouping = taskManagement.AllTasks.map((task) => task.grouping);
    const distinctGrouping = TaskManagementFilterHelper.GetValues([...artifactGrouping]);

    const artifactResourceManager = taskManagement.AllTasks.map((task) => task.managerName);
    const distinctResourceManager = TaskManagementFilterHelper.GetValues([...artifactResourceManager]);

    setState((prevState) => ({
      ...prevState,
      status: workflowStatuses,
      publisher: distinctPublisher,
      grouping: distinctGrouping,
      title: distinctTitle,
      manager: distinctResourceManager,
    }));
  }, [taskManagement.AllTasks]);
  return (
    <>
      <Grid container spacing={1} style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}>
        <Grid item xs={12} style={{ textAlign: 'right' }}>
          <Typography variant="overline">Filters</Typography>
        </Grid>

        <Grid item xs={12}>
          <TypedownFilter
            isLoading={props.isLoading}
            title="Title"
            options={state.title}
            selectedOptions={taskManagement.Filters.data.title}
            onChange={(options) => { changeFilter('title', options as string[]); }}
          />
        </Grid>
        <Grid item xs={12}>
          <Divider />
        </Grid>
        <Grid item xs={12}>
          <TypedownFilter
            isLoading={props.isLoading}
            title="Publisher"
            options={state.publisher}
            selectedOptions={taskManagement.Filters.data.publisher}
            onChange={(options) => { changeFilter('publisher', options as string[]); }}
          />
        </Grid>
        <Grid item xs={12}>
          <Divider />
        </Grid>
        <Grid item xs={12}>
          <TypedownFilter
            isLoading={props.isLoading}
            title="Grouping"
            options={state.grouping}
            selectedOptions={taskManagement.Filters.data.grouping}
            onChange={(options) => { changeFilter('grouping', options as string[]); }}
          />
        </Grid>
        <Grid item xs={12}>
          <Divider />
        </Grid>
        <Grid item xs={12}>
          <TypedownFilter
            isLoading={props.isLoading}
            title="Resource Manager"
            options={state.manager}
            selectedOptions={taskManagement.Filters.data.manager}
            onChange={(options) => { changeFilter('manager', options as string[]); }}
          />
        </Grid>
        <Grid item xs={12}>
          <Divider />
        </Grid>
        <Grid item xs={12}>
          <CheckboxFilter
            title="Status"
            isLoading={props.isLoading}
            options={state.status}
            selectedOptions={taskManagement.Filters.data.status}
            onChange={(options) => { changeFilter('status', options); }}
          />
        </Grid>
        {!props.isLoading && (
        <Grid item xs={12} style={{ textAlign: 'right' }}>
          <Button onClick={() => { clearAllFilters(); }}>Clear</Button>
        </Grid>
        )}
      </Grid>
    </>
  );
};

export default Filters;
