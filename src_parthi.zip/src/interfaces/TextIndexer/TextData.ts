import Artifact from '../Artifact';
import TextArtifact from './TextArtifact';
import ArtifactStatus from '../enums/ArtifactStatus';
import IssueArtifact from './IssueArtifact';
import IndexingTypes from '../enums/IndexingTypes';
import WorkflowStatus from '../enums/WorkflowStatus';

interface TextData extends Artifact {
  groupIndexer: string;
  isReadOnly: boolean;
  isPublishedViaWorkflow: boolean;
  lockedBy: string;
  lockOwned: boolean;
  submitTasks: string[];

  workflowStatusId: WorkflowStatus;
  workflowStatus?: string;

  artifactStatusId: ArtifactStatus;
  articleArtifactDocument: TextArtifact;
  resourceId: string;
  issueResourceTypeId: number;
  grouping: string;
  revisionDate: Date;
  dropboxIssue: IssueArtifact;
  indexingTypes: IndexingTypes[];
};

export default TextData;
