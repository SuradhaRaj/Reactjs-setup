import {
  Record, Static, Array,
} from 'runtypes';
import { TitleSearchResultValidator } from '../Search/TitleSearchResult';
import { NonEmptyString } from '../../runtypeTypes';

export const ResourceListResponseValidator = Record({
  resources: Array(TitleSearchResultValidator),
  organisationName: NonEmptyString,
});

type ResourceListResponse = Static<typeof ResourceListResponseValidator>;
export default ResourceListResponse;
