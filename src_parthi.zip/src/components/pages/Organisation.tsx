/* eslint-disable max-len */
import React from 'react';
import {
  Grid, CircularProgress, makeStyles, Theme, createStyles, Divider, Typography,
} from '@material-ui/core';
import Axios from 'axios';
import { useParams } from 'react-router-dom';
import OrganisationData from '../../interfaces/Organisation/OrganisationData';
import ErrorPaper from '../organisms/ErrorPaper';
import OrganisationReadonlyFields from '../organisms/Organisation/OrganisationReadonlyFields';
import LicenceTemplates from '../organisms/Organisation/LicenceTemplates';
import OrganisationPathParams from '../../interfaces/Organisation/OrganisationPathParams';
import GetOrganisationResponse from '../../interfaces/Organisation/GetOrganisationResponse';
import GetOrganisationReferenceDataResponse, { GetOrganisationReferenceDataResponseValidator } from '../../interfaces/Organisation/GetOrganisationReferenceDataResponse';
import Contacts from '../organisms/Organisation/Contacts';
import OrganisationContact from '../../interfaces/Organisation/OrganisationContact';
import LicenceTemplate from '../../interfaces/Organisation/LicenceTemplate';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    paddingLeft: theme.spacing(2),
    paddingRight: theme.spacing(2),
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
  },
  divider: {
    marginTop: theme.spacing(4),
    marginBottom: theme.spacing(4),
    textAlign: 'right',
  },
  dividerHeader: {
    fontSize: '1rem',
    color: theme.palette.text.secondary,
    paddingRight: theme.spacing(1),
  },
}));

interface OrganisationState {
  organisationData: OrganisationData | null;
  licenceTemplates: LicenceTemplate[] | null;
  contacts: OrganisationContact[] | null;
  errored: boolean;
  loading: boolean;
  referenceData: GetOrganisationReferenceDataResponse | null;
};

const Organisation: React.SFC = () => {
  const [state, setState] = React.useState<OrganisationState>({
    organisationData: null,
    errored: false,
    loading: true,
    licenceTemplates: null,
    contacts: null,
    referenceData: null,
  });

  const classes = useStyles();
  const params = useParams<OrganisationPathParams>();

  React.useEffect(() => {
    const organisationId = params.partnerId;

    const organisationPromise = Axios.get<GetOrganisationResponse>(`${process.env.REACT_APP_API_URL}/api/organisation/${organisationId}`);
    const referenceDataPromise = Axios.get<GetOrganisationReferenceDataResponse>(`${process.env.REACT_APP_API_URL}/api/organisation/getorganisationreferencedata`);

    Promise.all([organisationPromise, referenceDataPromise])
      .then((responses) => {
        const getOrganisationResponse = responses[0].data; // this response will be validated at deeper levels
        const referenceData = GetOrganisationReferenceDataResponseValidator.check(responses[1].data);

        setState((prevState) => ({
          ...prevState,
          organisationData: getOrganisationResponse.organisation,
          licenceTemplates: getOrganisationResponse.licenceTemplates,
          contacts: getOrganisationResponse.contacts,
          referenceData,
        }));
      })
      .catch(() => (
        setState((prevState) => ({
          ...prevState,
          errored: true,
        }))
      ))
      .finally(() => (
        setState((prevState) => ({
          ...prevState,
          loading: false,
        }))));
  }, []);

  const onLicenceTemplatesChange = (newLicenceTemplates: LicenceTemplate[]) => (
    setState((prevState) => ({
      ...prevState,
      licenceTemplates: newLicenceTemplates,
    }))
  );

  const onContactsChange = (newContacts: OrganisationContact[]) => {
    setState((prevState) => ({
      ...prevState,
      contacts: newContacts,
    }));
  };

  if (state.loading) {
    return <CircularProgress />;
  }

  if (state.errored) {
    return (
      <ErrorPaper
        text="Unable to load partner"
      />
    );
  }

  return (
    <Grid container justify="center" className={classes.root}>
      {!state.organisationData || !state.referenceData || !state.licenceTemplates || !state.contacts ? (
        <ErrorPaper
          text="Unable to load partner"
        />
      ) : (
        <>
          <Grid item xs={7}>
            <OrganisationReadonlyFields
              data={state.organisationData}
            />
          </Grid>
          <Grid item xs={7} className={classes.divider}>
            <Divider />
            <Typography
              variant="overline"
              className={classes.dividerHeader}
            >
              LICENCE TEMPLATES
            </Typography>
          </Grid>
          <Grid item xs={7}>
            <LicenceTemplates
              referenceData={state.referenceData}
              licenceTemplates={state.licenceTemplates}
              onChangeHandler={onLicenceTemplatesChange}
            />
          </Grid>
          <Grid item xs={7} className={classes.divider}>
            <Divider />
            <Typography
              variant="overline"
              className={classes.dividerHeader}
            >
              CONTACTS
            </Typography>
          </Grid>
          <Grid item xs={7}>
            <Contacts
              contacts={state.contacts}
              organisationId={state.organisationData.organisationId}
              handleContactsChange={onContactsChange}
              contactRoleTypeLookup={state.referenceData.contactRoleType}
            />
          </Grid>
        </>
      )}
    </Grid>
  );
};

export default Organisation;
