import React from 'react';
import { mount } from 'enzyme';
import OrganisationReadonlyFields from '../../../components/organisms/Organisation/OrganisationReadonlyFields';
import OrganisationData from '../../../interfaces/Organisation/OrganisationData';

const SampleOrganisation: OrganisationData = {
  organisationId: 12321232,
  hubSpotId: 23232323,
  organisationName: 'smpl Name',
  organisationDepartment: 'sample Department',
  organisationCode: 'smpl Code',
  organisationType: null,
  rcti: true,
  organisationAbn: null,
  organisationGstStatus: null,
  organisationStreetAddress: '12 gray street',
  organisationSuburb: 'melbourne',
  organisationState: 'VIC',
  organisationPostcode: '3000',
  organisationCountry: 'Australia',
  organisationPhone: '+123456',
  organisationFax: '+121121',
  organisationEmail: 'smpl email',
  organisationWebAddress: 'smpl web address',
  organisationActivityDescription: null,
  isPublisher: true,
  isSubscriber: false,
};

const wrapper = mount(<OrganisationReadonlyFields
  data={SampleOrganisation}
/>);

describe('Organisation Readonly Fields', () => {
  it('should show passed in readonly fields', () => {
    expect(wrapper.text().includes('smpl Name')).toBeTruthy();
    expect(wrapper.text().includes('smpl Code')).toBeTruthy();
    expect(wrapper.text().includes('+123456')).toBeTruthy();
    expect(wrapper.text().includes('+121121')).toBeTruthy();
    expect(wrapper.text().includes('smpl email')).toBeTruthy();
    expect(wrapper.text().includes('smpl web address')).toBeTruthy();
    expect(wrapper.text().includes('12 gray street, melbourne, VIC, 3000, Australia')).toBeTruthy();
  });
});
