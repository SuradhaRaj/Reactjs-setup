import React from 'react';
import { shallow } from 'enzyme';
import { ValidationErrorDialog } from '../components/molecules/MediaIndexer/ValidationErrorDialog';

describe('Validation dialog', () => {
  it('should render the correct number of errors', () => {
    let wrapper = shallow(<ValidationErrorDialog isOpen onProceed={() => undefined} onReturn={() => undefined} errors={[1]} allowSkip={false} />);
    expect(wrapper.find('[data-skip-min-reqs-btn]')).toHaveLength(0);

    wrapper = shallow(<ValidationErrorDialog isOpen onProceed={() => undefined} onReturn={() => undefined} errors={[]} allowSkip />);
    expect(wrapper.find('[data-skip-min-reqs-btn]')).toHaveLength(1);
  });
});
