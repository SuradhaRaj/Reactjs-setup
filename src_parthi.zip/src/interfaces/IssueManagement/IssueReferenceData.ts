import { Record, Static } from 'runtypes';
import { LookupOptionValidator } from '../LookupOption';
import { ArrayWithElements } from '../../runtypeTypes';

export const IssueReferenceDataValidator = Record({
  issueWorkflowStates: ArrayWithElements(LookupOptionValidator),
  accessRights: ArrayWithElements(LookupOptionValidator),
});

type IssueReferenceData = Static<typeof IssueReferenceDataValidator>;
export default IssueReferenceData;
