import {
  Record, Static, String, Number, Null, Array, Undefined, Boolean,
} from 'runtypes';

export const FileValidator = Record({
  filename: String,
  size: Number,
  date: String,
  isExisted: Boolean,
});

export const IssueArtifactValidator = Record({
  organisationName: String,
  resourceName: String,
  volumeNumber: String.Or(Null),
  issueNumber: String.Or(Null),
  publicationYear: Number.Or(Null),
  grouping: String,
  issueEdition: String.Or(Null),
  resourceId: String,
  files: Array(FileValidator),
  notes: Array(String).Or(Undefined),
  issueId: Number,
  publisherNote: String.Or(Null),
});

type IssueArtifact = Static<typeof IssueArtifactValidator>;
export default IssueArtifact;
