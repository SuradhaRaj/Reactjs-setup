interface OrganisationPathParams {
  partnerId: string;
};

export default OrganisationPathParams;
