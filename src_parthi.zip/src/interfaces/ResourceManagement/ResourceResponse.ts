import {
  Static, Record, Array,
} from 'runtypes';
import { ResourceValidator } from './Resource';
import { NumberGreaterZero } from '../../runtypeTypes';
import { OrganisationContactValidator } from '../Organisation/OrganisationContact';
import { OrganisationValidator } from './Organisation';

export const ResourceResponseValidator = Record({
  resource: ResourceValidator,
  organisation: OrganisationValidator,
  issueYears: Array(Record({ item1: NumberGreaterZero, item2: NumberGreaterZero })),
  contacts: Array(OrganisationContactValidator),
});

type ResourceResponse = Static<typeof ResourceResponseValidator>;
export default ResourceResponse;
