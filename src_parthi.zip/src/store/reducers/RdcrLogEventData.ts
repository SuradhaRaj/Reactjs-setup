import {
  ActionTypes, UPDATE_LOGEVENT_DATA,
} from '../actions/ActnLogEventData';
import LogEventData from '../../interfaces/Events/LogEventData';

export interface LogEventDataState {
  LogEventData: LogEventData;
}

export const initialState: LogEventDataState = {
  LogEventData: {
    logInfo: [],
  },
};

export default (state = initialState, action: ActionTypes): LogEventDataState => {
  switch (action.type) {
    case UPDATE_LOGEVENT_DATA:
      return {
        ...state,
        LogEventData: action.payload,
      };

    default:
      return state;
  }
};
