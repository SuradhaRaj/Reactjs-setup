import React from 'react';
import {
  TypographyProps, Typography, Link, LinkProps,
} from '@material-ui/core';
import CopyableTooltip from '../molecules/CopyableTooltipIconButton';

interface ContactDetailsDisplayProps {
  content: string | number | null | undefined;
  className?: string;
  contentTextProps?: TypographyProps;
  icon: JSX.Element;
  isLink?: boolean;
  linkProps?: LinkProps;
};

const CopyableTooltipIconWithContentText: React.FC<ContactDetailsDisplayProps> = (props) => (
  <>
    {props.content && (
      <div className={props.className}>
        <CopyableTooltip
          title={props.content}
          placement="top"
          arrow
          color="primary"
        >
          {props.icon}
        </CopyableTooltip>
        {props.isLink ? (
          <Link
            {...props.linkProps}
          >
            <Typography {...props.contentTextProps}>
              {props.content}
            </Typography>
          </Link>
        ) : (
          <Typography {...props.contentTextProps}>
            {props.content}
          </Typography>
        )}
      </div>
    )}
  </>
);

export default CopyableTooltipIconWithContentText;
