interface ReplaceArticleAArtifactRequest {
  artifactId: number;
  issuePath: string;
  filename: string;
  shouldRestartWorkflow: boolean;
};

export default ReplaceArticleAArtifactRequest;
