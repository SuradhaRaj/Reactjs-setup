/* eslint @typescript-eslint/no-explicit-any: 0 */
import React, { useState } from 'react';
import {
  createStyles, Typography, Divider, makeStyles, Theme,
} from '@material-ui/core';
import Grid from '@material-ui/core/Grid';
import { DateTime } from 'luxon';
import Scrollbars from 'react-custom-scrollbars';
import ReadOnlyTextField from '../../Shared/ReadOnlyTextField';
import Transcript from './Transcript';

import SwitchMediaPlayer from './SwitchMediaPlayer';

import WorkflowInfoDrawer from '../../organisms/WorkFlowInfoDrawer';
import MediaWorkflowInfo from '../MediaWorflowInfo';
import LuxonExtensions from '../../../utils/LuxonExtensions';
import MediaData from '../../../interfaces/MediaIndexer/MediaData';
import LogEventOption from '../../../interfaces/Events/LogEventOption';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    position: 'sticky',
    top: (props: MediaIndexerReadOnlyFieldsProps) => (props.mediaData.isReadOnly ? 60 : 16),
    paddingRight: '0px',
  },
  switchMediaPlayer: {
    height: '100%',
  },
  scrollArea: {
    marginTop: theme.spacing(2),
  },
}));

interface MediaIndexerReadOnlyFieldsProps {
  mediaData: MediaData;
  logInfo: LogEventOption[];
  switchJwtToken: string;
}

interface State {
  isVideoExpanded: boolean;
  scrollHeight: number;
}

const MediaIndexerReadOnlyFields = (props: MediaIndexerReadOnlyFieldsProps) => {
  const [state, setState] = useState<State>({
    isVideoExpanded: false,
    scrollHeight: 1000,
  });

  const classes = useStyles(props);

  function toggleResizeVideo() {
    setState((prevState: State) => ({
      isVideoExpanded: !prevState.isVideoExpanded,
      scrollHeight: prevState.isVideoExpanded ? 1000 : 880,
    }));
  };

  return (
    <Grid container className={classes.root}>
      <Grid container spacing={1}>
        <Grid item xs={9}>
          <Typography variant="h6" color="primary">{props.mediaData.mediaArtifactDocument.rmitNumber}</Typography>
        </Grid>
        <Grid item xs={3}>
          <WorkflowInfoDrawer content={(
            <MediaWorkflowInfo
              LogInfo={props.logInfo}
              WorkflowInfoItems={[
                {
                  labelText: 'External Id',
                  isDate: false,
                  value: props.mediaData.mediaArtifactDocument.externalId,
                },
                {
                  labelText: 'Media Id',
                  isDate: false,
                  value: props.mediaData.mediaArtifactDocument.videoId,
                },
                {
                  labelText: 'Video Content Id',
                  isDate: false,
                  value: props.mediaData.mediaArtifactDocument.videoContentId,
                },
                {
                  labelText: 'SM Program Id',
                  isDate: false,
                  value: props.mediaData.mediaArtifactDocument.smProgramId,
                },
                {
                  labelText: 'Original Id',
                  isDate: false,
                  value: props.mediaData.mediaArtifactDocument.originalId,
                },
                {
                  labelText: 'Site Id',
                  isDate: false,
                  value: props.mediaData.mediaArtifactDocument.siteId,
                },
                {
                  labelText: 'Repeat',
                  isDate: false,
                  value: props.mediaData.mediaArtifactDocument.isRepeat !== undefined && props.mediaData.mediaArtifactDocument.isRepeat ? 'Yes' : 'No',
                },
                {
                  labelText: 'VCMS Input Date',
                  isDate: true,
                  value: props.mediaData.mediaArtifactDocument.createdDate,
                },
                {
                  labelText: 'Encoding Start Date',
                  isDate: true,
                  value: props.mediaData.mediaArtifactDocument.encodeDate,
                },
                // {
                //  labelText: 'Availability',
                //  isDate: false,
                //  value: '',
                // },
                {
                  labelText: 'File Size',
                  isDate: false,
                  value: `${props.mediaData.mediaArtifactDocument.size?.toLocaleString()} B`,
                },
                {
                  labelText: 'Electronic Format Types',
                  isDate: false,
                  value: props.mediaData.electronicTypeFormat,
                },
                {
                  labelText: 'Media Type',
                  isDate: false,
                  value: props.mediaData.mediaArtifactDocument.mediaType,
                },
                {
                  labelText: 'Media File URL',
                  isDate: false,
                  value: props.mediaData.mediaArtifactDocument.uri,
                },
              ]}
            />
          )}
          />
        </Grid>
      </Grid>
      <Grid container spacing={1}>
        <Grid item xs={12}>
          <SwitchMediaPlayer
            JwtToken={props.switchJwtToken}
            VideoContentID={props.mediaData.mediaArtifactDocument.videoContentId}
            ClassName={classes.switchMediaPlayer}
            onVideoResize={toggleResizeVideo}
            isVideoExpanded={state.isVideoExpanded}
          />
        </Grid>

      </Grid>
      <Scrollbars autoHeight className={classes.scrollArea} autoHeightMax={state.scrollHeight}>
        <Grid container spacing={1} style={{ width: '100%' }}>
          <Grid item xs={12}>
            <Transcript labelText="Transcript" displayText={props.mediaData.mediaArtifactDocument.captions} />
          </Grid>
          <Grid item xs={12}>
            <Divider style={{ marginRight: 10 }} />
          </Grid>
          <Grid item xs={3}>
            <ReadOnlyTextField labelText="Media Type" displayText={props.mediaData.mediaArtifactDocument.mediaType} oneLine={false} />
          </Grid>

          <Grid item xs={3}>
            <ReadOnlyTextField labelText="Episode or Segment" displayText={props.mediaData.mediaArtifactDocument.assetType} oneLine={false} />
          </Grid>

          <Grid item xs={3}>
            <ReadOnlyTextField labelText="Program Id" displayText={props.mediaData.mediaArtifactDocument.smProgramId} oneLine={false} />
          </Grid>

          <Grid item xs={3}>
            <ReadOnlyTextField labelText="Episode Id" displayText={props.mediaData.mediaArtifactDocument.episodeId} oneLine={false} />
          </Grid>

          <Grid item xs={3}>
            <ReadOnlyTextField labelText="Repeat" displayText={props.mediaData.mediaArtifactDocument.isRepeat ? 'Yes' : 'No'} oneLine={false} />
          </Grid>

          {props.mediaData.mediaArtifactDocument.broadcastOn && (
          <Grid item xs={3}>
            <ReadOnlyTextField
              labelText="Date of Broadcast"
              displayText={DateTime.fromISO(props.mediaData.mediaArtifactDocument.broadcastOn).toFormat('d LLL yyyy h:mm a')}
              oneLine={false}
            />
          </Grid>
          )}

          {props.mediaData.mediaArtifactDocument.segmentBroadcastStart && (
          <Grid item xs={3}>
            <ReadOnlyTextField
              labelText="Segment Broadcast Start"
              displayText={DateTime.fromISO(props.mediaData.mediaArtifactDocument.segmentBroadcastStart).toFormat('d LLL yyyy h:mm:ss a')}
              oneLine={false}
            />
          </Grid>
          )}

          {props.mediaData.mediaArtifactDocument.segmentBroadcastEnd && (
          <Grid item xs={3}>
            <ReadOnlyTextField
              labelText="Segment Broadcast End"
              displayText={DateTime.fromISO(props.mediaData.mediaArtifactDocument.segmentBroadcastEnd).toFormat('d LLL yyyy h:mm:ss a')}
              oneLine={false}
            />
          </Grid>
          )}

          <Grid item xs={3}>
            <ReadOnlyTextField
              labelText="Duration"
              displayText={
                    LuxonExtensions.FormatDuration(
                      props.mediaData.mediaArtifactDocument.duration ? props.mediaData.mediaArtifactDocument.duration : 0,
                    )
                  }
              oneLine={false}
            />
          </Grid>

          <Grid item xs={3}>
            <ReadOnlyTextField labelText="Channel/Station" displayText={props.mediaData.mediaArtifactDocument.channel} oneLine={false} />
          </Grid>

          {props.mediaData.mediaArtifactDocument.programBroadcastStart && (
          <Grid item xs={3}>
            <ReadOnlyTextField
              labelText="Program Broadcast Start"
              displayText={DateTime.fromISO(props.mediaData.mediaArtifactDocument.programBroadcastStart).toFormat('d LLL yyyy h:mm a')}
              oneLine={false}
            />
          </Grid>
          )}

          {props.mediaData.mediaArtifactDocument.programBroadcastEnd && (
          <Grid item xs={3}>
            <ReadOnlyTextField
              labelText="Program Broadcast End"
              displayText={DateTime.fromISO(props.mediaData.mediaArtifactDocument.programBroadcastEnd).toFormat('d LLL yyyy h:mm a')}
              oneLine={false}
            />
          </Grid>
          )}

          <Grid item xs={3}>
            <ReadOnlyTextField labelText="Series Link" displayText={props.mediaData.mediaArtifactDocument.seriesLink} oneLine={false} />
          </Grid>

          <Grid item xs={3}>
            <ReadOnlyTextField labelText="Subtitles" displayText={props.mediaData.mediaArtifactDocument.hasSubtitles ? 'Yes' : 'No'} oneLine={false} />
          </Grid>

          <Grid item xs={3}>
            <ReadOnlyTextField labelText="Is Pay TV?" displayText={props.mediaData.mediaArtifactDocument.isPayTv ? 'Yes' : 'No'} oneLine={false} />
          </Grid>

          <Grid item xs={3}>
            <ReadOnlyTextField labelText="State" displayText={props.mediaData.workflowStatus} oneLine={false} />
          </Grid>

          {props.mediaData.mediaArtifactDocument.createdDate && (
            <Grid item xs={3}>
              <ReadOnlyTextField
                labelText="Created Date"
                displayText={DateTime.fromISO(props.mediaData.mediaArtifactDocument.createdDate).toFormat('d LLL yyyy h:mm a')}
                oneLine={false}
              />
            </Grid>
          )}
          {props.mediaData.mediaArtifactDocument.modifiedDate && (
            <Grid item xs={3}>
              <ReadOnlyTextField
                labelText="Last Modified Date"
                displayText={DateTime.fromISO(props.mediaData.mediaArtifactDocument.modifiedDate).toFormat('d LLL yyyy h:mm a')}

                oneLine={false}
              />
            </Grid>
          )}
        </Grid>
      </Scrollbars>
    </Grid>
  );
};

export default MediaIndexerReadOnlyFields;
