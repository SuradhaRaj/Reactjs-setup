import ResourceString from '../interfaces/res/ResourceString';

const strings: Array<ResourceString> = [
  { id: 1, message: "Title contains 'Editorial', did you mean for the Resource Type to be 'Editorial' or 'Journal Article'?" },
  { id: 2, message: "Title contains 'Obituary', did you mean for the Resource Type to be 'Obituary'?" },
  { id: 3, message: "Title contains 'Introduction' and/or 'Appendix', did you mean for the Resource Type to be 'Book'?" },
  { id: 4, message: "Title contains 'News' and/or 'Interview', did you mean for the Resource Type to be 'Interview'?" },
  { id: 5, message: "Title contains 'Introduction' and/or 'Appendix', did you mean for the Resource Type to be 'Conference Item'?" },
  { id: 6, message: 'Article Order has not been assigned' },
  { id: 7, message: "Title contains 'Introduction' and Article Order is greater than 5, is the Article Order correct?" },
  { id: 8, message: "Contributor is 'Reviewed By' and this article is peer reviewed" },
  { id: 9, message: 'This article is Peer Reviewed but no Contributors have been selected' },
  { id: 10, message: "This article is Peer Reviewed and Resource Type is set to 'Book Item', 'Conference Item' or 'Journal Item'" },
  { id: 11, message: "This article is Peer Reviewed and Resource Type is set to 'Book Review', or 'Review'" },
  { id: 12, message: "No Contributors or Pagination has been provided and Resource Type is 'Journal Article'" },
  { id: 13, message: "No Contributors are marked as 'Reviewed By' and Resource Type is 'Book Review'" },
  { id: 14, message: "No Contributors are assigned and Resource Type is 'Book Chapter'" },
  { id: 15, message: "No Contributors are assigned and Resource Type is 'Conference Paper'" },
  { id: 16, message: "An identifier contains a person's title (Sir, Professor, Dame or Dr)" },
  { id: 17, message: "Title includes 'Peer Reviewed' but is not marked as Peer Reviewed" },
  { id: 18, message: "A FAST Term contains '--Book Review' where Resource Type is 'Book Review', please ensure it has been correctly assigned" },
  { id: 19, message: "A FAST Term contains '--Fiction' where Genre is 'Fiction', please ensure it has been correctly assigned" },
  { id: 20, message: "A FAST Term contains 'Workshop' where Resource Type is 'Conference Paper' and Title contains 'Conference'" },
  { id: 21, message: "A FAST Term contains 'Competition', please ensure it has been correctly assigned" },
  { id: 22, message: "A FAST Term contains 'Awards', please ensure it has been correctly assigned" },
  { id: 23, message: "A FAST Term contains 'Bureau of Statistics', please ensure it has been correctly assigned" },
  { id: 24, message: "A FAST Term contains '--Statistics', please ensure it has been correctly assigned" },
  { id: 25, message: "A FAST Term contains '--Research', please ensure it has been correctly assigned" },
  { id: 26, message: "A FAST Term contains 'Associations', 'Institutions' and/or '--Membership', please ensure it has been correctly assigned" },
  { id: 27, message: "A FAST Term contains 'Australian Bureau of Statistics', please ensure it has been correctly assigned" },
];

export default strings;
