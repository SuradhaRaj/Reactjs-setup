import React, { useEffect, useState } from 'react';
import {
  Typography,
  Grid,
  Card,
  makeStyles,
} from '@material-ui/core';
import { useTypedSelector } from '../../../store/store';

import TextInputField from '../../Shared/TextInputField';

type NewType = boolean;

interface ConferenceProp {
  ConferenceDate: string;
  ConferenceName: string ;
  ConferenceNumber: string;
  ConferenceSponsor: string;
  ConferenceTheme: string;
}
// export interface Props {
//   isLoading: NewType;
//   childvalue: string;
//   // parentconference: ConferenceProp;
//  }
const useStyles = makeStyles({
  resourceIdeContainer: {
    paddingBottom: '20',
  },

  heading: {
    'font-size': '13px',
    'font-weight': '500',
    'text-transform': 'none',
    color: '#000000',
  },
});

function Conference(props: any): JSX.Element {
  const classes = useStyles();

  const getResourceData = useTypedSelector((store) => store.ResourceDataOnId);
  // const getReferenceData = useTypedSelector((store) => store.ResourceReferenceData);

  const [confstate, stateConfstate] = useState<ConferenceProp>({
    ConferenceDate: '',
    ConferenceName: '',
    ConferenceNumber: '',
    ConferenceSponsor: '',
    ConferenceTheme: '',
  });

  function ontextchange(e: React.FormEvent<HTMLInputElement>, control: string) {
    if (control === 'ConferenceDate') {
      stateConfstate((prev) => ({
        ...prev,
        ConferenceDate: e.currentTarget.value,
      }));
    } else if (control === 'ConferenceName') {
      stateConfstate((prev) => ({
        ...prev,
        ConferenceName: e.currentTarget.value,
      }));
    } else if (control === 'ConferenceNum') {
      stateConfstate((prev) => ({
        ...prev,
        ConferenceNumber: e.currentTarget.value,
      }));
    } else if (control === 'ConferenceSpon') {
      stateConfstate((prev) => ({
        ...prev,
        ConferenceSponsor: e.currentTarget.value,
      }));
    } else if (control === 'ConferenceTheme') {
      stateConfstate((prev) => ({
        ...prev,
        ConferenceTheme: e.currentTarget.value,
      }));
    }
    // props.callback({ confstate });
  }

  // const [protst, stateProtst] = useState<Props>({
  //   isLoading: false,
  //   childvalue: 'childval',
  //   parentconference: {
  //     ConferenceDate: '',
  //     ConferenceName: '',
  //     ConferenceNumber: '',
  //     ConferenceSponsor: '',
  //     ConferenceTheme: '',
  //   },
  // });

  useEffect(() => {
    const confDate: string = getResourceData.ResourceData.dateOfConference != null ? getResourceData.ResourceData.dateOfConference : 'date';
    const ConfName: string = getResourceData.ResourceData.nameOfConference != null ? getResourceData.ResourceData.nameOfConference : 'name';
    const ConfNumber: string = getResourceData.ResourceData.numberOfConference != null ? getResourceData.ResourceData.numberOfConference : 'number';
    const ConfSponsor: string = getResourceData.ResourceData.sponsorOfConference != null ? getResourceData.ResourceData.sponsorOfConference : 'sponsor';
    const ConfTheme: string = getResourceData.ResourceData.themeOfConference != null ? getResourceData.ResourceData.themeOfConference : 'theme';

    stateConfstate((prev) => ({
      ...prev,
      ConferenceDate: confDate,
      ConferenceName: ConfName,
      ConferenceNumber: ConfNumber,
      ConferenceSponsor: ConfSponsor,
      ConferenceTheme: ConfTheme,
    }));
  }, [getResourceData.ResourceData]);

  useEffect(() => {
    if (confstate.ConferenceDate !== '') props.callback(confstate);
  }, [confstate]);

  return (
    <Card
      variant="outlined"
      className="resourceIdeContainer"
      style={{
        marginLeft: 20,
        marginRight: 20,
        paddingBottom: 20,
        marginTop: 20,
      }}
    >
      <Grid item xs={12} style={{ textAlign: 'left' }}>
        <Typography
          className={classes.heading}
          variant="overline"
          style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
        >
          Conference
        </Typography>
      </Grid>
      <Grid
        container
        spacing={2}
        style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
      >
        <Grid item xs={3}>
          <div className="custominput mt0">
            <TextInputField
              keyName="eissn"
              labelText="Conference Date"
              inputText=""
              value={confstate.ConferenceDate}
              // onChangeFunction={(e: any) => e}
              //  onBlur={(e: React.FormEvent<HTMLInputElement>) => {
              //   // ontextchange(e, 'ConferenceDate');
              //   props.callback({ confstate });
              // }}
              onChangeFunction={(e: React.FormEvent<HTMLInputElement>) => {
                stateConfstate({
                  ...confstate,
                  ConferenceDate: e.currentTarget.value,
                });
              }}
              error={false}
            />
          </div>
        </Grid>
        <Grid item xs={6}>
          <div className="custominput mt0">
            <TextInputField
              keyName="eissn"
              labelText="Conference Name"
              value={confstate.ConferenceName}
              // inputText=""
              // onChangeFunction={(e: any) => e}
              onChangeFunction={(e: React.FormEvent<HTMLInputElement>) => {
                console.log(e.currentTarget.value);
                stateConfstate({
                  ...confstate,
                  ConferenceName: e.currentTarget.value,
                });
              }}
              // }}
              onBlur={(e: React.FormEvent<HTMLInputElement>) => {
                console.log(e);
                // props.callback({ confstate });
              }}
              error={false}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custominput mt0">
            <TextInputField
              keyName="eissn"
              labelText="Conference Number"
              inputText=""
              value={confstate.ConferenceNumber}
              // onChangeFunction={(e: any) => e}
              onChangeFunction={(e: React.FormEvent<HTMLInputElement>) => {
                stateConfstate({
                  ...confstate,
                  ConferenceNumber: e.currentTarget.value,
                });
              }}
              // onBlur={(e: React.FormEvent<HTMLInputElement>) => {
              //    //   ontextchange(e, 'ConferenceNum');
              //    props.callback({ confstate });
              //   }}
              error={false}
            />
          </div>
        </Grid>
        <Grid item xs={6}>
          <div className="custominput mt0">
            <TextInputField
              keyName="eissn"
              labelText="Conference Sponsor"
              inputText=""
              value={confstate.ConferenceSponsor}
              // onChangeFunction={(e: any) => e}
              onChangeFunction={(e: React.FormEvent<HTMLInputElement>) => {
                stateConfstate({
                  ...confstate,
                  ConferenceSponsor: e.currentTarget.value,
                });
              }}
              //  onBlur={(e: React.FormEvent<HTMLInputElement>) => {
              //  // ontextchange(e, 'ConferenceSpon');
              //  props.callback({ confstate });
              // }}
              error={false}
            />
          </div>
        </Grid>
        <Grid item xs={6}>
          <div className="custominput mt0">
            <TextInputField
              keyName="eissn"
              labelText="Conference Theme"
              inputText=""
              value={confstate.ConferenceTheme}
              // onChangeFunction={(e: any) => e}
              onChangeFunction={(e: React.FormEvent<HTMLInputElement>) => {
                stateConfstate({
                  ...confstate,
                  ConferenceTheme: e.currentTarget.value,
                });
              }}
              // onBlur={(e: React.FormEvent<HTMLInputElement>) => {
              //  // ontextchange(e, 'ConferenceTheme');
              //  props.callback({ confstate });
              // }}
              error={false}
            />
          </div>
        </Grid>
      </Grid>
    </Card>
  );
};

export default Conference;
