const informitBaseUrl = 'https://beta.informit.org';
export default informitBaseUrl;
