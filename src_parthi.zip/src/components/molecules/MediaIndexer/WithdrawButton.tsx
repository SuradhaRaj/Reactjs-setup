import React, { useState, useContext } from 'react';
import {
  createStyles, makeStyles, Typography,
} from '@material-ui/core';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import axios from 'axios';
import { useSnackbar } from 'notistack';
import { AppContext } from '../../Context';

const useStyles = makeStyles(createStyles({
  dialogText: {
    marginBottom: '20px',
  },
  button: {
    borderRadius: '50px',
    margin: 5,
  },
  userNote: {
    marginBottom: '15px',
  },
  notesContainer: {
    height: '700px',
    minWidth: '700px',
  },
  createdBy: {
    fontWeight: 600,
  },
  addButton: {
    top: '15px',
    float: 'right',
  },
}));

interface State {
  open: boolean;
}

interface Props {
  artifactId: number;
  onWithdrawCallback: Function;
}

const WithdrawButton = (props: Props): JSX.Element => {
  const classes = useStyles();
  const snackbar = useSnackbar();
  const context = useContext(AppContext);
  const [state, setState] = useState<State>({ open: false });

  const handleOpenDialog = (): void => {
    setState({
      ...state,
      open: true,
    });
  };

  const handleCloseDialog = (): void => {
    setState({
      ...state,
      open: false,
    });
  };

  const handleWithdraw = (): void => {
    handleCloseDialog();
    context.showBlockUi();
    axios.post(`${process.env.REACT_APP_API_URL}/api/artifact/withdrawartifact/${props.artifactId}`)
      .then(() => {
        props.onWithdrawCallback();
        snackbar.enqueueSnackbar('Artifact scheduled for withdrawal.', { variant: 'success' });
      })
      .catch(() => {
        snackbar.enqueueSnackbar('Unable to withdraw artifact.', { variant: 'error' });
      })
      .finally(() => {
        context.hideBlockUi();
      });
  };

  return (
    <>
      <Button
        variant="outlined"
        size="small"
        color="primary"
        className={classes.button}
        onClick={handleOpenDialog}
      >
        Withdraw
      </Button>
      <Dialog
        open={state.open}
        onClose={handleCloseDialog}
        aria-labelledby="form-dialog-title"
      >
        <DialogTitle id="form-dialog-title">Woah, hold up a second!</DialogTitle>
        <DialogContent>
          <Typography>Withdrawing this artifact will schedule it to be removed from public access.</Typography>
          <Typography>Are you sure you want to do this?</Typography>
        </DialogContent>
        <DialogActions>
          <Button color="primary" variant="outlined" onClick={handleCloseDialog}>
            Cancel
          </Button>
          <Button color="primary" onClick={handleWithdraw}>
            Withdraw
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default WithdrawButton;
