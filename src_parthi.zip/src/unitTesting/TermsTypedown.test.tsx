/* eslint-disable @typescript-eslint/no-empty-function */
import React from 'react';
import { mount, shallow } from 'enzyme';
import { CircularProgress } from '@material-ui/core';
import DocumentNodeStateEnum from '../interfaces/MediaIndexer/DocumentNodeStateEnum';
import { TermsTypedown } from '../components/molecules/MediaIndexer/TermsTypedown';

const wrapper = mount((
  <TermsTypedown
    selectedTerms={[{
      id: 1, name: 'Test 1', createdBy: '', createdDate: '', state: DocumentNodeStateEnum.SystemSuggested, isNew: false,
    },
    {
      id: 2, name: 'Test 2', createdBy: '', createdDate: '', state: DocumentNodeStateEnum.SystemSuggested, isNew: false,
    }]}
    topicSuggestions={['Test Suggestion 1', 'Test Suggestion 2']}
    keyName="fast"
    onChangeFunction={() => {}}
    countFunction={() => {}}
    disabled={false}
    error={false}
    classes={{}}
    fastAndIdentifierCount={3}
    fastAndIdentifierLimit={6}
  />
));

describe('Terms Typedown Tests', () => {
  it('should display suggested topics', () => {
    expect(
      wrapper.contains('Test Suggestion 1'),
    ).toBe(true);

    expect(
      wrapper.contains('Test Suggestion 2'),
    ).toBe(true);
  });

  it('should display terms passed into props', () => {
    expect(
      wrapper.contains('Test 1'),
    ).toBe(true);

    expect(
      wrapper.contains('Test 2'),
    ).toBe(true);
  });

  it('terms should be able to be deleted', () => {
    const wp = shallow((
      <TermsTypedown
        selectedTerms={[{
          id: 1, name: 'Test 1', createdBy: '', createdDate: '', state: DocumentNodeStateEnum.UserAdded, isNew: false,
        },
        {
          id: 2, name: 'Test 2', createdBy: '', createdDate: '', state: DocumentNodeStateEnum.UserAdded, isNew: false,
        }]}
        topicSuggestions={['Test Suggestion 1', 'Test Suggestion 2']}
        keyName="fast"
        onChangeFunction={() => {}}
        countFunction={() => {}}
        disabled={false}
        error={false}
        classes={{}}
        fastAndIdentifierCount={3}
        fastAndIdentifierLimit={6}
      />
    ));

    wp.find({ 'data-key': 'termChip1' }).simulate('delete');

    expect(
      wp.contains('Test 1'),
    ).toBe(false);
  });

  it('loading wheel should react to loading flag changes', () => {
    const wp = mount((
      <TermsTypedown
        selectedTerms={[]}
        topicSuggestions={[]}
        keyName="fast"
        onChangeFunction={() => {}}
        disabled={false}
        error={false}
        classes={{}}
        fastAndIdentifierCount={3}
        fastAndIdentifierLimit={6}
      />
    ));

    // loading should be hidden
    expect(wp.contains(<CircularProgress color="inherit" size={20} />)).toBeFalsy();

    // set loading to true
    wp.setState({ loading: true });

    // check is loading is shown
    expect(wp.contains(<CircularProgress color="inherit" size={20} />)).toBeTruthy();

    // set loading to false
    wp.setState({ loading: false });

    // check is loading is not shown
    expect(wp.contains(<CircularProgress color="inherit" size={20} />)).toBeFalsy();
  });

  it('should display the number of remaining options', () => {
    const wp = mount((
      <TermsTypedown
        selectedTerms={[]}
        topicSuggestions={[]}
        keyName="fast"
        onChangeFunction={() => {}}
        disabled={false}
        error={false}
        classes={{}}
        fastAndIdentifierCount={2}
        fastAndIdentifierLimit={6}
      />
    ));

    // number of remaining selections should be displayed
    expect(wp.find('[data-remaining]').text()).toBe('4');
  });
});
