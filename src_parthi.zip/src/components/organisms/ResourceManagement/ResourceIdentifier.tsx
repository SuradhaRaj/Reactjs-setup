import React, { useEffect, useState, Fragment } from 'react';
import {
  Typography, Grid, Card, Button, makeStyles,
} from '@material-ui/core';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import DeleteRoundedIcon from '@material-ui/icons/DeleteRounded';
import MenuIcon from '@material-ui/icons/Menu';
import { green, red } from '@material-ui/core/colors';
import { Alert, AlertTitle } from '@material-ui/lab';
import EditIcon from '@material-ui/icons/Edit';
import RemoveCircleIcon from '@material-ui/icons/RemoveCircle';
import TextInputField from '../../Shared/TextInputField';
import { TypedownOption, StrStrTypedownOption } from '../../../interfaces/TypedownOption';
import Typedown from '../Typedown';
import { useTypedSelector } from '../../../store/store';
import ValidateIssnIsbn from '../../../utils/ValidateIssnIsbn';

function createData({ UID, RI, Values }: {UID: number; RI: string; Values: Array<string | null> }) {
  return { UID, RI, Values };
}

type NewType = boolean;
interface Props {
  isLoading: NewType;
}
const useStyles = makeStyles({
  resourceIdeContainer: {
    paddingBottom: '20',
  },
  heading: {
    'font-size': '13px',
    'font-weight': '500',
    'text-transform': 'none',
    color: '#000000',
  },
  table: {
    minWidth: 650,
  },
});
interface SetUserResIdVal {
  selResIdentifier: TypedownOption | StrStrTypedownOption;
  setIdentifierVal: string;
}
interface EditData {
  ResCatagoryPos: number;
  ResCategoryValPos: number;
}
function ResourceIdentifier(props: any): JSX.Element {
  const classes = useStyles();
  const ResIdentifiers: Array<TypedownOption | StrStrTypedownOption> = ([
    { id: 1, value: 'ISBN' },
    { id: 2, value: 'eISBN' },
    { id: 3, value: 'ISSN' },
    { id: 4, value: 'eISSN' },
    { id: 5, value: 'Series ISSN' },
    { id: 6, value: 'Previous ISSN' },
    { id: 7, value: 'Later ISSN' },
    { id: 8, value: 'Digital Object Identifier' },
    { id: 9, value: 'Persistent Identifier' },
    { id: 10, value: 'Uniform Resource Identifier' },
  ]);
  const [StateResIdentifier, setStateResIdentifier] = useState<SetUserResIdVal>({
    selResIdentifier: { id: '', value: '' },
    setIdentifierVal: '',
  });
  const getResourceData = useTypedSelector((store) => store.ResourceDataOnId);
  const [rowsData, setrowsData] = useState<Array<{UID: number; RI: string; Values: Array<string | null>}>>(
    [],
  );
  const [buttonType, setButtonType] = useState<{buttonLable: string}>(
    {
      buttonLable: 'Add',
    },
  );
  const [dragData, setDragData] = useState<{dragItem: any;dragOverItem: any}>({
    dragItem: null,
    dragOverItem: null,
  });
  const [stateEdit, SetStateEdit] = useState<EditData>({
    ResCatagoryPos: -1,
    ResCategoryValPos: -1,
  });
  const [error, setError] = useState<{enable: boolean;msg: string}>({
    enable: false,
    msg: '',
  });
  useEffect(() => {
    const fromdata = getResourceData.ResourceData;
    setrowsData([]);
    const spChars = /[\[\]]/; // eslint-disable-line
    if (fromdata.issn !== null && fromdata.issn !== '') {
      let arrIssn: (Array<string | null>) = [];
      if (!spChars.test(fromdata.issn)) {
        arrIssn.push(fromdata.issn);
      } else {
        // arrIssn = fromdata.issn.replace(/\[|\]/g,'').split(',');
        // arrIssn = JSON.parse(JSON.stringify(fromdata.issn));
        arrIssn = JSON.parse(fromdata.issn.replace(/'/g, '"'));
      }
      setrowsData((current) => [...current, createData({ UID: 3, RI: 'ISSN', Values: arrIssn })]);
    }
    if (fromdata.eIssn !== null && fromdata.eIssn !== '') {
      let arrEISSN: (Array<string | null>) = [];
      if (!spChars.test(fromdata.eIssn)) {
        arrEISSN.push(fromdata.eIssn);
      } else {
        // arrEISSN = fromdata.eIssn.replace(/\[|\]/g,'').split(',');
        arrEISSN = JSON.parse(fromdata.eIssn.replace(/'/g, '"'));
      }
      setrowsData((current) => [...current, createData({ UID: 4, RI: 'eISSN', Values: arrEISSN })]);
    }
    if (fromdata.isbn !== null && fromdata.isbn !== '') {
      let arrISBN: (Array<string | null>) = [];
      if (!spChars.test(fromdata.isbn)) {
        arrISBN.push(fromdata.isbn);
      } else {
        // arrISBN = fromdata.isbn.replace(/\[|\]/g,'').split(',');
        arrISBN = JSON.parse(fromdata.isbn.replace(/'/g, '"'));
      }
      setrowsData((current) => [...current, createData({ UID: 1, RI: 'ISBN', Values: arrISBN })]);
    }
    if (fromdata.eIsbn !== null && fromdata.eIsbn !== '') {
      let arrEISBN: (Array<string | null>) = [];
      if (!spChars.test(fromdata.eIsbn)) {
        arrEISBN.push(fromdata.eIsbn);
      } else {
        // arrEISBN = fromdata.eIsbn.replace(/\[|\]/g,'').split(',');
        arrEISBN = JSON.parse(fromdata.eIsbn.replace(/'/g, '"'));
      }
      setrowsData((current) => [...current, createData({ UID: 2, RI: 'eISBN', Values: arrEISBN })]);
    }
    if (fromdata.seriesIssn !== null && fromdata.seriesIssn !== '') {
      let arrSERIES: (Array<string | null>) = [];
      if (!spChars.test(fromdata.seriesIssn)) {
        arrSERIES.push(fromdata.seriesIssn);
      } else {
        // arrSERIES = fromdata.seriesIssn.replace(/\[|\]/g,'').split(',');
        arrSERIES = JSON.parse(fromdata.seriesIssn.replace(/'/g, '"'));
      }
      setrowsData((current) => [...current, createData({ UID: 5, RI: 'Series ISSN', Values: arrSERIES })]);
    }
    if (fromdata.prevIssn !== null && fromdata.prevIssn !== '') {
      let arrPREV: (Array<string | null>) = [];
      if (!spChars.test(fromdata.prevIssn)) {
        arrPREV.push(fromdata.prevIssn);
      } else {
        // arrPREV = fromdata.prevIssn.replace(/\[|\]/g,'').split(',');
        arrPREV = JSON.parse(fromdata.prevIssn.replace(/'/g, '"'));
      }
      setrowsData((current) => [...current, createData({ UID: 6, RI: 'Previous ISSN', Values: arrPREV })]);
    }
    if (fromdata.laterIssn !== null && fromdata.laterIssn !== '') {
      let arrLATER: (Array<string | null>) = [];
      if (!spChars.test(fromdata.laterIssn)) {
        arrLATER.push(fromdata.laterIssn);
      } else {
        // arrLATER = fromdata.laterIssn.replace(/\[|\]/g,'').split(',');
        arrLATER = JSON.parse(fromdata.laterIssn.replace(/'/g, '"'));
      }
      setrowsData((current) => [...current, createData({ UID: 7, RI: 'Later ISSN', Values: arrLATER })]);
    }
    if (fromdata.doi !== null && fromdata.doi !== '') {
      let doi: (Array<string | null>) = [];
      if (!spChars.test(fromdata.doi)) {
        doi.push(fromdata.doi);
      } else {
        // doi = fromdata.doi.replace(/\[|\]/g,'').split(',');
        doi = JSON.parse(fromdata.doi.replace(/'/g, '"'));
      }
      setrowsData((current) => [...current, createData({ UID: 8, RI: 'Digital Object Identifier', Values: doi })]);
    }
    if (fromdata.persistentIdentifier !== null && fromdata.persistentIdentifier !== '') {
      let persistentIdentifier: (Array<string | null>) = [];
      if (!spChars.test(fromdata.persistentIdentifier)) {
        persistentIdentifier.push(fromdata.persistentIdentifier);
      } else {
        // persistentIdentifier = fromdata.persistentIdentifier.replace(/\[|\]/g,'').split(',');
        persistentIdentifier = JSON.parse(fromdata.persistentIdentifier.replace(/'/g, '"'));
      }
      setrowsData((current) => [...current, createData({ UID: 9, RI: 'Persistent Identifier', Values: persistentIdentifier })]);
    }
    if (fromdata.website !== null && fromdata.website !== '') {
      let website: (Array<string | null>) = [];
      if (!spChars.test(fromdata.website)) {
        website.push(fromdata.website);
      } else {
        // website = fromdata.website.replace(/\[|\]/g,'').split(',');
        website = JSON.parse(fromdata.website.replace(/'/g, '"'));
      }
      setrowsData((current) => [...current, createData({ UID: 10, RI: 'Uniform Resource Identifier', Values: website })]);
    }
  }, [getResourceData.ResourceData]);

  useEffect(() => {
    if (rowsData.length !== 0) { props.callback(rowsData); }
  }, [rowsData]);

  function addData() {
    let checkData = true;
    let istrue = true;
    if (StateResIdentifier.setIdentifierVal !== '' && StateResIdentifier.selResIdentifier.id !== '') {
      if (StateResIdentifier.selResIdentifier.value.toLowerCase().includes('issn')) {
        istrue = ValidateIssnIsbn.issnCheck(StateResIdentifier.setIdentifierVal.replace(/[^a-zA-Z0-9]/g, ''));
      } else if (StateResIdentifier.selResIdentifier.value.toLowerCase().includes('isbn')) {
        if (StateResIdentifier.setIdentifierVal.length === 10) {
          istrue = ValidateIssnIsbn.isbn10Check(StateResIdentifier.setIdentifierVal.replace(/[^a-zA-Z0-9]/g, ''));
        } else {
          istrue = ValidateIssnIsbn.isbn13Check(StateResIdentifier.setIdentifierVal.replace(/[^a-zA-Z0-9]/g, ''));
        }
      }
      if (istrue) {
        if (buttonType.buttonLable === 'Add') {
          rowsData.forEach((val) => {
            if (val.RI === StateResIdentifier.selResIdentifier.value) {
              val.Values.push(StateResIdentifier.setIdentifierVal);
              checkData = false;
            }
          });
          if (checkData === true) {
            const ID = +StateResIdentifier.selResIdentifier.id;
            const newRow = createData({ UID: ID, RI: StateResIdentifier.selResIdentifier.value, Values: [StateResIdentifier.setIdentifierVal] });
            setrowsData((prev) => [...prev, newRow]);
          } else {
            setrowsData((prev) => [...prev]);
            // alert("Resource Identifier is already exist. kindly use edit icon if need to be edit the value");
          }
        // rows.push(createData({ RI: StateResIdentifier.selResIdentifier.value, Values: StateResIdentifier.setIdentifierVal}));
        } else {
          rowsData[stateEdit.ResCatagoryPos].Values[stateEdit.ResCategoryValPos] = StateResIdentifier.setIdentifierVal;
          setrowsData((prev) => [...prev]);
          setButtonType({
            buttonLable: 'Add',
          });
          SetStateEdit({
            ResCatagoryPos: -1,
            ResCategoryValPos: -1,
          });
        }
        setStateResIdentifier({
          selResIdentifier: { id: '', value: '' },
          setIdentifierVal: '',
        });
        setError({
          enable: false,
          msg: '',
        });
      } else {
        setError({
          enable: true,
          msg: `${StateResIdentifier.selResIdentifier.value} is not a valid data`,
        });
        // alert(StateResIdentifier.selResIdentifier.value+" is not a valid ISSN or ISBN");
      }
    } else {
      setError({
        enable: true,
        msg: 'Kindly fill values',
      });
      // alert('Kindly fill values');
    }
  }
  function deleteData(getResCatPos: number, dataPos: number) {
    if (rowsData[getResCatPos].Values.length <= 1) {
      setrowsData((prev) => prev.filter((_, index) => index !== getResCatPos));
    } else {
      const updatedData = rowsData[getResCatPos].Values.filter((_, index) => index !== dataPos);
      rowsData[getResCatPos].Values = updatedData;
      setrowsData((prev) => [...prev]);
    }
  }
  function editData(getResCatID: number, val: string, catagoryPos: number, valuePos: number) {
    setButtonType({ buttonLable: 'Update' });
    setStateResIdentifier({
      selResIdentifier: ResIdentifiers.filter((obj) => obj.id === getResCatID)[0],
      setIdentifierVal: val,
    });
    SetStateEdit({
      ResCatagoryPos: catagoryPos,
      ResCategoryValPos: valuePos,
    });
  }
  const handleDrag = (catagoryID: number) => {
    const dupRowsData = [...rowsData];
    const draggedItem = dupRowsData[catagoryID].Values.splice(dragData.dragItem, 1)[0];
    dupRowsData[catagoryID].Values.splice(dragData.dragOverItem, 0, draggedItem);
    setDragData({
      dragItem: null,
      dragOverItem: null,
    });
    setrowsData(dupRowsData);
    // console.log('row--', rowsData);
  };
  return (
    <Card
      variant="outlined"
      className="resourceIdeContainer"
      style={{
        marginLeft: 20,
        marginRight: 20,
        paddingBottom: 20,
        marginTop: 20,
      }}
    >
      <Grid
        container
        spacing={2}
        style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
      >
        <Grid item xs={12} style={{ textAlign: 'left' }}>
          <Typography
            className={classes.heading}
            variant="overline"
            style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
          >
            Resource Identifiers
          </Typography>
        </Grid>
        <Grid item xs={6}>
          {error.enable
            ? (
              <Alert variant="outlined" severity="error">
                {error.msg}
              </Alert>
            ) : ''}
        </Grid>
      </Grid>

      <Grid
        container
        spacing={2}
        style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
      >
        <Grid item xs={3}>
          <div className="custom_autocomplete">
            <Typedown
              disabled={buttonType.buttonLable === 'Update'}
              isLoading={props.isLoading}
              label="Resource Identifier"
              options={ResIdentifiers}
              selectedValue={StateResIdentifier.selResIdentifier}
              onChange={(Options) => {
                setStateResIdentifier(
                  {
                    ...StateResIdentifier,
                    selResIdentifier: { id: +Options.id, value: Options.value },
                  },
                );
              }}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custominput">
            <TextInputField
              keyName="resIdentifierVal"
              labelText=""
              inputText=""
              onChangeFunction={(e: any) => setStateResIdentifier(
                {
                  ...StateResIdentifier,
                  setIdentifierVal: e.target.value,
                },
              )}
              error={false}
              value={StateResIdentifier.setIdentifierVal}
            />
          </div>
        </Grid>
        <Grid item xs={2}>
          <Button
            onClick={() => { addData(); }}
            color="primary"
            variant="outlined"
            className="addbutton"
          >
            {buttonType.buttonLable}
          </Button>
        </Grid>
      </Grid>
      <Grid xs={12} spacing={2}>
        <div className="custom_table">
          <TableContainer>
            <Table className={classes.table} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell>Resource Identifier</TableCell>
                  <TableCell align="left">Action</TableCell>
                  <TableCell align="left">Values</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {rowsData.map((row, ind) => (
                  <>
                    <TableRow key={row.UID}>
                      <TableCell rowSpan={row.Values.length + 1} component="th" scope="row">
                        {row.RI}
                      </TableCell>
                    </TableRow>
                    {row.Values.map((val, pos) => (
                      <TableRow
                        draggable
                        onDragStart={(e) => setDragData((prev) => ({
                          ...prev,
                          dragItem: pos,
                        }))}
                        onDragEnter={(e) => setDragData((prev) => ({
                          ...prev,
                          dragOverItem: pos,
                        }))}
                        onDragEnd={() => handleDrag(ind)}
                        onDragOver={(e) => e.preventDefault()}
                      >
                        <TableCell className="action_icon">
                          <Button
                            onClick={() => { editData(row.UID, val == null ? 'null' : val, ind, pos); }}
                          >
                            <EditIcon
                              style={{ color: green[500] }}
                              fontSize="small"
                            />
                          </Button>
                          <Button
                           // onClick={() => { }}
                            onClick={() => {
                              const confirmBox = window.confirm(
                                'Do you really want to delete this?',
                              );
                              if (confirmBox === true) {
                                deleteData(ind, pos);
                              }
                            }}
                          >
                            <RemoveCircleIcon
                              style={{ color: red[500] }}
                              fontSize="small"
                            />
                          </Button>
                        </TableCell>
                        <TableCell align="left">{val}</TableCell>
                      </TableRow>
                    ))}
                  </>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </div>
      </Grid>
    </Card>
  );
}

export default ResourceIdentifier;
