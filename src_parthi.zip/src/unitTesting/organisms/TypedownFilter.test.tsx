import React from 'react';
import { shallow } from 'enzyme';
import Skeleton from '@material-ui/lab/Skeleton';
import TypedownFilter from '../../components/organisms/TypedownFilter';

describe('Typedown filter', () => {
  it('should show the loading skeletons', () => {
    const wrapper = shallow(<TypedownFilter
      isLoading
      onChange={() => undefined}
      options={['Item1', 'Item2', 'Item3']}
      selectedOptions={[]}
      title="Some filter title"
    />);

    expect(wrapper.find(Skeleton).length).toBeGreaterThan(0);
  });
});
