/* eslint-disable @typescript-eslint/no-empty-function */
import React from 'react';
import { mount, shallow } from 'enzyme';
import { GeolocationsTypedown } from '../components/molecules/MediaIndexer/GeolocationsTypedown';
import DocumentNodeStateEnum from '../interfaces/MediaIndexer/DocumentNodeStateEnum';
import ArtifactType from '../interfaces/enums/ArtifactType';

const wrapper = mount(
  <GeolocationsTypedown
    selectedGeolocations={[{
      id: 1, name: 'Test 1', createdBy: '', createdDate: '', state: DocumentNodeStateEnum.UserAdded, isNew: false,
    },
    {
      id: 2, name: 'Test 2', createdBy: '', createdDate: '', state: DocumentNodeStateEnum.UserAdded, isNew: false,
    }]}
    locationSuggestions={['Test Suggestion 1', 'Test Suggestion 2']}
    keyName="fast"
    onChangeFunction={() => {}}
    disabled={false}
    error={false}
    classes={{}}
    typedownLimit={3}
    artifactTypeId={ArtifactType.Media}
  />,
);

describe('Geolocations Typedown Tests', () => {
  it('should display suggested topics', () => {
    expect(
      wrapper.contains('Test Suggestion 1'),
    ).toBe(true);

    expect(
      wrapper.contains('Test Suggestion 2'),
    ).toBe(true);
  });

  it('should display terms passed into props', () => {
    expect(
      wrapper.contains('Test 1'),
    ).toBe(true);

    expect(
      wrapper.contains('Test 2'),
    ).toBe(true);
  });

  it('terms should be able to be deleted', () => {
    const wp = shallow(
      <GeolocationsTypedown
        selectedGeolocations={[{
          id: 1, name: 'Test 1', createdBy: '', createdDate: '', state: DocumentNodeStateEnum.UserAdded, isNew: false,
        },
        {
          id: 2, name: 'Test 2', createdBy: '', createdDate: '', state: DocumentNodeStateEnum.UserAdded, isNew: false,
        }]}
        locationSuggestions={['Test Suggestion 1', 'Test Suggestion 2']}
        keyName="fast"
        onChangeFunction={() => {}}
        disabled={false}
        error={false}
        classes={{}}
        typedownLimit={3}
        artifactTypeId={ArtifactType.Media}
      />,
    );
    wp.find({ 'data-key': 'geoChip1' }).simulate('delete');

    expect(
      wp.contains('Test 1'),
    ).toBe(false);
  });

  it('loading wheel should react to loading flag changes', () => {
    const wp = mount((
      <GeolocationsTypedown
        selectedGeolocations={[]}
        locationSuggestions={[]}
        keyName="fast"
        onChangeFunction={() => {}}
        disabled={false}
        error={false}
        classes={{}}
        typedownLimit={3}
        artifactTypeId={ArtifactType.Media}
      />
    ));

    // loading should be hidden
    expect(wp.find('.MuiCircularProgress-svg')).toHaveLength(0);

    // set loading to true
    wp.setState({ loading: true });

    // check is loading is shown
    expect(wp.find('.MuiCircularProgress-svg')).toHaveLength(1);

    // set loading to false
    wp.setState({ loading: false });

    // check is loading is not shown
    expect(wp.find('.MuiCircularProgress-svg')).toHaveLength(0);
  });
});
