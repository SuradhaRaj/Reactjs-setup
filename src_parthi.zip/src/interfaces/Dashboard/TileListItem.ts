interface TileListItem {
    name: string;
    value: number | string;
};

export default TileListItem;
