import React from 'react';
import { mount } from 'enzyme';
import Transcript from '../components/molecules/MediaIndexer/Transcript';

const wrapper = mount(
  <Transcript labelText="This is a test label" displayText="This is test display text" />,
);

describe('Transcript Tests', () => {
  it('should display label that is passed into props', () => {
    expect(
      wrapper.contains('This is a test label'),
    ).toBe(true);
  });

  it('should display display text that is passed into props', () => {
    expect(
      wrapper.contains('This is test display text'),
    ).toBe(true);
  });
});
