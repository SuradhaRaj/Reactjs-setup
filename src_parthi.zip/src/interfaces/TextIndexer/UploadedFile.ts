import FileUploadStatus from '../enums/FileUploadStatus';

export default interface UploadedFile {
  name: string;
  status: FileUploadStatus;
  filetype: string|null;
  pageCount: number;
  errorMessages: string[];
  isDeleting?: boolean;
// eslint-disable-next-line semi
};
