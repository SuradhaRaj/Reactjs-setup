import {
  Static, Record, Number, String, Boolean, Null,
} from 'runtypes';
import { IsoDate, NumberGreaterZero } from '../../runtypeTypes';

export const LicenceTemplateValidator = Record({
  licenceTemplateId: NumberGreaterZero,
  ielcopyright: String.Or(Null),
  // copyrightClearedDate: IsoDate.Or(Null),
  clearanceStatusId: Number.Or(Null),
  contractStartDate: IsoDate.Or(Null),
  contractEndDate: IsoDate.Or(Null),
  ppvavailable: Boolean,
  agreementNumber: String,
  embargoPeriod: Number.Or(Null),
  price: Number,
  royaltiesDue: Boolean.Or(Null),
  clearedById: Number.Or(Null),
  royaltyRate: Number.Or(Null),
  archiveRoyaltyRate: Number.Or(Null),
  noticePeriod: Number.Or(Null),
  archivalPeriod: Number.Or(Null),
  // archivePeriodStartDate: IsoDate.Or(Null),
  terminationNote: String.Or(Null),
  // noticeProvidedDate: IsoDate.Or(Null),
  individualSubscriptions: Boolean,
  cclicenceTypeId: Number.Or(Null),
  // isOpenAccess: Boolean,
  accessRightId: Number.Or(Null),
  perpetualAccess: Boolean,
  accessTypeId: Number.Or(Null),
});

type LicenceTemplate = Static<typeof LicenceTemplateValidator>;

export default LicenceTemplate;
