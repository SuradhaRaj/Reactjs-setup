import React, { useEffect, useState } from 'react';
import {
  Typography,
  Grid,
  Card,
  makeStyles,
} from '@material-ui/core';
import TextInputField from '../../Shared/TextInputField';
import { useTypedSelector } from '../../../store/store';

interface ResIPublisher {
  publisherName: string | null;
  publisherDisplay: string | null;
  publisherPlace: string | null;
  publisherDate: string | null;
}
type NewType = boolean;
interface Props {
  isLoading: NewType;
}
const useStyles = makeStyles({
  resourceIdeContainer: {
    paddingBottom: '20',
  },
  heading: {
    'font-size': '13px',
    'font-weight': '500',
    'text-transform': 'none',
    color: '#000000',
  },
});

function Publisher(props: any): JSX.Element {
  const classes = useStyles();
  const getResourceData = useTypedSelector((store) => store.ResourceDataOnId);
  const [publisher, setPublisher] = useState<ResIPublisher>({
    publisherName: null,
    publisherDisplay: null,
    publisherPlace: null,
    publisherDate: null,
  });

  function ontextchange(e: React.FormEvent<HTMLInputElement>, control: string) {
    if (control === 'PlaceofPub') {
      setPublisher({
        ...publisher,
        publisherPlace: e.currentTarget.value,
      });
    } else if (control === 'NameofPub') {
      setPublisher({
        ...publisher,
        publisherName: e.currentTarget.value,
      });
    } else if (control === 'PubDisplay') {
      setPublisher({
        ...publisher,
        publisherDisplay: e.currentTarget.value,
      });
    } else if (control === 'PubDisplay') {
      setPublisher({
        ...publisher,
        publisherDate: e.currentTarget.value,
      });
    }
    props.callback(publisher);
  }

  useEffect(() => {
    const fromdata = getResourceData.ResourceData;
    setPublisher((prevState) => ({
      ...prevState,
      publisherName: fromdata.nameOfPublisher,
      publisherDisplay: fromdata.nameOfPublisherDisplay,
      publisherPlace: fromdata.placeOfPublication,
      publisherDate: fromdata.dateOfPublication,
    }));
  }, [getResourceData.ResourceData]);

  useEffect(() => {
    if (publisher.publisherName !== '') props.callback(publisher);
  }, [publisher]);

  return (
    <Card
      variant="outlined"
      className="resourceIdeContainer"
      style={{
        marginLeft: 20,
        marginRight: 20,
        paddingBottom: 20,
        marginTop: 20,
      }}
    >
      <Grid item xs={12} style={{ textAlign: 'left' }}>
        <Typography
          className={classes.heading}
          variant="overline"
          style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
        >
          Publisher
        </Typography>
      </Grid>
      <Grid
        container
        spacing={2}
        style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
      >
        <Grid item xs={3}>
          {/* <div className="custom_autocomplete">
            <TypedownFilter
              isLoading={props.isLoading}
              title="Place of Publication"
              options={publisher.publisherPlace}
              selectedOptions={taskManagement.Filters.data.title}
              onChange={(options) => {
                changeFilter("title", options as string[]);
              }}
            />
          </div> */}
          <div className="custominput mt0">
            <TextInputField
              keyName="place"
              labelText="Place of Publication"
              value={publisher.publisherPlace}
              onChangeFunction={(e: React.FormEvent<HTMLInputElement>) => {
                ontextchange(e, 'PlaceofPub');
              }}
              error={false}
            />
          </div>
        </Grid>
        <Grid item xs={4}>
          <div className="custominput mt0">
            <TextInputField
              keyName="name"
              labelText="Name of Publisher"
              value={publisher.publisherName}
              onChangeFunction={(e: React.FormEvent<HTMLInputElement>) => {
                ontextchange(e, 'NameofPub');
              }}
              error={false}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          {/* <div className="custom_autocomplete">
            <TypedownFilter
              isLoading={props.isLoading}
              title="Publisher Display"
              options={publisher.publisherDisplay}
              selectedOptions={taskManagement.Filters.data.title}
              onChange={(options) => {
                changeFilter("title", options as string[]);
              }}
            />
          </div> */}
          <div className="custominput mt0">
            <TextInputField
              keyName="display"
              labelText="Publisher Display"
              value={publisher.publisherDisplay}
              onChangeFunction={(e: React.FormEvent<HTMLInputElement>) => {
                ontextchange(e, 'PubDisplay');
              }}
              error={false}
            />
          </div>
        </Grid>
        <Grid item xs={2}>
          {/* <div className="customdatepicker">
            <InlineDatePicker
              labelText="Date of Publication"
              value = {'06/06/1995'}
            />
          </div> */}
          <div className="custominput mt0">
            <TextInputField
              keyName="display"
              labelText="Date of Publication"
              value={publisher.publisherDate}
              onChangeFunction={(e: React.FormEvent<HTMLInputElement>) => {
                ontextchange(e, 'DateofPub');
              }}
              error={false}
            />
          </div>
        </Grid>
      </Grid>
    </Card>
  );
}

export default Publisher;
