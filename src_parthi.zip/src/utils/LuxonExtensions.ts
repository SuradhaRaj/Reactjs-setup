import { DateTime, Duration, DurationObject } from 'luxon';

const ToFriendlyDateString = (dateTime: DateTime): string => {
  const startOfToday = DateTime.local().startOf('day');
  const startOfYesterday = DateTime.local().startOf('day').minus({ day: 1 });

  if (dateTime >= startOfToday) {
    return `Today, ${dateTime.toFormat('h:mma')}`;
  }
  if (dateTime >= startOfYesterday) {
    return `Yesterday, ${dateTime.toFormat('h:mma')}`;
  }

  return dateTime.toFormat('d LLL yyyy  h:mma');
};

const FormatDuration = (seconds: number) => {
  const duration = Duration.fromMillis(seconds * 1000);
  const durationObj: DurationObject = duration.shiftTo('hours', 'minutes', 'seconds').toObject();

  let durationString = '';

  if (durationObj !== undefined) {
    if (durationObj.hours && durationObj.hours > 0) {
      durationString += `${durationObj.hours}h `;
    }

    if (durationObj.minutes && durationObj?.minutes > 0) {
      durationString += `${durationObj.minutes}m `;
    }

    if (durationObj.seconds && durationObj?.seconds > 0) {
      durationString += `${durationObj.seconds}s `;
    }
  }
  return durationString.trim();
};

const ToFriendlyDateStringNull = (dateTime: DateTime | null, nullPlaceholder: string) => {
  if (dateTime === null) { return nullPlaceholder; }
  return ToFriendlyDateString(dateTime);
};

const isValidISO = (iso: string): boolean => {
  const dateiso = DateTime.fromISO(iso);
  return dateiso.isValid;
};

export default {
  ToFriendlyDateString,
  ToFriendlyDateStringNull,
  FormatDuration,
  isValidISO,
};
