import React from 'react'; // { useState }
import AccountCircle from '@material-ui/icons/AccountCircle';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/IconButton';
import {
  makeStyles, createStyles, Theme, Menu, MenuItem,
} from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import LockOpen from '@material-ui/icons/LockOpen';
// import { useMsal } from '@azure/msal-react';
import { AppContext } from '../Context';

const useStyles = makeStyles((theme: Theme) => createStyles({
  typography: {
    marginLeft: theme.spacing(1),
  },
}));

export default function LoginStatus(): JSX.Element {
  // const [isSignoutShown, setSignoutShown] = useState(false);
  const classes = useStyles();

  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>): void => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = (): void => {
    setAnchorEl(null);
  };

  // const { instance } = useMsal();

  function handleLogout() {
    window.location.href = '/Signout';
  };

  return (
    <AppContext.Consumer>
      {(context) => (
        <>
          <Button
            edge="end"
            aria-label="account of current user"
            aria-haspopup="true"
            color="inherit"
            onClick={handleClick}
          >
            <AccountCircle />
            <Typography className={classes.typography}>{context.userInfo.data.name}</Typography>
            <ExpandMoreIcon />
          </Button>
          <Menu
            id="simple-menu"
            anchorEl={anchorEl}
            keepMounted
            open={Boolean(anchorEl)}
            onClose={handleClose}
            style={{ top: '64px', right: '0px' }}
          >
            <MenuItem onClick={handleLogout}>
              <LockOpen />
              {/* {isSignoutShown && <Signout />} */}
              <Typography className={classes.typography}>Logout</Typography>
            </MenuItem>
          </Menu>
        </>
      )}

    </AppContext.Consumer>
  );
}
