import React, { useState, useEffect } from 'react';
import {
  makeStyles, createStyles,
  Grid, Theme, Breadcrumbs, Typography,
} from '@material-ui/core';

import { useParams, useRouteMatch } from 'react-router-dom';
import Axios from 'axios';
import { useDispatch } from 'react-redux';
import RootIssue from '../organisms/IssueManagement/RootIssue';
import RootIssueAdd from '../organisms/IssueManagement/RootIssueAdd';
import { default as IssueType } from '../../interfaces/IssueManagement/Issue';
import IssueResponse, { IssueResponseValidator } from '../../interfaces/IssueManagement/IssueResponse';
import ErrorPaper from '../organisms/ErrorPaper';
import useRuntypeError from '../hooks/useRuntypeError';
import IssueReferenceData, { IssueReferenceDataValidator } from '../../interfaces/IssueManagement/IssueReferenceData';
import { updateIssueReferenceData } from '../../store/actions/ActnIssueReferenceData';
import EventHelper from '../../utils/EventHelper';

interface State {
    isLoading: boolean;
    hasError: boolean;
    data: IssueResponse;
    errorCode: number;
}

const ISSUE_ADD_MODE_ROUTE_MATCH = '/resources/:resId/addIssue';

export default function Issue() {
  const match = useRouteMatch({
    path: ISSUE_ADD_MODE_ROUTE_MATCH,
    strict: true,
    sensitive: true,
  });
    // add mode using resID
  const isAddMode = !!(match && match.isExact);
  const { resId } = useParams();

  // edit mode
  const { issueId } = useParams();
  const issueResponse = useRuntypeError(IssueResponseValidator);
  const dispatch = useDispatch();
  const referenceDataValidator = useRuntypeError(IssueReferenceDataValidator);

  const useStyles = makeStyles((theme: Theme) => createStyles({
    nav: {
      position: 'absolute',
      top: theme.spacing(-6),
      left: theme.spacing(2),
    },
  }));
  const classes = useStyles();

  const [state, setState] = useState<State>({
    isLoading: false,
    hasError: false,
    data: {} as IssueResponse,
    errorCode: 0,
  });

  useEffect(() => {
    if (isAddMode) { return undefined; }
    setState((prevState) => ({ ...prevState, isLoading: true }));
    const IssueRequest = Axios.get<IssueResponse>(`${process.env.REACT_APP_API_URL}/api/issue/${issueId}`);
    const referenceDataRequest = Axios.get<IssueReferenceData>(`${process.env.REACT_APP_API_URL}/api/issue/referencedata`);

    const updateIssueHandler = (evt: CustomEvent) => {
      // console.log('event', event.detail);
      if (issueId !== evt.detail.EntityId.toString()) { return; }// prevent wrong trigger.
      console.info('update-issue');

      // console.log(event.detail);
    };

    EventHelper.on('update-issue', updateIssueHandler);

    Promise.all([referenceDataRequest, IssueRequest]).then((
      [referenceDataResp, issueResp],
    ) => {
      const data: IssueResponse = issueResp.data;
      if (referenceDataValidator.validate(referenceDataResp.data)) {
        dispatch(updateIssueReferenceData(referenceDataResp.data));
      }
      setState((prevState) => ({
        ...prevState,
        data,
      }));
    }).catch((err) => {
      let errorCode = 0;
      if (err.response.status) {
        errorCode = err.response.status;
      }
      setState((prevState) => ({
        ...prevState,
        hasError: true,
        errorCode,
      }));
    }).finally(() => {
      setState((prevState) => ({
        ...prevState,
        isLoading: false,
      }));
    });

    return () => {
    //  // Anything in here is fired on component unmount.
      EventHelper.off('update-issue', updateIssueHandler);
    //  // console.log('event off');
    };
  }, []);

  const updateIssue = (issue: IssueType) => {
    setState((prevState) => ({
      ...prevState,
      data: {
        ...prevState.data,
        issue: {
          ...issue,
        },
      },
    }));
  };

  if (isAddMode) {
    if (!Number(resId)) {
      return (<div data-testid="genericError"><ErrorPaper text="Can not add Issue" /></div>);
    }
  } else {
    if (!issueResponse.isValid) {
      return issueResponse.error();
    }
    if (state.hasError) {
      if (state.errorCode === 404) {
        return (<div data-testid="404Error"><ErrorPaper text="The specified resource does not exist" /></div>);
      }

      return (<div data-testid="genericError"><ErrorPaper text="Unable to load resource" /></div>);
    }
  }

  return (
    <Grid container justify="center" style={{ position: 'relative' }}>

      {!isAddMode && !state.isLoading && state.data.issue && state.data.issue.issueId && (
        <Breadcrumbs className={classes.nav}>
          <Typography>{`${state.data.issue.issueId}:${state.data.issue.grouping}:${state.data.issue.resouceName}`}</Typography>
        </Breadcrumbs>
      )}

      <Grid item xs={10} lg={8}>

        {!isAddMode && state.data.issue && (
        <RootIssue
          data={state.data}
          updateIssue={updateIssue}
          isLoading={state.isLoading}
        />
        )}

        {
                    isAddMode && (
                    <RootIssueAdd
                      resourceId={Number(resId)}
                      updateIssue={updateIssue}
                      isLoading={state.isLoading}
                    />
                    )
                }

      </Grid>
    </Grid>
  );
}
