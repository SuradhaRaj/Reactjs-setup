/* eslint-disable max-len */
import React from 'react';
import {
  Record, Static, Array,
} from 'runtypes';
import Axios from 'axios';
import { debounce } from 'lodash';
import AuthorOption, { AuthorOptionValidator } from '../../../interfaces/TextIndexer/AuthorOption';
import TypedownOption from '../../../interfaces/TypedownOption';
import Typedown from '../Typedown';
import ArticleDocumentAuthor from '../../../interfaces/TextIndexer/ArticleDocumentAuthor';

const SearchAuthorResponseValidator = Record({ results: Array(AuthorOptionValidator) });
type SearchAuthorResponse = Static<typeof SearchAuthorResponseValidator>;

export const getAuthorName = (name: ArticleDocumentAuthor | AuthorOption): string => {
  let result = name.firstName;

  if (name.middleName !== null && name.middleName !== '') {
    result += ` ${name.middleName}`;
  }

  result += ` ${name.lastName}`;

  if (name.orcidCode !== null && name.orcidCode !== '') {
    result += ` (${name.orcidCode})`;
  }

  return result;
};

interface AuthorTypedownProps {
  selectedOption?: TypedownOption;
  onSelectHandler(author?: AuthorOption): void;
  isLegal: boolean;
  readonly?: boolean;
}

interface AuthorTypedownState {
  loading: boolean;
  authorOptions: AuthorOption[];
}

const AuthorTypedown = (props: AuthorTypedownProps) => {
  const [state, setState] = React.useState<AuthorTypedownState>({
    loading: false,
    authorOptions: [],
  });

  const getAuthorOptions = debounce((data: string) => {
    setState({
      ...state,
      loading: true,
    });

    Axios.get<SearchAuthorResponse>(`${process.env.REACT_APP_API_URL}/api/indexing/searchauthor?searchTerm=${data}`, { params: { isLegal: props.isLegal } })
      // populate options
      .then((response) => {
        // SearchAuthorResponseValidator.check(response.data);
        setState((prevState) => ({
          ...prevState,
          authorOptions: response.data.results,
        }));
      })
      .catch(() => setState((prevState) => ({
        ...prevState,
        authorOptions: [],
      })))
      .finally(() => {
        setState((prevState) => ({
          ...prevState,
          loading: false,
        }));
      });
  }, 300);

  const onSelect = (selectedOption: TypedownOption) => {
    const selectedAuthor = state.authorOptions.find((option) => option.authorId === selectedOption.id);
    props.onSelectHandler(selectedAuthor);
  };

  return (
    <Typedown
      options={state.authorOptions.map((option) => ({ value: getAuthorName(option), id: option.authorId }))}
      onInputChange={getAuthorOptions}
      filterOptions={(x) => x}
      selectedValue={props.selectedOption}
      allowMultiple={false}
      onChange={onSelect}
      autoSelect
      label="Personal Author"
      showLoadingSpinner={state.loading}
      disabled={props.readonly}
    />
  );
};

export default AuthorTypedown;
