import {
  Record, Static,
} from 'runtypes';
import { ResourceIssueValidator } from './ResourceIssueData';
import { ArrayWithElements } from '../../runtypeTypes';

export const ResourceIssueListValidator = Record({
  issues: ArrayWithElements(ResourceIssueValidator),
});

type ResourceIssueListData = Static<typeof ResourceIssueListValidator>;
export default ResourceIssueListData;
