/* eslint @typescript-eslint/no-explicit-any: 0 */
import React from 'react';
import axios from 'axios';
import _ from 'lodash';
import {
  Grid, Chip, Zoom, createStyles, withStyles, WithStyles, Typography, TextField, CircularProgress,
} from '@material-ui/core';
import Autocomplete, { AutocompleteRenderOptionState } from '@material-ui/lab/Autocomplete';
import match from 'autosuggest-highlight/match';
import parse from 'autosuggest-highlight/parse';
import AddCircleIcon from '@material-ui/icons/AddCircle';
import TypedownCounter from '../../atoms/TypedownCounter';

import DocumentFastNode from '../../../interfaces/MediaIndexer/DocumentFastNode';
import DocumentNodeStateEnum from '../../../interfaces/MediaIndexer/DocumentNodeStateEnum';
import { TypedownDebounceTime } from '../../../constants/MediaIndexerConstants';
import ExpandedSearchDialogBox from '../../organisms/ExpandedSearchDialogBox';
import StringExtensions from '../../../utils/StringExtensions';

const useStyles = createStyles({
  typedownContainer: {
    width: '100%',
    position: 'relative',
  },
  geolocationsInput: {
    width: '100%',
  },
  geolocationsTextField: {
    marginTop: '0px',
  },
  locationsContainer: {
    textAlign: 'left',
    marginTop: 5,
  },
  addButton: {
    position: 'absolute',
    top: '530px',
    left: '1125px',
  },
  suggestionsHeader: {
    textAlign: 'left',
  },
  suggestionsContainer: {
    textAlign: 'left',
  },
  chip: {
    marginRight: '5px',
    marginBottom: '5px',
  },
  renderOptionHighlighted: {
    fontWeight: 550,
  },
});

interface State {
  geolocationOptions: GeolocationOption[];
  loading: boolean;
  expandedSearchDialogOpen: boolean;
}

interface GeolocationsTypedownProps {
  selectedGeolocations: DocumentFastNode[];
  locationSuggestions: string[];
  keyName: string;
  artifactTypeId: number;
  onChangeFunction(key: string, value: DocumentFastNode[]): void;
  disabled?: boolean;
  error: boolean;
  errorText?: string | undefined;
  typedownLimit: number;
  classes: any;
  readOnly?: boolean;
}

interface GeolocationOption {
  id: number;
  name: string;
  count: number;
}

export class GeolocationsTypedown extends React.Component<GeolocationsTypedownProps & WithStyles<typeof useStyles>, State, {}> {
  constructor(props: GeolocationsTypedownProps) {
    super(props);
    this.handleGeoocationChange = _.debounce(this.handleGeoocationChange, TypedownDebounceTime);
    this.handleGeoocationChange = this.handleGeoocationChange.bind(this);
    this.addGeolocationToList = this.addGeolocationToList.bind(this);
    this.handleDeleteLocation = this.handleDeleteLocation.bind(this);
    this.clearTypedownOptions = this.clearTypedownOptions.bind(this);
    this.renderChips = this.renderChips.bind(this);
    this.renderSuggestions = this.renderSuggestions.bind(this);
    this.makeGeolocationAvailable = this.makeGeolocationAvailable.bind(this);
    this.addGeolocationFromExpandedSearch = this.addGeolocationFromExpandedSearch.bind(this);

    this.state = { geolocationOptions: [], loading: false, expandedSearchDialogOpen: false };
  }

  getGeolocations(searchTerm: string): Promise<GeolocationOption[]> {
    const returnList: GeolocationOption[] = [];

    const suggestionsPromise = new Promise<GeolocationOption[]>((resolve, reject) => {
      this.setState((prevState) => ({
        ...prevState,
        loading: true,
        geolocationOptions: [],
      }));

      fetch(`${process.env.REACT_APP_API_URL}/api/Indexing/searchfastgeo?searchTerm=${searchTerm}&artifactTypeId=${this.props.artifactTypeId}`)
        .then((res) => res.json())
        .then(
          (result) => {
            if (result.status === 200) {
              for (let i = 0; i < result.results.length; i += 1) {
                returnList.push({
                  id: result.results[i].fastID,
                  name: result.results[i].name,
                  count: result.results[i].count,
                });
              }

              // Add the expanded search option to the bottom of the list
              returnList.push({
                id: 0,
                name: 'Search from all FAST Geolocations...',
                count: 0,
              });
            }
            resolve(returnList);
          },
          (error: Error) => {
            reject(error);
          },
        )
        .then(() => {
          this.setState((prevState) => ({
            ...prevState,
            loading: false,
          }));
        });
    });

    return suggestionsPromise;
  }

  getOptionRender(option: GeolocationOption, renderOptionState: AutocompleteRenderOptionState): JSX.Element {
    if (option.id === 0) {
      return (
        <>
          <Grid item xs={12}>
            <span>{option.name}</span>
          </Grid>
        </>
      );
    }

    const matches = match(option.name, renderOptionState.inputValue);
    const parts = parse(option.name, matches);
    const { classes } = this.props;

    return (
      <>
        <Grid item xs={12}>
          {parts.map((part) => (
            <span className={part.highlight ? classes.renderOptionHighlighted : ''}>
              {/* If the first character of a non-matched part is a non-ascii character, do not render it. */}
              {part.text && StringExtensions.RemoveInitialNonAscii(part.text)}
            </span>
          ))}
        </Grid>
      </>
    );
  }

  handleDeleteLocation = (geolocationToDelete: DocumentFastNode) => () => {
    // If this was a historic geolocation then we want to change it's state to user removed, otherwise delete the golocation outright
    if (!geolocationToDelete.isNew) {
      const newList: DocumentFastNode[] = this.props.selectedGeolocations.filter((geolocation) => geolocation.id !== geolocationToDelete.id);

      newList.push(geolocationToDelete);
      newList[newList.length - 1] = {
        ...newList[newList.length - 1],
        state: DocumentNodeStateEnum.UserRemoved,
      };
      this.props.onChangeFunction(this.props.keyName, newList);
    } else {
      const newList: DocumentFastNode[] = this.props.selectedGeolocations.filter((geolocation) => geolocation.id !== geolocationToDelete.id);
      this.props.onChangeFunction(this.props.keyName, newList);
    }
  }

  makeGeolocationAvailable = (id: number): boolean => {
    // Makes a post to make the selected geolocation available, returns TRUE if successful
    let success = false;

    axios.post(`${process.env.REACT_APP_API_URL}/api/Indexing/fastgeoshowonui?fastId=${id}`)
      .then((response: any) => {
        if (response.status === 200) {
          success = true;
        }
      });

    return success;
  }

  handleGeoocationChange(event: any): void {
    const value: string = event.target.value;

    if (value.length > 2 && value.length < 100) {
      this.getGeolocations(value)
        .then((result: GeolocationOption[]) => {
          this.setState({ geolocationOptions: result });
        });
    }
  }

  addGeolocationToList(event: any, values: Array<GeolocationOption>): void {
    if (values !== undefined && values !== null && values[values.length - 1] !== undefined) {
      const value = values[values.length - 1];

      // First check if the selected option was the expanded search option, if so then open the dialog, otherwise proceed normally
      if (value.id === 0 && value.name === 'Search from all FAST Geolocations...') {
        this.setState((prevState) => ({
          ...prevState,
          expandedSearchDialogOpen: true,
        }));
      } else if (this.props.selectedGeolocations !== undefined && this.props.selectedGeolocations.length < this.props.typedownLimit) {
        const existingGeolocation = this.props.selectedGeolocations.find((location) => location.name === value.name);
        // If the location already exists as user removed, set it to user added but not a new location
        if (existingGeolocation !== undefined && existingGeolocation.state === DocumentNodeStateEnum.UserRemoved) {
          // create a new array of selected geolocations without the selected value to avoid directly altering the props array
          const newGeolocationList = [...this.props.selectedGeolocations.filter((location) => location.name !== value.name)];
          const newGeolocation: DocumentFastNode = {
            ...existingGeolocation,
            state: DocumentNodeStateEnum.UserAdded,
            createdBy: '',
            createdDate: '',
          };
          this.props.onChangeFunction(this.props.keyName, [...newGeolocationList, newGeolocation]);
        } else if (existingGeolocation === undefined) {
          const newGeolocation: DocumentFastNode = {
            id: value.id, name: value.name, createdBy: '', createdDate: '', state: DocumentNodeStateEnum.UserAdded, isNew: true,
          };
          this.props.onChangeFunction(this.props.keyName, [...this.props.selectedGeolocations, newGeolocation]);
        }
      } else {
        const newGeolocation: DocumentFastNode = {
          id: value.id, name: value.name, createdBy: '', createdDate: '', state: DocumentNodeStateEnum.UserAdded, isNew: true,
        };
        this.props.onChangeFunction(this.props.keyName, [newGeolocation]);
      }
    }
  }

  addGeolocationFromSuggestion(verifiedValueId: number) {
    if (verifiedValueId !== undefined && verifiedValueId !== 0) {
      const geoList: DocumentFastNode[] = [...this.props.selectedGeolocations];

      for (let i = 0; i < geoList.length; i++) {
        if (geoList[i].id === verifiedValueId) {
          geoList[i] = {
            ...this.props.selectedGeolocations[i],
            state: DocumentNodeStateEnum.UserVerified,
            isNew: false,
          };
        }
      }

      this.props.onChangeFunction(this.props.keyName, geoList);
    }
  }

  addGeolocationFromExpandedSearch(id: number, name: string) {
    // First make this geolocation available
    this.makeGeolocationAvailable(id);

    if (this.props.selectedGeolocations !== undefined && this.props.selectedGeolocations.length < this.props.typedownLimit) {
      const existingGeolocation = this.props.selectedGeolocations.find((location) => location.id === id);

      // If the location already exists as user removed, set it to user added but not a new location
      if (existingGeolocation !== undefined && existingGeolocation.state === DocumentNodeStateEnum.UserRemoved) {
        // create a new array of selected geolocations without the selected value to avoid directly altering the props array
        const newGeolocationList = [...this.props.selectedGeolocations.filter((location) => location.id !== id)];
        const newGeolocation: DocumentFastNode = {
          ...existingGeolocation,
          state: DocumentNodeStateEnum.UserAdded,
          createdBy: '',
          createdDate: '',
        };
        this.props.onChangeFunction(this.props.keyName, [...newGeolocationList, newGeolocation]);
      } else if (existingGeolocation === undefined) {
        const newGeolocation: DocumentFastNode = {
          id, name, createdBy: '', createdDate: '', state: DocumentNodeStateEnum.UserAdded, isNew: true,
        };
        this.props.onChangeFunction(this.props.keyName, [...this.props.selectedGeolocations, newGeolocation]);
      }
    } else {
      const newGeolocation: DocumentFastNode = {
        id, name, createdBy: '', createdDate: '', state: DocumentNodeStateEnum.UserAdded, isNew: true,
      };
      this.props.onChangeFunction(this.props.keyName, [newGeolocation]);
    }

    // Close the expanded search dialog
    this.setState((prevState) => ({
      ...prevState,
      expandedSearchDialogOpen: false,
    }));
  }

  clearTypedownOptions(): void {
    this.setState({ geolocationOptions: [] });
  }

  verifyGeolocationsCount(): boolean {
    return this.props.selectedGeolocations.filter(
      (location) => location.state === DocumentNodeStateEnum.UserAdded || location.state === DocumentNodeStateEnum.UserVerified,
    ).length >= this.props.typedownLimit;
  }

  renderChips(location: DocumentFastNode): JSX.Element {
    const { classes } = this.props;

    if (location.state !== DocumentNodeStateEnum.SystemSuggested && location.state !== DocumentNodeStateEnum.UserRemoved) {
      return (
        <Zoom in={this.props.selectedGeolocations.includes(location)}><Chip tabIndex={-1} className={classes.chip} data-key={`geoChip${location.id}`} variant="outlined" label={location.name} disabled={this.props.readOnly} onDelete={this.handleDeleteLocation(location)} color="primary" /></Zoom>
      );
    }

    return (
      <></>
    );
  }

  renderSuggestedChips(location: DocumentFastNode): JSX.Element {
    const { classes } = this.props;

    if (location.state === DocumentNodeStateEnum.SystemSuggested) {
      return (
        <Zoom in={this.props.selectedGeolocations.includes(location)} key={location.id}>
          <Chip
            tabIndex={-1}
            className={classes.chip}
            data-key={`geoChipSuggested${location.id}`}
            label={location.name}
            disabled={this.props.readOnly}
            onDelete={() => this.addGeolocationFromSuggestion(location.id)}
            deleteIcon={<AddCircleIcon />}
          />
        </Zoom>
      );
    }

    return (
      <></>
    );
  }

  renderSuggestions() {
    const { classes } = this.props;

    if (this.props.locationSuggestions !== undefined && this.props.locationSuggestions.length > 0) {
      return (
        <>
          <Grid container item xs={12} style={{ position: 'relative' }}>
            <Grid item xs={12}>
              <Typography variant="overline" className={classes.suggestionsHeader}>
                Suggested geolocations
              </Typography>
            </Grid>
          </Grid>
          <Grid container item xs={10}>
            <Grid item xs={12} className={classes.suggestionsContainer}>
              {this.props.locationSuggestions.map((location) => <Chip tabIndex={-1} data-key={`geoSuggestion${location}`} disabled={this.props.readOnly || this.props.disabled} className={classes.chip} label={location} variant="outlined" key={location} />)}
            </Grid>
          </Grid>
        </>
      );
    }

    return null;
  }

  render(): JSX.Element {
    const { classes } = this.props;
    return (
      <>
        {this.renderSuggestions()}
        <div className={classes.typedownContainer}>
          <Grid item xs={6} style={{ position: 'relative' }}>
            <Autocomplete
              multiple
              filterOptions={(x) => (x)}
              disabled={this.props.disabled || this.props.readOnly || this.verifyGeolocationsCount()}
              className={classes.geolocationsInput}
              id="fast-geolocations"
              options={this.state.geolocationOptions}
              onChange={this.addGeolocationToList}
              onOpen={this.clearTypedownOptions}
              renderInput={(params: any) => (
                <TextField
                  {...params}
                  className={classes.geolocationsTextField}
                  variant="outlined"
                  label="FAST Geolocations"
                  margin="normal"
                  fullWidth
                  onChange={(e: { persist: () => void }) => {
                    e.persist();
                    this.handleGeoocationChange(e);
                  }}
                  error={this.props.error}
                  helperText={this.props.error ? this.props.errorText : ''}
                  InputProps={{
                    ...params.InputProps,
                    endAdornment: (
                      <>
                        {this.state.loading ? <CircularProgress color="inherit" size={20} /> : null}
                        {params.InputProps.endAdornment}
                      </>
                    ),
                  }}
                />
              )}
              // eslint-disable-next-line max-len
              renderOption={(option: GeolocationOption, renderOptionState: AutocompleteRenderOptionState) => this.getOptionRender(option, renderOptionState)}
              renderTags={() => <></>}
            />
          </Grid>
          {!this.props.error && (
          <Grid item xs={6}>
            <TypedownCounter
              limit={this.props.typedownLimit}
              selected={this.props.selectedGeolocations.filter(
                (location) => location.state === DocumentNodeStateEnum.UserAdded || location.state === DocumentNodeStateEnum.UserVerified,
              ).length}
            />
          </Grid>
          )}
          <Grid container item xs={9} className={classes.locationsContainer}>
            {this.props.selectedGeolocations.map((location: DocumentFastNode) => this.renderChips(location))}
          </Grid>
          <Grid container item xs={9} className={classes.locationsContainer}>
            {this.props.selectedGeolocations.map((location: DocumentFastNode) => this.renderSuggestedChips(location))}
          </Grid>
        </div>

        {/* Expanded Search Dialog */}
        <ExpandedSearchDialogBox
          open={this.state.expandedSearchDialogOpen}
          title="Expanded search - FAST Geolocations"
          subheading="Choose a FAST Geolocation from this expanded list, any items added from here will appear on the regular search afterwards"
          handleCloseFunction={() => {
            this.setState((prevState) => ({
              ...prevState,
              expandedSearchDialogOpen: false,
            }));
          }}
          handleAddOptionFunction={this.addGeolocationFromExpandedSearch}
          searchApiEndpoint="Indexing/searchfastgeoexpanded"
          artifactTypeId={this.props.artifactTypeId}
        />
      </>
    );
  }
}

export default withStyles(useStyles)(GeolocationsTypedown);
