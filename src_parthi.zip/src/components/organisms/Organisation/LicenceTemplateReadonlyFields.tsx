import React from 'react';
import {
  makeStyles, Theme, createStyles, Grid,
} from '@material-ui/core';
import { DateTime } from 'luxon';
import SecondaryData from '../../molecules/SecondaryData';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    paddingTop: theme.spacing(3),
    position: 'relative',
  },
  chips: {
    position: 'absolute',
    top: 5,
    right: 8,
  },
  chip: {
    marginLeft: theme.spacing(1),
  },
  columnWrapper: {
    paddingLeft: theme.spacing(3),
    paddingRight: theme.spacing(3),
    paddingBottom: theme.spacing(1),
  },
  field: {
    marginTop: theme.spacing(1),
    marginRight: theme.spacing(2),
  },
  heading: {
    fontSize: '1rem',
    fontWeight: 500,
    textTransform: 'uppercase',
    color: theme.palette.primary.main,
    textDecoration: 'underline',
  },
  label: {
    fontWeight: 460,
  },
  buttonWrapper: {
    textAlign: 'right',
    paddingRight: theme.spacing(1),
    paddingTop: theme.spacing(1),
  },
}));

interface LicenceTemplateReadonlyFieldsProps {
  contractStartDate: string | null;
  contractEndDate: string | null;
  price: number;
  accessRights: string | null;
  royaltyRate: number | null;
  clearedBy: string | null;
  accessType: string | null;
};

const LicenceTemplateReadonlyFields: React.FC<LicenceTemplateReadonlyFieldsProps> = (props) => {
  const classes = useStyles();

  return (
    <Grid container className={classes.root}>
      <Grid item xs={12}>
        <Grid container>
          <SecondaryData
            title="Price"
            content={`$${props.price.toFixed(2)}`}
          />
          <SecondaryData
            title="Cleared By"
            content={props.clearedBy}
          />
          <SecondaryData
            title="Access Rights"
            content={props.accessRights}
          />
          <SecondaryData
            title="Access Type"
            content={props.accessType}
          />
          <SecondaryData
            title="Contract Start Date"
            content={props.contractStartDate ? DateTime.fromISO(props.contractStartDate).toFormat('d LLLL yyyy') : null}
          />
          <SecondaryData
            title="Contract End Date"
            content={props.contractEndDate ? DateTime.fromISO(props.contractEndDate).toFormat('d LLLL yyyy') : null}
          />
        </Grid>
      </Grid>
    </Grid>
  );
};

export default LicenceTemplateReadonlyFields;
