import React from 'react';

const FilterableItem = (props: React.PropsWithChildren<{ filterValue: string; showValues: string[] }>) => {
  let show = false;
  const filterValueUpper = props.filterValue.toLocaleUpperCase().replace(/ /g, '');
  props.showValues.forEach((element) => {
    if (element.toLocaleUpperCase().indexOf(filterValueUpper) > -1) {
      show = true;
    }
  });
  if (!show) {
    return null;
  }
  return (<>{props?.children}</>);
};

export default FilterableItem;
