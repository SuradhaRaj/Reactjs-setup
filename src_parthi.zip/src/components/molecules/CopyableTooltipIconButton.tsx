import React from 'react';
import { Tooltip, TooltipProps, IconButton } from '@material-ui/core';
import { useSnackbar } from 'notistack';

interface CopyableTooltipProps extends TooltipProps {
  disabled?: boolean;
}

const CopyableTooltip: React.FC<React.PropsWithChildren<CopyableTooltipProps>> = (props) => {
  const snackbar = useSnackbar();
  const copyToClipboard = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    e.preventDefault();
    e.stopPropagation();
    const text = props.title?.toString();
    const textField = document.createElement('textarea');
    if (text !== undefined) {
      textField.innerText = text;
    }
    document.body.appendChild(textField);
    textField.select();
    document.execCommand('copy');
    textField.remove();

    snackbar.enqueueSnackbar(`Copied ${props.title} to clipboard.`, { variant: 'info' });
  };

  return (
    <>
      <Tooltip {...props}>
        <IconButton onClick={copyToClipboard} disabled={props.disabled} style={{ padding: 0, background: 'none' }}>
          {props.children}
        </IconButton>
      </Tooltip>
    </>
  );
};

export default CopyableTooltip;
