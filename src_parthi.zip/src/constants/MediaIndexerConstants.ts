// Typedowns
export const BroadSubjectTypedownLimit = 4;
export const FastAndIndentifiersTypedownLimit = 6;
export const GenreChecklistLimit = 2;
export const GeolocationsTypedownLimit = 3;
export const LanguageTypedownLimit = 10;
export const NarrowSubjectTypedownLimit = 4;

// Typedown Debounce Time (ms)
export const TypedownDebounceTime = 500;
