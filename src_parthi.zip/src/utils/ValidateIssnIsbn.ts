const issnCheck = (issn: string): boolean => {
  try {
    const i1: number = +(issn[0].toString()) * 8;
    const i2: number = +(issn[1].toString()) * 7;
    const i3: number = +(issn[2].toString()) * 6;
    const i4: number = +(issn[3].toString()) * 5;
    const i5: number = +(issn[4].toString()) * 4;
    const i6: number = +(issn[5].toString()) * 3;
    const i7: number = +(issn[6].toString()) * 2;
    const total: number = i1 + i2 + i3 + i4 + i5 + i6 + i7;
    const mean: number = total % 11;
    const cd: number = 11 - mean;
    if (issn[7].toString() === cd.toString() || mean === 0) {
      return true;
    }
    if (issn[7].toString() === 'X' && mean === 1) {
      return true;
    }

    return false;
  } catch (error) {
    return false;
  }
};
const isbn10Check = (isbn: string): boolean => {
  try {
    const i1: number = +(isbn[0].toString()) * 10;
    const i2: number = +(isbn[1].toString()) * 9;
    const i3: number = +(isbn[2].toString()) * 8;
    const i4: number = +(isbn[3].toString()) * 7;
    const i5: number = +(isbn[4].toString()) * 6;
    const i6: number = +(isbn[5].toString()) * 5;
    const i7: number = +(isbn[6].toString()) * 4;
    const i8: number = +(isbn[7].toString()) * 3;
    const i9: number = +(isbn[8].toString()) * 2;
    const total: number = i1 + i2 + i3 + i4 + i5 + i6 + i7 + i8 + i9;
    const mean: number = total % 11;
    const cd: number = 11 - mean;
    if (isbn[9].toString() === cd.toString() || mean === 0) {
      return true;
    }
    if (isbn[9].toString() === 'X' && mean === 1) {
      return true;
    }

    return false;
  } catch (error) {
    return false;
  }
};
const isbn13Check = (isbn: string): boolean => {
  try {
    const i1: number = +(isbn[0].toString()) * 1;
    const i2: number = +(isbn[1].toString()) * 3;
    const i3: number = +(isbn[2].toString()) * 1;
    const i4: number = +(isbn[3].toString()) * 3;
    const i5: number = +(isbn[4].toString()) * 1;
    const i6: number = +(isbn[5].toString()) * 3;
    const i7: number = +(isbn[6].toString()) * 1;
    const i8: number = +(isbn[7].toString()) * 3;
    const i9: number = +(isbn[8].toString()) * 1;
    const i10: number = +(isbn[9].toString()) * 3;
    const i11: number = +(isbn[10].toString()) * 1;
    const i12: number = +(isbn[11].toString()) * 3;
    const i13: number = +(isbn[12].toString()) * 1;
    const total: number = i1 + i2 + i3 + i4 + i5 + i6 + i7 + i8 + i9 + i10 + i11 + i12 + i13;
    const mean: number = total % 10;
    if (mean === 0) return true; ;
    const cd: number = 10 - mean;
    if (isbn[12].toString() === cd.toString()) {
      return true;
    }
    return false;
  } catch (error) {
    return false;
  }
};
export default {
  issnCheck,
  isbn10Check,
  isbn13Check,
};
