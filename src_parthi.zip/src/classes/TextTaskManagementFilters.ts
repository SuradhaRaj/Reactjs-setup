import {
  Record, String, Array as RtArray, Static, Undefined,
} from 'runtypes';
import Filters from './Filters';
import TextTaskManagementTasks from '../interfaces/TaskManagementText/TextTaskManagementTasks';
import TextTaskManagementArtifactTask from '../interfaces/TaskManagementText/TextTaskManagementArtifactTask';

const RuntypeDeclaration = Record({
  status: RtArray(String).Or(Undefined),
  publisher: RtArray(String).Or(Undefined),
  grouping: RtArray(String).Or(Undefined),
  title: RtArray(String).Or(Undefined),
  manager: RtArray(String).Or(Undefined),
});

interface TextTaskManagementFiltersData {
  status: Array<string>;
  publisher: Array<string>;
  grouping: Array<string>;
  title: Array<string>;
  manager: Array<string>;
}

type TextTaskManagementFiltersDataRt = Static<typeof RuntypeDeclaration> ;

class TextTaskManagementFilters extends Filters<TextTaskManagementFiltersData> {
  constructor(filterContent: TextTaskManagementFiltersDataRt) {
    try {
      RuntypeDeclaration.check(filterContent);
      super({
        status: filterContent.status === undefined ? [] : filterContent.status,
        publisher: filterContent.publisher === undefined ? [] : filterContent.publisher,
        grouping: filterContent.grouping === undefined ? [] : filterContent.grouping,
        title: filterContent.title === undefined ? [] : filterContent.title,
        manager: filterContent.manager === undefined ? [] : filterContent.manager,
      });
    } catch (error) {
      console.error(error);
      throw error;
    }
  }

  static empty() {
    return new TextTaskManagementFilters({
      status: [], grouping: [], title: [], publisher: [], manager: [],
    });
  }

  private filterArtifactTasks(tasks: TextTaskManagementArtifactTask[]): TextTaskManagementArtifactTask[] {
    const results = tasks;
    // if (tasks.length > 0) {
    //  if (this.data.status.length > 0) {
    //    results = results.filter((task) => some(this.data.status,
    //      (filterItem) => task.workflowStatusId === parseInt(WorkflowStatusDisplayNamesInverted[filterItem])));
    //  }
    if (this.data.publisher.length > 0) {
    //    // eslint-disable-next-line max-len
    //    results = results.filter((task) => some(this.data.publisher, (filterItem) => TextTaskManagementFilters.compare(task.nameOfPublisher, filterItem)));
    }
    //  if (this.data.title.length > 0) {
    //    results = results.filter((task) => some(this.data.title, (filterItem) => TextTaskManagementFilters.compare(task.title, filterItem)));
    //  }
    //  if (this.data.grouping.length > 0) {
    //    results = results.filter((task) => some(this.data.grouping, (filterItem) => TextTaskManagementFilters.compare(task.grouping, filterItem)));
    //  }
    //  if (this.data.manager.length > 0) {
    //    results = results.filter((task) => some(this.data.manager, (filterItem) => TextTaskManagementFilters.compare(task.managerName, filterItem)));
    //  }
    // }
    return results;
  }

  static compare(item1: string | null, item2: string) {
    if (item1 === null) {
      return false;
    }
    return item1.trim().toUpperCase() === item2.trim().toUpperCase();
  }

  filterTasks(tasksToFilter: TextTaskManagementTasks): TextTaskManagementTasks {
    let results = { ...tasksToFilter };
    results = this.filterArtifactTasks(results);
    return results;
  };
}

export default TextTaskManagementFilters;
