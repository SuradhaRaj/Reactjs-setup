import { find } from 'lodash';
import ResourceString from '../interfaces/res/ResourceString';

const MapNumberToString = (resourceStrings: Array<ResourceString>, id: number): string => {
  const resourceString = find(resourceStrings, { id });
  return resourceString?.message ?? '';
};

const MapNumberListToStringList = (resourceStrings: ResourceString[], idList: number[]): string[] => {
  const returnList: string[] = [];
  let resourceString = '';
  let id = 0;

  for (let i = 0; i < idList.length; i++) {
    id = idList[i];
    resourceString = find(resourceStrings, { id })?.message ?? '';

    if (resourceString !== '') {
      returnList.push(resourceString);
    }

    resourceString = '';
  }

  return returnList;
};

export default {
  MapNumberToString,
  MapNumberListToStringList,
};
