interface AddCorporateAuthorRequest {
  corporateName: string;
  isLegal: boolean;
};

export default AddCorporateAuthorRequest;
