/* eslint-disable  @typescript-eslint/no-explicit-any */
import React, { useState } from 'react';
import {
  Chip, makeStyles, createStyles, Popover, Tooltip,
} from '@material-ui/core';
import { KeyValue, isKeyValue } from '../../interfaces/TaskManagementText/TextTaskManagementRequest';

const useStyles = makeStyles(() => createStyles({
  chip: {
    '& .MuiChip-label': {
      paddingLeft: 10,
      paddingRight: 4,
      fontSize: '0.6rem',
      fontWeight: 600,
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
    },
    '&.MuiChip-root': {
      height: 20,
      maxWidth: '100%',
    },
    '& .MuiChip-deleteIcon': {
      width: 18,
      height: 18,
      margin: '0 3px 0 0',
    },
    marginRight: 3,
    cursor: 'pointer',
  },
  popover: {
    '& .MuiPaper-root': {
      padding: 10,
    },
  },
}));

interface Props {
    content: Array<string | KeyValue>;
  maxLength: number;
    onDelete(item: string | KeyValue): void;
}

interface State {
  showDialog: boolean;
}

export default (props: Props): JSX.Element => {
  const classes = useStyles();

  const itemsToShow = props.content.slice(0, props.maxLength);
  const itemsToHide = props.content.slice(props.maxLength, props.content.length);
  const [anchorEl, setAnchorEl] = useState<HTMLDivElement | null>(null);

  const handleClick = (event: React.MouseEvent<HTMLDivElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const itemToShowHTML = itemsToShow.map((item) => {
    const keyName = isKeyValue(item) ? item.value : item;

    return (
      <Tooltip title={keyName}>
        <Chip
          data-visible-chips
          key={keyName}
          label={keyName}
          onDelete={() => props.onDelete(item)}
          className={classes.chip}
        />
      </Tooltip>
    );
  });

  const itemToHideHTML = itemsToHide.map((item) => {
    const keyName = isKeyValue(item) ? item.value : item;
    return (
      <Chip
        data-hidden-chips
        key={keyName}
        label={keyName}
        onDelete={() => props.onDelete(item)}
        className={classes.chip}
      />
    );
  });

  const open = Boolean(anchorEl);

  return (
    <>
      {itemToShowHTML}
      {itemsToHide.length > 0 && (
        <Chip data-more-items label={`+${itemsToHide.length} more`} className={classes.chip} onClick={handleClick} />
      )}

      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'center',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
        className={classes.popover}
      >
        <>
          {itemToHideHTML}
        </>
      </Popover>
    </>
  );
};
