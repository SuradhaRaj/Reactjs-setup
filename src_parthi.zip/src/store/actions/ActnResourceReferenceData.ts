import ResourceReferenceData from '../../interfaces/ResourceManagement/ResourceReferenceData';

export const UPDATE_RESOURCE_REFERENCE_DATA = 'UPDATE_RESOURCE_REFERENCE_DATA';

interface UpdateResourceReferenceDataAction {
  type: typeof UPDATE_RESOURCE_REFERENCE_DATA;
  payload: ResourceReferenceData;
}

export type ActionTypes = UpdateResourceReferenceDataAction;

export function updateTextReferenceData(data: ResourceReferenceData): ActionTypes {
  return {
    type: UPDATE_RESOURCE_REFERENCE_DATA,
    payload: data,
  };
}
