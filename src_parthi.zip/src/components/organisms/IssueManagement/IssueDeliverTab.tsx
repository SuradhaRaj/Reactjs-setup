import React, { useContext } from 'react';
import {
  makeStyles, Theme, createStyles, Grid, Divider,

} from '@material-ui/core';
import { useSnackbar } from 'notistack';
import Axios, { AxiosResponse, AxiosError } from 'axios';
import { Static } from 'runtypes';
import Issue from '../../../interfaces/IssueManagement/Issue';
import { MetadataItem } from '../../Shared/MetadataItem';
import RejectedFile from '../../../interfaces/TextIndexer/RejectedFile';
import UploadedFile from '../../../interfaces/TextIndexer/UploadedFile';
import FileUploadStatus from '../../../interfaces/enums/FileUploadStatus';
import { MaxFiles as MaxFilesConst } from '../../../constants/FileUploadConstants';
import { UploadFileResponse, UploadFileResponseValidator } from '../../../interfaces/TextIndexer/UploadFileResponse';
import DateExtensions from '../../../utils/DateExtensions';
import TitleWithSecondaryText from '../../molecules/TitleWithSecondaryText';
import ReadOnlyTextField from '../../Shared/ReadOnlyTextField';
import UpdateIssueResponse from '../../../interfaces/IssueManagement/UpdateIssueResponse';
import LoadingButton from '../../molecules/LoadingButton';
import WorkflowStatus from '../../../interfaces/enums/WorkflowStatus';
import Dropzone from '../TextIndexer/Dropzone';
import UploadedExtraFileList from '../TextIndexer/UploadedExtraFileList';
import UploadedFileList from '../TextIndexer/UploadedFileList';
import DownloadFilesList from '../TextIndexer/DownloadFilesList';
import { FileValidator } from '../../../interfaces/TextIndexer/IssueArtifact';
import IssueResponse from '../../../interfaces/IssueManagement/IssueResponse';
import DialogWithCustomContent from '../../molecules/DialogWithCustomContent';
import SmallChip from '../../molecules/SmallChip';
import INFORMIT_WEBSITE from '../../../constants/InformitConstants';
import SwitchField from '../../Shared/SwitchField';
import { AppContext } from '../../Context';
import ExtraRequest from '../../../interfaces/TextIndexer/ExtraRequest';

const NO_ISSUE_DATA_UPDATED = 'NoChange';
const ISSUE_FILES_RECEIVED = WorkflowStatus.IssueFilesReceived;
const READY_FOR_FILE_PREP = WorkflowStatus.ReadyForFilePrep;

const useStyles = makeStyles((theme: Theme) => createStyles({
  booleanIndicator: {
    marginLeft: theme.spacing(2),
  },
  gridrow: {
    display: 'flex',
  },
  MetadataItem: {
    'padding-left': theme.spacing(20),
  },

  paper: {
    padding: theme.spacing(4),
    position: 'relative',
  },
  tabContent: {
    '& > *': {
      display: 'inline-block',
      // width: 125,
    },
  },
  divider: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(2),
  },
  contentWrapper: {
    paddingTop: 30,
    paddingRight: 30,
  },
  SubmitButton: {
    width: 170,
    marginTop: theme.spacing(1),
    alignSelf: 'right',
  },
}));

interface AddFileRequest {
    issuePath: string;
    filename: string;
    data: number[];
    issueId: number;
    // eslint-disable-next-line semi
};

interface Props {
    issue: Issue;
    isReplace: boolean;
    updateIssue(issue: Issue): void;
}

interface State {
    downloadFiles: Static<typeof FileValidator>[];
    uploadedFiles: UploadedFile[];
    downloadExtraFiles: Static<typeof FileValidator>[];
    uploadedExtraFiles: UploadedFile[];
    submitting: boolean;
    rejectedFiles: RejectedFile[];
    rejectedExtraFiles: RejectedFile[];
    publisherDialogOpen: boolean;
}

export default (props: Props) => {
  const classes = useStyles();
  const issue = props.issue;
  const issuepath = `${issue.resouceName}\\${issue.grouping}`;
  const context = useContext(AppContext);

  const [state, setState] = React.useState<State>({
    uploadedFiles: [],
    submitting: false,
    downloadExtraFiles: [],
    uploadedExtraFiles: [],
    rejectedFiles: [],
    downloadFiles: [],
    rejectedExtraFiles: [],
    publisherDialogOpen: false,

  });
  React.useEffect(() => {
      interface IssueResponse { fileType: 'pdf' | 'html' | null; filename: string; pageCount: number; fileSize: number }

      const issueRequest = Axios.get<IssueResponse[]>(`${process.env.REACT_APP_API_URL}/api/issue/getissuefiles?IssuePath=${issuepath}`);
      const extraRequest = Axios.get<ExtraRequest[]>(`${process.env.REACT_APP_API_URL}/api/issue/getextrafiles?IssuePath=${issuepath}`);

      Axios.all([
        issueRequest,
        extraRequest,
      ]).then(Axios.spread((

        ...responses
      ) => {
        const issueResponse: AxiosResponse<IssueResponse[]> = responses[0] as AxiosResponse<IssueResponse[]>;
        const extraResponse: AxiosResponse<ExtraRequest[]> = responses[1] as AxiosResponse<ExtraRequest[]>; ;

        const newUploadedFiles: UploadedFile[] = [];
        const newDownloadFiles: Static<typeof FileValidator>[] = [];
        issueResponse.data.forEach((file) => {
          newUploadedFiles.push({
            name: file.filename,
            status: FileUploadStatus.Valid,
            errorMessages: [],
            pageCount: file.pageCount,
            filetype: file.fileType,
          });

          newDownloadFiles.push({
            filename: file.filename,
            size: file.fileSize,
            date: '',
            isExisted: false, // this field is not used in this page.
          });
        });

        const newUploadedExtraFiles: UploadedFile[] = [];
        const newDownloadExtraFiles: Static<typeof FileValidator>[] = [];
        extraResponse.data.forEach((file) => {
          newUploadedExtraFiles.push({
            name: file.filename,
            status: FileUploadStatus.Valid,
            errorMessages: [],
            pageCount: file.pageCount,
            filetype: file.fileType,
          });

          newDownloadExtraFiles.push({
            filename: file.filename,
            size: file.fileSize,
            date: '',
            isExisted: false, // this field is not used in this page.
          });
        });

        setState({
          ...state,
          uploadedFiles: newUploadedFiles,
          downloadFiles: newDownloadFiles,
          uploadedExtraFiles: newUploadedExtraFiles,
          downloadExtraFiles: newDownloadExtraFiles,
        });
      })).catch((e) => {
        console.error(e);
      }); ;
  }, []);

  const MaxFiles = props.isReplace ? 1 : MaxFilesConst;
  const { enqueueSnackbar } = useSnackbar();

  const updateUploadFilesStatusBase = (filename: string, statusUpdated: Partial<UploadedFile> | { isDeleting: boolean }, uploadFilePropName: 'uploadedFiles' |'uploadedExtraFiles') => {
    setState((prevState) => {
      const newUploadedFiles = [...prevState[uploadFilePropName]];

      const i = newUploadedFiles.findIndex((value) => value.name === filename);

      if (i !== -1) {
        newUploadedFiles[i] = {
          ...newUploadedFiles[i],
          ...statusUpdated,
        };
      }

      const newState = {
        ...prevState,

      };

      newState[uploadFilePropName] = newUploadedFiles;

      return newState;
    });
  };

  const updateUploadFilesStatus = (filename: string, statusUpdated: Partial<UploadedFile> | { isDeleting: boolean }) => {
    updateUploadFilesStatusBase(filename, statusUpdated, 'uploadedFiles');
  };

  const updateUploadExtraFilesStatus = (filename: string, statusUpdated: Partial<UploadedFile> | { isDeleting: boolean }) => {
    updateUploadFilesStatusBase(filename, statusUpdated, 'uploadedExtraFiles');
  };

  const updateFile = (filename: string, status: FileUploadStatus, responseData: UploadFileResponse) => {
    updateUploadFilesStatus(filename, {
      status, filetype: responseData.fileType, pageCount: responseData.pageCount, errorMessages: responseData.messages,
    });
  };

  const updateExtraFile = (filename: string, status: FileUploadStatus, responseData: UploadFileResponse) => {
    updateUploadExtraFilesStatus(filename, {
      status, filetype: responseData.fileType, pageCount: responseData.pageCount, errorMessages: responseData.messages,
    });
  };

  const startFileVerification = (file: File) => {
    const request: AddFileRequest = {
      issuePath: `${issue.resourceId}\\${issue.grouping}`,
      issueId: issue.issueId,
      filename: file.name,
      data: [],
    };

    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    return file.arrayBuffer()
      .then((arrayBuffer: ArrayBuffer) => {
        request.data = Array.from(new Uint8Array(arrayBuffer));
        /// api/issue/uploadissuefile
        // send the request and update the state once complete
        Axios.post('api/issue/uploadissuefile', request)
        // update the state of that file once it's uploaded
          .then((response: AxiosResponse<UploadFileResponse>) => {
            UploadFileResponseValidator.check(response.data);
            updateFile(request.filename, FileUploadStatus.Valid, response.data);

            // if (issue.workflowStatusId === WorkflowStatus.IssueToBeReceived) { //RMIT-2375
            Axios.get<IssueResponse>(`${process.env.REACT_APP_API_URL}/api/issue/${issue.issueId}`)
              .then((issueResponse) => {
                props.updateIssue(issueResponse.data.issue);
              });
            // }
          })
          .catch((error: AxiosError<UploadFileResponse>) => {
            if (UploadFileResponseValidator.guard(error.response?.data)) {
              if (error.response?.data !== undefined) {
                updateFile(request.filename, FileUploadStatus.Invalid, error.response.data);
              }
            } else {
              updateFile(request.filename, FileUploadStatus.Invalid, {
                pageCount: 0,
                messages: ['Error reading verification response'],
                fileType: null,
                status: undefined,
              });
            }
          });
      });
  };

  const startExtraFileVerification = (file: File) => {
    const request: AddFileRequest = {
      issuePath: `${issue.resourceId}\\${issue.grouping}`,
      issueId: issue.issueId,
      filename: file.name,
      data: [],
    };

    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    return file.arrayBuffer()
      .then((arrayBuffer: ArrayBuffer) => {
        request.data = Array.from(new Uint8Array(arrayBuffer));
        /// api/issue/uploadissuefile
        // send the request and update the state once complete
        Axios.post(`${process.env.REACT_APP_API_URL}/api/issue/uploadextrafile`, request)
        // update the state of that file once it's uploaded
          .then((response: AxiosResponse<UploadFileResponse>) => {
            UploadFileResponseValidator.check(response.data);
            updateExtraFile(request.filename, FileUploadStatus.Valid, response.data);

            // if (issue.workflowStatusId === WorkflowStatus.IssueToBeReceived) { //RMIT-2375
            // Axios.get<IssueResponse>(`/api/issue/${issue.issueId}`)
            //    .then((issueResponse) => {
            //        props.updateIssue(issueResponse.data.issue);
            //    });
            // }
          })
          .catch((error: AxiosError<UploadFileResponse>) => {
            if (UploadFileResponseValidator.guard(error.response?.data)) {
              if (error.response?.data !== undefined) {
                updateExtraFile(request.filename, FileUploadStatus.Invalid, error.response.data);
              }
            } else {
              updateExtraFile(request.filename, FileUploadStatus.Invalid, {
                pageCount: 0,
                messages: ['Error reading verification response'],
                fileType: null,
                status: undefined,
              });
            }
          });
      });
  };

  const onUpdateNotes = (notes: string) => {
    Axios.post(`${process.env.REACT_APP_API_URL}/api/issue/updateissuenotes`, { issueId: issue.issueId, notesForRmitPublishing: notes })
    // update the state of that file once it's uploaded
      .then(() => {
        issue.notesForRmitPublishing = notes;
        enqueueSnackbar('Notes saved Successfully', { variant: 'success' });
      })
      .catch(() => undefined);
  };

  const onFileDrop = async (uploadedFiles: File[], rejectedFiles: RejectedFile[]) => {
    const newUploadedFiles = [...state.uploadedFiles];
    // First check if any of the accepted files exist already and move them to rejected with the correct error message
    uploadedFiles.forEach(async (file) => {
      if (state.uploadedFiles.find((f) => f.name === file.name) !== undefined) {
        rejectedFiles.push({ filename: file.name, errorMessageId: 2 });
      } else {
        newUploadedFiles.push({
          name: file.name,
          status: FileUploadStatus.Verifying,
          errorMessages: [],
          pageCount: 0,
          filetype: null,
        });
        startFileVerification(file);
      }
    });

    const allUploadedFiles = [...newUploadedFiles];

    if (allUploadedFiles.length === MaxFiles) {
      enqueueSnackbar('Max number of files reached', {
        variant: 'info',
      });
    } else if (allUploadedFiles.length > MaxFiles) {
      enqueueSnackbar('Max number of files exceeded', {
        variant: 'error',
      });
    }

    // Then show an error message if there are any errors
    if (rejectedFiles.length > 0) {
      setState({
        ...state,
        //  rejectedErrorDialogOpen: true,
        rejectedFiles,
        uploadedFiles: allUploadedFiles,
      });
    } else {
      setState({
        ...state,
        uploadedFiles: allUploadedFiles,
        rejectedFiles: [],
      });
    }
  };

  const onExtraFileDrop = async (uploadedFiles: File[], rejectedFiles: RejectedFile[]) => {
    const newUploadedFiles = [...state.uploadedExtraFiles];
    // First check if any of the accepted files exist already and move them to rejected with the correct error message
    uploadedFiles.forEach(async (file) => {
      if (state.uploadedFiles.find((f) => f.name === file.name) !== undefined) {
        rejectedFiles.push({ filename: file.name, errorMessageId: 2 });
      } else {
        newUploadedFiles.push({
          name: file.name,
          status: FileUploadStatus.Verifying,
          errorMessages: [],
          pageCount: 0,
          filetype: null,
        });
        startExtraFileVerification(file);
      }
    });

    const allUploadedFiles = [...newUploadedFiles];

    if (allUploadedFiles.length === MaxFiles) {
      enqueueSnackbar('Max number of files reached', {
        variant: 'info',
      });
    } else if (allUploadedFiles.length > MaxFiles) {
      enqueueSnackbar('Max number of files exceeded', {
        variant: 'error',
      });
    }

    // Then show an error message if there are any errors
    if (rejectedFiles.length > 0) {
      setState({
        ...state,
        //  rejectedErrorDialogOpen: true,
        rejectedExtraFiles: rejectedFiles,
        uploadedExtraFiles: allUploadedFiles,
      });
    } else {
      setState({
        ...state,
        uploadedExtraFiles: allUploadedFiles,
        rejectedExtraFiles: [],
      });
    }
  };

  const isSubmitDisabled = () => (
    state.submitting
        || state.uploadedFiles.length > MaxFiles
        || state.uploadedFiles.find((uploadedFile) => uploadedFile.status !== FileUploadStatus.Valid || uploadedFile.isDeleting) !== undefined
        || issue.workflowStatusId === ISSUE_FILES_RECEIVED
        || issue.workflowStatusId === READY_FOR_FILE_PREP
        // || state.failedErrorDialogOpen
  );

  const isAllowAccept = true;// issue.workflowStatusId === ISSUE_FILES_RECEIVED; //RMIT-2375
  const isAllowUpload = true;/* [
    WorkflowStatus.IssueToBeReceived,
    WorkflowStatus.ReadyForDigitising,
    WorkflowStatus.DigitisingInProgress,
  ].includes(issue.workflowStatusId as WorkflowStatus); */ // RMIT-2375

  const acceptFile = () => {
    Axios.post(`${process.env.REACT_APP_API_URL}/api/issue/acceptfile/${issue.issueId}`)
      .then((response: AxiosResponse<UpdateIssueResponse & { messages: string[] }>) => {
        if (response.data.messages[0] !== NO_ISSUE_DATA_UPDATED) {
          enqueueSnackbar('The files have been accepted', {
            variant: 'success',
          });
        } else {
          enqueueSnackbar('issue state is "Ready For File Prep"', {
            variant: 'info',
          });
        }
        props.updateIssue(response.data.issue);
      }).catch(() => {
        enqueueSnackbar('Erroe occured.', {
          variant: 'error',
        });
      });
  };

  const submitFiles = () => {
    Axios.post(`${process.env.REACT_APP_API_URL}/api/issue/submitfile/${issue.issueId}`)
      .then((response: AxiosResponse<UpdateIssueResponse & { messages: string[] }>) => {
        if (response.data.messages[0] !== NO_ISSUE_DATA_UPDATED) {
          enqueueSnackbar('The files have been submitted successfully', {
            variant: 'success',
          });
        } else {
          enqueueSnackbar('issue state is "Issue file Received."', {
            variant: 'info',
          });
        }
        props.updateIssue(response.data.issue);
      }).catch(() => {
        enqueueSnackbar('Erroe occured.', {
          variant: 'error',
        });
      });
  };

  const enableEmail = () => {
    Axios.post(`${process.env.REACT_APP_API_URL}/api/issue/enableEmail/${issue.issueId}`)
      .then((response: AxiosResponse<UpdateIssueResponse>) => {
        if (response.data.issue.emailEnabled !== issue.emailEnabled) {
          enqueueSnackbar('switch email enabled successfully', {
            variant: 'success',
          });
          props.updateIssue(response.data.issue);
        }
      }).catch(() => {
        enqueueSnackbar('switch email enabled is fail', {
          variant: 'error',
        });
      });
  };

  const removeFile = (fileName: string) => {
    // set the file status to deleting
    updateUploadFilesStatus(fileName, { isDeleting: true });

    Axios.delete(`${process.env.REACT_APP_API_URL}/api/issue/deleteissuefile?IssuePath=${issue.resouceName}\\${issue.grouping}&filename=${fileName}`)
      .then(() => {
        const newFiles = state.uploadedFiles.filter((uploadedFile) => uploadedFile.name !== fileName);

        setState((prevState) => ({
          ...prevState,
          uploadedFiles: newFiles,
        }));
      }).catch(() => {
        updateUploadFilesStatus(fileName, { isDeleting: false });
        enqueueSnackbar(`Error removing ${fileName}`, {
          variant: 'error',
        });
      });
  };

  const removeExtraFile = (fileName: string) => {
    // set the file status to deleting
    updateUploadFilesStatus(fileName, { isDeleting: true });

    Axios.delete(`${process.env.REACT_APP_API_URL}/api/issue/deleteextrafile?IssuePath=${issue.resouceName}\\${issue.grouping}&filename=${fileName}`)
      .then(() => {
        const newFiles = state.uploadedExtraFiles.filter((uploadedFile) => uploadedFile.name !== fileName);

        setState((prevState) => ({
          ...prevState,
          uploadedExtraFiles: newFiles,
        }));
      }).catch(() => {
        updateUploadExtraFilesStatus(fileName, { isDeleting: false });
        enqueueSnackbar(`Error removing ${fileName}`, {
          variant: 'error',
        });
      });
  };

  const isOnLive = (): boolean => {
    return issue.workflowStatusId === WorkflowStatus.IssueLive; ;
  };

  const alertUrl = `${INFORMIT_WEBSITE}/journal/${issue.resouceName}`;
  const alertLink = (<a href={alertUrl} target="_blank" rel="noopener noreferrer">Open in Informit</a>);

  return (
    <>
      { /* Resource Name */}
      <ReadOnlyTextField
        labelText="Resource Name"
        displayText={issue.resouceName}
        oneLine
      />

      { /* Resource Title */}
      <ReadOnlyTextField
        labelText="Resource Title"
        displayText={issue.resouceTitle}
        oneLine
      />

      { /* grouping */}
      <ReadOnlyTextField
        labelText="Grouping"
        displayText={issue.grouping}
        oneLine
      />

      { /* Resource Name */}
      {!isOnLive() && (
      <ReadOnlyTextField
        labelText="Alert On Live"
        displayText={alertLink}
        oneLine
      />
      )}

      <SwitchField
        labelText="Email Enabled"
        checked={issue.emailEnabled}
        onChange={enableEmail}
        name="emailEnabled"
        oneLine
      />

      <Divider className={classes.divider} />
      <SmallChip
        style={{ position: 'absolute', right: '0px' }}
        label="Publisher Notes"
        onClick={() => {
          setState({
            ...state,
            publisherDialogOpen: !state.publisherDialogOpen,
          });
        }}
      />
      <DialogWithCustomContent
        open={state.publisherDialogOpen}
        title="Publisher notes"
        cancelButtonText="Cancel"
        confirmButtonText="Save Notes"
        handleCloseFunction={() => {
          setState({
            ...state,
            publisherDialogOpen: !state.publisherDialogOpen,
          });
        }}
        handleConfirmOptionFunction={() => onUpdateNotes((document.getElementById('pubpopup') as HTMLFormElement)?.value || '')}
        dialogContent={() => (<textarea id="pubpopup" rows={10} cols={60}>{issue.notesForRmitPublishing}</textarea>)}
      />
      <Grid container style={{ position: 'relative' }}>
        <Grid item xs={4}>
          {/* volumeNumber */}
          <MetadataItem title="Volume Number" value={issue.volumeNumber} />

        </Grid>
        <Grid item xs={4}>
          {/* issueNumber */}
          <MetadataItem title="Issue Number" value={issue.issueNumber} />

        </Grid>

        <Grid item xs={4}>
          {/* issueMonthSeason */}
          <MetadataItem
            title="Issue Month Season"
            value={issue.issueMonthSeason}
          />
        </Grid>
        <Grid item xs={4}>
          {/* publicationYear */}
          <MetadataItem
            title="Publication Year"
            value={issue.publicationYear}
          />
        </Grid>

        <Grid item xs={4}>
          {/* Date Of Publication */}
          <MetadataItem
            title="Date Of Publication"
            value={issue.dateOfPublication}
            alwaysDisplay
          />
        </Grid>
        {/* Schedule Date */}
        <Grid item xs={4}>

          <MetadataItem title="Schedule Date" value={DateExtensions.convertDateToFormFormat(issue.scheduleDate)} alwaysDisplay />
        </Grid>

        <Grid item xs={4}>
          {/* Issue Title */}
          <MetadataItem title="Issue Title" value={issue.issueTitle} />
        </Grid>

        <Grid item xs={4}>
          {/* Publisher Notes (Notes For Informit) */}
          <MetadataItem
            title="Publisher Notes"
            value={issue.notesForRmitPublishing}
          />
        </Grid>

        <Grid item xs={4}>
          {/* Issue ManagementNotes */}
          {context.userInfo.isInRole('InformitAdmin') && (
          <MetadataItem
            title="Notes For Management"
            value={issue.notesIssueManagement}
          />
          )}
        </Grid>

        <Grid item xs={4}>
          {/* Indexer Notes */}
          <MetadataItem title="Indexer Notes" value={issue.notesIndexer} />

        </Grid>
      </Grid>
      <Divider className={classes.divider} />
      <Grid container style={{ position: 'relative' }}>
        <Grid item xs={6}>
          <TitleWithSecondaryText
            title="Upload"
            secondaryText="Documents of Issue"
          />
          <div className={classes.contentWrapper}>
            <Dropzone onFileDrop={onExtraFileDrop} disabled={false} icon="doc" dropedFileType="extra" />
          </div>
        </Grid>
        <Grid item xs={6}>
          <TitleWithSecondaryText
            title="Confirm"
            secondaryText="Document name and submit"
          />
          <div className={classes.contentWrapper}>
            <UploadedExtraFileList
              disabled={isSubmitDisabled()}
              files={state.uploadedExtraFiles}
              removeFile={removeExtraFile}
             // submitFiles={submitFiles}
              submitting={state.submitting}
              maxFiles={MaxFiles}
            />
          </div>

        </Grid>
      </Grid>
      <Divider className={classes.divider} />
      {isAllowUpload ? (
        <Grid container style={{ position: 'relative' }}>
          <Grid item xs={6}>
            <TitleWithSecondaryText
              title="Upload"
              secondaryText="Documents of Issue"
            />
            <div className={classes.contentWrapper}>
              <Dropzone onFileDrop={onFileDrop} disabled={false} />
            </div>
          </Grid>
          <Grid item xs={6}>
            <TitleWithSecondaryText
              title="Confirm"
              secondaryText="Document name and submit"
            />
            <div className={classes.contentWrapper}>
              <UploadedFileList
                disabled={isSubmitDisabled()}
                files={state.uploadedFiles}
                removeFile={removeFile}
                submitFiles={submitFiles}
                submitting={state.submitting}
                maxFiles={MaxFiles}
              />
            </div>

          </Grid>
        </Grid>

      ) : (
        <Grid container justify="center">
          <Grid item xs={6}>
            <TitleWithSecondaryText
              title="Download"
              secondaryText="Publisher supplied documents"
            />
            <div className={classes.contentWrapper}>
              <DownloadFilesList
                files={state.downloadFiles}
                issuePath={issuepath}
              />
            </div>
            {isAllowAccept && (
              <div style={{ textAlign: 'right' }}>

                <LoadingButton
                  onClick={acceptFile}
                  disabled={!isAllowAccept}
                  variant="contained"
                  color="primary"
                  isLoading={state.submitting}
                  className={classes.SubmitButton}
                >
                  Accept
                </LoadingButton>
              </div>
            )}
          </Grid>
        </Grid>
      )}

    </>

  );
};
