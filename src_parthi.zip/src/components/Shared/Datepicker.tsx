import React, { Fragment, useEffect, useState } from 'react';
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import makeStyles from '@material-ui/styles/makeStyles';

export interface DropdownProps {
    labelText: string;

}

const useStyles = makeStyles({
  root: {
    '& .MuiInputBase-root': {
      padding: 0,
      '& .MuiButtonBase-root': {
        padding: 0,
        paddingLeft: 10,
        paddingRight: 10,
      },
      '& .MuiInputBase-input': {
        padding: 9,
      },
    },
    '& .MuiFormLabel-root': {
      fontsize: '0.8rem',
      color: 'rgba(0, 0, 0, 0.87)',
    },
  },
});

function InlineDatePicker(this: any, props: any) {
  const [selectedDate, handleDateChange] = useState(new Date());
  const classes = useStyles();

  const [value, setValue] = React.useState<Date | null>(new Date());

  return (

    <MuiPickersUtilsProvider utils={DateFnsUtils}>
      <KeyboardDatePicker
        className={classes.root}
        autoOk
        variant="inline"
        inputVariant="outlined"
        label={props.labelText}
        format="MM/dd/yyyy"
        value={props.value}
        InputAdornmentProps={{ position: 'end' }}
        onChange={(newValue) => setValue(newValue)}
      />
    </MuiPickersUtilsProvider>

  );
}

export default InlineDatePicker;
