import { shallow } from 'enzyme';
import React from 'react';
import IssueTaskTable, { IssueTaskRow } from '../../../components/organisms/TextTaskManagement/IssueTaskTable';
import TextTaskManagementIssueTask from '../../../interfaces/TaskManagementText/TextTaskManagementIssueTask';
import WorkflowStatus from '../../../interfaces/enums/WorkflowStatus';

describe('Issue table', () => {
  it('should render the correct number of rows', () => {
    const data: TextTaskManagementIssueTask[] = [
      {
        artifactId: 1,
        title: 'Removal of Autologous Tissue Substitute from Left Metatarsal-Phalangeal Joint, Percutaneous Endoscopic Approach',
        grouping: 'Seldom',
        publisher: 'Skynoodle',
        delivered: Date.now.toString(),
        manager: 'UA',
        files: 27,
        publisherNotes: 'In quis justo.',
        indexerNotes: 'Fusce consequat. Nulla nisl. Nunc nisl.',
        indexer: null,
        workflowStatusId: WorkflowStatus.ReadyForIssueSplitting,
        indexingCompany: 'Test Company',
        dateOfPublication: Date.now.toString(),
        resourceId: 'Test',
        rmitNumber: '123456',
        scheduleDate: Date.now.toString(),
      }, {
        artifactId: 2,
        title: 'Insertion of Infusion Device into Right Femoral Region, Percutaneous Approach',
        grouping: 'Often',
        publisher: 'Devpulse',
        delivered: Date.now.toString(),
        manager: 'KP',
        files: 10,
        publisherNotes: 'Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante.',
        indexerNotes: 'Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.',
        indexer: 'Greta Huntly',
        workflowStatusId: WorkflowStatus.ReadyForIssueSplitting,
        indexingCompany: 'Test Company',
        dateOfPublication: Date.now.toString(),
        resourceId: 'Test',
        rmitNumber: '123456',
        scheduleDate: Date.now.toString(),
      }, {
        artifactId: 3,
        title: 'Occlusion of Right Subclavian Artery, Open Approach',
        grouping: 'Weekly',
        publisher: 'Yozio',
        delivered: Date.now.toString(),
        manager: 'AR',
        files: 28,
        publisherNotes: 'Morbi a ipsum.',
        indexerNotes: 'Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis. Fusce posuere felis sed lacus.',
        indexer: null,
        workflowStatusId: WorkflowStatus.ReadyForIssueSplitting,
        indexingCompany: 'Test Company',
        dateOfPublication: Date.now.toString(),
        resourceId: 'Test',
        rmitNumber: '123456',
        scheduleDate: Date.now.toString(),
      },
    ];
    const wrapper = shallow(<IssueTaskTable rows={data} canUnlock={false} onUpdate={() => undefined} />);
    expect(wrapper.find(IssueTaskRow)).toHaveLength(3);
  });
});
