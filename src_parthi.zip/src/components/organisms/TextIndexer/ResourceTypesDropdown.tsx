/* eslint @typescript-eslint/no-explicit-any: 0 */
import React from 'react';
import {
  InputLabel, Select, MenuItem, FormControl, createStyles, FormHelperText, makeStyles,
} from '@material-ui/core';
import ResourceTypeDropdownOption from '../../../interfaces/TextIndexer/ResourceTypeDropdownOption';

const useStyles = makeStyles(() => createStyles({
  dropdownField: {
    width: '100%',
  },
}));

export interface ResourceTypeDropdownProps {
  id: string;
  labelText: string;
  options: ResourceTypeDropdownOption[];
  selectedOption: number | null;
  keyName: string;
  onChangeFunction(keyName: string, id: number, stringValue: string): void;
  inputProps?: any;
  isReadOnly?: boolean;
  error?: boolean;
  errorMessage?: string;
}

interface State {
  labelWidth: number;
}

const ResourceTypesDropdown = (props: ResourceTypeDropdownProps) => {
  const inputLabel = React.createRef<HTMLLabelElement>();
  const classes = useStyles();
  const [state, setState] = React.useState<State>({
    labelWidth: 0,
  });

  React.useEffect(() => {
    if (inputLabel.current !== null) {
      const offsetWidth = inputLabel.current.offsetWidth;

      setState((prevState) => ({
        ...prevState,
        labelWidth: offsetWidth,
      }));
    }
  }, [inputLabel.current]);

  const handleChange = (event: any) => {
    const selectedOption = props.options.find((option) => option.value.id === event.target.value);

    if (selectedOption !== undefined) {
      props.onChangeFunction(props.keyName, selectedOption.value.id, selectedOption.value.stringValue);
    }
  };

  return (
    <FormControl variant="outlined" className={classes.dropdownField} error={props.error}>
      <InputLabel ref={inputLabel} id={`${props.id}Label`}>{props.labelText}</InputLabel>
      <Select
        labelId={`${props.id}Label`}
        id={props.id}
        value={props.selectedOption}
        onChange={handleChange}
        labelWidth={state.labelWidth}
        inputProps={props.inputProps}
        disabled={props.isReadOnly}
      >
        {props.options.map((option) => <MenuItem key={option.value.id} style={{ whiteSpace: 'pre-wrap' }} value={option.value.id}>{option.display}</MenuItem>)}
      </Select>
      <FormHelperText>
        {props.error ? props.errorMessage : ''}
      </FormHelperText>
    </FormControl>
  );
};

export default ResourceTypesDropdown;
