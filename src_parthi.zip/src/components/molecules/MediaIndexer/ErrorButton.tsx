/* eslint @typescript-eslint/no-explicit-any: 0 */
import React from 'react';
import { InputLabel, Select, MenuItem } from '@material-ui/core';
import {
  withStyles, createStyles, WithStyles,
} from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import CloseIcon from '@material-ui/icons/Close';

import { RouteComponentProps } from 'react-router-dom';
import ArtifactErrorCode from '../../../interfaces/MediaIndexer/ArtifactErrorCode';

const useStyles = createStyles({
  dialogText: {
    marginBottom: '20px',
  },
  errorButton: {
    borderRadius: '50px',
    margin: 5,
  },
  dropdownField: {
    width: '100%',
    marginBottom: '10px',
  },
});

interface State {
  open: boolean;
  dropdownOption: number;
  reason: string;
}

interface ErrorButtonProps {
  errorCodes: ArtifactErrorCode[];
  onSendFunction: Function;
  classes: any;
}

class ErrorButton extends React.Component<ErrorButtonProps & WithStyles<typeof useStyles> & RouteComponentProps<{}>, State, {}> {
  constructor(props: ErrorButtonProps & RouteComponentProps<{}>) {
    super(props);
    this.handleOpenDialog = this.handleOpenDialog.bind(this);
    this.handleCloseDialog = this.handleCloseDialog.bind(this);
    this.handleDropdownChange = this.handleDropdownChange.bind(this);
    this.handleReasonChange = this.handleReasonChange.bind(this);
    this.sendError = this.sendError.bind(this);
    this.state = {
      open: false, dropdownOption: 0, reason: '',
    };
  }

  handleOpenDialog(): void {
    this.setState({ open: true });
  }

  handleCloseDialog(): void {
    this.setState({
      open: false, dropdownOption: 0, reason: '',
    });
  }

  handleDropdownChange(event: any): void {
    this.setState({ dropdownOption: event.target.value });
  }

  handleReasonChange(event: any): void {
    this.setState({ reason: event.target.value });
  }

  sendError(): void {
    if (this.state.dropdownOption !== 0) {
      const chosenError: ArtifactErrorCode = this.props.errorCodes[this.state.dropdownOption - 1];
      if (chosenError !== undefined) {
        this.props.onSendFunction(chosenError, this.state.reason.trim());
      }
    }
  }

  render(): JSX.Element {
    const { classes } = this.props;
    return (
      <>
        <Button
          size="small"
          color="secondary"
          variant="outlined"
          className={classes.errorButton}
          onClick={this.handleOpenDialog}
          startIcon={<CloseIcon />}
        >
          Reject
        </Button>
        <Dialog open={this.state.open} onClose={this.handleCloseDialog} aria-labelledby="form-dialog-title">
          <DialogTitle id="form-dialog-title">Reject Artifact</DialogTitle>
          <DialogContent>
            <DialogContentText className={classes.dialogText}>
              Please select an error and provide a suitable reason as to why that error was chosen
            </DialogContentText>
            <InputLabel id="ErrorDialogDropdown">Error</InputLabel>
            <Select
              labelId="ErrorDialogDropdown"
              className={classes.dropdownField}
              defaultValue={this.props.errorCodes[0]}
              onChange={this.handleDropdownChange}
            >
              {this.props.errorCodes.map((error) => <MenuItem key={error.errorID} value={error.errorID}>{error.name}</MenuItem>)}
            </Select>
            <TextField
              autoFocus
              multiline
              margin="dense"
              id="name"
              label="Reason"
              rows="4"
              type="text"
              fullWidth
              onChange={this.handleReasonChange}
            />
          </DialogContent>
          <DialogActions>
            <Button color="primary" onClick={this.handleCloseDialog}>
              Cancel
            </Button>
            <Button color="primary" variant="contained" onClick={this.sendError}>
              Send
            </Button>
          </DialogActions>
        </Dialog>
      </>
    );
  }
}

export default withStyles(useStyles)(ErrorButton);
