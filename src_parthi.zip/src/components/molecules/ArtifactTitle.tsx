import React from 'react';
import {
  makeStyles, createStyles, Theme, Typography,
} from '@material-ui/core';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    marginLeft: theme.spacing(2),
  },
}));

export default function (): JSX.Element {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <Typography variant="h6">
        Task View
      </Typography>
    </div>
  );
}
