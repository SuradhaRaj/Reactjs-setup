import {
  Static, Record, Number, String, Boolean, Runtype, Unknown,
} from 'runtypes';
import DocumentNodeStateEnum from './DocumentNodeStateEnum';

export const DocumentContributorValidator = Record({
  contributorID: Number,
  contributorConfidence: Number,
  firstName: String,
  middleName: String,
  lastName: String,
  typeID: Number,
  type: String,
  createdBy: String,
  createdDate: String,
  state: Unknown as Runtype<DocumentNodeStateEnum>,
  isNew: Boolean,
});

type DocumentContributor = Static<typeof DocumentContributorValidator>;

export default DocumentContributor;
