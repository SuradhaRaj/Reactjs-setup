import React from 'react';
import {
  makeStyles, Theme, createStyles, Grid, Typography, CircularProgress,
} from '@material-ui/core';
import Axios from 'axios';
import ResourceIssue from './ResourceIssue';
import ResourceIssueData from '../../../interfaces/ResourceList/ResourceIssueData';
import LoadingButton from '../../molecules/LoadingButton';
import ResourceIssueListData from '../../../interfaces/ResourceList/ResourceIssueListData';
import ErrorPaper from '../ErrorPaper';
import Resource from '../../../interfaces/ResourceManagement/Resource';

const useStyles = makeStyles((theme: Theme) => createStyles({
  loadButton: {
    margin: 'auto',
    position: 'relative',
    paddingTop: theme.spacing(2),
  },
  year: {
    paddingTop: theme.spacing(2),
  },
  issue: {
    paddingTop: theme.spacing(2),
  },
  loadingSpinner: {
    display: 'block',
    margin: 'auto',
    paddingTop: theme.spacing(2),
  },
  errorPaper: {
    display: 'block',
    margin: 'auto',
    paddingTop: theme.spacing(2),
  },
}));

interface State {
  isloading: boolean;
  issues: ResourceIssueData[];
  error: boolean;
}

interface Props {
    resource: Resource;

}

const ResourceNext = (props: Props) => {
  const classes = useStyles();
  const [state, setState] = React.useState<State>({
    isloading: false,
    issues: [],
    error: false,
  });

  const resourceId = props.resource.resourceId;
  const publisher: string = props.resource.nameOfPublisher ?? '';
  const resourceTitle: string = props.resource.resourceTitle ?? '';
  const resourceTypeId: number|null = props.resource.resourceTypeId;

  const loadData = () => {
    setState((prevState) => ({
      ...prevState,
      isloading: true,
    }));

    // Get list of issues for the next task
    Axios.get<ResourceIssueListData>(`${process.env.REACT_APP_API_URL}/api/resource/getissuesfornext?resourceId=${resourceId}`)
      .then((response) => {
        setState((prevState) => ({
          ...prevState,
          issues: response.data.issues,
        }));
      })
      .catch(() => {
        setState((prevState) => ({
          ...prevState,
          error: true,
        }));
      })
      .finally(() => {
        setState((prevState) => ({
          ...prevState,
          isloading: false,
        }));
      });
  };

  return (
    <Grid container>

      {state.error ? (
        <div className={classes.errorPaper}>
          <ErrorPaper
            text="An error occured when trying to load issues for the next task"
          />
        </div>
      ) : (
        <>
          {state.isloading ? (
            <div className={classes.loadingSpinner}>
              <CircularProgress />
            </div>
          ) : (
            <>
              {state.issues.length === 0 ? (
                <div className={classes.loadButton}>
                  <Grid item xs={12}>
                    <LoadingButton
                      color="primary"
                      onClick={loadData}
                      isLoading={state.isloading}
                    >
                      Load issues for the next task

                    </LoadingButton>
                  </Grid>
                </div>
              ) : (
                <>
                  <Grid item xs={12}>
                    <div className={classes.year}>
                      <Typography variant="h6" gutterBottom>
                        Next Task
                      </Typography>
                      <hr style={{ marginBottom: '0px' }} />
                    </div>
                  </Grid>
                  <Grid item xs={12}>
                    {state.issues.map((issue) => (
                      <Grid container>
                        <Grid item xs={12} className={classes.issue}>
                          <ResourceIssue
                            issueData={issue}
                            publisher={publisher}
                            resourceTitle={resourceTitle}
                            displayArticle={false}
                            resourceTypeId={resourceTypeId}
                          />
                        </Grid>
                      </Grid>
                    ))}
                  </Grid>
                </>
              )}
            </>
          )}
        </>
      )}
    </Grid>

  );
};

export default ResourceNext;
