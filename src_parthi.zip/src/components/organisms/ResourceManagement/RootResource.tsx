/* eslint-disable max-len */
import {
  Paper, makeStyles, Theme, createStyles, Typography,
  Grid, Button, Divider, Tabs, Tab, Dialog, DialogTitle, DialogContent, DialogActions, Tooltip,
} from '@material-ui/core';
import React, { useState, useRef, useEffect } from 'react';
import { useFormik } from 'formik';
import SettingsIcon from '@material-ui/icons/Settings';
import { useSnackbar } from 'notistack';
import Skeleton from '@material-ui/lab/Skeleton';
import Axios, { AxiosResponse } from 'axios';
import classname from 'classnames';
import AddIcon from '@material-ui/icons/NoteAdd';
import SmallChip from '../../molecules/SmallChip';
import RootResourceForm, { RootResourceFormik } from './RootResourceForm';
import Resource from '../../../interfaces/ResourceManagement/Resource';
import ButtonWithDialog from '../../molecules/ButtonWithDialog';
import ResourceValidationSchema from '../../../validationSchemas/ResourceValidationSchema';
import LoadingButton from '../../molecules/LoadingButton';

import UpdateResourceResponse, { UpdateResourceResponseValidator } from '../../../interfaces/ResourceManagement/UpdateResourceResponse';
import ContactTab from './Tabs/ContactTab';
import TabPanel from './Tabs/TabPanel';
import ResourceTab from './Tabs/ResourceTab';
import AdminTab from './Tabs/AdminTab';
import { useTypedSelector } from '../../../store/store';
import LicenseTab from './Tabs/LicenseTab';
import OrganisationContact from '../../../interfaces/Organisation/OrganisationContact';
import ResourceResponse from '../../../interfaces/ResourceManagement/ResourceResponse';

import RejectedFile from '../../../interfaces/TextIndexer/RejectedFile';

interface State {
    showEditDialog: boolean;
    formFilterValue: string;
    activeTab: number;
    isSubmitting: boolean;
    years: number[];
    isCoverImageUpdated: boolean;
    resourceData: Resource;
}

interface Props {
    data: ResourceResponse;
    isLoading: boolean;
    updateResource(resource: Resource): void;
    // updateLogo(file: File): void;
    updateContacts(contacts: OrganisationContact[]): void;
}

const RootResource = (props: Props) => {
  const useStyles = makeStyles((theme: Theme) => createStyles({
    paper: {
      padding: theme.spacing(4),
      position: 'relative',
      paddingBottom: 0,
    },
    divider: {
      marginTop: theme.spacing(2),
      marginBottom: theme.spacing(2),
    },
    titleRow: {
      alignItems: 'baseline',
      marginBottom: theme.spacing(2),
    },
    resourceSettings: {
      position: 'absolute',
      top: theme.spacing(4),
      right: theme.spacing(4),
    },
    resourceId: {
      fontSize: '0.85rem',
      fontWeight: 600,
      marginRight: theme.spacing(4),
    },
    resourceTitle: {
      display: 'block',
      fontSize: '0.85rem',
      maxWidth: '66%',
      marginLeft: theme.spacing(2),
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap',
    },
    titleLive: {
      marginLeft: theme.spacing(2),
    },

    licenseStatus: {
      color: theme.palette.success.contrastText,
      background: theme.palette.success.main,
      marginLeft: theme.spacing(1),
    },
    tabContentLoading: {
      display: 'grid',
      gridGap: theme.spacing(2),
      gridTemplateColumns: '12% 12% 12%',
    },
    row: {
      display: 'flex',
    },
    addButton: {
      position: 'absolute',
      top: theme.spacing(4),
      right: theme.spacing(30),
    },
    button: {
      borderRadius: 50,
      margin: 5,
    },
  }));

  const snackbar = useSnackbar();
  const classes = useStyles();
  const form = useRef<HTMLDivElement>();
  const [state, setState] = useState<State>({
    showEditDialog: false,
    formFilterValue: '',
    activeTab: 0,
    isSubmitting: false,
    years: [2016],
    isCoverImageUpdated: false,
    resourceData: props.data.resource,
  });
  useEffect(() => {
    setState((prevState) => ({
      ...prevState,
      resourceData: props.data.resource,

    }));
  }, [props.data.resource]);
  const showEditDialog = (show: boolean) => {
    setState((prevState) => ({
      ...prevState,
      showEditDialog: show,
    }));
  };
  const referenceData = useTypedSelector((store) => store.ResourceReferenceData.ResourceReferenceData);
  const formik: RootResourceFormik = useFormik<Resource>({
    initialValues: props.data.resource,
    onSubmit: (values) => { console.error(values); },
    validationSchema: ResourceValidationSchema,
    validateOnBlur: true,
    validateOnChange: true,
    enableReinitialize: true,
  });

  const saveResource = () => {
    formik.validateForm().then((errors) => {
      if (Object.keys(errors).length === 0) {
        setState((prevState) => ({ ...prevState, isSubmitting: true }));
        Axios.patch<UpdateResourceResponse>(`${process.env.REACT_APP_API_URL}/api/resource`, { resource: formik.values, isCoverImageUpdated: state.isCoverImageUpdated }).then(({ data }) => {
          props.updateResource(data.resource);
          if (UpdateResourceResponseValidator.guard(data)) {
            snackbar.enqueueSnackbar('Saved Successfully', { variant: 'success' });
          } else {
            snackbar.enqueueSnackbar('Saved successfully, refresh to see the updated values..', { variant: 'warning' });
          }
          showEditDialog(false);
        }).catch(() => {
          showEditDialog(false);
          snackbar.enqueueSnackbar('Unable to save resource', { variant: 'error' });
        }).finally(() => {
          setState((prevState) => ({ ...prevState, isSubmitting: false }));
        });
      } else {
        const element: Element = document.getElementsByClassName('Mui-error')[0];

        if (element !== undefined) {
          if (form !== undefined && form.current && form.current.scrollBy) {
            form.current.scrollBy({
              top: element.getBoundingClientRect().top - 200,
              behavior: 'smooth',
            });
          }
        }
      }
    });
  };

  const discardChanges = () => {
    formik.resetForm();
    showEditDialog(false);
  };

  const handleChangeTab = (event: React.ChangeEvent<{}>, newValue: number) => {
    setState((prevState) => ({ ...prevState, activeTab: newValue }));
  };

  function open(link: string) {
    window.open(link, '_blank');
  }

  // [todo] temp function to pass eslint
  function test(data: RejectedFile[]) { return data; }

  function startFileVerification(file: File) {
    const request: { resourceId: number; filename: string; data: number[] } = {
      resourceId: props.data.resource.resourceId,
      filename: file.name,
      data: [],
    };

    file.arrayBuffer()
      .then((arrayBuffer: ArrayBuffer) => {
        request.data = Array.from(new Uint8Array(arrayBuffer));
        Axios.post(`${process.env.REACT_APP_API_URL}/api/resource/uploadImageCover`, request).then((response: AxiosResponse<{ filename: string;imageData: string }>) => {
          setState((prevState) => ({
            ...prevState,
            resourceData: {
              ...props.data.resource,
              imageData: response.data.imageData,

            },
          }));

          formik.setFieldValue('logo', response.data.filename);
        });
      });
  }

  function onFileDrop(acceptedfiles: File[], rejectfile: RejectedFile[]) {
    test(rejectfile);// remove later

    let file: File;
    if (acceptedfiles.length > 0) {
      file = acceptedfiles[0];
      startFileVerification(file);
      setState((prevState) => ({ ...prevState, isCoverImageUpdated: true }));
    }
  }

  return (
    <>

      <Paper className={classes.paper}>
        <Grid container className={classes.titleRow}>
          <Grid item xs={12}>

            {props.isLoading && (
            <div>
              <Skeleton variant="text" animation="wave" width="50%" height={50} />
              <Skeleton variant="text" animation="wave" width="25%" />
            </div>
            )}
            {!props.isLoading && (
            <>
              <Grid container>
                <Grid item xs={12} className={classes.row}>
                  <Typography className={classes.resourceId}>{props.data.resource.resourceName}</Typography>
                  <Tooltip title={props.data.resource.resourceTitle ?? ''}>
                    <Typography className={classes.resourceTitle}>{props.data.resource.resourceTitle}</Typography>
                  </Tooltip>
                  <SmallChip className={classes.titleLive} label={referenceData.resourceWorkflowStates.find((x) => x.Key === props.data.resource.workflowStatusId)?.Value ?? 'Unknown'} />
                  <Button
                    variant="contained"
                    size="small"
                    color="primary"
                    onClick={() => open(`/resources/${props.data.resource.resourceId}/addIssue`)}
                    startIcon={<AddIcon />}
                    className={classname(classes.addButton, classes.button)}
                  >
                    Add
                  </Button>
                  <Button
                    data-testid="showEdit"
                    className={classes.resourceSettings}
                    startIcon={<SettingsIcon />}
                    onClick={() => showEditDialog(true)}
                  >
                    Modify / View All
                  </Button>
                </Grid>
              </Grid>
              <Divider className={classes.divider} />
            </>

            )}

          </Grid>
        </Grid>

        {props.isLoading && (
        <TabPanel value={state.activeTab} index={0}>
          <Grid container>
            <Grid item xs={10}>
              <div className={classes.tabContentLoading}>
                <Skeleton variant="text" animation="wave" />
                <Skeleton variant="text" animation="wave" />
                <Skeleton variant="text" animation="wave" />
                <Skeleton variant="text" animation="wave" />
                <Skeleton variant="text" animation="wave" />
              </div>
            </Grid>
            <Grid item xs={2}>
              <Skeleton variant="rect" height={140} width={100} style={{ borderRadius: 4 }} animation="pulse" />
            </Grid>
          </Grid>

        </TabPanel>
        )}

        {!props.isLoading && (
        <>
          <TabPanel value={state.activeTab} index={0}>
            <ResourceTab resource={state.resourceData} />
          </TabPanel>
          <TabPanel value={state.activeTab} index={1}>
            <LicenseTab />
          </TabPanel>
          <TabPanel value={state.activeTab} index={2}>
            <ContactTab
              contacts={props.data.contacts}
              hubspotOrgId={props.data.organisation.hubSpotOrgId}
              updateContacts={props.updateContacts}
              contactRoleTypeLookup={referenceData.contactRoleType}
              organisationId={props.data.organisation.organisationId}
            />
          </TabPanel>
          <TabPanel value={state.activeTab} index={3}>
            <AdminTab resource={props.data.resource} />
          </TabPanel>

          <Divider className={classes.divider} />
          <Tabs value={state.activeTab} onChange={handleChangeTab}>
            <Tab label="Resource" />
            <Tab label="License" />
            <Tab label="Contacts" />
            <Tab label="Workflow &amp; Admin" />
          </Tabs>

          <Dialog
            fullWidth
            maxWidth="lg"
            onClose={() => showEditDialog(false)}
            aria-labelledby="simple-dialog-title"
            disableBackdropClick={formik.dirty}
            disableEscapeKeyDown
            open={state.showEditDialog}
          >
            <DialogTitle data-testid="editDialog">
              Editing details for
              {' '}
              <strong>{props.data.resource.resourceTitle}</strong>
            </DialogTitle>
            <DialogContent dividers ref={form}>
              <RootResourceForm formik={formik} filterValue={state.formFilterValue} onFileDrop={onFileDrop} />
            </DialogContent>
            <DialogActions>
              {!formik.dirty && (
              <Button data-testid="close" onClick={() => showEditDialog(false)}>Close</Button>
              )}
              {formik.dirty && (
              <>
                <ButtonWithDialog
                  buttonProps={{
                    variant: 'text',
                    color: 'primary',
                    type: 'button',
                  }}
                  dialogContent={() => (
                    <Typography>
                      Are you sure you want to
                      {' '}
                      <strong>discard</strong>
                      {' '}
                      your changes?
                    </Typography>
                  )}
                  dialogActions={(closeDialog) => (
                    <>
                      <Button variant="outlined" color="primary" onClick={() => closeDialog()}>Keep Editing</Button>
                      <Button onClick={() => { discardChanges(); showEditDialog(false); }}>Discard Changes</Button>
                    </>
                  )}
                >
                  Discard
                </ButtonWithDialog>
                <LoadingButton data-testid="save" color="primary" variant="outlined" onClick={saveResource} isLoading={state.isSubmitting}>Save</LoadingButton>
              </>
              )}
            </DialogActions>
          </Dialog>
        </>
        )}
      </Paper>
    </>
  );
};

export default RootResource;
