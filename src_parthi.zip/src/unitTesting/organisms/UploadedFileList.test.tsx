/* eslint-disable @typescript-eslint/no-empty-function */
import React from 'react';
import { mount } from 'enzyme';
import { IconButton, Tooltip } from '@material-ui/core';
import UploadedFileList, { UploadedFileListItem } from '../../components/organisms/TextIndexer/UploadedFileList';
import FileUploadStatus from '../../interfaces/enums/FileUploadStatus';
import LoadingButton from '../../components/molecules/LoadingButton';
import SmallChip from '../../components/molecules/SmallChip';

describe('Uploaded file list', () => {
  const wrapper = mount(
    <UploadedFileList
      removeFile={() => {}}
      maxFiles={3}
      submitFiles={() => {}}
      disabled={false}
      submitting={false}
      files={[
        {
          name: 'file1.pdf',
          pageCount: 3,
          filetype: 'pdf',
          status: FileUploadStatus.Valid,
          errorMessages: [],
        },
        {
          name: 'file2.html',
          pageCount: 3,
          filetype: 'html',
          status: FileUploadStatus.Invalid,
          errorMessages: ['error reason'],
        },
        {
          name: 'file3.pdf',
          pageCount: 3,
          filetype: 'html',
          status: FileUploadStatus.Verifying,
          errorMessages: [],
        },
      ]}
    />,
  );

  it('should show the names of all files', () => {
    expect(wrapper.contains('file1.pdf'));
    expect(wrapper.contains('file2.html'));
    expect(wrapper.contains('file3.pdf'));
  });

  it('should show the correct number of list items', () => {
    expect(wrapper.find(UploadedFileListItem).length).toBe(3);
  });

  it('should show the number of files added', () => {
    expect(wrapper.contains('3 files'));
  });

  it('should allow submit if not disabled', () => {
    expect(wrapper.find(LoadingButton).props().disabled).toBeFalsy();
  });

  it('should not allow submit if it is disabled', () => {
    const wp = mount(
      <UploadedFileList
        removeFile={() => {}}
        maxFiles={3}
        submitFiles={() => {}}
        disabled
        submitting={false}
        files={[
          {
            name: 'file1.pdf',
            pageCount: 3,
            filetype: 'pdf',
            status: FileUploadStatus.Invalid,
            errorMessages: ['error'],
          },
          {
            name: 'file2.html',
            pageCount: 3,
            filetype: 'html',
            status: FileUploadStatus.Valid,
            errorMessages: [],
          },
          {
            name: 'file3.pdf',
            pageCount: 3,
            filetype: 'html',
            status: FileUploadStatus.Valid,
            errorMessages: [],
          },
        ]}
      />,
    );

    expect(wp.find(LoadingButton).props().disabled).toBeTruthy();
  });

  it('should not allow submit if it already submitting', () => {
    const wp = mount(
      <UploadedFileList
        removeFile={() => {}}
        maxFiles={3}
        submitFiles={() => {}}
        disabled={false}
        submitting
        files={[
          {
            name: 'file1.pdf',
            pageCount: 3,
            filetype: 'pdf',
            status: FileUploadStatus.Invalid,
            errorMessages: ['error'],
          },
          {
            name: 'file2.html',
            pageCount: 3,
            filetype: 'html',
            status: FileUploadStatus.Valid,
            errorMessages: [],
          },
          {
            name: 'file3.pdf',
            pageCount: 3,
            filetype: 'html',
            status: FileUploadStatus.Valid,
            errorMessages: [],
          },
        ]}
      />,
    );

    expect(wp.find(LoadingButton).props().isLoading).toBeTruthy();
  });

  it('should not allow submit if max files are exceeded', () => {
    const wp = mount(
      <UploadedFileList
        removeFile={() => {}}
        maxFiles={2}
        submitFiles={() => {}}
        disabled={false}
        submitting
        files={[
          {
            name: 'file1.pdf',
            pageCount: 3,
            filetype: 'pdf',
            status: FileUploadStatus.Invalid,
            errorMessages: ['error'],
          },
          {
            name: 'file2.html',
            pageCount: 3,
            filetype: 'html',
            status: FileUploadStatus.Valid,
            errorMessages: [],
          },
          {
            name: 'file3.pdf',
            pageCount: 3,
            filetype: 'html',
            status: FileUploadStatus.Valid,
            errorMessages: [],
          },
        ]}
      />,
    );

    expect(wp.find(LoadingButton).props().disabled).toBeTruthy();
  });

  it('should allow file delete if not verifying or deleting', () => {
    const wp = mount(
      <UploadedFileList
        removeFile={() => {}}
        maxFiles={2}
        submitFiles={() => {}}
        disabled={false}
        submitting
        files={[
          {
            name: 'file3.pdf',
            pageCount: 3,
            filetype: 'html',
            status: FileUploadStatus.Valid,
            errorMessages: [],
          },
        ]}
      />,
    );

    expect(wp.find(IconButton).props().disabled).toBe(false);
  });

  it('should not allow file delete while deleting', () => {
    const wp = mount(
      <UploadedFileList
        removeFile={() => {}}
        maxFiles={2}
        submitFiles={() => {}}
        disabled={false}
        submitting
        files={[
          {
            name: 'file3.pdf',
            pageCount: 3,
            filetype: 'html',
            status: FileUploadStatus.Valid,
            errorMessages: [],
            isDeleting: true,
          },
        ]}
      />,
    );

    expect(wp.find(IconButton).length).toBe(0);
  });

  it('should not allow file delete while verifying', () => {
    const wp = mount(
      <UploadedFileList
        removeFile={() => {}}
        maxFiles={2}
        submitFiles={() => {}}
        disabled={false}
        submitting
        files={[
          {
            name: 'file3.pdf',
            pageCount: 3,
            filetype: 'html',
            status: FileUploadStatus.Verifying,
            errorMessages: [],
          },
        ]}
      />,
    );

    expect(wp.find(IconButton).props().disabled).toBeTruthy();
  });

  it('should show errors if a file is invalid', () => {
    const wp = mount(
      <UploadedFileList
        removeFile={() => {}}
        maxFiles={2}
        submitFiles={() => {}}
        disabled={false}
        submitting
        files={[
          {
            name: 'file3.pdf',
            pageCount: 3,
            filetype: 'html',
            status: FileUploadStatus.Invalid,
            errorMessages: ['error 1', 'error 2'],
          },
        ]}
      />,
    );

    expect(wp.find(SmallChip).contains('2 Errors'));
    expect(wp.find(Tooltip).contains('error 1'));
    expect(wp.find(Tooltip).contains('error 2'));
  });
});
