enum IndexingTypes {
  Legal = 1,
  Education = 2
}

export default IndexingTypes;
