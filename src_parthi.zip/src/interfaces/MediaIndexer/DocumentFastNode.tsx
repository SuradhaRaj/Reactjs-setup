import {
  Record, Number, String, Runtype, Boolean, Unknown, Static,
} from 'runtypes';
import DocumentNodeStateEnum from './DocumentNodeStateEnum';

export const DocumentFastNodeValidator = Record({
  id: Number,
  name: String,
  createdBy: String,
  createdDate: String,
  state: Unknown as Runtype<DocumentNodeStateEnum>,
  isNew: Boolean,
});

type DocumentFastNode = Static<typeof DocumentFastNodeValidator>;

export default DocumentFastNode;
