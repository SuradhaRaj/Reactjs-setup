import React from 'react';

import {
  createStyles, makeStyles, Theme,
} from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import { Grid } from '@material-ui/core';
import { Route, Switch, withRouter } from 'react-router-dom';
import routes from '../../RouteConfig';

import LoginStatus from '../molecules/LoginStatus';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    flexGrow: 1,
  },
  title: {
    flexGrow: 1,
  },
  toolbar: {
    padding: 0,
  },
  toolbarSides: {
    backgroundColor: theme.palette.primary.main,
    width: '100%',
    height: '74px',
    alignItems: 'center',
  },
  toolbarCenter: {
    alignItems: 'center',
    backgroundColor: theme.palette.primary.light,
  },
  menuButton: {
    padding: 0,
  },
}));

export default withRouter(({ history }) => {
  const classes = useStyles();

  const reloadHome = () => {
    const currentRoute = history.location.pathname;

    if (currentRoute === '/') {
      history.go(0);
    } else {
      history.push('/');
    }
  };

  return (
    <AppBar position="static">
      <Toolbar className={classes.toolbar}>
        <Grid
          container
          direction="row"
        >
          <Grid container item xs={2} className={classes.toolbarSides} style={{ justifyContent: 'center' }}>
            <IconButton
              classes={{
                root: classes.menuButton,
              }}
              color="inherit"
              aria-label="menu"
              onClick={reloadHome}
            >
              <img alt="Informit Logo" src="/assets/informitlogo.png" width={109} height={64} />
            </IconButton>
          </Grid>
          <Grid container item xs={8} className={classes.toolbarCenter}>
            <Switch>
              {
                routes.map((route) => <Route path={route.path} component={route.header} exact={route.exact} />)
              }
            </Switch>
          </Grid>
          <Grid container item xs={2} className={classes.toolbarSides}>
            <div>
              <LoginStatus />
            </div>
          </Grid>
        </Grid>
      </Toolbar>
    </AppBar>
  );
});
