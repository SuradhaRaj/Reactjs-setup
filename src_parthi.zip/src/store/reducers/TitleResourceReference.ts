import {
  ActionTypes, UPDATE_TITLE_REFERENCE_DATA,
} from '../actions/ActnTitleResourceReference';
import { TypedownOption, StrStrTypedownOption } from '../../interfaces/TypedownOption';
import TitleResourceReferenceData from '../../interfaces/ResourceManagement/TitleInformation';

export interface TitleResourceReferenceDataState {
    TitleResourceReferenceData: TitleResourceReferenceData;
}

export const initialState: TitleResourceReferenceDataState = {
  TitleResourceReferenceData: {
    broadSubjectLookup: [],
    contentType: [],
    descriptionType: [],
    fileType: [],
    frequency: [],
    indexingCompany: [],
    languages: [],
    mediaType: [],
    resourceManager: [],
    resourceTypes: [],
    titleType: [],
    resourceIndexes: [],
    seriesTitles: [],
    uniformTitles: [],
    resourceWorkflowStates: [],
    contactRoleType: [],
    accessRight: [],
    indexType: [],
    productLibrary: [],
    collection: [],
    clearedBy: [],
    countryOfPublicationMarc: [],
    cclicenceType: [],
    accessType: [],
    clearanceStatus: [],
    royaltyOrganisation: [],
    resourceslookup: [],
    fasttermLookup: [],
    fastGeoLookup: [],
    subjectLC: [],
    identifierlookup: [],
  },
};

export default (state = initialState, action: ActionTypes): TitleResourceReferenceDataState => {
  switch (action.type) {
    case UPDATE_TITLE_REFERENCE_DATA:
      return {
        ...state,
        TitleResourceReferenceData: action.payload,
      };

    default:
      return state;
  }
};
