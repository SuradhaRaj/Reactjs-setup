import {
  Static, Record, String, Null,
} from 'runtypes';
import { SearchResultValidator } from './SearchResult';

export const IssueSearchResultValidator = Record({
  dateOfPublication: String.Or(Null),
  scheduleDate: String.Or(Null),
  issueWorkFlowStatus: String.Or(Null),
  indexerGroup: String.Or(Null),
  numberOfArticles: String.Or(Null),
  grouping: String.Or(Null),
  resourceTitle: String.withConstraint((s) => !!s || 'Non empty string is required'),
  resourceID: String,
  resourceManager: String,
}).And(SearchResultValidator);

type IssueSearchResult = Static<typeof IssueSearchResultValidator>;

export default IssueSearchResult;
