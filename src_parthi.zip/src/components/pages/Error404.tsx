import React from 'react';
import NotInterestedIcon from '@material-ui/icons/NotInterested';
import {
  Grid, makeStyles, Typography, createStyles, Theme,
} from '@material-ui/core';
import { Link } from 'react-router-dom';

const useStyles = makeStyles((theme: Theme) => createStyles({
  backgroundRoot: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    right: 0,
    left: 0,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: -1,
  },
  backgroundIcon: { height: 300, width: 300, opacity: 0.04 },
  link: {
    marginTop: theme.spacing(1),
  },
}));

export default function Error404(): JSX.Element {
  const classes = useStyles();

  return (
    <>
      <Grid container>
        <Grid item xs={4} />
        <Grid item xs={4} justify="flex-end">
          <Grid item xs={12} direction="column" style={{ display: 'flex' }} alignItems="center">
            <Typography>We were unable to find the page you were looking for.</Typography>
            <Link to="/" className={classes.link}>Take me home</Link>
          </Grid>
        </Grid>
      </Grid>
      <div className={classes.backgroundRoot}>
        <NotInterestedIcon className={classes.backgroundIcon} />
      </div>
    </>
  );
}
