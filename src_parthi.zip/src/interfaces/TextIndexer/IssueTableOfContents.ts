import {
  Static, Record, Array, String, Number,
} from 'runtypes';

export const TableOfContentsArticleValidator = Record({
  artifactId: Number,
  workflowState: String,
  indexer: String,
  title: String,
  fallbackTitle: String,
});

export const IssueTableOfContentsValidator = Record({
  articles: Array(TableOfContentsArticleValidator),
});

export type TableOfContentsArticle = Static<typeof TableOfContentsArticleValidator>;

type IssueTableOfContents = Static<typeof IssueTableOfContentsValidator>;
export default IssueTableOfContents;
