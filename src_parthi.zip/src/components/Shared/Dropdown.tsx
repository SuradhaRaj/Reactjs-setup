/* eslint @typescript-eslint/no-explicit-any: 0 */
import React from 'react';
import {
  InputLabel, Select, MenuItem, FormControl, createStyles, withStyles, WithStyles, FormHelperText,
} from '@material-ui/core';
import classnames from 'classnames';
import DropdownOption from '../../interfaces/MediaIndexer/DropdownOption';

const useStyles = createStyles({
  dropdownField: {
    width: '100%',
  },
});

export interface DropdownProps {
  id: string;
  labelText: string;
  options: Array<DropdownOption>;
  selectedOption?: string | number | null;
  keyName: string;
  onChangeFunction: Function;
  classes: any;
  inputProps?: any;
  isReadOnly?: boolean;
  error?: boolean;
  errorMessage?: string;
  className?: string;
  value?: string | number |null ;
  helperText?: string;
  onBlur?: (event: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  allowUnselect?: boolean;
}

interface State {
  labelWidth: number;
}

class Dropdown extends React.Component<DropdownProps & WithStyles<typeof useStyles>, State> {
  private inputLabel = React.createRef<HTMLLabelElement>();

  constructor(props: DropdownProps) {
    super(props);
    this.handleChange = this.handleChange.bind(this);
    this.state = {
      labelWidth: 0,
    };
  }

  componentDidMount() {
    if (this.inputLabel.current != null) {
      this.setState({
        labelWidth: this.inputLabel.current.offsetWidth,
      });
    }
  }

  createOption = (option: DropdownOption) => (<MenuItem key={option.value} style={{ whiteSpace: 'pre-wrap' }} value={option.value}>{option.display}</MenuItem>)

  options = () => {
    let options: JSX.Element[] = [];
    if (this.props.allowUnselect) {
      options.push(this.createOption({ display: '-----', value: '' }));
    }
    options = options.concat(this.props.options.map((option) => this.createOption(option)));
    return options;
  }

  handleChange(event: any) {
    let value = event.target.value;
    if (value === '') {
      value = null;
    }
    this.props.onChangeFunction(this.props.keyName, value);
  }

  render() {
    const { classes } = this.props;
    return (
      <FormControl variant="outlined" className={classnames(classes.dropdownField, this.props.className)} error={this.props.error} margin="normal">
        <InputLabel shrink ref={this.inputLabel} id={`${this.props.id}Label`}>{this.props.labelText}</InputLabel>
        <Select
          labelId={`${this.props.id}Label`}
          id={this.props.id}
          defaultValue={this.props.selectedOption}
          value={this.props.value}
          onChange={this.handleChange}
          labelWidth={this.state.labelWidth}
          inputProps={this.props.inputProps}
          disabled={this.props.isReadOnly}
          onBlur={this.props.onBlur}
        >
          { this.options() }
        </Select>
        <FormHelperText>
          {this.props.error ? this.props.errorMessage : this.props.helperText}
        </FormHelperText>
      </FormControl>
    );
  }
}

export default withStyles(useStyles)(Dropdown);
