// eslint-disable-next-line import/prefer-default-export
export const MinSearchLength = 3;
