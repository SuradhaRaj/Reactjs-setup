import {
  Record, String, Static,
} from 'runtypes';

export const DocumentLangNodeValidator = Record({
  id: String,
  name: String,
  createdBy: String,
  createdDate: String,
});

type DocumentLangNode = Static<typeof DocumentLangNodeValidator>;

export default DocumentLangNode;
