/* eslint-disable @typescript-eslint/no-explicit-any */
import * as React from 'react';
import {
  makeStyles, createStyles, TableHead, TableRow, TableCell, TableSortLabel,
} from '@material-ui/core';
import { Order } from '../../utils/TableSortHelper';

export interface HeadCell {
    id: string;
    label: string;
    rightAlign?: boolean;
    className?: string;
    canSort?: boolean;
  }

interface EnhanceTableHeadProps {
    onRequestSort: Function;
    order: Order;
    orderBy: string | undefined;
    headCells: HeadCell[];
}

export default function EnhancedTableHead(props: EnhanceTableHeadProps): JSX.Element {
  const useStyles = makeStyles(() => createStyles({
    visuallyHidden: {
      border: 0,
      clip: 'rect(0 0 0 0)',
      height: 1,
      margin: -1,
      overflow: 'hidden',
      padding: 0,
      position: 'absolute',
      top: 20,
      width: 1,
    },
  }));
  const classes = useStyles();

  const { order, orderBy, onRequestSort } = props;
  const createSortHandler = (property: keyof any) => (event: React.MouseEvent<unknown>) => {
    onRequestSort(event, property);
  };

  return (
    <>
      <TableHead>
        <TableRow>
          {props.headCells.map((headCell) => (
            <TableCell
              key={headCell.id}
              align={headCell.rightAlign ? 'right' : 'left'}
              className={headCell.className}
              sortDirection={orderBy === headCell.id ? order : false}
            >
              {headCell.canSort || headCell.canSort === undefined ? (
                <TableSortLabel
                  active={orderBy === headCell.id}
                  direction={orderBy === headCell.id ? order : 'asc'}
                  onClick={createSortHandler(headCell.id)}
                >
                  {headCell.label}
                  {orderBy === headCell.id ? (
                    <span className={classes.visuallyHidden}>
                      {order === 'desc' ? 'sorted descending' : 'sorted ascending'}
                    </span>
                  ) : null}
                </TableSortLabel>
              ) : (<span>{headCell.label}</span>)}

            </TableCell>
          ))}
        </TableRow>
      </TableHead>
    </>
  );
}
