import * as Yup from 'yup';
import { DateTime } from 'luxon';
import Resource from '../interfaces/ResourceManagement/Resource';

const IsbnOrIssnReq = Yup.string().transform((x) => x ?? '').test('isbnOrIssnReq', 'At least one of ISSN, ISBN, eISSN or eISBN is required', function test(): boolean {
  const obj = this.parent as Partial<Resource>;
  return (!!obj.issn || !!obj.isbn || !!obj.eIsbn || !!obj.eIssn);
});

const schema: Partial<Record<keyof Resource, Yup.Schema<unknown>>> = {
  publicationYear: Yup.string().transform((x) => x ?? '').required('Publication Year is required.').test('publicationYear', 'Date must be in the format "YYYY"', (value: string) => {
    const dateNum = parseInt(value);
    const CURRENT_YEAR = DateTime.local().year;
    if (Number.isNaN(dateNum)) return false;

    if (value.length === 4 /* YYYY */) {
      if (dateNum < 1800 || dateNum > CURRENT_YEAR) { return false; }
      return true;
    }
    return false;
  }),
  resourceTitle: Yup.string().transform((x) => x ?? '').required('Resouce Title is required'),
  dateOfPublication: Yup.string().transform((x) => x ?? '').required('Date of Publication is required').test('dateOfPublication', 'Date must be in the format "YYYY", "YYYYMM" or "YYYYMMDD", and cannot be in the future.', (value: string) => {
    const dateNum = parseInt(value);
    const CURRENT_YEAR = DateTime.local().year;
    const CURRENT_MONTH = DateTime.local().month;

    if (Number.isNaN(dateNum)) return false;

    if (value.length === 4 /* YYYY */) {
      if (dateNum < 1800 || dateNum > CURRENT_YEAR) { return false; }
      return true;
    }
    if (value.length === 6 /* YYYYMM */) {
      const year = parseInt(value.substring(0, 4));
      const month = parseInt(value.substring(4));

      if (year < 1800 || year > CURRENT_YEAR) { return false; }
      if (month < 1 || month > 12) { return false; }
      if (year === CURRENT_YEAR && month > CURRENT_MONTH) { return false; }

      return true;
    }
    if (value.length === 8 /* YYYYMMDD */) {
      const date = DateTime.fromFormat(value, 'YYYYMMDD');
      if (!date.isValid) { return false; }
      if (date.diffNow().years > 0) { return false; }
      return true;
    }
    return false;
  }),
  mediaTypeId: Yup.number().transform((x) => (Number.isNaN(x) ? 0 : x)).positive('Media Type is required'),
  resourceManagerId: Yup.number().transform((x) => (Number.isNaN(x) ? 0 : x)).positive('Resource manager is required'),
  contentTypeId: Yup.number().transform((x) => (Number.isNaN(x) ? 0 : x)).positive('Content type is required'),
  resourceTypeId: Yup.number().transform((x) => (Number.isNaN(x) ? 0 : x)).positive('Resource type is required'),
  fileTypeId: Yup.number().transform((x) => (Number.isNaN(x) ? 0 : x)).positive('File Type is required'),
  resourceLanguage: Yup.array().min(1, 'At least one language must be selected'),
  resourceBroadSubject: Yup.array().min(1, 'At least one broad subject must be selected'),
  resourceFast: Yup.array().min(1, 'At least one FAST term must be selected'),
  resourceSubtitle: Yup.string().transform((x) => x ?? '').required('Subtitle is required'),
  uniformTitleID: Yup.number().transform((x) => (Number.isNaN(x) ? 0 : x)).positive('Uniform title is required'),
  edition: Yup.string().transform((x) => x ?? '').required('Edition is required.'),
  // frequencyId: Yup.number().transform((x) => (Number.isNaN(x) ? 0 : x)).positive('Frequency is required'),
  placeOfPublication: Yup.string().transform((x) => x ?? '').required('Place of Publication is required'),
  nameOfPublisherDisplay: Yup.string().transform((x) => x ?? '').required('Publisher Display Name is required'),
  doi: Yup.string().transform((x) => x ?? '').required('Digital Object Identifier is required'),
  persistentIdentifier: Yup.string().transform((x) => x ?? '').required('Persistent Identifier is required'),
  seriesTitleID: Yup.number().transform((x) => (Number.isNaN(x) ? 0 : x)).positive('Series title is required'),
  seriesVolume: Yup.string().transform((x) => x ?? '').required('Series Volumne is required'),
  seriesIssn: Yup.string().transform((x) => x ?? '').required('Series ISSN is required'),
  description: Yup.string().transform((x) => x ?? '').required('Description is required'),
  descriptionTypeId: Yup.number().transform((x) => (Number.isNaN(x) ? 0 : x)).positive('Description type is required'),
  source: Yup.string().transform((x) => x ?? '').required('Source is required'),
  indexingCompanyId: Yup.number().transform((x) => (Number.isNaN(x) ? 0 : x)).positive('Indexing Company is required'),
  issn: IsbnOrIssnReq,
  eIssn: IsbnOrIssnReq,
  eIsbn: IsbnOrIssnReq,
  isbn: IsbnOrIssnReq,
  resourceSubjectLc: Yup.array().required('Subject LC is required').max(6, 'The max (6) has been exceeded'),
};

export default Yup.object().shape(schema);
