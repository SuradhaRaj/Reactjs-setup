import React from 'react';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import BuildInformation from '../../config/build.json';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    position: 'sticky',
    bottom: 0,
    right: 0,
    zIndex: 100,
    width: 'auto',
    float: 'right',
    fontFamily: 'Consolas',
    backgroundColor: theme.palette.primary.light,
    opacity: 0.2,
    padding: 10,
    color: theme.palette.common.white,
    borderTopLeftRadius: 4,
    transition: 'all 0.2s',
    '&:hover': {
      opacity: 1,
      height: '4.5em',
    },
    height: '2.5em',
    overflow: 'hidden',
  },
  buildNumber: {
    position: 'relative',
    top: 10,
  },
}));

const BuildDetails = (): JSX.Element => {
  const classes = useStyles();

  if (!BuildInformation.DomainsToShow.includes(window.location.host)) {
    return (<></>);
  }

  return (
    <div className={classes.root}>
      <div>{BuildInformation.SourceBranchName}</div>
      <div className={classes.buildNumber}>{BuildInformation.BuildNumber}</div>
    </div>
  );
};

export default BuildDetails;
