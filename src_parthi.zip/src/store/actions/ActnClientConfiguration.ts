import ClientConfiguration from '../../classes/ClientConfiguration';

export const UPDATE_CONFIGURATION = 'UPDATE_CONFIGURATION';

interface UpdateConfiguration {
  type: typeof UPDATE_CONFIGURATION;
  payload: ClientConfiguration;
}

export type ActionTypes = UpdateConfiguration;

export function updateConfiguration(data: ClientConfiguration): ActionTypes {
  return {
    type: UPDATE_CONFIGURATION,
    payload: data,
  };
}
