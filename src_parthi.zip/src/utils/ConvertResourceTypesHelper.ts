import TextResourceType from '../interfaces/TextIndexer/ReferenceData/TextResourceType';
import ResourceTypeDropdownOption from '../interfaces/TextIndexer/ResourceTypeDropdownOption';

const ConvertChildren = (returnList: ResourceTypeDropdownOption[], list: TextResourceType[], numberOfTabs: number) => {
  for (let i = 0; i < list.length; i++) {
    let indentedName: string = list[i].name;
    // First add indentation to the name
    for (let j = 0; j < numberOfTabs; j++) {
      indentedName = `\t${indentedName}`;
    }

    // Now add the child to the returnList
    returnList.push({
      display: indentedName,
      value: {
        id: list[i].resourceTypeID,
        stringValue: list[i].name,
      },
    });

    if (list[i].children?.length > 0) {
      // Now convert its children
      ConvertChildren(returnList, list[i].children, numberOfTabs + 1);
    }
  }
};

const ConvertResourceTypes = (list: TextResourceType[], issueResourceTypeId?: number): ResourceTypeDropdownOption[] => {
  const returnList: ResourceTypeDropdownOption[] = [];

  // If we have an issueResourceTypeId then we want to filter by that, otherwise convert all resource types
  if (issueResourceTypeId) {
    const baseResourceType = list.find((x) => x.resourceTypeID === issueResourceTypeId);

    if (baseResourceType) {
      // Add resource type to returnList
      returnList.push({
        display: baseResourceType.name,
        value: {
          id: baseResourceType.resourceTypeID,
          stringValue: baseResourceType.name,
        },
      });

      if (baseResourceType.children?.length > 0) {
        // Convert children of current resource type
        ConvertChildren(returnList, baseResourceType.children, 1);
      }
    }
  } else {
    // Loop through top level resource types
    for (let i = 0; i < list.length; i++) {
      // Add resource type to returnList
      returnList.push({
        display: list[i].name,
        value: {
          id: list[i].resourceTypeID,
          stringValue: list[i].name,
        },
      });

      if (list[i].children?.length > 0) {
        // Convert children of current resource type
        ConvertChildren(returnList, list[i].children, 1);
      }
    }
  }

  return returnList;
};

export default {
  ConvertResourceTypes,
};
