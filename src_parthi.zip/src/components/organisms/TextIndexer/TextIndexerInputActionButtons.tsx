import React from 'react';
import {
  Button, makeStyles, createStyles, Typography, Hidden, withStyles, ListItemText, ListItemIcon, IconButton,
} from '@material-ui/core';
import SaveIcon from '@material-ui/icons/Save';
import PublishIcon from '@material-ui/icons/Publish';
import DeleteIcon from '@material-ui/icons/Delete';
import Menu, { MenuProps } from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import MoreHorizIcon from '@material-ui/icons/MoreHoriz';
import CheckIcon from '@material-ui/icons/Check';
// import ClearIcon from '@material-ui/icons/Clear';
import SaveAndSubmitButton from '../../molecules/MediaIndexer/SaveAndSubmitButton';
import ArtifactErrorCode from '../../../interfaces/MediaIndexer/ArtifactErrorCode';
import ArtifactStatus from '../../../interfaces/enums/ArtifactStatus';
import WithdrawButton from '../../molecules/MediaIndexer/WithdrawButton';
import AddNewArticlesButton from './AddNewArticlesButton';
import ReplaceArtifact from './ReplaceArtifact';
import ButtonWithDialog from '../../molecules/ButtonWithDialog';
import DialogWithCustomContent from '../../molecules/DialogWithCustomContent';
import WorkflowStatus from '../../../interfaces/enums/WorkflowStatus';

const useStyles = makeStyles(createStyles({
  button: {
    borderRadius: 50,
    margin: 5,
  },
}));

export interface TextIndexerInputActionButtonsProps {
  readonly?: boolean;
  errorCodes: ArtifactErrorCode[];
  submitTasks: string[];
  saveAndSubmitArtifact(action: string): void;
  saveAndPublishArtifact(): void;
  saveArtifact(): void;
  updateArtifactStatus(newStatus: ArtifactStatus): void;
  deleteArtifact(): void;
  approveIssueQA(): void;
  approveIssueQAReady: boolean;
  artifactStatus: ArtifactStatus;
  artifactId: number;
  formHasChange: boolean;
  workflowStatusId: WorkflowStatus;
  isAdmin: boolean;
}

const StyledMenu = withStyles({
  paper: {
    border: '1px solid #d3d4d5',
  },
})((props: MenuProps) => (
  <Menu
    elevation={0}
    getContentAnchorEl={null}
    anchorOrigin={{
      vertical: 'bottom',
      horizontal: 'center',
    }}
    transformOrigin={{
      vertical: 'top',
      horizontal: 'center',
    }}
    {...props}
  />
));

const StyledMenuItem = withStyles((theme) => ({
  root: {
    '&:focus': {
      backgroundColor: theme.palette.primary.main,
      '& .MuiListItemIcon-root, & .MuiListItemText-primary': {
        color: theme.palette.common.white,
      },
    },
  },
}))(MenuItem);

const TextIndexerInputActionButtons = (props: TextIndexerInputActionButtonsProps) => {
  const classes = useStyles();

  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = React.useState(false);

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  // If the artifact is a QA item, then we want to render different action buttons
  // if (props.workflowStatusId === WorkflowStatus.ReadyForArticleQA) { //RMIT-2375
  return (
    <>
      <div style={{ float: 'right' }}>
        {/* <Button
            variant="contained"
            color="primary"
            size="small"
            type="button"
            startIcon={<ClearIcon />}
            onClick={(event) => {
              event.preventDefault();
              props.saveArtifact();
            }}
            className={classes.button}
          >
            Reject
          </Button> */}

        {/* NOTE: Approve button will be disabled if table of contents is loading */}
        <Button
          variant="contained"
          color="primary"
          size="small"
          type="button"
          startIcon={<CheckIcon />}
          disabled={!props.approveIssueQAReady}
          onClick={(event) => {
            event.preventDefault();
            props.approveIssueQA();
          }}
          className={classes.button}
        >
          Approve
        </Button>

        <Button
          variant="contained"
          color="primary"
          size="small"
          type="button"
          startIcon={<SaveIcon />}
          onClick={(event) => {
            event.preventDefault();
            props.saveArtifact();
          }}
          className={classes.button}
        >
          Save
        </Button>
      </div>
    </>
  );
  // }//RMIT-2375

  return (
    <>
      <div style={{ float: 'right' }}>
        {!props.readonly && props.artifactStatus !== ArtifactStatus.Published && (
          <>
            {/* Replace, Delete and Add buttons are separate */}
            <Hidden lgDown>
              <ReplaceArtifact artifactId={props.artifactId} />
              <ButtonWithDialog
                buttonProps={{
                  variant: 'contained',
                  color: 'primary',
                  size: 'small',
                  type: 'button',
                  startIcon: (<DeleteIcon />),
                  className: classes.button,
                }}
                dialogContent={() => (
                  <Typography>
                    Deleting this artifact is
                    {' '}
                    <strong>permanent</strong>
                    {' '}
                    and cannot be undone.  Are you sure you wish to continue?
                  </Typography>
                )}
                dialogActions={(closeDialog) => (
                  <>
                    <Button variant="outlined" color="primary" onClick={() => closeDialog()}>Cancel</Button>
                    <Button onClick={() => { closeDialog(); props.deleteArtifact(); }}>Delete artifact</Button>
                  </>
                )}
                dialogTitle="Delete Artifact"
              >
                Delete
              </ButtonWithDialog>
              <AddNewArticlesButton />
            </Hidden>

            <SaveAndSubmitButton
              options={props.submitTasks}
              submitFunction={(action: string) => props.saveAndSubmitArtifact(action)}
            />
            <Button
              data-testid="save"
              variant="contained"
              color="primary"
              size="small"
              type="button"
              startIcon={<SaveIcon />}
              onClick={(event) => {
                event.preventDefault();
                props.saveArtifact();
              }}
              className={classes.button}
            >
              Save
            </Button>

            {/* Replace, Delete and Add buttons combined into More button */}
            <Hidden xlUp>
              <IconButton
                color="primary"
                size="small"
                onClick={handleClick}
                style={{ borderRadius: '50px', margin: 5 }}
              >
                <MoreHorizIcon />
              </IconButton>
              <StyledMenu
                id="customized-menu"
                anchorEl={anchorEl}
                keepMounted
                open={Boolean(anchorEl)}
                onClose={handleClose}
              >
                <ReplaceArtifact artifactId={props.artifactId} menuOption />

                <StyledMenuItem>
                  <ListItemIcon>
                    <DeleteIcon fontSize="small" />
                  </ListItemIcon>
                  <ListItemText
                    primary="Delete"
                    onClick={() => setDeleteDialogOpen(true)}
                  />
                </StyledMenuItem>

                <DialogWithCustomContent
                  open={deleteDialogOpen}
                  title="Delete Artifact"
                  dialogContent={() => (
                    <Typography>
                      Deleting this artifact is
                      {' '}
                      <strong>permanent</strong>
                      {' '}
                      and cannot be undone.  Are you sure you wish to continue?
                    </Typography>
                  )}
                  handleCloseFunction={() => setDeleteDialogOpen(false)}
                  handleConfirmOptionFunction={() => { setDeleteDialogOpen(false); props.deleteArtifact(); }}
                  cancelButtonText="Cancel"
                  confirmButtonText="Delete artifact"
                />

                <AddNewArticlesButton menuOption />
              </StyledMenu>
            </Hidden>
          </>
        )}
        {props.isAdmin && props.artifactStatus === ArtifactStatus.Published && (
          <>

            <ReplaceArtifact
              artifactId={props.artifactId}
              isPublished
            />

            <WithdrawButton
              artifactId={props.artifactId}
              onWithdrawCallback={() => (props.updateArtifactStatus(ArtifactStatus.Withdrawn))}
            />

            <Button
              data-testid="saveAndPublish"
              color="primary"
              size="small"
              className={classes.button}
              disabled={!props.formHasChange}
              variant="contained"
              startIcon={<PublishIcon />}
              onClick={props.saveAndPublishArtifact}
            >
              Save &amp; Publish
            </Button>

          </>
        )}
      </div>
    </>
  );
};

export default TextIndexerInputActionButtons;
