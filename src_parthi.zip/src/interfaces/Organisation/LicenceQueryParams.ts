export enum LicenceTemplateQueryParamKeys {
    licenceTemplateId = 'licenseTemplateId',
};

export type LicenceTemplateQueryParams = {
  licenceTemplateId: number;
};

export const GenerateLicenceTemplateQueryString = (params: LicenceTemplateQueryParams) => (
  `?${LicenceTemplateQueryParamKeys.licenceTemplateId}=${params.licenceTemplateId}`
);
