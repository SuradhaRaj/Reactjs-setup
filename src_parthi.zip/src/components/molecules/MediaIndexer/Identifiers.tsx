/* eslint @typescript-eslint/no-explicit-any: 0 */
import React from 'react';
import axios from 'axios';
import _ from 'lodash';
import {
  Grid, TextField, Chip, withStyles, WithStyles, createStyles, Zoom, CircularProgress,
} from '@material-ui/core';
import Autocomplete, { AutocompleteRenderOptionState } from '@material-ui/lab/Autocomplete';
import match from 'autosuggest-highlight/match';
import parse from 'autosuggest-highlight/parse';
import DocumentItemNode from '../../../interfaces/MediaIndexer/DocumentItemNode';
import LoadingButton from '../LoadingButton';
import TypedownCounter from '../../atoms/TypedownCounter';
import { TypedownDebounceTime } from '../../../constants/MediaIndexerConstants';
import ArtifactType from '../../../interfaces/enums/ArtifactType';
import AddNewIdentifierRequest from '../../../interfaces/TextIndexer/AddNewIdentifierRequest';

const useStyles = createStyles({
  addButton: {
    top: '25px',
    marginLeft: '10px',
  },
  idInput: {
    width: '100%',
  },
  idContainer: {
    textAlign: 'left',
  },
  identifiersTextField: {
  },
  chip: {
    marginRight: '5px',
    marginBottom: '5px',
  },
  renderOptionHighlighted: {
    fontWeight: 550,
  },
});

interface State {
  identifierValue: string;
  identifierOptions: IdentifierOption[];
  callingApi: boolean;
  loading: boolean;
}

interface IdentifiersProps {
  selectedIdentifiers: DocumentItemNode[];
  keyName: string;
  onChangeFunction(key: string, value: DocumentItemNode[]): void;
  fastAndIdentifierCount: number;
  fastAndIdentifierLimit: number;
  disabled?: boolean;
  error: boolean;
  errorText?: string | undefined;
  errorSnackbarFunction(error: string): void;
  classes: any;
  readOnly?: boolean;
  artifactType: ArtifactType;
}

interface IdentifierOption {
  id: number;
  name: string;
}

export class Identifiers extends React.Component<IdentifiersProps & WithStyles<typeof useStyles>, State, {}> {
  constructor(props: IdentifiersProps) {
    super(props);
    this.handleIdentifierChange = _.debounce(this.handleIdentifierChange, TypedownDebounceTime);
    this.handleIdentifierChange = this.handleIdentifierChange.bind(this);
    this.addIdentiferToList = this.addIdentiferToList.bind(this);
    this.handleDeleteIdentifier = this.handleDeleteIdentifier.bind(this);
    this.addNewIdentiferToList = this.addNewIdentiferToList.bind(this);
    this.renderChips = this.renderChips.bind(this);

    this.state = {
      identifierValue: '',
      identifierOptions: [],
      callingApi: false,
      loading: false,
    };
  }

  getIdentifiers(searchTerm: string): Promise<IdentifierOption[]> {
    const returnList: IdentifierOption[] = [];

    const suggestionsPromise = new Promise<IdentifierOption[]>((resolve, reject) => {
      this.setState((prevState) => ({
        ...prevState,
        loading: true,
        identifierOptions: [],
      }));

      fetch(`${process.env.REACT_APP_API_URL}/api/Indexing/searchidentifiers?searchTerm=${searchTerm}&artifactType=${this.props.artifactType}`)
        .then((res) => res.json())
        .then(
          (result) => {
            if (result.status === 200) {
              for (let i = 0; i < result.results.length; i += 1) {
                returnList.push({ id: result.results[i].identifierID, name: result.results[i].name });
              }
            }
            resolve(returnList);
          },
          (error: Error) => {
            reject(error);
          },
        ).finally(() => {
          this.setState((prevState) => ({
            ...prevState,
            loading: false,
          }));
        });
    });

    return suggestionsPromise;
  }

  getOptionRender(option: IdentifierOption, renderOptionState: AutocompleteRenderOptionState): JSX.Element {
    const matches = match(option.name, renderOptionState.inputValue);
    const parts = parse(option.name, matches);
    const { classes } = this.props;

    return (
      <>
        <Grid item xs={12}>
          {parts.map((part) => (
            <span className={part.highlight ? classes.renderOptionHighlighted : ''}>
              {part.text}
            </span>
          ))}
        </Grid>
      </>
    );
  }

  handleDeleteIdentifier = (idToDelete: DocumentItemNode) => () => {
    const newList = this.props.selectedIdentifiers.filter((id) => id.name !== idToDelete.name);
    this.props.onChangeFunction(this.props.keyName, newList);
  }

  handleIdentifierChange(event: any): void {
    const value: string = event.target.value;

    if (value.length > 2 && value.length < 100) {
      this.getIdentifiers(value)
        .then((result: IdentifierOption[]) => {
          this.setState({ identifierOptions: result, identifierValue: value });
        });
    }
  }

  addIdentiferToList(event: any, value: string | IdentifierOption | null): void {
    // If we have a valid value and it is not already in the id list then we will add it to the list
    if (typeof value !== 'string') {
      if (value !== undefined && value !== null && this.props.selectedIdentifiers !== undefined) {
        if (this.props.selectedIdentifiers.find((id) => id.name === value.name) === undefined) {
          this.props.onChangeFunction(this.props.keyName, [...this.props.selectedIdentifiers, {
            id: value.id, name: value.name, createdBy: '', createdDate: '',
          }]);
        }
      } else if (value !== undefined && value != null && this.props.selectedIdentifiers === undefined) {
        this.props.onChangeFunction(this.props.keyName, [{
          id: value.id, name: value.name, createdBy: '', createdDate: '',
        }]);
      }
    }
  }

  addNewIdentiferToList(): void {
    const value: string = this.state.identifierValue;

    if (value === null || value === undefined || value === '') {
      return;
    }

    this.setState((prevState) => ({
      ...prevState,
      callingApi: true,
    }));

    const requestData: AddNewIdentifierRequest = {
      name: value.trim(),
      artifactType: this.props.artifactType,
    };

    axios.post(`${process.env.REACT_APP_API_URL}/api/Indexing/AddNewIdentifier`, requestData)
      .then((response: any) => {
        if (response !== null && response.data.status === 200) {
          if (this.props.selectedIdentifiers !== undefined) {
            if (value !== '' && this.props.selectedIdentifiers.find((id) => id.name === value) === undefined) {
              this.props.onChangeFunction(this.props.keyName, [...this.props.selectedIdentifiers, {
                id: response.data.identifierID, name: value, createdBy: '', createdDate: '',
              }]);
            }
          } else if (this.props.selectedIdentifiers === undefined && value !== '') {
            this.props.errorSnackbarFunction('An error occured when trying to add a new identifier');
            this.props.onChangeFunction(this.props.keyName, [{
              id: 0, name: value, createdBy: '', createdDate: '',
            }]);
          }
        } else {
          this.props.errorSnackbarFunction('An error occured when trying to add a new identifier');
        }
      }).finally(() => {
        this.setState((prevState) => ({
          ...prevState,
          callingApi: false,
        }));
      });
  }

  renderChips() {
    if (this.props.selectedIdentifiers !== undefined) {
      return (
        this.props.selectedIdentifiers.map((id: DocumentItemNode) => <Zoom in={this.props.selectedIdentifiers.includes(id)} key={id.id}><Chip tabIndex={-1} style={{ margin: '5px' }} variant="outlined" disabled={this.props.readOnly} label={id.name} onDelete={this.handleDeleteIdentifier(id)} color="primary" /></Zoom>)
      );
    }

    return null;
  }

  render(): JSX.Element {
    const { classes } = this.props;
    return (
      <>
        <Grid container item xs={12}>
          <Grid item xs={6} style={{ position: 'relative' }}>
            <Autocomplete
              freeSolo
              filterOptions={(x) => (x)}
              disabled={this.props.disabled || this.props.readOnly || this.props.fastAndIdentifierCount >= this.props.fastAndIdentifierLimit}
              className={classes.idInput}
              id="identifiers"
              options={this.state.identifierOptions}
              onChange={this.addIdentiferToList}
              renderInput={(params: any) => (
                <TextField
                  {...params}
                  variant="outlined"
                  label="Identifiers"
                  margin="normal"
                  className={classes.identifiersTextField}
                  fullWidth
                  onChange={(e: { persist: () => void}) => {
                    e.persist();
                    this.handleIdentifierChange(e);
                  }}
                  error={this.props.error}
                  helperText={this.props.error ? this.props.errorText : ''}
                  InputProps={{
                    ...params.InputProps,
                    endAdornment: (
                      <>
                        {this.state.loading ? <CircularProgress color="inherit" size={20} /> : null}
                        {params.InputProps.endAdornment}
                      </>
                    ),
                  }}
                />
              )}
              // eslint-disable-next-line max-len
              renderOption={(option: IdentifierOption, renderOptionState: AutocompleteRenderOptionState) => this.getOptionRender(option, renderOptionState)}
              renderTags={() => <></>}

            />
          </Grid>
          <Grid item xs={1}>
            <LoadingButton isLoading={this.state.callingApi} className={classes.addButton} disabled={this.props.readOnly} size="small" color="primary" onClick={this.addNewIdentiferToList}>Add</LoadingButton>
          </Grid>
          {!this.props.error && (
          <Grid item xs={6}>
            <TypedownCounter
              limit={this.props.fastAndIdentifierLimit}
              selected={this.props.fastAndIdentifierCount}
            />
          </Grid>
          )}
        </Grid>
        <Grid container item xs={9} className={classes.idContainer}>
          {
            this.renderChips()
          }
        </Grid>
      </>
    );
  }
}

export default withStyles(useStyles)(Identifiers);

// export default compose<IdentifiersProps, {}>(withStyles(useStyles), withSnackbar)(Identifiers);
