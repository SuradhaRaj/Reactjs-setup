import React, { useState } from 'react';
import {
  Typography, Grid, Card, Button, makeStyles,
} from '@material-ui/core';
import { green, red } from '@material-ui/core/colors';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import EditIcon from '@material-ui/icons/Edit';
import RemoveCircleIcon from '@material-ui/icons/RemoveCircle';

import FormGroup from '@material-ui/core/FormGroup';
import Checkbox from '@material-ui/core/Checkbox';
import { boolean } from 'yup';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Contractdate from './Contractdate';
import TextInputField from '../../Shared/TextInputField';
import TypedownFilter from '../TypedownFilter';
import { useTypedSelector } from '../../../store/store';

import TextareaField from '../../Shared/TextareaField';
import { StrStrTypedownOption } from '../../../interfaces/TypedownOption';

function createData({
  IndexType,
  StartDate,
  StartVolume,
  Startissue,
  Enddate,
  EndVolume,
  Endissue,
  ProductType,
}: {
  IndexType: string;
  StartDate: string;
  StartVolume: string;
  Startissue: number;
  Enddate: string;
  EndVolume: string;
  Endissue: number;
  ProductType: string;
}) {
  return {
    IndexType,
    StartDate,
    StartVolume,
    Startissue,
    Enddate,
    EndVolume,
    Endissue,
    ProductType,
  };
}

const rows = [
  createData({
    IndexType: 'Selective',
    StartDate: 'Nov 1987',
    StartVolume: 'No 48',
    Startissue: 48,
    Enddate: 'Spring 1988',
    EndVolume: 'No 57',
    Endissue: 57,
    ProductType: 'AFAT ',
  }),
  createData({
    IndexType: 'Comprehensive',
    StartDate: '2008',
    StartVolume: 'No 48',
    Startissue: 48,
    Enddate: '2012',
    EndVolume: 'No 98',
    Endissue: 98,
    ProductType: 'AFAT ',
  }),
  createData({
    IndexType: 'Comprehensive',
    StartDate: '2008',
    StartVolume: 'No 48',
    Startissue: 48,
    Enddate: '2014',
    EndVolume: '',
    Endissue: 109,
    ProductType: 'Collections ',
  }),
];

interface State {
  isLoading: any;
  publisher: Array<string>;
}

export interface SelectedOptionState {
  grouping: string[];
  publisher: string[];
  title: string[];
  id: string[];
  article: string[];
  documentNumber: string[];
  resource: string[];
  hasIndexerNotes?: boolean;
  hasPublisherNotes?: boolean;
  includeRelated?: boolean;
}

type NewType = boolean;

interface Props {
  isLoading: NewType;
  productInfo: Array<StrStrTypedownOption> | null;
}

const useStyles = makeStyles({
  resourceIdeContainer: {
    paddingBottom: '20',
  },

  heading: {
    'font-size': '13px',
    'font-weight': '500',
    'text-transform': 'none',
    color: '#000000',
  },
  addbutton: {
    height: '32px',
    'font-size': '13px',
    'line-height': '30px',
  },
  subheading: {
    'font-size': '12px',
    'font-weight': '500',
    'text-transform': 'none',
    color: '#000000',
  },
  borderleft: {
    borderleft: '1px solid #cccccc',
  },
  notification: {},
  typo: {
    fontSize: '17px',
    'font-weight': '600',
    marginBottom: '0px',
    paddingLeft: '20px !important',
    'text-transform': 'none',
  },
  root: {
    width: '100%',
  },
  table: {
    minWidth: 650,
  },
  customaccordion: {
    PaddingLeft: '20',
    paddingRight: '20',
  },
});

function LicenseInfo(props: Props): JSX.Element {
  const classes = useStyles();
  const taskManagement = useTypedSelector((store) => store.TextTaskManagement);

  const [state] = useState<State>({
    publisher: [],
    isLoading: boolean,
  });

  function changeFilter<T extends keyof SelectedOptionState>(
    filterName: T,
    value: SelectedOptionState[T],
  ) {
    //    setFilterList(filterList.updateFilter<keyof SelectedOptionState>(filterName, value));
  }

  //  const [filterList, setFilterList] = useState<SelectedOptionFilters>(SelectedOptionFilters.empty());

  return (
    <Grid
      item
      xs={12}
      container
      style={{
        marginLeft: 0,
        marginRight: 0,
        paddingBottom: 0,
        marginTop: 0,
        marginBottom: 0,
      }}
    >
      <Grid
        xs={12}
        container
        spacing={4}
        style={{
          marginLeft: 0,
          marginRight: 0,
        }}
      >
        <Grid item xs={6} container spacing={2}>
          <Grid item xs={6}>
            <div className="custominput mt0">
              <TextInputField
                keyName="eissn"
                labelText="Agreement Number"
                inputText=""
                onChangeFunction={(e: any) => e}
                //       onBlur={() => { }}
                error={false}
              />
            </div>
          </Grid>
          <Grid item xs={6}>
            <div className="customradiobutton">
              <span>Perpetual Access?</span>
              <FormControl component="fieldset">
                <RadioGroup
                  row
                  aria-label="position"
                  name="position"
                  defaultValue="start"
                >
                  <FormControlLabel
                    value="start"
                    control={<Radio color="primary" />}
                    label="Yes"
                    labelPlacement="start"
                  />
                  <FormControlLabel
                    value="start"
                    control={<Radio color="primary" />}
                    label="No"
                    labelPlacement="start"
                  />
                </RadioGroup>
              </FormControl>
            </div>
          </Grid>
          <Grid item xs={12}>
            <div className="custominput mt0">
              <TextInputField
                keyName="eissn"
                labelText="Copyright Statement"
                inputText=""
                onChangeFunction={(e: any) => e}
                //       onBlur={() => { }}
                error={false}
              />
            </div>
          </Grid>
          <Grid item xs={6}>
            <div className="custominput mt0">
              <TextInputField
                keyName="eissn"
                labelText="Price"
                inputText=""
                onChangeFunction={(e: any) => e}
                //       onBlur={() => { }}
                error={false}
              />
            </div>
          </Grid>
          <Grid item xs={6}>
            <div className="custommultislect">
              <TypedownFilter
                isLoading={props.isLoading}
                title="Clearance Status"
                options={state.publisher}
                selectedOptions={taskManagement.Filters.data.publisher}
                onChange={(options) => {
                  changeFilter('publisher', options as string[]);
                }}
              />
            </div>
          </Grid>
          <Grid item xs={6}>
            <div className="custommultislect">
              <TypedownFilter
                isLoading={props.isLoading}
                title="Access Rights"
                options={state.publisher}
                selectedOptions={taskManagement.Filters.data.publisher}
                onChange={(options) => {
                  changeFilter('publisher', options as string[]);
                }}
              />
            </div>
          </Grid>
          <Grid item xs={6}>
            <div className="custommultislect">
              <TypedownFilter
                isLoading={props.isLoading}
                title="Access Type (KBART)"
                options={state.publisher}
                selectedOptions={taskManagement.Filters.data.publisher}
                onChange={(options) => {
                  changeFilter('publisher', options as string[]);
                }}
              />
            </div>
          </Grid>
        </Grid>
        <Grid item xs={6} container>
          <Grid xs={12}>
            <Card
              variant="outlined"
              className="royaltyinfoContainer"
              style={{
                marginLeft: 0,
                marginRight: 0,
                paddingBottom: 0,
                marginTop: 0,
                marginBottom: 0,
              }}
            >
              <Grid
                xs={12}
                container
                spacing={2}
                style={{
                  marginBottom: 0,
                }}
              >
                <Grid item xs={6}>
                  <h6 className={classes.heading}>Royalty Information</h6>
                </Grid>
                <Grid item xs={6} style={{ textAlign: 'right' }}>
                  <FormControl component="fieldset" className="customCheckbox">
                    <FormGroup aria-label="position" row>
                      <FormControlLabel
                        value="RoyaltiesDue"
                        control={<Checkbox color="primary" />}
                        label="Royalties Due?"
                        labelPlacement="end"
                      />
                    </FormGroup>
                  </FormControl>
                </Grid>
              </Grid>
              <Grid xs={12} container spacing={2}>
                <Grid item xs={6}>
                  <div className="custommultislect">
                    <TypedownFilter
                      isLoading={props.isLoading}
                      title="Royalty Organization"
                      options={state.publisher}
                      selectedOptions={taskManagement.Filters.data.publisher}
                      onChange={(options) => {
                        changeFilter('publisher', options as string[]);
                      }}
                    />
                  </div>
                </Grid>
                <Grid item xs={6}>
                  <div className="custommultislect">
                    <TypedownFilter
                      isLoading={props.isLoading}
                      title="Cleared By"
                      options={state.publisher}
                      selectedOptions={taskManagement.Filters.data.publisher}
                      onChange={(options) => {
                        changeFilter('publisher', options as string[]);
                      }}
                    />
                  </div>
                </Grid>
                <Grid item xs={6}>
                  <div className="custominput mt0">
                    <TextInputField
                      keyName="eissn"
                      labelText="Royalty Rate"
                      inputText=""
                      onChangeFunction={(e: any) => e}
                      //       onBlur={() => { }}
                      error={false}
                    />
                  </div>
                </Grid>
                <Grid item xs={6}>
                  <div className="custominput mt0">
                    <TextInputField
                      keyName="eissn"
                      labelText="Archive Royalty Rate"
                      inputText=""
                      onChangeFunction={(e: any) => e}
                      //       onBlur={() => { }}
                      error={false}
                    />
                  </div>
                </Grid>
              </Grid>
            </Card>
          </Grid>
          <Grid
            xs={12}
            style={{
              marginLeft: 0,
              marginRight: 0,
              paddingLeft: 0,
              paddingRight: 0,
            }}
          >
            <Card
              variant="outlined"
              className="royaltybottomContainer"
              style={{
                marginLeft: 0,
                marginRight: 0,
                paddingBottom: 0,
                marginTop: 0,
                marginBottom: 0,
              }}
            >
              <Grid xs={12} container>
                <Grid item xs={7}>
                  <FormControl component="fieldset" className="customCheckbox">
                    <FormGroup aria-label="position">
                      <FormControlLabel
                        value="RoyaltiesDue"
                        control={<Checkbox color="primary" />}
                        label="Individual Subscriptions Available?"
                        labelPlacement="end"
                      />
                    </FormGroup>
                    <FormGroup aria-label="position">
                      <FormControlLabel
                        value="RoyaltiesDue"
                        control={<Checkbox color="primary" />}
                        label="PPV Available?"
                        labelPlacement="end"
                      />
                    </FormGroup>
                  </FormControl>
                </Grid>
                <Grid item xs={5}>
                  <div className="custommultislect">
                    <TypedownFilter
                      isLoading={props.isLoading}
                      title="Royalty Organization"
                      options={state.publisher}
                      selectedOptions={taskManagement.Filters.data.publisher}
                      onChange={(options) => {
                        changeFilter('publisher', options as string[]);
                      }}
                    />
                  </div>
                </Grid>
              </Grid>
            </Card>
          </Grid>
        </Grid>
      </Grid>
      <Grid xs={12}>
        <Contractdate isLoading={state.isLoading} />
      </Grid>
      <Grid xs={12}>
        <Card
          variant="outlined"
          className="resourceIdeContainer"
          style={{
            marginLeft: 0,
            marginRight: 0,
            paddingBottom: 20,
            marginTop: 0,
            paddingTop: 0,
          }}
        >
          <Grid container xs={12}>
            <Typography
              className={classes.heading}
              variant="overline"
              style={{
                paddingLeft: 20,
                paddingRight: 20,
                marginTop: 0,
              }}
            >
              Full-text Resource Coverage
            </Typography>
          </Grid>
          <Grid
            xs={12}
            spacing={2}
            container
            style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
          >
            <Grid item xs={2}>
              <div className="custommultislect">
                <TypedownFilter
                  isLoading={props.isLoading}
                  title="Index Type"
                  options={state.publisher}
                  selectedOptions={taskManagement.Filters.data.publisher}
                  onChange={(options) => {
                    changeFilter('publisher', options as string[]);
                  }}
                />
              </div>
            </Grid>
            <Grid item xs={2}>
              <div className="custominput mt0">
                <TextInputField
                  keyName="eissn"
                  labelText="Start Date"
                  inputText=""
                  onChangeFunction={(e: any) => e}
                  // onBlur={() => {}}
                  error={false}
                />
              </div>
            </Grid>
            <Grid item xs={2}>
              <div className="custominput mt0">
                <TextInputField
                  keyName="eissn"
                  labelText="Start Volume"
                  inputText=""
                  onChangeFunction={(e: any) => e}
                  // onBlur={() => {}}
                  error={false}
                />
              </div>
            </Grid>
            <Grid item xs={2}>
              <div className="custominput mt0">
                <TextInputField
                  keyName="eissn"
                  labelText="Start Issues"
                  inputText=""
                  onChangeFunction={(e: any) => e}
                  // onBlur={() => {}}
                  error={false}
                />
              </div>
            </Grid>
            <Grid item xs={2}>
              <div className="custominput mt0">
                <TextInputField
                  keyName="eissn"
                  labelText="End Date"
                  inputText=""
                  onChangeFunction={(e: any) => e}
                  // onBlur={() => {}}
                  error={false}
                />
              </div>
            </Grid>
            <Grid item xs={2}>
              <div className="custominput mt0">
                <TextInputField
                  keyName="eissn"
                  labelText="End Volume"
                  inputText=""
                  onChangeFunction={(e: any) => e}
                  // onBlur={() => {}}
                  error={false}
                />
              </div>
            </Grid>
            <Grid item xs={2}>
              <div className="custominput mt0">
                <TextInputField
                  keyName="eissn"
                  labelText="End Issues"
                  inputText=""
                  onChangeFunction={(e: any) => e}
                  // onBlur={() => {}}
                  error={false}
                />
              </div>
            </Grid>
            <Grid item xs={2}>
              <div className="custommultislect">
                <TypedownFilter
                  isLoading={props.isLoading}
                  title="Product Type"
                  options={state.publisher}
                  selectedOptions={taskManagement.Filters.data.publisher}
                  onChange={(options) => {
                    changeFilter('publisher', options as string[]);
                  }}
                />
              </div>
            </Grid>
            <Grid item xs={6} />
            <Grid item xs={2} style={{ textAlign: 'right' }}>
              <Button
                type="button"
                // onClick={() => {}}
                color="primary"
                variant="outlined"
                className="addbutton"
              >
                Add
              </Button>
            </Grid>
          </Grid>
          <Grid xs={12} spacing={2}>
            <div className="custom_table">
              <TableContainer>
                <Table className={classes.table} aria-label="simple table">
                  <TableHead>
                    <TableRow>
                      <TableCell align="left" />
                      <TableCell align="left">Index Type</TableCell>
                      <TableCell align="left">Start Date</TableCell>
                      <TableCell align="left">Start Volume</TableCell>
                      <TableCell align="left">Start Issue</TableCell>
                      <TableCell align="left">End Date</TableCell>
                      <TableCell align="left">End Volume</TableCell>
                      <TableCell align="left">End Issue</TableCell>
                      <TableCell align="left">Product Type</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {rows.map((row) => (
                      <TableRow key={row.IndexType}>
                        <TableCell className="action_icon">
                          <Button type="button">
                            <EditIcon
                              style={{ color: green[500] }}
                              fontSize="small"
                            />
                          </Button>
                          <Button type="button">
                            <RemoveCircleIcon
                              style={{ color: red[500] }}
                              fontSize="small"
                            />
                          </Button>
                        </TableCell>
                        <TableCell component="th" scope="row">
                          {row.IndexType}
                        </TableCell>
                        <TableCell align="left">{row.StartDate}</TableCell>
                        <TableCell align="left">{row.StartVolume}</TableCell>
                        <TableCell align="left">{row.Startissue}</TableCell>
                        <TableCell align="left">{row.Enddate}</TableCell>
                        <TableCell align="left">{row.EndVolume}</TableCell>
                        <TableCell align="left">{row.Endissue}</TableCell>
                        <TableCell align="left">{row.ProductType}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </div>
          </Grid>
          <Grid
            xs={12}
            spacing={2}
            style={{
              marginLeft: '20',
              marginRight: '20',
            }}
          >
            <div className="customtextarea mlr20">
              <FormControl>

                <TextareaField
                  id="Textarea-text"
                  inputText=""
                  error={false}
                  labelText="Product Notes"
                  keyName=""
                  onChangeFunction={undefined}
                  onBlur={undefined}
                />
              </FormControl>
            </div>
          </Grid>
        </Card>
      </Grid>
    </Grid>
  );
}

export default LicenseInfo;
