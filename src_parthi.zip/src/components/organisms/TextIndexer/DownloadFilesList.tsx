/* eslint-disable max-len */
import React from 'react';
import { Static } from 'runtypes';
import {
  Typography, List, makeStyles, Theme, createStyles, Divider, ListItem, ListItemText, ListItemSecondaryAction, IconButton, CircularProgress, Box,
} from '@material-ui/core';
import Scrollbars from 'react-custom-scrollbars';
import bytes from 'bytes';
import DownloadIcon from '@material-ui/icons/GetApp';
import Axios from 'axios';
import { useSnackbar } from 'notistack';
import { FileValidator } from '../../../interfaces/TextIndexer/IssueArtifact';

const useStyles = makeStyles((theme: Theme) => createStyles({
  list: {
    marginRight: theme.spacing(2),
    marginBottom: 0,
    height: 275,
  },
  fileCount: {
    marginRight: theme.spacing(2),
    marginBottom: theme.spacing(1),
  },
  noDownlodColor: {
    color: '#f00',
    marginRight: theme.spacing(1),

  },
  DownlodColor: {
    color: theme.palette.text.primary,
    marginRight: theme.spacing(1),

  },
  secondaryText: {
    color: theme.palette.text.secondary,
    marginRight: theme.spacing(1),
  },
}));

interface DownloadFilesListItemProps {
    file: Static<typeof FileValidator>;
    issuePath: string;
    mode?: string;
};

export const MODE_EXTRA = 'extra';

interface DownloadFilesListItemState {
    loading: boolean;
}

const DownloadFilesListItem = (props: DownloadFilesListItemProps) => {
  const classes = useStyles();

  const [state, setState] = React.useState<DownloadFilesListItemState>({ loading: false });

  const { enqueueSnackbar } = useSnackbar();
  let downloadRoute: string;
  if (props.mode === MODE_EXTRA) {
    downloadRoute = 'downloadextra';
  } else {
    downloadRoute = 'downloadissue';
  }
  const downloadUrl = `${process.env.REACT_APP_API_URL}/api/articleindexer/${downloadRoute}?issuePath=${props.issuePath}&filename=${props.file.filename}`;

  const downloadFile = () => {
    setState({
      ...state,
      loading: true,
    });

    Axios.get(downloadUrl, { responseType: 'blob' })
      .then((response) => {
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', props.file.filename);
        document.body.appendChild(link);
        link.click();
        link.remove();
      })
      .catch(() => {
        enqueueSnackbar(`An error occurred while downloading ${props.file.filename}`, { variant: 'error' });
      })
      .finally(() => {
        setState((prevState) => ({
          ...prevState,
          loading: false,
        }));
      });
  };

  const downloadIcon = props.file.isExisted ? (
    <IconButton
      edge="end"
      onClick={downloadFile}
    >
      <DownloadIcon />
    </IconButton>
  )
    : '';
  return (
    <>
      <Divider variant="fullWidth" component="li" />
      <ListItem dense disableGutters>
        <ListItemText
          primary={(
            <Box display="flex">
              <Box width="100%" className={props.file.isExisted ? classes.DownlodColor : classes.noDownlodColor}>
                {props.file.filename}
              </Box>
              <Box className={props.file.isExisted ? classes.DownlodColor : classes.noDownlodColor}>
                {bytes(props.file.size, { decimalPlaces: 2, fixedDecimals: true })}
              </Box>
            </Box>
          )}
        />
        <ListItemSecondaryAction>
          {state.loading ? (
            <CircularProgress size={24} />
          ) : downloadIcon}
        </ListItemSecondaryAction>
      </ListItem>
    </>
  );
};

interface DownloadFilesListProps {
    files: Static<typeof FileValidator>[];
    issuePath: string;
    mode?: string;
};

const DownloadFilesList = (props: DownloadFilesListProps) => {
  const classes = useStyles();
  return (
    <>
      {props.files.length === 0
        ? (
          <Typography>No files available for download</Typography>
        )
        : (
          <>
            <Typography
              variant="body1"
              align="right"
              className={classes.fileCount}
            >
              {`${props.files.length} file${props.files.length === 1 ? '' : 's'}`}
            </Typography>
            <Scrollbars
              autoHeight
              autoHeightMax={275}
              autoHeightMin={0}
            >
              <List dense disablePadding className={classes.list}>
                {props.files.map((file) => (
                  <DownloadFilesListItem
                    file={file}
                    issuePath={props.issuePath}
                    mode={props.mode}
                  />
                ))}
              </List>
            </Scrollbars>
          </>
        )}
    </>
  );
};

export default DownloadFilesList;
