import React, { useEffect, useState } from 'react';
import UnfoldMoreIcon from '@material-ui/icons/UnfoldMore';
import UnfoldLessIcon from '@material-ui/icons/UnfoldLess';
import {
  makeStyles, createStyles, Theme, Typography, CircularProgress,
} from '@material-ui/core';
import classNames from 'classnames';

interface Props {
  JwtToken: string;
  VideoContentID: string;
  ClassName: string;
  onVideoResize(): void;
  isVideoExpanded: boolean;
}

interface State {
  scriptLoaded: boolean;
}

const useStyles = makeStyles((theme: Theme) => createStyles({
  expander: {
    backgroundColor: theme.palette.primary.light,
    color: '#fff',
    padding: theme.spacing(1),
    display: 'flex',
    justifyContent: 'flex-end',
    borderRadius: '0px 0px 4px 4px',
    cursor: 'pointer',
  },
  typography: {
    display: 'inline',
  },
  root: {
    display: 'flex',
    justifyContent: 'center',
  },
  container: {
    width: '50%',
    height: '100%',
    transition: 'all 0.5s',
  },
  containerExpanded: {
    width: '80%',
  },
}));

const SwitchMediaPlayer: React.FC<Props> = (props) => {
  const classes = useStyles();
  const [state, setState] = useState<State>({
    scriptLoaded: false,
  });

  const loadResources = () => {
    const script = document.createElement('script');
    script.src = 'https://html-player.switch.tv/bundle/4.1.0/rmit/player.js';
    script.onload = () => {
      setState({
        ...state,
        scriptLoaded: true,
      });
    };
    document.body.appendChild(script);

    const link = document.createElement('link');
    link.href = 'https://html-player.switch.tv/bundle/4.1.0/rmit/skin.css';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
  };

  useEffect(() => {
    loadResources();
  }, []);

  useEffect(() => {
    if (state.scriptLoaded) {
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      const player = new SwitchUniversalPlayer(document.getElementById('player'));

      // the plugin will load the asset by video id
      player.load({
        contentID: props.VideoContentID,
        token: props.JwtToken,
      });
    }
  }, [state.scriptLoaded]);

  return (

    <div className={classes.root}>
      {state.scriptLoaded && (
      <div className={classNames(classes.container, { [classes.containerExpanded]: props.isVideoExpanded })}>
        <div style={{ borderRadius: '4px 4px 0px 0px' }} id="player" className={props.ClassName} />
        {!props.isVideoExpanded && (
        <div className={classes.expander} onClick={props.onVideoResize} role="button" tabIndex={-1}>
          <Typography className={classes.typography}>Expand video</Typography>
          <UnfoldMoreIcon />
        </div>
        )}
        {props.isVideoExpanded && (
        <div className={classes.expander} onClick={props.onVideoResize} role="button" tabIndex={-1}>
          <Typography className={classes.typography}>Shrink video</Typography>
          <UnfoldLessIcon />
        </div>
        )}
      </div>
      )}
      {!state.scriptLoaded && (<CircularProgress />)}

    </div>
  );
};

export default SwitchMediaPlayer;
