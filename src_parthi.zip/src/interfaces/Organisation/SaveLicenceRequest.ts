interface SaveLicenceRequest {
  licenceId: number;
  ielcopyright: string | null;
  clearanceStatusId: number | null;
  contractStartDate: string | null;
  contractEndDate: string | null;
  ppvavailable: boolean;
  agreementNumber: number | null;
  embargoPeriod: number | null;
  price: number;
  royaltiesDue: boolean | null;
  clearedById: number | null;
  royaltyRate: number | null;
  noticePeriod: number | null;
  archivalPeriod: number | null;
  archivePeriodStartDate: string | null;
  terminationNote: string | null;
  noticeProvidedDate: string | null;
  individualSubscriptions: boolean;
  cclicenceTypeId: number | null;
  organisationId: number;
  isOpenAccess: boolean;
  accessRightId: number | null;
  royaltyOrganisationName: string | null;
  archiveRoyaltyRate: number | null;
  withdrawalDate: string | null;
  accessTypeId: number | null;
  perpetualAccess: boolean;
}

export default SaveLicenceRequest;
