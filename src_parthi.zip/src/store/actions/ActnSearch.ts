import SearchResult from '../../interfaces/Search/SearchResult';
import SearchFilters from '../../classes/SearchFilters';

export const UPDATE_SEARCH_RESULTS = 'UPDATE_SEARCH_RESULTS';
export const UPDATE_SEARCH_FILTERS = 'UPDATE_SEARCH_FILTERS';
export const UPDATE_SEARCH_ITEM = 'UPDATE_SEARCH_ITEM';

interface UpdateSearchResultsAction {
  type: typeof UPDATE_SEARCH_RESULTS;
  payload: SearchResult[];
}

interface UpdateSearchFiltersAction {
  type: typeof UPDATE_SEARCH_FILTERS;
  payload: SearchFilters;
}

interface UpdateSearchItemAction {
  type: typeof UPDATE_SEARCH_ITEM;
  payload: SearchResult;
}

export type ActionTypes = UpdateSearchResultsAction | UpdateSearchFiltersAction | UpdateSearchItemAction;

export function updateSearchResults(results: SearchResult[]): ActionTypes {
  return {
    type: UPDATE_SEARCH_RESULTS,
    payload: results,
  };
}

export function updateSearchFilters(filters: SearchFilters): ActionTypes {
  return {
    type: UPDATE_SEARCH_FILTERS,
    payload: filters,
  };
}

export function updateSearchItem(item: SearchResult): ActionTypes {
  return {
    type: UPDATE_SEARCH_ITEM,
    payload: item,
  };
}
