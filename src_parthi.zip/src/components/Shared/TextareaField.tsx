import React, { useState, useEffect, useRef } from 'react';

import {
  TextField, FormControl, createStyles, makeStyles,
} from '@material-ui/core';

const useStyles = makeStyles(() => createStyles({
  textAreaField: {
    width: '100%',
  },

}));

interface TextareaFieldProps {
    labelText: string;
    id: string;
    inputText?: string | number | Date | null | undefined;
    required?: boolean;
    keyName: string;
    onChangeFunction: any;
    onBlur: any;
    error: boolean;
    type?: string;
    errorMessage?: string;
    inputProps?: any;
    readOnly?: boolean;
    value?: string | number | Date | null | undefined;
    placeholder?: string;
    customHandleChangeFunction?: boolean;
  }

const TextareaField = (props: TextareaFieldProps) => {
  const classes = useStyles();
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  // The value of the textarea
  const [value, setValue] = useState<string>();

  const handleChange = (event: any): void => {
    props.onChangeFunction(props.keyName, event.target.value);
  };

  // This function is triggered when textarea changes
  const textAreaChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    setValue(event.target.value);
  };

  useEffect(() => {
    if (textareaRef && textareaRef.current) {
      textareaRef.current.style.height = '220px';
      const scrollHeight = textareaRef.current.scrollHeight;
      textareaRef.current.style.height = `${scrollHeight}px`;
    }
  }, [value]);

  return (
    <div>
      <FormControl className={classes.textAreaField}>
        <textarea
          ref={textareaRef}
          onChange={textAreaChange}
        >
          {value}
        </textarea>
      </FormControl>
    </div>
  );
};

export default TextareaField;
