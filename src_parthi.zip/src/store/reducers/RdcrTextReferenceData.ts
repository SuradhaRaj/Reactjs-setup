import {
  ActionTypes, UPDATE_TEXT_REFERENCE_DATA,
} from '../actions/ActnTextReferenceData';
import TextReferenceData from '../../interfaces/TextIndexer/ReferenceData/TextReferenceData';

export interface TextReferenceDataState {
  TextReferenceData: TextReferenceData;
}

export const initialState: TextReferenceDataState = {
  TextReferenceData: {
    accessRight: [],
    authorRoleTypeLookup: [],
    genres: [],
    resourceTypes: [],
    languageLookup: [],
    sectionNameOptions: [],
    descriptionTypes: [],
    mediaTypes: [],
  },
};

export default (state = initialState, action: ActionTypes): TextReferenceDataState => {
  switch (action.type) {
    case UPDATE_TEXT_REFERENCE_DATA:
      return {
        ...state,
        TextReferenceData: action.payload,
      };

    default:
      return state;
  }
};
