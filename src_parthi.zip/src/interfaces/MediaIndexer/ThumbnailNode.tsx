/*eslint-disable*/
export default interface ThumbnailNode {
    thumbnailUrl: string;
    isSelected: boolean;
}