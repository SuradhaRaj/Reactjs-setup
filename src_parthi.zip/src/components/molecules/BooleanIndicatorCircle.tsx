import React from 'react';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';

interface Props {
  name: string;
  status: boolean | null;
}

const BooleanIndicator = (props: Props) => (
  props.status ? (<CheckCircleIcon color="primary" />) : (<CheckCircleIcon color="disabled" />)
);

export default BooleanIndicator;
