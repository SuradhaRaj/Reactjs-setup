import React from 'react';
import { mount } from 'enzyme';
import TypedownCounter from '../../components/atoms/TypedownCounter';

describe('Typedown Counter Tests', () => {
  it('Displays how many items are remaining when there are spaces left', () => {
    const wp = mount(<TypedownCounter limit={6} selected={3} />);
    expect(wp.find('[data-remaining]').text()).toBe('3');
  });

  it('Displays the limit reached message when the limit has been reached', () => {
    const wp = mount(<TypedownCounter limit={4} selected={4} />);
    expect(wp.text()).toBe('Limit reached');
  });
});
