import React from 'react';
import {
  makeStyles, Theme, createStyles, Typography, Grid, Paper, Divider, Button,
} from '@material-ui/core';
import { useHistory } from 'react-router-dom';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import OrganisationSearchResult from '../../../interfaces/Search/OrganisationSearchResult';
import RuntypeErrorPaper from '../RuntypeError';
import SmallChip from '../../molecules/SmallChip';
import SecondaryData from '../../molecules/SecondaryData';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    padding: theme.spacing(2),
    transition: 'all 0.2s',
    position: 'relative',
  },
  name: {
    fontSize: '0.85rem',
    marginLeft: theme.spacing(2),
    fontWeight: 600,
  },
  department: {
    fontSize: '0.85rem',
    marginLeft: theme.spacing(2),
    display: 'block',
  },
  row: {
    display: 'flex',
  },
  divider: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(1),
  },
  button: {
    borderRadius: 50,
    position: 'absolute',
    right: '0',
    '& .MuiButton-label': {
      maxHeight: '15px',
    },
  },
  secondaryDataRow: {
    display: 'flex',
    paddingBottom: theme.spacing(2),
  },
}));

interface OrganisationResultProps {
  result: OrganisationSearchResult;
};

const OrganisationResult: React.SFC<OrganisationResultProps> = (props) => {
  const classes = useStyles();
  const history = useHistory();

  try {
    // OrganisationSearchResultValidator.check(props.result);
  } catch (error) {
    return (<RuntypeErrorPaper data={props.result} error={error} />);
  }

  const navigateToOrganisation = () => {
    history.push(`/partner/${props.result.id}`);
  };

  return (
    <Grid container>
      <Grid item xs={12}>
        <Paper className={classes.root}>
          <Grid container>
            <Grid item xs={12}>
              <Grid container>
                <Grid item xs={12} className={classes.row}>
                  <SmallChip label="ORGANISATION" />
                  <Typography className={classes.name}>{props.result.code}</Typography>
                  <Typography className={classes.name}>{props.result.name}</Typography>
                  <Typography className={classes.name}>
                    {props.result.numberOfTitles}
                    {' '}
                    Resources
                  </Typography>
                </Grid>
              </Grid>
              <Divider className={classes.divider} />
              <Grid container>
                <Grid item xs={9} className={classes.secondaryDataRow}>
                  <SecondaryData title="Address" content={props.result.address} alwaysDisplay variantName="subtitle1" />
                  <SecondaryData title="Primary Contact" content={props.result.primaryContact} alwaysDisplay variantName="subtitle1" />
                  <Button
                    size="small"
                    color="primary"
                    variant="outlined"
                    onClick={navigateToOrganisation}
                    endIcon={<ArrowForwardIcon />}
                    className={classes.button}
                  >
                    Open
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Paper>
      </Grid>
    </Grid>
  );
};

export default OrganisationResult;
