import React from 'react';
import {
  Paper, makeStyles, createStyles, Theme, Grid, Divider,
} from '@material-ui/core';

import Skeleton from '@material-ui/lab/Skeleton';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    padding: theme.spacing(2),
    transition: 'all 0.2s',
    '&:hover': {
      paddingRight: theme.spacing(6),
      '& $navigateChevron': {
        visibility: 'visible',
        opacity: 1,
      },
    },
    position: 'relative',
  },
  rmitNumber: {
    fontSize: '0.85rem',
    marginLeft: theme.spacing(2),
    fontWeight: 600,
  },
  title: {
    fontSize: '0.85rem',
    marginLeft: theme.spacing(2),
  },
  row: {
    display: 'flex',
  },
  divider: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(1),
  },
  secondaryData: {
    marginRight: theme.spacing(4),
  },
  workflowState: {
    alignSelf: 'center',
    marginLeft: 'auto',
  },
}));

export default function LoadingResult() {
  const classes = useStyles();

  return (
    <Grid container>
      <Grid item xs={12}>
        <Paper className={classes.root}>
          <Grid container>
            <Grid item xs={12}>
              <Grid container>
                <Grid item xs={12} className={classes.row}>
                  <Skeleton variant="text" width={50} />
                  <Skeleton className={classes.title} variant="text" width={150} />
                </Grid>
              </Grid>
              <Divider className={classes.divider} />
              <Grid container>
                <Grid item xs={9} className={classes.row}>
                  <Skeleton className={classes.secondaryData} variant="text" width={150} />
                  <Skeleton className={classes.secondaryData} variant="text" width={150} />
                  <Skeleton className={classes.secondaryData} variant="text" width={150} />
                </Grid>
                <Grid item xs={3} className={classes.row}>
                  <Skeleton className={classes.workflowState} variant="text" width={150} />
                </Grid>
              </Grid>
            </Grid>

          </Grid>
        </Paper>
      </Grid>
    </Grid>
  );
}
