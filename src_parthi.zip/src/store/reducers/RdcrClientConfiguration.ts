import {
  ActionTypes, UPDATE_CONFIGURATION,
} from '../actions/ActnClientConfiguration';
import ClientConfiguration from '../../classes/ClientConfiguration';

export interface ClientConfigurationState {
  ClientConfiguration: ClientConfiguration;
}

export const initialState: ClientConfigurationState = {
  ClientConfiguration: ClientConfiguration.empty(),
};

export default (state = initialState, action: ActionTypes): ClientConfigurationState => {
  switch (action.type) {
    case UPDATE_CONFIGURATION:
      return {
        ...state,
        ClientConfiguration: action.payload,
      };
    default:
      return state;
  }
};
