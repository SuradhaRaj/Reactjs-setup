import React, { useState } from 'react';
import Autocomplete from '@material-ui/lab/Autocomplete';
import Skeleton from '@material-ui/lab/Skeleton';
import {
  TextField, Grid, CircularProgress, Zoom, Chip,
} from '@material-ui/core';
import parse from 'autosuggest-highlight/parse';
import match from 'autosuggest-highlight/match';
import { TypedownOption, StrStrTypedownOption } from '../../interfaces/TypedownOption';
import ConfirmationDialog from '../molecules/ConfirmationDialog';
import TypedownCounter from '../atoms/TypedownCounter';

export interface TypedownProps {
    options: Array<TypedownOption | StrStrTypedownOption> ;
    selectedOptions: Array<TypedownOption | StrStrTypedownOption>;
    selectedValue: TypedownOption | StrStrTypedownOption | null;
  allowMultiple: boolean;
    onChange(data: TypedownOption | StrStrTypedownOption): void;
    onChangeMultiple(data: Array<TypedownOption | StrStrTypedownOption>): void;
  isLoading: boolean;
  onInputChange(data: string): void;
  label?: string;
  showLoadingSpinner: boolean;
  filterOptions?(x: string[]): string[];
  onBlur?(e: React.FocusEvent<HTMLDivElement>): void;
  autoSelect?: boolean;
  disabled?: boolean;
  error?: boolean;
  errorMessage?: string | string[] | undefined;
  typedownLimit?: number;
}

interface State {
  typedownValue: string;
    selectedValue: TypedownOption | StrStrTypedownOption | null;
  dialogOpen: boolean;
    optionBeingConfirmed: TypedownOption | StrStrTypedownOption | undefined;
}

const Typedown = (props: TypedownProps): JSX.Element => {
  const [state, setState] = useState<State>({
    typedownValue: '',
    selectedValue: props.selectedValue,
    dialogOpen: false,
    optionBeingConfirmed: undefined,
  });

  React.useEffect(() => {
    setState((prevState) => ({
      ...prevState,
      typedownValue: props.selectedValue?.value ?? '',
      selectedValue: props.selectedValue,
    }));
  }, [props.selectedValue]);

  const onDeleteChip = (chipToRemove: string): void => {
    const newOptions = props.selectedOptions.filter((item) => item.value !== chipToRemove);
    props.onChangeMultiple(newOptions);
  };

  const onSelect = (item?: TypedownOption | StrStrTypedownOption, ignoreNotes?: boolean): void => {
    if (item !== undefined) {
      if (!ignoreNotes && item.scopeNote) {
        // if there are scope notes that need to be shown in a dialog that have not yet been opened yet
        setState((prevState) => ({
          ...prevState,
          optionBeingConfirmed: item,
          dialogOpen: true,
        }));
      } else if (props.allowMultiple) {
        const newOptions = [...props.selectedOptions, item];
        props.onChangeMultiple(newOptions);

        setState((prevState) => ({
          ...prevState,
          typedownValue: '',
          selectedValue: null,
        }));
      } else {
        props.onChange(item);
        setState((prevState) => ({
          ...prevState,
          typedownValue: item.value,
          selectedValue: item,
        }));
      }
    }
  };

  const closeDialog = (dialogResponse: boolean) => {
    if (dialogResponse) {
      // select the option and ignore the scope notes
      onSelect(state.optionBeingConfirmed, true);
    }

    // remove the option being confirmed from the state and close dialog
    setState((prevState) => ({
      ...prevState,
      optionBeingConfirmed: undefined,
      dialogOpen: false,
    }));
  };

  const changeInputValue = (typedownValue: string, reason: string): void => {
    if (reason === 'input') {
      setState((prevState) => ({
        ...prevState,
        typedownValue,
      }));

      props.onInputChange(typedownValue);
    }
  };

  const availableOptions = (): Array<TypedownOption | StrStrTypedownOption> => {
    const newOptions = props.options.filter((item) => !props.selectedOptions.map((x) => x.value).includes(item.value));
    return newOptions;
  };

  const renderChips = () => {
    const chips = props.selectedOptions.map((option) => option.value);
    return (
      chips.map((chip) => (
        <Zoom in={chips.includes(chip)} key={chip}>
          <Chip
            tabIndex={-1}
            style={{ margin: '5px' }}
            variant="outlined"
            size="medium"
            label={chip}
            onDelete={() => onDeleteChip(chip)}
            color="primary"
          />
        </Zoom>
      ))
    );
  };

  return (
    <>
      {!props.isLoading && (
      <Grid container>
        <Grid item xs={12}>
          <Autocomplete
            disabled={props.disabled}
            options={availableOptions().map((option) => option.value)}
            inputValue={state.typedownValue}
            value={state.selectedValue?.value}
            onInputChange={(e: React.ChangeEvent<{}>, value: string, reason: string) => changeInputValue(value, reason)}
            onChange={(e: React.ChangeEvent<{}>, value: string|null) => onSelect(props.options.find((option) => option.value === value))}
            filterOptions={props.filterOptions}
            onBlur={props.onBlur}
            // autoSelect={props.autoSelect}
            renderInput={(params) => (
              <TextField
                {...params}
                variant="outlined"
                label={props.label}
                fullWidth
                disabled={props.disabled}
                error={props.error}
                value={state.typedownValue}
                helperText={props.errorMessage}
                InputProps={
                  {
                    ...params.InputProps,
                    endAdornment: (<>{props.showLoadingSpinner && (<CircularProgress color="inherit" size={18} />)}</>),
                  }
                }
              />
            )}
            renderOption={(option, { inputValue }) => {
              const matches = match(option, inputValue);
              const parts = parse(option, matches);

              return (
                <div data-autocomplete-option>
                  {parts.map((part, index) => (
                    <span key={`${part.text + index}`} style={{ fontWeight: part.highlight ? 700 : 400, whiteSpace: 'pre-wrap' }}>
                      {part.text}
                    </span>
                  ))}
                </div>
              );
            }}
          />
        </Grid>
        {!props.error && props.typedownLimit && (
          <Grid item xs={12}>
            <TypedownCounter
              limit={props.typedownLimit}
              selected={props.selectedOptions.length}
            />
          </Grid>
        )}
        <Grid item xs={12}>
          {renderChips()}
        </Grid>
      </Grid>
      )}
      {props.isLoading && (
        <Grid container>
          <Grid item xs={12}>
            <Skeleton animation="wave" />
          </Grid>
        </Grid>
      )}
      <ConfirmationDialog
        isOpen={state.dialogOpen}
        dialogTitle={`Are you sure you want to add '${state.optionBeingConfirmed?.value || ' this item'}'?`}
        dialogBodyText={state.optionBeingConfirmed?.scopeNote ? `Scope notes: ${state.optionBeingConfirmed?.scopeNote}` : 'Scope notes unavailable'}
        onProceed={() => closeDialog(true)}
        onReturn={() => closeDialog(false)}
        successButtonText="Yes"
        successButtonProps={{
          variant: 'text',
        }}
        rejectButtonText="No"
        rejectButtonProps={{
          variant: 'text',
        }}
      />
    </>
  );
};

Typedown.defaultProps = {
  isLoading: false,
  onChange: () => undefined,
  onChangeMultiple: () => undefined,
  allowMultiple: false,
  selectedOptions: [],
  selectedValue: null,
  onInputChange: () => undefined,
  showLoadingSpinner: false,
} as Partial<TypedownProps>;

export default Typedown;
