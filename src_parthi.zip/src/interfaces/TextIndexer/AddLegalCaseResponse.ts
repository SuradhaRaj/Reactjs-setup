import {
  Record, Static, String, Number,
} from 'runtypes';

export const AddLegalCaseResponseValidator = Record({
  name: String.withConstraint((s) => s !== ''),
  id: Number.withConstraint((n) => n > 0),
});

type AddLegalCaseResponse = Static<typeof AddLegalCaseResponseValidator>;
export default AddLegalCaseResponse;
