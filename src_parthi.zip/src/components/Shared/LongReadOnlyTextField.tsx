import React from 'react';
import {
  makeStyles, createStyles, Typography, Grid, FormLabel,
} from '@material-ui/core';

const useStyles = makeStyles(() => createStyles({
  longReadOnlyTextField: {
    width: '90%',
    textAlign: 'left',
    maxHeight: '190px',
    overflowY: 'auto',
    display: 'block',
    margin: 'auto',
  },
  longReadOnlyTextFieldLabel: {
    float: 'left',
    marginLeft: '18px',
  },
  longReadOnlyTextFieldWrapper: {
    paddingTop: '16px',
  },
}));

interface LongReadOnlyTextFieldProps {
    labelText: string;
    displayText: string;
}

export default function LongReadOnlyTextField(props: LongReadOnlyTextFieldProps): JSX.Element {
  const classes = useStyles();

  return (
    <div className={classes.longReadOnlyTextFieldWrapper}>
      <Grid item xs={12}>
        <FormLabel className={classes.longReadOnlyTextFieldLabel}>{props.labelText}</FormLabel>
      </Grid>
      <Grid item xs={12}>
        <Typography className={classes.longReadOnlyTextField} variant="body1">{props.displayText}</Typography>
      </Grid>
    </div>
  );
}
