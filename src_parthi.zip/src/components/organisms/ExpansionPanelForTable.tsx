import React from 'react';
import {
  ExpansionPanel, ExpansionPanelSummary, ExpansionPanelDetails, Typography, makeStyles, createStyles,
} from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import SmallChip from '../molecules/SmallChip';
import DenseFixedLayoutTable from './DenseFixedLayoutTable';

const useStyles = makeStyles(() => createStyles({
  root: {
    '& .MuiTableContainer-root': {
      boxShadow: 'none',
    },
  },
  expansionPanelContent: {
    padding: 0,
  },
  count: {
    marginRight: 12,
  },
  title: {
    fontWeight: 600,
  },
  expansionSummary: {
    '& .MuiExpansionPanelSummary-content': {
      alignItems: 'center',
    },
  },
}));

interface Props extends React.PropsWithChildren<{}>{
  defaultExpanded: boolean;
  count: number;
  title: string;
}

export default (props: Props) => {
  const classes = useStyles();
  const ref = React.createRef<HTMLDivElement>();
  return (

    <ExpansionPanel
      TransitionProps={{ unmountOnExit: true }}
      className={classes.root}
      defaultExpanded={props.defaultExpanded}
    >
      <ExpansionPanelSummary
        className={classes.expansionSummary}
        expandIcon={<ExpandMoreIcon />}
      >
        <SmallChip label={props.count} className={classes.count} data-count />
        <Typography className={classes.title} data-title>{props.title}</Typography>
      </ExpansionPanelSummary>
      <ExpansionPanelDetails className={classes.expansionPanelContent}>
        <DenseFixedLayoutTable forwordRef={ref}>
          {props.children}
        </DenseFixedLayoutTable>
      </ExpansionPanelDetails>
    </ExpansionPanel>
  );
};
