import React from 'react';
import { mount } from 'enzyme';
import LongReadOnlyTextField from '../components/Shared/ReadOnlyTextField';

const wrapper = mount(
  <LongReadOnlyTextField labelText="This is a test label" displayText="This is test display text" />,
);

describe('LongReadOnlyTextField Tests', () => {
  it('should display label that is passed into props', () => {
    expect(
      wrapper.contains('This is a test label'),
    ).toBe(true);
  });

  it('should display display text that is passed into props', () => {
    expect(
      wrapper.contains('This is test display text'),
    ).toBe(true);
  });
});
