import TaskManagementTask from '../../interfaces/TaskManagementTask';
import TaskManagementFilters from '../../classes/TaskManagementFilters';

const tasks: TaskManagementTask[] = [
  {
    artifactId: 1,
    broadcastDate: '',
    channel: 'Channel1',
    documentId: '',
    indexer: '',
    isLocked: false,
    itemTitle: '',
    programTitle: 'ProgramTitle3',
    rmitNumber: '',
    workflowState: 'State3',
  }, {
    artifactId: 1,
    broadcastDate: '',
    channel: 'Channel2',
    documentId: '',
    indexer: '',
    isLocked: false,
    itemTitle: '',
    programTitle: 'ProgramTitle1',
    rmitNumber: '',
    workflowState: 'State2',
  }, {
    artifactId: 1,
    broadcastDate: '',
    channel: 'Channel3',
    documentId: '',
    indexer: '',
    isLocked: false,
    itemTitle: '',
    programTitle: 'ProgramTitle2',
    rmitNumber: '',
    workflowState: 'State1',
  },
];

describe('Task management filters - Filter tasks', () => {
  it('should return all items when no filter is applied', () => {
    const filters = TaskManagementFilters.empty();

    const result = filters.filterTasks(tasks);
    expect(result.length).toBe(3);
  });

  it('should return items matching the channel filter', () => {
    const filters = new TaskManagementFilters({ channel: ['Channel1', 'Channel2'], status: [], program: [] });

    const result = filters.filterTasks(tasks);
    expect(result.length).toBe(2);
    expect(result[0].channel).toBe('Channel1');
    expect(result[1].channel).toBe('Channel2');
  });

  it('should return items matching the status filter', () => {
    const filters = new TaskManagementFilters({ channel: [], status: ['State3', 'State2'], program: [] });

    const result = filters.filterTasks(tasks);
    expect(result.length).toBe(2);
    expect(result[0].workflowState).toBe('State3');
    expect(result[1].workflowState).toBe('State2');
  });

  it('should return items matching the status filter', () => {
    const filters = new TaskManagementFilters({ channel: [], status: [], program: ['ProgramTitle3', 'ProgramTitle2'] });

    const result = filters.filterTasks(tasks);
    expect(result.length).toBe(2);
    expect(result[0].programTitle).toBe('ProgramTitle3');
    expect(result[1].programTitle).toBe('ProgramTitle2');
  });

  it('should ignore the trailing and leading whitespace when filtering', () => {
    const tasksToTest = [{
      artifactId: 1,
      broadcastDate: '',
      channel: 'Channel ',
      documentId: '',
      indexer: '',
      isLocked: false,
      itemTitle: '',
      programTitle: 'ProgramTitle2',
      rmitNumber: '',
      workflowState: 'State1',
    },
    {
      artifactId: 1,
      broadcastDate: '',
      channel: ' Channel',
      documentId: '',
      indexer: '',
      isLocked: false,
      itemTitle: '',
      programTitle: 'ProgramTitle2',
      rmitNumber: '',
      workflowState: 'State1',
    },
    {
      artifactId: 1,
      broadcastDate: '',
      channel: ' Channel ',
      documentId: '',
      indexer: '',
      isLocked: false,
      itemTitle: '',
      programTitle: 'ProgramTitle2',
      rmitNumber: '',
      workflowState: 'State1',
    },
    {
      artifactId: 1,
      broadcastDate: '',
      channel: ' Channel 2 ',
      documentId: '',
      indexer: '',
      isLocked: false,
      itemTitle: '',
      programTitle: 'ProgramTitle2',
      rmitNumber: '',
      workflowState: 'State1',
    }];

    const filters = new TaskManagementFilters({ channel: ['Channel'], status: undefined, program: undefined });

    const result = filters.filterTasks(tasksToTest);
    expect(result.length).toBe(3);
  });

  it('should be case insensitive when applying the filter', () => {
    const tasksToTest = [{
      artifactId: 1,
      broadcastDate: '',
      channel: 'ChaNNel',
      documentId: '',
      indexer: '',
      isLocked: false,
      itemTitle: '',
      programTitle: 'ProgramTitle2',
      rmitNumber: '',
      workflowState: 'State1',
    },
    {
      artifactId: 1,
      broadcastDate: '',
      channel: ' CHanneL',
      documentId: '',
      indexer: '',
      isLocked: false,
      itemTitle: '',
      programTitle: 'ProgramTitle2',
      rmitNumber: '',
      workflowState: 'State1',
    }];

    const filters = new TaskManagementFilters({ channel: ['channel'], status: undefined, program: undefined });

    const result = filters.filterTasks(tasksToTest);
    expect(result.length).toBe(2);
  });
});
