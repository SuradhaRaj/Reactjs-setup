import {
  Record, Static,
} from 'runtypes';
import { ResourceArticleValidator } from './ResourceArticleData';
import { ArrayWithElements } from '../../runtypeTypes';

export const ResourceArticleListValidator = Record({
  articles: ArrayWithElements(ResourceArticleValidator),
});

type ResourceArticleList = Static<typeof ResourceArticleListValidator>;
export default ResourceArticleList;
