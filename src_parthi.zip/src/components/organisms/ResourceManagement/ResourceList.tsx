import React from 'react';
import {
  Grid, Typography,
} from '@material-ui/core';
import ResourceYear from './ResourceYear';
import Resource from '../../../interfaces/ResourceManagement/Resource';
import ResourceNext from './ResourceNext';

interface Props {
  years: number[];
  resource: Resource;
}

const ResourceList = (props: Props) => (
  <Grid container>
    <Grid item xs={12}>
      <ResourceNext
        resource={props.resource}
      />
      {props.years.length > 0 ? (
        <>
          {props.years
            .sort((a, b) => b - a)
            .map((year) => (
              <ResourceYear
                year={year}
                resourceId={props.resource.resourceId}
                publisher={props.resource.nameOfPublisher ?? ''}
                resourceTitle={props.resource.resourceTitle ?? ''}
                resourceTypeId={props.resource.resourceTypeId}
              />
            ))}
        </>
      ) : (
        <Typography>
          NO ISSUES AVAILABLE FOR THIS RESOURCE
        </Typography>
      )}
    </Grid>
  </Grid>
);

export default ResourceList;
