import React from 'react';
import { DateTime } from 'luxon';
import { useFormik } from 'formik';
import {
  Grid, Button, Chip, Zoom,
} from '@material-ui/core';
import Axios from 'axios';
import { useSnackbar } from 'notistack';
import * as Yup from 'yup';
import TypedownOption from '../../../interfaces/TypedownOption';
import TypedownAsync from '../TypedownAsync';
import CorporateAuthor from '../../../interfaces/TextIndexer/CorporateAuthor';
import TextInputField from '../../Shared/TextInputField';
import LoadingButton from '../../molecules/LoadingButton';
import AddCorporateAuthorResponse, { AddCorporateAuthorResponseValidator } from '../../../interfaces/TextIndexer/AddCorporateAuthorResponse';
import AddCorporateAuthorRequest from '../../../interfaces/TextIndexer/AddCorporateAuthorRequest';
import DropdownWithId from '../DropdownWithId';
import AuthorRoleType from '../../../interfaces/TextIndexer/ReferenceData/AuthorRoleType';

interface CorporateAuthorTypedownProps {
  selectedCorporateAuthors: CorporateAuthor[];
  initialCorporateAuthors: CorporateAuthor[];
  roleTypeLookup: AuthorRoleType[];
  onChangeMultiple(authors: CorporateAuthor[]): void;
  readonly?: boolean;
  userName: string;
  isLegal: boolean;
}

interface CorporateAuthorTypedownState {
  loading: boolean;
  corporateAuthorOptions: TypedownOption[];
  isAddingNew: boolean;
};

const CorporateAuthorTypedown: React.SFC<CorporateAuthorTypedownProps> = (props) => {
  const [state, setState] = React.useState<CorporateAuthorTypedownState>({
    loading: false,
    corporateAuthorOptions: [],
    isAddingNew: false,
  });

  const { enqueueSnackbar } = useSnackbar();

  const initialFormValues: CorporateAuthor = {
    corporateAuthorId: -1,
    corporateName: '',
    roleType: 'Author',
    roleTypeId: props.roleTypeLookup.findIndex((option) => option.name === 'Author') + 1,
    createdBy: '',
    createdDate: '',
  };

  const onDeleteChip = (idToDelete: number) => {
    props.onChangeMultiple(props.selectedCorporateAuthors.filter((author) => author.corporateAuthorId !== idToDelete));
  };

  const renderChips = () => (
    props.selectedCorporateAuthors.map((author) => (
      <Zoom
        in={props.selectedCorporateAuthors.find((a) => a.corporateAuthorId === author.corporateAuthorId) !== undefined}
        key={author.corporateAuthorId}
      >
        <Chip
          tabIndex={-1}
          style={{ margin: '5px' }}
          variant="outlined"
          size="medium"
          label={`${author.roleType} | ${author.corporateName}`}
          onDelete={() => onDeleteChip(author.corporateAuthorId)}
          color="primary"
        />
      </Zoom>
    ))
  );

  const formik = useFormik({
    initialValues: { ...initialFormValues },
    onSubmit: () => undefined,
    isInitialValid: false,
    validateOnMount: true,
    validationSchema: Yup.object().shape({
      corporateAuthorId: Yup
        .number()
        .required(),
      roleType: Yup
        .string()
        .required(),
      roleTypeId: Yup
        .number()
        .required(),
      corporateName: Yup
        .string()
        .required(),
    }),
  });

  const handleSelect = (data: TypedownOption) => {
    // set the author name and id when an author is selected from the typedown
    formik.setValues({
      ...formik.values,
      corporateName: data.value,
      corporateAuthorId: data.id,
    }, true);
  };

  const handleSwitchAddingNew = () => {
    formik.resetForm();
    setState((prevState) => ({
      ...prevState,
      isAddingNew: !prevState.isAddingNew,
    }));
  };

  const handleCreateAuthor = () => {
    setState((prevState) => ({
      ...prevState,
      loading: true,
    }));

    const requestData: AddCorporateAuthorRequest = {
      corporateName: formik.values.corporateName,
      isLegal: props.isLegal,
    };

    Axios.post<AddCorporateAuthorResponse>(`${process.env.REACT_APP_API_URL}/api/indexing/addnewcorporateauthor`, requestData)
      .then((response) => {
        if (response.data.status === 204) {
          enqueueSnackbar('Could not create author as this author already exists', { variant: 'info' });
          return;
        }

        AddCorporateAuthorResponseValidator.check(response.data);
        const newAuthor: CorporateAuthor = {
          ...formik.values,
          corporateAuthorId: response.data.corporateAuthorId,
          corporateName: response.data.corporateName,
          createdBy: props.userName,
          createdDate: DateTime.local().toISO(),
        };

        props.onChangeMultiple([...props.selectedCorporateAuthors, newAuthor]);
      })
      .catch(() => {
        enqueueSnackbar('Error creating corporate author', { variant: 'error' });
      })
      .finally(() => {
        setState((prevState) => ({
          ...prevState,
          loading: false,
          isAddingNew: false,
        }));

        formik.resetForm();
      });
  };

  const handleAddExistingAuthor = () => {
    // first check if the author is already selected, if so, do nothing
    if (props.selectedCorporateAuthors.find((author) => author.corporateAuthorId === formik.values.corporateAuthorId) !== undefined) return;

    const initialAuthor = props.initialCorporateAuthors.find((author) => author.corporateAuthorId === formik.values.corporateAuthorId);

    // if the author already existed before, re-add it with the initial values
    // else add the author with the current user and time
    const newAuthor = initialAuthor !== undefined
      ? { ...initialAuthor }
      : {
        ...formik.values,
        createdBy: props.userName,
        createdDate: DateTime.local().toISO(),
      };

    props.onChangeMultiple([...props.selectedCorporateAuthors, newAuthor]);

    formik.resetForm();
  };

  const handleAddButtonClick = () => {
    if (state.isAddingNew) {
      handleCreateAuthor();
    } else {
      handleAddExistingAuthor();
    }
  };

  return (
    <Grid container>
      {props.roleTypeLookup.length && (
        <>
          {state.isAddingNew ? (
            <Grid item xs={10} style={{ marginTop: 3 }}>
              {/* Corporate Name */}
              <TextInputField
                labelText="Corporate Name"
                inputText={formik.values.corporateName}
                value={formik.values.corporateName}
                keyName="corporateName"
                onBlur={formik.handleBlur}
                error={!!formik.errors.corporateName}
                onChangeFunction={formik.handleChange}
                readOnly={props.readonly}
              />
            </Grid>
          ) : (

            <Grid item xs={10} style={{ marginTop: 15 }}>
              {/* Corporate Author */}
              <TypedownAsync
                disabled={props.readonly}
                url={`${process.env.REACT_APP_API_URL}/api/indexing/searchcorporateauthor`}
                onChange={handleSelect}
                label="Corporate Author"
                additionalUriParameters={{ isLegal: props.isLegal }}
                onBlur={formik.handleBlur}
                selectedValue={formik.values.corporateAuthorId > 0
                  ? { id: formik.values.corporateAuthorId, value: formik.values.corporateName }
                  : null}
              />
            </Grid>
          )}
          <Grid item xs={2} style={{ marginTop: 15 }}>
            <Button
              onClick={handleSwitchAddingNew}
              disabled={props.readonly}
            >
              {state.isAddingNew ? 'cancel' : 'new'}
            </Button>
          </Grid>
          <Grid item xs={10}>
            {/* Role Type */}
            <DropdownWithId
              valueKey="roleType"
              idKey="roleTypeId"
              lookup={props.roleTypeLookup.map((option) => ({ key: option.authorRoleTypeId, value: option.name }))}
              isReadOnly={props.readonly}
              id="RoleType"
              options={props.roleTypeLookup.map((lookupOption) => ({ display: lookupOption.name, value: lookupOption.name }))}
              selectedOption={formik.values.roleType}
              value={formik.values.roleType}
              labelText="Role Type"
              onChangeHandler={(key: string, value: string) => formik.setFieldValue(key, value, true)}
            />
          </Grid>
          <Grid item xs={2} style={{ marginTop: 15 }}>
            <LoadingButton
              onClick={handleAddButtonClick}
              disabled={!formik.isValid || props.readonly}
              isLoading={state.loading}
            >
              {state.isAddingNew ? 'Create' : 'Add'}
            </LoadingButton>
          </Grid>
        </>
      )}
      <Grid item xs={12}>
        {renderChips()}
      </Grid>
    </Grid>

  );
};

export default CorporateAuthorTypedown;
