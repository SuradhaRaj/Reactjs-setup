import React from 'react';
import {
  makeStyles, Theme, createStyles, Grid, Typography, Divider,
} from '@material-ui/core';
import { DateTime } from 'luxon';

import Issue from '../../../interfaces/IssueManagement/Issue';
import SecondaryData from '../../molecules/SecondaryData';
import LuxonExtensions from '../../../utils/LuxonExtensions';
import ReadOnlyTextField from '../../Shared/ReadOnlyTextField';

const SecondaryDataDisplay = (props: {
    title: string;
    content: string | number | null;
    nullDisplay?: string;
    isDate?: boolean;
}) => {
  let content;
  const nullDisplay = (props.nullDisplay ?? 'Never');
  if (props.isDate ?? false) {
    content = props.content !== null ? LuxonExtensions.ToFriendlyDateString(DateTime.fromISO(props.content.toString())) : nullDisplay;
  } else {
    content = props.content !== null ? props.content : nullDisplay;
  }
  return (
    <SecondaryData
      title={props.title}
      content={content}
    />
  );
};

interface Props {
    issue: Issue;
}

const useStyles = makeStyles((theme: Theme) => createStyles({
  booleanIndicator: {
    marginLeft: theme.spacing(2),
  },
  GridContainer: {
    position: 'relative',
  },

  GridInline: {
    display: 'flex',
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(1),
  },
  divider: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(2),
  },
  tabContent: {
    '& > *': {
      display: 'inline-block',
      // width: 125,
    },
  },
}));
export default (props: Props) => {
  const classes = useStyles();
  const issue = props.issue;
  return (
    <>

      { /* Resource Name */}
      <ReadOnlyTextField
        labelText="Resource Name"
        displayText={issue.resouceName}
        oneLine
      />

      { /* Resource Title */}
      <ReadOnlyTextField
        labelText="Resource Title"
        displayText={issue.resouceTitle}
        oneLine
      />

      { /* grouping */}
      <ReadOnlyTextField
        labelText="Grouping"
        displayText={issue.grouping}
        oneLine
      />
      <Divider className={classes.divider} />
      <Grid container className={classes.GridContainer}>
        <Grid item xs={12}>
          <Typography variant="overline">WORKFLOW &amp; ADMIN</Typography>

        </Grid>
        <Grid item xs={12} className={classes.GridInline}>
          { /* I_030 Resource Id */}
          <SecondaryDataDisplay title="Resource ID" content={issue.resourceId} />

          { /* I_013 Issue Id */}
          <SecondaryDataDisplay isDate title="Issue Id" content={issue.issueId} />

        </Grid>

        <Grid item xs={12} className={classes.GridInline}>
          { /* I_026 Issue Created Date */}
          <SecondaryDataDisplay isDate title="Issue Created Date" content={issue.issueCreated} />
          { /* I_017 Content Rcvd Date */}
          <SecondaryDataDisplay isDate title="Content Rcvd Date" content={issue.contentRcvdDate} />
          { /* I_018 Files Sent Date */}
          <SecondaryDataDisplay isDate title="Files Sent Date" content={issue.filesSentDate} />
          { /* I_025 Files Accepted Date */}
          <SecondaryDataDisplay isDate title="Files Accepted Date" content={issue.filesAcceptedDate} />
          { /* I_019 Files Rcvd Date */}
          <SecondaryDataDisplay isDate title="Files Rcvd Date" content={issue.filesRcvdDate} />
          { /* I_027 Issue Live Date */}
          <SecondaryDataDisplay isDate title="Issue Live Date" content={issue.issueLiveDate} />
        </Grid>

        <Grid item xs={12} className={classes.GridInline}>
          { /* I_011 Content Source */}
          <SecondaryDataDisplay isDate title="Content Source" content={issue.contentSource} />
          { /* I_012 Content Import Date */}
          <SecondaryDataDisplay isDate title="Content Import Date" content={issue.contentImportDate} />
        </Grid>
        <Grid item xs={12} className={classes.GridInline}>
          { /* I_028 Issue Hard Copy Rcvd Date */}
          <SecondaryDataDisplay isDate title="Issue Hard Copy Rcvd Date" content={issue.issueHardCopyRcvdDate} />

          { /* I_029 Issue Hard Copy Sent Date */}
          <SecondaryDataDisplay isDate title="Issue Hard Copy Sent Date" content={issue.issueHardCopySentDate} />
        </Grid>
        <Grid item xs={12} className={classes.GridInline}>
          { /* I_001 Last Revision Date */}
          <SecondaryDataDisplay isDate title="Last Revision Date" content={issue.lastRevisionDate} />
          { /* I_002 Date Last Modified */}
          <SecondaryDataDisplay isDate title=" Date Last Modified" content={issue.lastModified} />
        </Grid>
      </Grid>

    </>
  );
};
