import UserInfo from '../../classes/UserInfo';

describe('UserInfo', () => {
  it('should throw an exception when the object is incorrect', () => {
    const incorrectObj = JSON.parse('{"somekey": "somevalue"}');
    const initFunc = () => new UserInfo(incorrectObj);

    expect(initFunc).toThrow();
  });
});

describe('UserInfo - isInRole - ', () => {
  it('should return true for role in the users list', () => {
    const userInfo = new UserInfo({ name: 'test user', username: 'testuser1', roles: ['InformitAdmin'] });

    expect(userInfo.isInRole('InformitAdmin')).toBe(true);
  });

  it('should return false for role not in the users list', () => {
    const userInfo = new UserInfo({ name: 'test user', username: 'testuser1', roles: ['InformitAdmin'] });

    expect(userInfo.isInRole('IndexersAdmin')).toBe(false);
  });
});

describe('UserInfo - isInAnyRole - ', () => {
  it('should return true for role in the users list (single)', () => {
    const userInfo = new UserInfo({ name: 'test user', username: 'testuser1', roles: ['InformitAdmin'] });

    expect(userInfo.isInAnyRole(['InformitAdmin'])).toBe(true);
  });

  it('should return false for role not in the users list (single)', () => {
    const userInfo = new UserInfo({ name: 'test user', username: 'testuser1', roles: ['InformitAdmin'] });

    expect(userInfo.isInAnyRole(['IndexersAdmin'])).toBe(false);
  });

  it('should return true for role in the users list (user multiple)', () => {
    const userInfo = new UserInfo({ name: 'test user', username: 'testuser1', roles: ['InformitAdmin', 'IndexersAdmin'] });

    expect(userInfo.isInAnyRole(['InformitAdmin'])).toBe(true);
  });

  it('should return true for role in the users list (request multiple)', () => {
    const userInfo = new UserInfo({ name: 'test user', username: 'testuser1', roles: ['IndexersAdmin'] });

    expect(userInfo.isInAnyRole(['InformitAdmin', 'IndexersAdmin'])).toBe(true);
  });

  it('should return false when the user has no roles', () => {
    const userInfo = new UserInfo({ name: 'test user', username: 'testuser1', roles: [] });

    expect(userInfo.isInAnyRole(['InformitAdmin', 'IndexersAdmin'])).toBe(false);
  });
});
