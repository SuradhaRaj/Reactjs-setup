import React from 'react';
import {
  Grid, Paper, Typography, makeStyles, Theme, createStyles, Divider, Button,
} from '@material-ui/core';
import { useHistory } from 'react-router-dom';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import IssueSearchResult from '../../../interfaces/Search/IssueSearchResult';
import RuntypeErrorPaper from '../RuntypeError';
import SmallChip from '../../molecules/SmallChip';
import SecondaryData from '../../molecules/SecondaryData';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    padding: theme.spacing(2),
    transition: 'all 0.2s',
    position: 'relative',
  },
  primaryId: {
    fontSize: '0.85rem',
    marginLeft: theme.spacing(2),
    fontWeight: 600,
  },
  primaryTitle: {
    fontSize: '0.85rem',
    marginLeft: theme.spacing(2),
  },
  button: {
    borderRadius: 50,
    position: 'absolute',
    right: '0',
    '& .MuiButton-label': {
      maxHeight: '15px',
    },
  },
  titleLive: {
    alignSelf: 'right',
    marginLeft: 'auto',
  },
  row: {
    display: 'flex',
  },
  divider: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(1),
  },
  workflowState: {
    alignSelf: 'center',
    marginLeft: 'auto',
  },
  unlock: {
    marginLeft: 'auto',
  },
  secondaryDataRow: {
    display: 'flex',
    paddingBottom: theme.spacing(2),
  },
}));

interface IssueResultProps {
  result: IssueSearchResult;
}

const getManagerInitials = (managerName: string): string => managerName.split(' ').map((s) => s[0]).toString().replace(',', '');

const IssueResult: React.SFC<IssueResultProps> = (props) => {
  const classes = useStyles();
  const history = useHistory();
  try {
    // IssueSearchResultValidator.check(props.result);
  } catch (error) {
    return (<RuntypeErrorPaper data={props.result} error={error} />);
  }

  const navigateToIndexerUi = (): void => {
    history.push(`/issues/${props.result.id}`);
  };

  return (
    <Grid container>
      <Grid item xs={12}>
        <Paper className={classes.root}>
          <Grid container>
            <Grid item xs={12}>
              <Grid container>
                <Grid item xs={12} className={classes.row}>
                  <SmallChip label="ISSUE" />
                  <Typography className={classes.primaryId}>{props.result.resourceID}</Typography>
                  <Typography className={classes.primaryTitle}>{props.result.resourceTitle}</Typography>
                  <Typography className={classes.primaryTitle}>{props.result.numberOfArticles}</Typography>
                </Grid>
              </Grid>
              <Divider className={classes.divider} />
              <Grid container>
                <Grid item xs={9} className={classes.secondaryDataRow}>
                  <SecondaryData title="Grouping" content={props.result.grouping} alwaysDisplay variantName="subtitle1" />
                  <SecondaryData title="Schedule Date" content={props.result.scheduleDate} alwaysDisplay variantName="subtitle1" />
                  <SecondaryData title="Date Of Publication" content={props.result.dateOfPublication} alwaysDisplay variantName="subtitle1" />
                  <SecondaryData title="Indexer Group" content={props.result.indexerGroup} alwaysDisplay variantName="subtitle1" />
                  <SecondaryData title="Manager" content="" alwaysDisplay variantName="subtitle1" initialsCol={getManagerInitials(props.result.resourceManager)} />
                  <Button
                    size="small"
                    color="primary"
                    variant="outlined"
                    onClick={navigateToIndexerUi}
                    endIcon={<ArrowForwardIcon />}
                    className={classes.button}
                  >
                    Open
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Paper>
      </Grid>
    </Grid>
  );
};

export default IssueResult;
