/* eslint-disable  @typescript-eslint/no-explicit-any */
import React, { useState } from 'react';
import Autocomplete from '@material-ui/lab/Autocomplete';
import Skeleton from '@material-ui/lab/Skeleton';
import {
  TextField, makeStyles, createStyles, Grid, Typography,
} from '@material-ui/core';
import parse from 'autosuggest-highlight/parse';
import match from 'autosuggest-highlight/match';
import ChipGroup from '../molecules/ChipGroup';
import { KeyValue, isKeyValue } from '../../interfaces/TaskManagementText/TextTaskManagementRequest';

const useStyles = makeStyles(() => createStyles({
  autocomplete: {
    '& .MuiInputBase-input.MuiOutlinedInput-input.MuiAutocomplete-input.MuiAutocomplete-inputFocused': {
      padding: 0,
      fontSize: 13,
    },
  },
  title: {
    fontSize: '0.8rem',
  },

}));

interface Props {
    id?: string;
    title: string;
    options: Array<string | KeyValue>;
    selectedOptions: Array<string | KeyValue>;
    onChange(newOptions: Array<string | KeyValue>): void;
    isLoading: boolean;
}

interface State {
    typedownValue: string;
    selectedValue: string;
}

export default (props: Props): JSX.Element => {
  const classes = useStyles();
  const [state, setState] = useState<State>({ typedownValue: '', selectedValue: '' });

  const onDeleteChip = (chipToRemove: string | KeyValue): void => {
    const newOptions = props.selectedOptions.filter((item) => {
      if (isKeyValue(item) && isKeyValue(chipToRemove)) {
        return item.value !== chipToRemove.value && item.id !== chipToRemove.id;
      } if (typeof item === 'string' && typeof chipToRemove === 'string') {
        return item !== chipToRemove;
      }
      return new Error('Cannot do the chip to remove.');
    });

    props.onChange(newOptions);
  };

  const onAddChip = (chipToAdd: string | KeyValue | null): void => {
    if (chipToAdd !== null && chipToAdd !== '') {
      const newOptions = [...props.selectedOptions, chipToAdd];
      props.onChange(newOptions);
    }

    setState((prevState) => ({
      ...prevState,
      typedownValue: '',
      selectedValue: '',
    }));
  };

  const changeInputValue = (typedownValue: string, reason: string): void => {
    if (reason === 'input') {
      setState((prevState) => ({
        ...prevState,
        typedownValue,
      }));
    }
  };

  const availableOptions = (): Array<string | KeyValue> => {
    const newOptions = props.options.filter((item) => {
      if (isKeyValue(item)) {
        const soIdlist = props.selectedOptions.map((x) => { if (isKeyValue(x)) return x.id; return x; });
        return !soIdlist.includes(item.id);
      }
      return !props.selectedOptions.includes(item);
    });

    return newOptions;
  };

  return (
    <>
      {!props.isLoading && (
        <Grid container>
          <Grid item xs={12}>
            <Typography className={classes.title}>{props.title}</Typography>
          </Grid>
          <Grid item xs={12}>
            <Autocomplete
              id={props.id}
              options={availableOptions()}
              getOptionLabel={(option) => (isKeyValue(option) ? option.value : option)}
              inputValue={state.typedownValue}
              value={state.selectedValue}
              onInputChange={(e: React.ChangeEvent<{}>, value: string, reason: string) => changeInputValue(value, reason)}
              className={classes.autocomplete}
              onChange={(e: React.ChangeEvent<{}>, value: string | KeyValue | null) => {
                if (typeof value === 'string') {
                  onAddChip(value);
                } else if (isKeyValue(value)) {
                  onAddChip(value);
                }
              }}
              renderInput={(params) => (
                <TextField {...params} variant="outlined" fullWidth />
              )}
              renderOption={(option, { inputValue }) => {
                let matches;
                let parts;
                if (isKeyValue(option)) {
                  matches = match(option.value, inputValue);
                  parts = parse(option.value, matches);
                } else {
                  matches = match(option, inputValue);
                  parts = parse(option, matches);
                }

                return (
                  <div data-autocomplete-option>
                    {parts.map((part, index) => (
                      <span key={`${part.text + index}`} style={{ fontWeight: part.highlight ? 700 : 400 }}>
                        {part.text}
                      </span>
                    ))}
                  </div>
                );
              }}
            />
          </Grid>
          <Grid item xs={12}>
            <ChipGroup content={props.selectedOptions} maxLength={5} onDelete={onDeleteChip} />
          </Grid>
        </Grid>
      )}
      {props.isLoading && (
        <Grid container>
          <Grid item xs={12}>
            <Skeleton animation="wave" width={100} />
          </Grid>
          <Grid item xs={12}>
            <Skeleton animation="wave" />
          </Grid>
        </Grid>
      )}
    </>
  );
};
