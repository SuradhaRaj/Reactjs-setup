enum FileUploadStatus {
  Verifying,
  Valid,
  Invalid
};

export default FileUploadStatus;
