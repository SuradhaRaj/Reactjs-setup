import TextTaskManagementTasks from '../../interfaces/TaskManagementText/TextTaskManagementTasks';
import TextTaskManagementFilters from '../../classes/TextTaskManagementFilters';

export const UPDATE_TASK_LIST = 'UPDATE_TASK_MANAGEMENT_LIST_TEXT';
export const UPDATE_FILTERS = 'UPDATE_FILTERS_TEXT';
export const CLEAR_FILTERS = 'CLEAR_FILTERS_TEXT';

interface UpdateTaskListAction {
  type: typeof UPDATE_TASK_LIST;
  payload: TextTaskManagementTasks;
}

interface UpdateFiltersAction {
  type: typeof UPDATE_FILTERS;
  payload: TextTaskManagementFilters;
}

interface ClearFiltersAction {
  type: typeof CLEAR_FILTERS;
}

export type ActionTypes = UpdateTaskListAction | UpdateFiltersAction | ClearFiltersAction;

export function updateTaskManagementList(tasks: TextTaskManagementTasks): ActionTypes {
  return {
    type: UPDATE_TASK_LIST,
    payload: tasks,
  };
}

export function updateFilters(newFilters: TextTaskManagementFilters): ActionTypes {
  return {
    type: UPDATE_FILTERS,
    payload: newFilters,
  };
}

export function clearFilters(): ActionTypes {
  return {
    type: CLEAR_FILTERS,
  };
}
