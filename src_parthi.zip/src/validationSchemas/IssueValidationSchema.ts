import * as Yup from 'yup';
import { DateTime } from 'luxon';
import Issue, { TypeIssueAdd } from '../interfaces/IssueManagement/Issue';

const oneOfFieldsRequired = Yup.string().transform((x) => x ?? '').test('one-of-volumeNumber-issueNumber-issueMonthSeason-required', 'At least one of Volume Number, Issue Number, Issue Month Season is required', function test(): boolean {
  const obj = this.parent as Partial<Issue | TypeIssueAdd>;
  return (!!obj.volumeNumber || !!obj.issueNumber || !!obj.issueMonthSeason);
});

const schema: Partial<Record<keyof Issue | keyof TypeIssueAdd, Yup.Schema<unknown>>> = {
  publicationYear: Yup.string().transform((x) => x ?? '').required('Enter Issue Publication Year (e.g. 2013)').test('publicationYear', 'Date must be in the format "YYYY"', (value: string) => {
    const dateNum = parseInt(value);
    const CURRENT_YEAR = DateTime.local().year;
    if (Number.isNaN(dateNum)) return false;

    if (value.length === 4 /* YYYY */) {
      if (dateNum < 1800) { return false; }
      return true;
    }
    return false;
  }),
  volumeNumber: oneOfFieldsRequired,
  issueNumber: oneOfFieldsRequired,
  issueMonthSeason: oneOfFieldsRequired,

  dateOfPublication: Yup.string().transform((x) => x ?? '').required("Enter your publication's details e.g. Summer 2013 or Mar / Apr 2013 or Sep - Dec 2013"),
  scheduleDate: Yup.date().required("Enter your publication's details e.g. Summer 2013 or Mar / Apr 2013 or Sep - Dec 2013"),
};

export default Yup.object().shape(schema);
