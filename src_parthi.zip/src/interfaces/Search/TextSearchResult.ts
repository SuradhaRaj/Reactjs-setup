import {
  Record, Null, String, Static,
} from 'runtypes';
import { SearchResultValidator } from './SearchResult';

export const TextSearchResultValidator = Record({
  masId: String,
  grouping: String,
  publisher: String,
  itemTitle: String.Or(Null),
  resourceTitle: String,
  indexer: String.Or(Null),
  publicationYear: String,
  workflowState: String,
}).And(SearchResultValidator);

type TextSearchResult = Static<typeof TextSearchResultValidator>
export default TextSearchResult;
