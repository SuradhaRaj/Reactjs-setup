import React, { useEffect, useState } from 'react';
import Axios from 'axios';
import { useDispatch } from 'react-redux';
import { Grid } from '@material-ui/core';
import ClientConfiguration from '../../classes/ClientConfiguration';
import { updateConfiguration } from '../../store/actions/ActnClientConfiguration';
import ErrorPaper from './ErrorPaper';

interface State {
  hasReturned: boolean;
  didError: boolean;
}

export default (props: React.PropsWithChildren<{}>) => {
  const [state, setState] = useState<State>({
    didError: false,
    hasReturned: false,
  });

  const dispactch = useDispatch();

  useEffect(() => {
    Axios.get(`${process.env.REACT_APP_API_URL}/api/configuration/client`).then((response) => {
      const clientConfiguration = new ClientConfiguration(response.data);
      dispactch(updateConfiguration(clientConfiguration));
      setState((prevState) => ({
        ...prevState,
        didError: false,
        hasReturned: true,
      }));
    }).catch(() => {
      setState((prevState) => ({
        ...prevState,
        didError: true,
        hasReturned: true,
      }));
    });
  }, []);

  return (
    <>
      {!state.hasReturned && (<></>)}
      {state.didError && (
      <Grid container justify="center" style={{ marginTop: 24 }}>
        <Grid item xs={4}>
          <ErrorPaper text="Something went wrong trying to load.  Please contact the system administrator." />
        </Grid>
      </Grid>
      )}
      {state.hasReturned && !state.didError && (<>{props.children}</>)}
    </>
  );
};
