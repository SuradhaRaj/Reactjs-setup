import {
  Record, Static, Number, String,
} from 'runtypes';

export const CorporateAuthorValidator = Record({
  corporateAuthorId: Number,
  corporateName: String,
  roleType: String,
  roleTypeId: Number,
  createdBy: String,
  createdDate: String,
});

type CorporateAuthor = Static<typeof CorporateAuthorValidator>;
export default CorporateAuthor;
