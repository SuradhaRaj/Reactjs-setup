import {
  Record, Array, Static, String,
} from 'runtypes';
import { DocumentBroadSubjectValidator } from '../MediaIndexer/DocumentBroadSubject';
import { LookupOptionValidator } from '../LookupOption';
import { custLookupOptionValidator } from './customLookup';
import { FasttermValidator } from './FastTerm';
import { StrStrLookupOptionValidator } from '../StrStrLookupOption';
import { ArrayWithElements, KeyValue } from '../../runtypeTypes';
import { TextResourceTypeValidator } from '../TextIndexer/ReferenceData/TextResourceType';
import { ResourcesLookupValidator } from './ResourcesLookup';

export const ResourceReferenceDataValidator = Record({
  broadSubjectLookup: Array(DocumentBroadSubjectValidator),
  frequency: ArrayWithElements(custLookupOptionValidator),
  descriptionType: ArrayWithElements(custLookupOptionValidator),
  indexingCompany: ArrayWithElements(custLookupOptionValidator),
  mediaType: ArrayWithElements(custLookupOptionValidator),
  resourceTypes: ArrayWithElements(TextResourceTypeValidator),
  contentType: ArrayWithElements(LookupOptionValidator),
  fileType: ArrayWithElements(LookupOptionValidator),
  titleType: ArrayWithElements(LookupOptionValidator),
  resourceManager: ArrayWithElements(custLookupOptionValidator),
  languages: ArrayWithElements(custLookupOptionValidator),
  resourceIndexes: ArrayWithElements(LookupOptionValidator),
  seriesTitles: ArrayWithElements(LookupOptionValidator),
  uniformTitles: ArrayWithElements(custLookupOptionValidator),
  resourceWorkflowStates: ArrayWithElements(custLookupOptionValidator),
  contactRoleType: ArrayWithElements(LookupOptionValidator),
  accessRight: ArrayWithElements(custLookupOptionValidator),
  indexType: ArrayWithElements(StrStrLookupOptionValidator),
  productLibrary: ArrayWithElements(StrStrLookupOptionValidator),
  clearedBy: ArrayWithElements(LookupOptionValidator),
  countryOfPublicationMarc: ArrayWithElements(StrStrLookupOptionValidator),
  cclicenceType: ArrayWithElements(LookupOptionValidator),
  accessType: ArrayWithElements(LookupOptionValidator),
  clearanceStatus: ArrayWithElements(LookupOptionValidator),
  royaltyOrganisation: ArrayWithElements(LookupOptionValidator),
  resourceslookup: ArrayWithElements(ResourcesLookupValidator),
  fasttermLookup: ArrayWithElements(FasttermValidator),
  fastGeoLookup: ArrayWithElements(FasttermValidator),
  subjectLC: ArrayWithElements(custLookupOptionValidator),
  identifierlookup: ArrayWithElements(custLookupOptionValidator),
});

type ResourceReferenceData = Static<typeof ResourceReferenceDataValidator>;
export default ResourceReferenceData;
