import React, { useState } from 'react';
import SearchBar from 'material-ui-search-bar';
import {
  FormControl, MenuItem, Select, Typography, TextField, makeStyles, createStyles,
} from '@material-ui/core/';

const useStyles = makeStyles(() => createStyles({
  FormControl: {

  },
  searchbar_input: {

  },
}));

interface SearchbarProps {
    isLoading: boolean;
}
interface Props {
    isLoading: boolean;
}

const Searchbar = (props: SearchbarProps) => {
  const classes = useStyles();
  const [criteria, setCriteria] = useState('1');
  const [searchItem, setSearchItem] = useState('');
  console.log(criteria);
  return (
    <>
      {!props.isLoading && (
      <div className="searchbar_input">
        <SearchBar
          value={searchItem}
          className={classes.FormControl}
          placeholder="Search resource name"
          onChange={(value) => {
            setSearchItem(value);
          }}
          onRequestSearch={() => console.log('onRequestSearch')}
          style={{
            margin: '0 auto',
            maxWidth: 800,
          }}
        />

      </div>
      )}
    </>

  );
};

export default Searchbar;
