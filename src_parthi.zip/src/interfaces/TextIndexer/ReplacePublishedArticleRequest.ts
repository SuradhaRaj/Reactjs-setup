interface ReplacePublishedArticleRequest{
  filename: string;
  artifactId: number;
  issueId: number;
  issuePath: string;
};

export default ReplacePublishedArticleRequest;
