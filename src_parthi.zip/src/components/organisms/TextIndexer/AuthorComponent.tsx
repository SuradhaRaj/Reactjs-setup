import React, { useContext } from 'react';
import Axios from 'axios';
import {
  Grid, Zoom, Chip, Tooltip,
} from '@material-ui/core';
import {
  Record, Array, Static, String,
} from 'runtypes';
import { DateTime } from 'luxon';
import { useSnackbar } from 'notistack';
import ArticleDocumentAuthor from '../../../interfaces/TextIndexer/ArticleDocumentAuthor';
import AddAuthorRequest from '../../../interfaces/TextIndexer/AddAuthorRequest';
import AddAuthorResponse, { AddAuthorResponseValidator } from '../../../interfaces/TextIndexer/AddAuthorResponse';
import { AppContext } from '../../Context';
import AddAffiliationRequest from '../../../interfaces/TextIndexer/AddAffiliationRequest';
import AddAffiliationResponse, { AddAffiliationResponseValidator } from '../../../interfaces/TextIndexer/AddAffiliationResponse';
import { getAuthorName } from './AuthorTypedown';
import AuthorForm from './AuthorForm';
import AuthorRoleType from '../../../interfaces/TextIndexer/ReferenceData/AuthorRoleType';

interface AuthorComponentProps {
  selectedAuthors: ArticleDocumentAuthor[];
  initialAuthors: ArticleDocumentAuthor[];
  readOnly?: boolean;
  isLegal: boolean;
  keyName: string;
  roleTypeLookup: AuthorRoleType[];
  artifactArticleId: number;
  onChangeFunction(key: string, value: ArticleDocumentAuthor[], shouldValidate?: boolean): void;
}

interface AuthorComponentState {
  affiliationOptions: string[];
  loading: boolean;
}

const SearchAffiliationResponseValidator = Record({ results: Array(String) });
type SearchAffiliationResponse = Static<typeof SearchAffiliationResponseValidator>;

const AuthorComponent = (props: AuthorComponentProps) => {
  const { enqueueSnackbar } = useSnackbar();

  const context = useContext(AppContext);

  const [state, setState] = React.useState<AuthorComponentState>({
    affiliationOptions: [],
    loading: false,
  });

  const onDeleteChip = (idToDelete: number) => {
    props.onChangeFunction(props.keyName, props.selectedAuthors.filter((selected) => selected.authorId !== idToDelete), true);
  };

  const renderChips = () => (
    props.selectedAuthors.map((author) => (
      <Zoom in={props.selectedAuthors.find((a) => a.authorId === author.authorId) !== undefined} key={author.authorId}>
        <Tooltip
          title={author.affiliation || ''}
          placement="top"
          arrow
        >
          <Chip
            tabIndex={-1}
            style={{ margin: '5px' }}
            variant="outlined"
            size="medium"
            label={`${author.roleType} | ${getAuthorName(author)}`}
            onDelete={() => onDeleteChip(author.authorId)}
            color="primary"
          />
        </Tooltip>
      </Zoom>
    ))
  );

  const getAffiliationOptions = (authorId: number) => {
    Axios.get<SearchAffiliationResponse>(`${process.env.REACT_APP_API_URL}/api/indexing/searchaffiliation?searchTerm=${authorId}`)
      // populate affiliation options
      .then((response) => {
        // SearchAffiliationResponseValidator.check(response.data);
        setState((prevState) => ({
          ...prevState,
          affiliationOptions: response.data.results,
        }));
      })
      .catch(() => setState((prevState) => ({
        ...prevState,
        affiliationOptions: [],
      })));
  };

  const clearOptions = () => {
    setState((prevState) => ({
      ...prevState,
      affiliationOptions: [],
    }));
  };

  const handleAddAuthor = (authorToAdd: ArticleDocumentAuthor) => {
    // first check if the author has already been added. If so, do nothing
    if (props.selectedAuthors.find((selected) => selected.authorId === authorToAdd.authorId) !== undefined) {
      return;
    }
    // then check if the author with the same role and affiliation already existed
    const initialAuthor = props.initialAuthors.find((initial) => initial.authorId === authorToAdd.authorId
            && initial.roleTypeId === authorToAdd.roleTypeId
            && initial.affiliation === authorToAdd.affiliation);

    if (initialAuthor === undefined) {
      // if an affiliation is entered, we need to first add this to the database and get the affiliation Id
      if (authorToAdd.affiliation) {
        setState((prevState) => ({
          ...prevState,
          loading: true,
        }));

        const requestData: AddAffiliationRequest = {
          affiliation: authorToAdd.affiliation,
          authorId: authorToAdd.authorId,
          artifactArticleId: props.artifactArticleId,
        };

        Axios.post<AddAffiliationResponse>(`${process.env.REACT_APP_API_URL}/api/indexing/addnewaffiliation`, requestData)
          .then((response) => {
            AddAffiliationResponseValidator.check(response.data);
            const newAuthor: ArticleDocumentAuthor = {
              ...authorToAdd,
              ...response.data,
              createdBy: context.userInfo.data.name,
              createdDate: DateTime.local().toISO(),
            };

            props.onChangeFunction(props.keyName, [...props.selectedAuthors, newAuthor], true);
          })
          .catch(() => {
            enqueueSnackbar('Error adding author', { variant: 'error' });
          })
          .finally(() => {
            setState((prevState) => ({
              ...prevState,
              loading: false,
            }));
          });
      } else { // otherwise we can just add the author directly
        const newAuthor: ArticleDocumentAuthor = {
          ...authorToAdd,
          affiliation: null,
          affiliationId: null,
          createdBy: context.userInfo.data.name,
          createdDate: DateTime.local().toISO(),
        };

        props.onChangeFunction(props.keyName, [...props.selectedAuthors, newAuthor], true);
      }
    } else {
      props.onChangeFunction(props.keyName, [...props.selectedAuthors, { ...initialAuthor }], true);
    }
  };

  const handleCreateAuthor = (authorToAdd: ArticleDocumentAuthor) => {
    setState({
      ...state,
      loading: true,
    });

    const requestData: AddAuthorRequest = {
      firstName: authorToAdd.firstName,
      middleName: authorToAdd.middleName,
      lastName: authorToAdd.lastName,
      orcidCode: authorToAdd.orcidCode,
      affiliation: authorToAdd.affiliation,
      artifactArticleId: props.artifactArticleId,
      isLegal: props.isLegal,
    };

    Axios.post<AddAuthorResponse>(`${process.env.REACT_APP_API_URL}/api/indexing/addnewauthor`, requestData)
      .then((response) => {
        if (response.data.status === 204) {
          enqueueSnackbar('Could not create author as this author already exists', { variant: 'info' });
          return;
        }

        AddAuthorResponseValidator.check(response.data);
        // Add the existing form values and then overwrite the values returned about the newly created author
        const newAuthor = {
          ...authorToAdd,
          ...response.data,
          createdBy: context.userInfo.data.name,
          createdDate: DateTime.local().toISO(),
        };

        props.onChangeFunction(props.keyName, [...props.selectedAuthors, newAuthor], true);
      })
      .catch(() => {
        enqueueSnackbar('Error creating author', { variant: 'error' });
      })
      .finally(() => (
        setState((prevState) => ({
          ...prevState,
          loading: false,
        }))
      ));
  };

  return (
    <Grid container>
      {props.roleTypeLookup.length && (
        <>
          <AuthorForm
            isLegal={props.isLegal}
            affiliationOptions={state.affiliationOptions}
            loading={state.loading}
            handleAddAuthor={handleAddAuthor}
            handleCreateAuthor={handleCreateAuthor}
            updateAffiliationOptions={getAffiliationOptions}
            clearAffiliationOptions={clearOptions}
            roleTypeLookup={props.roleTypeLookup}
            readonly={props.readOnly}
          />
          <Grid item xs={12} style={{ paddingTop: 10 }}>
            {renderChips()}
          </Grid>
        </>
      )}
    </Grid>
  );
};

export default AuthorComponent;
