import {
  Record, String, Array as RtArray, Static, Undefined,
} from 'runtypes';
import { some } from 'lodash';
import Filters from './Filters';
import TaskManagementTask from '../interfaces/TaskManagementTask';

const RuntypeDeclaration = Record({
  channel: RtArray(String).Or(Undefined),
  status: RtArray(String).Or(Undefined),
  program: RtArray(String).Or(Undefined),
  product: RtArray(String).Or(Undefined),
  broadcastdate: RtArray(String).Or(Undefined),
});

interface TaskManagementFiltersData {
  channel: Array<string>;
  status: Array<string>;
  program: Array<string>;
    product: Array<string>;
    broadcastdate: Array<string>;
}

type TaskManagementFiltersDataRt = Static<typeof RuntypeDeclaration> ;

class TaskManagementFilters extends Filters<TaskManagementFiltersData> {
  constructor(filterContent: TaskManagementFiltersDataRt) {
    try {
      RuntypeDeclaration.check(filterContent);
      super({
        channel: filterContent.channel === undefined ? [] : filterContent.channel,
        status: filterContent.status === undefined ? [] : filterContent.status,
        program: filterContent.program === undefined ? [] : filterContent.program,
        product: filterContent.product === undefined ? [] : filterContent.product,
        broadcastdate: filterContent.broadcastdate === undefined ? [] : filterContent.broadcastdate,
      });
    } catch (error) {
      console.error(error);
      throw error;
    }
  }

  static empty() {
    return new TaskManagementFilters({
      channel: [], status: [], program: [], product: [], broadcastdate: [],
    });
  }

  filterTasks(tasksToFilter: TaskManagementTask[]): TaskManagementTask[] {
    const compare = (item1: string, item2: string) => item1.trim().toUpperCase() === item2.trim().toUpperCase();

    let results = tasksToFilter;

    if (results.length > 0) {
      if (this.data.channel.length > 0) {
        results = results.filter((task) => some(this.data.channel, (filterItem) => compare(task.channel, filterItem)));
      }
      if (this.data.status.length > 0) {
        results = results.filter((task) => some(this.data.status, (filterItem) => compare(task.workflowState, filterItem)));
      }
      if (this.data.program.length > 0) {
        results = results.filter((task) => some(this.data.program, (filterItem) => compare(task.programTitle, filterItem)));
      }

      if (this.data.product.length > 0) {
        results = results.filter((task) => some(this.data.product, (filterItem) => compare(task.siteId, filterItem)));
      }
      const bdate = this.data.broadcastdate;
      if (this.data.broadcastdate.length > 0) {
        results = results.filter((task) => some(bdate, (filterItem) => compare(new Date(task.broadcastDate).toLocaleDateString(), filterItem)));
      }
    }
    return results;
  };
}

export default TaskManagementFilters;
