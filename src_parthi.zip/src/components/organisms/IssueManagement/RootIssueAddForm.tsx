import {
  Box, Button, createStyles, makeStyles, Theme, Typography,
  Paper, Grid,
} from '@material-ui/core';
import Axios from 'axios';
import { FormikConfig, useFormik } from 'formik';
import { useSnackbar } from 'notistack';
import React, { useState } from 'react';
import { TypeIssueAdd } from '../../../interfaces/IssueManagement/Issue';
// import UpdateIssueResponse, { UpdateIssueResponseValidator } from '../../../interfaces/IssueManagement/UpdateIssueResponse';

import IssueValidationSchema from '../../../validationSchemas/IssueValidationSchema';
import LoadingButton from '../../molecules/LoadingButton';
import ReadOnlyTextField from '../../Shared/ReadOnlyTextField';
import TextInputField from '../../Shared/TextInputField';
import FormGroup from '../../Shared/FormGroup';
import FilterableItem from '../../Shared/FilterableItem';
import StickyActionBar from '../../atoms/StickyActionBar';

function useFormikTyped(config: FormikConfig<TypeIssueAdd>) {
  return useFormik<TypeIssueAdd>(config);
}

type RootIssueFormik = ReturnType<typeof useFormikTyped>;

const RootIssueAddForm = (props: {
    resourceId: number;
    filterValue: string;
    onSave: Function;
}) => {
  const snackbar = useSnackbar();
  const useStyles = makeStyles((theme: Theme) => createStyles({
    '@global': {
      input: { display: 'block' },
      '.MuiTextField-root': {
        display: 'block',
      },
      '.MuiInputBase-root': {
        width: '100%',
      },
      '.MuiOutlinedInput-input': {
        padding: '10px 14px',
        fontSize: '0.8rem',
      },
      '.MuiOutlinedInput-multiline': {
        padding: '0px',
        fontSize: '0.8rem',
      },
      '.MuiChip-label': {
        fontSize: '0.7rem',
      },
      '.MuiChip-root': {
        height: 24,
      },
      '.MuiChip-deleteIcon': {
        height: 16,
      },
      '.MuiFormControl-marginNormal': {
        marginTop: 12,
        marginBottom: 0,
      },
      '.MuiAutocomplete-inputRoot[class*="MuiOutlinedInput-root"] .MuiAutocomplete-input': {
        padding: '3px 0',
      },
      '.MuiInputLabel-outlined': {
        transform: 'translate(14px, 14px) scale(1)',
        fontSize: '0.8rem',
      },
      '.MuiOutlinedInput-root legend': {
        fontSize: '0.6rem',
      },
    },
    buttonGroup: {
      position: 'absolute',
      top: theme.spacing(4),
      right: theme.spacing(4),

    },
    formField: {
      marginBottom: theme.spacing(2),
      display: 'block',
    },
    paper: {
      padding: theme.spacing(4),
      position: 'relative',
      paddingBottom: 0,
      marginTop: theme.spacing(4),
    },
    button: {
      borderRadius: 50,
      margin: 5,
    },
  }));

  const formik: RootIssueFormik = useFormik<TypeIssueAdd>({
    initialValues: {
      resourceId: props.resourceId,
      issueNumber: null,
      volumeNumber: null,
      publicationYear: null,
      scheduleDate: null,
      issueMonthSeason: null,
      dateOfPublication: null,
    },
    onSubmit: (values) => { console.error(values); },
    validationSchema: IssueValidationSchema,
    validateOnBlur: true,
    validateOnChange: true,
    enableReinitialize: true,
  });

    interface State {
        formFilterValue: string;

        isSubmitting: boolean;
        years: number[];
        readonly: boolean;
    }
    const [state, setState] = useState<State>({
      formFilterValue: '',

      isSubmitting: false,
      years: [2016],
      readonly: false,
    });

    const {
      values, errors, handleChange, handleBlur,
    } = formik;

    const discardChanges = () => {
      window.location.reload();
      formik.resetForm();
    };
    const saveIssue = () => {
      formik.validateForm().then((error) => {
        if (Object.keys(error).length === 0) {
          setState((prevState) => ({ ...prevState, isSubmitting: true }));
          Axios.post<{ issueId: number }>(`${process.env.REACT_APP_API_URL}/api/issue`, { ...formik.values }).then(() => {
            snackbar.enqueueSnackbar('Issue creation in progress...', { variant: 'success' });
          }).catch((remoteError) => {
            snackbar.enqueueSnackbar(`Unable to save issue, Error:${remoteError.response.data.messages.join()}`, { variant: 'error' });
          })
            .finally(() => {
              setState((prevState) => ({ ...prevState, isSubmitting: false }));
            });
        }
      });
    };
    const classes = useStyles();

    return (
      <>
        <StickyActionBar offset={1}>
          {!state.readonly && (
            <>
              {formik.dirty && (
              <div className={classes.buttonGroup}>
                <Button className={classes.button} variant="outlined" color="primary" onClick={() => { discardChanges(); }}>Discard Changes</Button>
                <LoadingButton className={classes.button} data-testid="save" color="primary" variant="contained" onClick={saveIssue} isLoading={state.isSubmitting}>Save</LoadingButton>
              </div>
              )}
            </>
          )}
        </StickyActionBar>
        <Paper className={classes.paper}>
          <form>
            <div className={classes.formField} />
            <FormGroup groupName="Description" isFirst>
              <Typography>Add a new Issue</Typography>
              { /* Resource Id */}
              <ReadOnlyTextField
                labelText="Resource Id"
                displayText={values.resourceId}
                oneLine
              />

              <Grid container style={{ position: 'relative' }}>
                <Grid item xs={6}>
                  { /* I_008 volumeNumber */}
                  <Box width={8 / 12}>
                    <FilterableItem filterValue={props.filterValue} showValues={['volumeNumber']}>
                      <TextInputField
                        labelText="Volume Number"
                        value={values.volumeNumber}
                        keyName="volumeNumber"
                        onChangeFunction={handleChange}
                        onBlur={handleBlur}
                        error={!!errors.volumeNumber}
                        errorMessage={errors.volumeNumber}
                        readOnly={state.readonly}
                      />

                    </FilterableItem>
                  </Box>
                </Grid>
                <Grid item xs={6}>
                  { /* I_009 Issue Number */}
                  <Box width={8 / 12}>
                    <FilterableItem filterValue={props.filterValue} showValues={['issueNumber']}>
                      <TextInputField
                        labelText="Issue Number"
                        value={values.issueNumber}
                        keyName="issueNumber"
                        onChangeFunction={handleChange}
                        onBlur={handleBlur}
                        error={!!errors.issueNumber}
                        errorMessage={errors.issueNumber}
                        readOnly={state.readonly}
                      />

                    </FilterableItem>
                  </Box>
                </Grid>
                <Grid item xs={6}>
                  { /*  I_010 Issue Month Season */}
                  <Box width={8 / 12}>
                    <FilterableItem filterValue={props.filterValue} showValues={['issueMonthSeason']}>
                      <TextInputField
                        labelText="Issue Month Season"
                        value={values.issueMonthSeason ?? null}
                        keyName="issueMonthSeason"
                        onChangeFunction={handleChange}
                        onBlur={handleBlur}
                        error={!!errors.issueMonthSeason}
                        errorMessage={errors.issueMonthSeason}
                        readOnly={state.readonly}
                      />
                    </FilterableItem>
                  </Box>
                </Grid>
                <Grid item xs={6}>
                  { /* I_005 publication year */}
                  <Box width={8 / 12}>
                    <FilterableItem filterValue={props.filterValue} showValues={['publicationYear']}>
                      <TextInputField
                        labelText="Publication Year"
                        value={values.publicationYear}
                        keyName="publicationYear"
                        onChangeFunction={handleChange}
                        onBlur={handleBlur}
                        error={!!errors.publicationYear}
                        errorMessage={errors.publicationYear}
                        readOnly={state.readonly}
                      />
                    </FilterableItem>
                  </Box>
                </Grid>
                <Grid item xs={6}>
                  { /* I_006 Date Of Publication */}
                  <Box width={8 / 12}>
                    <FilterableItem filterValue={props.filterValue} showValues={['dateOfPublication']}>
                      <TextInputField
                        labelText="Date Of Publication"
                        value={values.dateOfPublication}
                        keyName="dateOfPublication"
                        onChangeFunction={handleChange}
                        onBlur={handleBlur}
                        error={!!errors.dateOfPublication}
                        errorMessage={errors.dateOfPublication}
                        readOnly={state.readonly}
                      />
                    </FilterableItem>
                  </Box>
                </Grid>
                <Grid item xs={6}>
                  { /* I_006 Schedule Date */}
                  <Box width={8 / 12}>
                    <FilterableItem filterValue={props.filterValue} showValues={['dateOfPublication']}>
                      <TextInputField
                        type="date"
                        labelText="Schedule Date"
                        value={values.scheduleDate}
                        keyName="scheduleDate"
                        onChangeFunction={handleChange}
                        onBlur={handleBlur}
                        error={!!errors.scheduleDate}
                        errorMessage={errors.scheduleDate}
                        readOnly={state.readonly}
                      />
                    </FilterableItem>
                  </Box>
                </Grid>
              </Grid>

            </FormGroup>
          </form>
        </Paper>
      </>
    );
};

export default RootIssueAddForm;
