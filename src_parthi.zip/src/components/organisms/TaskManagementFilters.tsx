import React, { useEffect, useState } from 'react';
import {
  Typography, Grid, Divider,
} from '@material-ui/core';
import Button from '@material-ui/core/Button';
import { useDispatch } from 'react-redux';
import { useLocation, useHistory } from 'react-router-dom';
import { DatePicker, MuiPickersUtilsProvider } from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';

// import { DateType } from '@date-io/type';
import TypedownFilter from './TypedownFilter';
import { updateFilters, clearFilters } from '../../store/actions/ActnTaskManagement';
import { useTypedSelector } from '../../store/store';
import CheckboxFilter from './CheckboxFilter';
import { default as Filters } from '../../classes/TaskManagementFilters';
import TaskManagementFilterHelper from '../../utils/TaskManagementFilterHelper';
import ProductCheckboxFilter from './ProductCheckboxFilter';

interface State {
    channels: Array<string>;
    status: Array<string>;
  programs: Array<string>;
    products: Array<string>;
    broadcastdate: Array<string>;
}

export interface SelectedFilter {
    channel: Array<string>;
    status: Array<string>;
    program: Array<string>;
    product: Array<string>;
    broadcastdate: Array<string>;
}
interface Props {
    isLoading: boolean;
    onDownloadCSV: Function;
}

const TaskManagementFilters = (props: Props) => {
  const dispatch = useDispatch();
  const taskManagement = useTypedSelector((store) => store.TaskManagement);
  const [date, setDate] = useState<Date| null>(null);
  const [state, setState] = useState<State>({
    channels: [],
    status: [],
    programs: [],
    products: [],
    broadcastdate: [],
  });

  const history = useHistory();
  const location = useLocation();
  const query = new URLSearchParams(location.search);

  const updateUrl = () => {
    const queryString = taskManagement.Filters.getQueryString();

    if (queryString !== '') {
      query.set('filter', queryString);
      const queryToSet = query.toString();
      history.push(`${location.pathname}?${queryToSet}`);
    } else {
      history.push(location.pathname);
    }
  };

  const changeChannel = (newOptions: Array<string>): void => {
    const newFilters = taskManagement.Filters.updateFilter('channel', newOptions);
    dispatch(updateFilters(newFilters));
    updateUrl();
  };

  const changeStatus = (newOptions: Array<string>): void => {
    const newFilters = taskManagement.Filters.updateFilter('status', newOptions);
    dispatch(updateFilters(newFilters));
    updateUrl();
  };

  const changeProgram = (newOptions: Array<string>): void => {
    const newFilters = taskManagement.Filters.updateFilter('program', newOptions);
    dispatch(updateFilters(newFilters));
    updateUrl();
  };

  const changeProduct = (newOptions: Array<string>): void => {
    const newFilters = taskManagement.Filters.updateFilter('product', newOptions);

    dispatch(updateFilters(newFilters));
    updateUrl();
  };

  const changeBroadcastdate = (newOptions: Date|null): void => {
    const newOptionsdate = newOptions === null || newOptions === undefined ? new Date() : new Date(newOptions).toLocaleDateString();

    /*eslint-disable */ 
    setDate(new Date(newOptions as Date));
    
    const newOptionsstr = new Array<string>(newOptionsdate.toString());// eslint-disable-line
    const newFilters = taskManagement.Filters.updateFilter('broadcastdate', newOptionsstr);
    dispatch(updateFilters(newFilters));
    updateUrl();
  };
  const clearAllFilters = (): void => {
    dispatch(clearFilters());
    setDate(null);
    history.push(location.pathname);
    };

    function exportCSV() {
        const filterJson = taskManagement.Filters.data;    
        props.onDownloadCSV(filterJson);
    }
    
  useEffect(() => {
    const filtersString = query.get('filter');
    if (filtersString != null) {
      const filters = JSON.parse(filtersString);
      dispatch(updateFilters(new Filters(filters)));
    }
  }, [location]);

  useEffect(() => {
    const channels = taskManagement.AllTasks.map((task) => task.channel);
    const distinctChannels = TaskManagementFilterHelper.GetValues(channels);

    const programs = taskManagement.AllTasks.map((task) => task.programTitle);
    const distinctPrograms = TaskManagementFilterHelper.GetValues(programs);

    const status = taskManagement.AllTasks.map((task) => task.workflowState);
      const distinctStatus = TaskManagementFilterHelper.GetValues(status);
    const product = taskManagement.AllTasks.map((task) => task.siteId);
    const distinctProducts = TaskManagementFilterHelper.GetValues(product);

    const broadcastdate = taskManagement.AllTasks.map((task) => new Date(task.broadcastDate).toLocaleDateString());
    const distinctBroadcastdate = TaskManagementFilterHelper.GetValues(broadcastdate);

    setState((prevState) => ({
      ...prevState,
      channels: distinctChannels,
      status: distinctStatus,
      programs: distinctPrograms,
      products: distinctProducts,
      broadcastdate: distinctBroadcastdate,

    }));
  }, [taskManagement.AllTasks]);
  return (
    <>
      <Grid container spacing={1} style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}>
        <Grid item xs={12} style={{ textAlign: 'right' }}>
          <Typography variant="overline">Filters</Typography>
        </Grid>
        <Grid item xs={12}>
          <TypedownFilter
            isLoading={props.isLoading}
            title="Program"
            options={state.programs}
            selectedOptions={taskManagement.Filters.data.program}
                      onChange={changeProgram}
          />
        </Grid>
        <Grid item xs={12}>
          <Divider />
        </Grid>
        <Grid item xs={12}>
          <CheckboxFilter
                      title="Status"
                      isLoading={props.isLoading}
                      options={state.status}
                      selectedOptions={taskManagement.Filters.data.status}
                      onChange={changeStatus}
          />
        </Grid>
        <Grid item xs={12}>
          <Divider />
        </Grid>
        <Grid item xs={12}>
          <TypedownFilter
                      isLoading={props.isLoading}
                      title="Channel"
                      options={state.channels}
                      selectedOptions={taskManagement.Filters.data.channel}
                      onChange={changeChannel}
          />
        </Grid>
        <Grid item xs={12}>
          <Divider />
        </Grid>
        <Grid item xs={12}>
          <ProductCheckboxFilter
                      title="Product"
                      isLoading={props.isLoading}
                      options={state.products}
                      selectedOptions={taskManagement.Filters.data.product}                      
                      onChange={changeProduct}
          />
        </Grid>
        <Grid item xs={12}>
          <Divider />
        </Grid>
        <Grid item xs={12}>
          <MuiPickersUtilsProvider utils={DateFnsUtils}>
            <DatePicker
              value={date} 
              onChange={changeBroadcastdate}
              label="Broadcast Date"
              autoOk
              variant="inline"
              emptyLabel="Select Broadcastdate"
              format="d MMM yyyy"
            />
          </MuiPickersUtilsProvider>
              </Grid>
              <Grid item xs={12} style={{ textAlign: 'right' }}>
                  <Button onClick={exportCSV}>Export CSV</Button>
                  {!props.isLoading && (<Button onClick={() => { clearAllFilters(); }}>Clear</Button>)}
        </Grid>      
      </Grid>
    </>
  );
};

export default TaskManagementFilters;
