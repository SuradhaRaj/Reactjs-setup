/* eslint @typescript-eslint/no-explicit-any: 0 */
import React from 'react';
import OpenInNewIcon from '@material-ui/icons/OpenInNew';
import {
  TableRow, TableCell, TableBody, Avatar, Tooltip, TablePagination, useTheme, IconButton,
  // Button,
} from '@material-ui/core';
import { makeStyles, createStyles, Theme } from '@material-ui/core/styles';
import LocalOfferOutlinedIcon from '@material-ui/icons/LocalOfferOutlined';
import classnames from 'classnames';
import { useHistory } from 'react-router-dom';
// import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import FolderIcon from '@material-ui/icons/Folder';

import ListAltIcon from '@material-ui/icons/ListAlt';
import { DateTime } from 'luxon';
import { TablePaginationActionsProps } from '@material-ui/core/TablePagination/TablePaginationActions';
import { KeyboardArrowLeft, KeyboardArrowRight } from '@material-ui/icons';
import LastPageIcon from '@material-ui/icons/LastPage';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import EnhanceTaskTableHead, { HeadCell } from '../../molecules/EnhancedTableHead';
import ArtifactType from '../../../interfaces/enums/ArtifactType';
import SmallChipDialog from '../SmallChipDialog';
import { useSort } from '../../../utils/TableSortHelper';
import CopyableTooltip from '../../molecules/CopyableTooltipIconButton';
import ArtifactLock from '../ArtifactLock';
import TextTaskManagementArtifactTask from '../../../interfaces/TaskManagementText/TextTaskManagementArtifactTask';
// icon
import WorkflowStatus, { WorkflowStatusDisplayNames } from '../../../interfaces/enums/WorkflowStatus';
import LuxonExtensions from '../../../utils/LuxonExtensions';
import TitleType, { TitleTypeNameMapping } from '../../../interfaces/enums/TitleType';

const useStyles = makeStyles((theme: Theme) => createStyles({
  row: {
    '&:hover': {
      '& $recordNumberIcon': {
        visibility: 'visible',
      },
      '& $navigationIcon': {
        visibility: 'visible',
      },
    },
    // transition: 'all 0s !important',
  },
  selectableCell: {
    cursor: 'pointer',
    padding: 5,
    textAlign: 'center',
    transition: 'all 0.2s',
  },
  emptyRowTd: {
    textAlign: 'center',
  },
  initials: {
    backgroundColor: theme.palette.primary.light,
    width: 'fit-content',
    height: 22,
    fontSize: 14,
    padding: 3,
    minWidth: 30,
  },
  check: {
    color: theme.palette.success.main,
  },
  initialsColumn: {
    width: 90,
  },
  filesColumn: {
    width: 60,
  },
  actionColumn: {
    width: 50,
  },
  deliveredColumn: {
    width: 100,
  },
  recordNumberColumn: {
    width: 35,
  },
  indexerColumn: {
    width: 35,
  },
  indexingCompanyColumn: {
    width: 160,
  },
  workflowStatusColumn:
    {
      width: 160,
      whiteSpace: 'nowrap',
    },
  workflowStatusColumnHeader:
    {
      width: 160,
      'word-wrap': 'break-word',
    },
  navigationColumn: {
    width: 110,
  },
  resourceTitleColumn: {
    /* width: 100, */
    'word-wrap': 'break-word',
  },

  titleColumn: {
    /* width: 100, */
    'word-wrap': 'break-word',
  },
  notesColumn: {
    width: 90,
  },
  publishDateColumn: {
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
  },
  notesChip: {
    marginRight: theme.spacing(1),
  },
  recordNumberIcon: {
    visibility: 'hidden',
  },
  navigationIcon: {
    visibility: 'hidden',
  },
  unlockIcon: {
    cursor: 'pointer',
  },
  button: {
    borderRadius: 50,
    '& .MuiButton-label': {
      maxHeight: '15px',
    },
  },
  artifactTypeColumn: {
    width: 20,
    padding: 2,
  },
  pagination: {
    backgroundColor: '#fefefe',
    borderRadius: '10px',
    float: 'left',
  },
}));
const useStyles1 = makeStyles((theme: Theme) => createStyles({
  root: {
    flexShrink: 0,
    marginLeft: theme.spacing(2.5),
  },
}));

function TablePaginationActions(props: TablePaginationActionsProps) {
  const classes = useStyles1();
  const theme = useTheme();
  const {
    count, page, rowsPerPage, onChangePage,
  } = props;

  const handleFirstPageButtonClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    onChangePage(event, 0);
  };

  const handleBackButtonClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    onChangePage(event, page - 1);
  };

  const handleNextButtonClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    onChangePage(event, page + 1);
  };

  const handleLastPageButtonClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    onChangePage(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
  };

  return (
    <div className={classes.root}>
      <IconButton
        onClick={handleFirstPageButtonClick}
        disabled={page === 0}
        aria-label="first page"
      >
        {theme.direction === 'rtl' ? <LastPageIcon /> : <FirstPageIcon />}
      </IconButton>
      <IconButton onClick={handleBackButtonClick} disabled={page === 0} aria-label="previous page">
        {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
      </IconButton>
      <IconButton
        onClick={handleNextButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="next page"
      >
        {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
      </IconButton>
      <IconButton
        onClick={handleLastPageButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="last page"
      >
        {theme.direction === 'rtl' ? <FirstPageIcon /> : <LastPageIcon />}
      </IconButton>
    </div>
  );
}
interface Props {
  canUnlock: boolean;
  onUpdate(row: TextTaskManagementArtifactTask): void;
    row: TextTaskManagementArtifactTask;
    isAdmin: boolean;
}

const getManagerInitials = (managerName: string): string => (managerName ? managerName.split(' ').map((s) => s[0]).toString().replace(',', '') : '');

export const ArtifactTextTaskRow: React.FC<Props> = ({
  row, canUnlock, onUpdate, isAdmin,
}) => {
  const classes = useStyles();
  const history = useHistory();
  const onUnlocked = () => {
    onUpdate({
      ...row,
      lockedBy: '',
    });
  };

  let artifactTypeIcon = <></>;
  if (row.artifactTypeId === ArtifactType.Issue) {
    artifactTypeIcon = <FolderIcon fontSize="small" />;
  } else if (row.artifactTypeId === ArtifactType.Text) {
    artifactTypeIcon = <ListAltIcon fontSize="small" />;
  }

  const titleType = row.titleTypeId ? `,${TitleTypeNameMapping[row.titleTypeId as TitleType]}` : '';

  const WorkflowStatusName = WorkflowStatusDisplayNames[row.workflowStatusId as WorkflowStatus];

  const filePrepDate = row.filePrepDate ? LuxonExtensions.ToFriendlyDateString(DateTime.fromISO(row.filePrepDate)) : '';

  return (
    <TableRow className={classes.row} hover key={row.rmitNumber}>
      <TableCell
        className={classnames(classes.navigationColumn, classes.selectableCell)}
        onClick={() => history.push(`/artifact/${row.artifactId}`)}
      >
        {/* <ChevronRightIcon className={classes.navigationIcon} /> */}
        <OpenInNewIcon />
      </TableCell>
      <TableCell align="center" className={classes.indexerColumn}>
        {row.lockedBy && (
          <ArtifactLock
            artifactId={row.artifactId}
            canUnlock={canUnlock}
            indexer={row.lockedBy}
            title={row.title || ''}
            onUnlocked={onUnlocked}
          />
        )}
      </TableCell>
      <TableCell className={classes.notesColumn}>
        {row.notesIndexer !== null && row.notesIndexer.length > 0 && (
        <SmallChipDialog style={{ marginRight: 8 }} label="Indexer" dialogTitle="Indexer notes" dialogContent={row.notesIndexer} />
        )}

      </TableCell>
      <TableCell>
        {row.source}
        {' '}
        {titleType}
      </TableCell>

      <TableCell className={classes.workflowStatusColumn}>
        <Tooltip title={row.workflowStatusId}><span>{WorkflowStatusName}</span></Tooltip>
      </TableCell>
      <TableCell>
        <Tooltip title={filePrepDate}>
          <span>

            {filePrepDate}
          </span>
        </Tooltip>
      </TableCell>
      <TableCell className={classes.artifactTypeColumn}>{artifactTypeIcon}</TableCell>
      <TableCell><Tooltip title={row.contentType}><span>{row.contentType}</span></Tooltip></TableCell>
      <TableCell className={classes.resourceTitleColumn}><span className={classes.resourceTitleColumn}>{row.resourceTitle}</span></TableCell>
      <TableCell><Tooltip title={row.resource}><span>{row.resource}</span></Tooltip></TableCell>
      <TableCell><Tooltip title={row.grouping}><span>{row.grouping}</span></Tooltip></TableCell>
      <TableCell><Tooltip title={row.title || ''}><span>{row.title}</span></Tooltip></TableCell>

      {isAdmin ? (
        <>
          <TableCell className={classes.initialsColumn}>
            <div style={{ display: 'flex', justifyContent: 'center' }}>
              <Tooltip title={row.managerName}>
                <Avatar variant="rounded" className={classes.initials}>{getManagerInitials(row.managerName)}</Avatar>
              </Tooltip>
            </div>
          </TableCell>
          <TableCell className={classes.notesColumn}>
            {row.notesPublisher !== null && row.notesPublisher.length > 0 && (
            <SmallChipDialog style={{ marginRight: 8 }} label="Publisher" dialogTitle="Publisher notes" dialogContent={row.notesPublisher as string} />
            )}

          </TableCell>
          <TableCell><Tooltip title={row.companyName}><span>{row.companyName}</span></Tooltip></TableCell>
        </>
      ) : ''}
      <TableCell>
        <Tooltip title={row.rmitNumber}><span>{row.rmitNumber}</span></Tooltip>
        <CopyableTooltip title={row.rmitNumber}><LocalOfferOutlinedIcon fontSize="small" className={classes.recordNumberIcon} /></CopyableTooltip>
      </TableCell>
      {isAdmin ? (
        <TableCell><Tooltip title={row.modifiedBy || ''}><span>{row.modifiedBy}</span></Tooltip></TableCell>
      ) : ''}
      <TableCell>
        <Tooltip title={row.lastModified}>
          <span>
            {' '}
            {LuxonExtensions.ToFriendlyDateString(DateTime.fromISO(row.lastModified))}
          </span>
        </Tooltip>
      </TableCell>

    </TableRow>
  );
};

interface TableProps {
      canUnlock: boolean;
      onUpdate(row: TextTaskManagementArtifactTask): void;
                                 rows: TextTaskManagementArtifactTask[];
    isAdmin: boolean;
}

const ArtifactTextTaskTable: React.FC<TableProps> = ({
  rows, canUnlock, onUpdate, isAdmin,
}) => {
  const classes = useStyles();

  const {
    handleRequestSort, order, orderBy, orderedData,
  } = useSort<TextTaskManagementArtifactTask>(rows);
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(100);
  const handleChangePage = (event: React.MouseEvent<HTMLButtonElement> | null, newPage: number) => {
    setPage(newPage);
  };
  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };
  const headCellsAdmin: HeadCell[] = [
    {
      id: 'navCell', label: '', canSort: false, className: classes.navigationColumn,
    },
    { id: 'indexer', label: '', className: classes.indexerColumn },
    {
      id: 'notesIndexer', label: 'Indexer Notes', className: classes.notesColumn,
    },
    {
      id: 'Collection', label: 'Collection', canSort: false, className: classes.notesColumn,
    },
    { id: 'workflowStatusId', label: 'Artefact Indexing Status', className: classes.workflowStatusColumnHeader },
    { id: 'filePrepDate', label: 'File Prep Date' },
    {
      id: 'type', label: 'Artefact Type', canSort: false, className: classes.artifactTypeColumn,
    },
    { id: 'contentType', label: 'Content Type' },
    {
      id: 'resourceTitle', label: 'Resource Title', className: classes.resourceTitleColumn,
    },
    { id: 'resource', label: 'Resource ID' },
    { id: 'grouping', label: 'Grouping' },
    {
      id: 'title', label: 'Artefact Title', className: classes.titleColumn, canSort: false,
    },
    {
      id: 'manager', label: 'Resource Manager', className: classes.initialsColumn, canSort: false,
    },
    {
      id: 'notesPublisher', label: 'Publisher Notes', className: classes.notesColumn, canSort: false,
    },
    { id: 'indexingCompany', label: 'Indexing Company', canSort: false },
    { id: 'rmitNumber', label: 'Document Number', canSort: false },

    { id: 'modifiedBy', label: 'Modified By', canSort: false },
    { id: 'lastModified', label: 'Last Modified' },

  ];

  const headCellsIndexer: HeadCell[] = [
    {
      id: 'navCell', label: '', canSort: false, className: classes.navigationColumn,
    },
    { id: 'indexer', label: '', className: classes.indexerColumn },
    {
      id: 'notesIndexer', label: 'Indexer Notes', className: classes.notesColumn,
    },
    {
      id: 'Collection', label: 'Collection', canSort: false, className: classes.notesColumn,
    },
    { id: 'workflowStatusId', label: 'Artefact Indexing Status', className: classes.workflowStatusColumnHeader },
    { id: 'filePrepDate', label: 'File Prep Date' },
    {
      id: 'type', label: 'Artefact Type', canSort: false, className: classes.artifactTypeColumn,
    },
    { id: 'contentType', label: 'Content Type' },
    {
      id: 'resourceTitle', label: 'Resource Title', className: classes.resourceTitleColumn,
    },
    { id: 'resourceid', label: 'Resource ID' },
    { id: 'grouping', label: 'Grouping' },
    {
      id: 'title', label: 'Artefact Title', className: classes.titleColumn, canSort: false,
    },
    { id: 'rmitNumber', label: 'Document Number', canSort: false },
    { id: 'lastModified', label: 'Last Modified' },
  ];

  const headCells = isAdmin ? headCellsAdmin : headCellsIndexer;

  return (
    <>
      <EnhanceTaskTableHead
        order={order}
        orderBy={orderBy}
        onRequestSort={handleRequestSort}
        headCells={headCells}
      />
      <TableBody>
        {orderedData.length > 0 ? orderedData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
          .map((row) => (
            <ArtifactTextTaskRow row={row} key={row.rmitNumber} canUnlock={canUnlock} onUpdate={onUpdate} isAdmin={isAdmin} />
          ))
          : (<EmptyTableRow />)}

      </TableBody>
      <div className={classes.pagination}>
        <TablePagination
          ActionsComponent={TablePaginationActions}
          rowsPerPageOptions={[25, 50, 100]}

          count={orderedData.length}
          page={page}
          onChangePage={handleChangePage}
          onChangeRowsPerPage={handleChangeRowsPerPage}
          rowsPerPage={rowsPerPage}
        />
      </div>
    </>
  );
};

export const EmptyTableRow: React.FC = () => {
  const classes = useStyles();
  return (
    <TableRow className={classes.row}>
      <TableCell className={classes.emptyRowTd} colSpan={10}>There are no tasks available to complete.</TableCell>
    </TableRow>
  );
};

export default ArtifactTextTaskTable;
