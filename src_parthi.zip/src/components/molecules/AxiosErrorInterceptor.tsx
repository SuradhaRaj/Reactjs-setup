import React, { useEffect, useState, useContext } from 'react';
import {
  makeStyles, Theme, createStyles, Typography, Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, Button,
} from '@material-ui/core';
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';
import axios from 'axios';
import { useHistory } from 'react-router-dom';
import { InteractionType, InteractionRequiredAuthError, BrowserAuthError } from '@azure/msal-browser';
import {
  useMsalAuthentication, useMsal, useAccount,
} from '@azure/msal-react';
// import { Provider } from 'react-redux';
// import { AppContext } from '../Context';
import { loginRequest, protectedResources } from '../../authConfig';
/**
 * useMsalAuthentication hook will initiate a login if a user is not already signed in.
 * Passing the "Silent" interaction type will call ssoSilent,
 * and if the user is not signed in, it will open a popup interaction to sign in the user.
 * For more information, please visit https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-react/docs/hooks.md#usemsalauthentication-hook
 */
const useStyles = makeStyles((theme: Theme) => createStyles({
  typography: {
    display: 'inline',
    marginLeft: theme.spacing(1),
  },
}));
interface DialogProps {
    clearError(): void;
}
function Axios401Dialog(): JSX.Element {
  const classes = useStyles();
  function navigateToLogin() {
    window.location.href = '/';
  }
  return (
    <Dialog
      open
      keepMounted
      aria-labelledby="alert-dialog-slide-title"
      aria-describedby="alert-dialog-slide-description"
    >
      <DialogTitle id="alert-dialog-slide-title">Session Expired</DialogTitle>
      <DialogContent>
        <DialogContentText id="alert-dialog-slide-description">
          <ErrorOutlineIcon color="secondary" />
          <Typography className={classes.typography}>Your session has expired and we need you to log in again.</Typography>
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button variant="text" color="primary" onClick={navigateToLogin}>
          Log me in
        </Button>
      </DialogActions>
    </Dialog>
  );
}
function Axios403Dialog(props: DialogProps): JSX.Element {
  const classes = useStyles();
  const history = useHistory();
  function navigateToHome() {
    props.clearError();
    history.push('/');
  }
  const handleClose = () => {
    props.clearError();
  };
  return (
    <Dialog
      open
      keepMounted
      aria-labelledby="alert-dialog-slide-title"
      aria-describedby="alert-dialog-slide-description"
    >
      <DialogTitle id="alert-dialog-slide-title">Something went wrong!</DialogTitle>
      <DialogContent>
        <DialogContentText id="alert-dialog-slide-description">
          <ErrorOutlineIcon color="secondary" />
          <Typography className={classes.typography}>
            You do not have access to the requested resource.
            Please contact your system administrator.
          </Typography>
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button onClick={navigateToHome} color="primary">Take me home</Button>
        <Button variant="contained" onClick={handleClose} color="primary">Okay</Button>
      </DialogActions>
    </Dialog>
  );
}
interface State {
    errorCode: number;
    hasReturned: boolean;
    didError: boolean;
}
export default function AxiosErrorInterceptor(props: React.PropsWithChildren<{}>): JSX.Element {
  const { instance, accounts, inProgress } = useMsal();
  const account = useAccount(accounts[0] || {});
  const [graphData, setGraphData] = useState(null);
  const [state, setState] = React.useState<State>({ errorCode: 0, hasReturned: false, didError: false });
  /**
     * useMsalAuthentication hook will initiate a login if a user is not already signed in.
     * Passing the "Silent" interaction type will call ssoSilent,
     * and if the user is not signed in, it will open a popup interaction to sign in the user.
     * For more information, please visit https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-react/docs/hooks.md#usemsalauthentication-hook
     */
  const { login, error } = useMsalAuthentication(InteractionType.Silent, loginRequest);
  useEffect(() => {
    if (error && error instanceof InteractionRequiredAuthError) {
      login(InteractionType.Popup, loginRequest)
        .catch((err) => {
          if (err instanceof BrowserAuthError
                        && (err.errorCode === 'popup_window_error' || err.errorCode === 'empty_window_error')) {
            login(InteractionType.Redirect, loginRequest);
          }
        });
    }
  }, [error]);
  useEffect(() => {
    if (account && inProgress === 'none' && !graphData && (window.location.href.indexOf('/Signout') < 0)) {
      instance.acquireTokenSilent({
        scopes: protectedResources.graphMe.scopes,
        account,
      }).then((response) => {
        console.log('Token Response', response);
        sessionStorage.setItem('ADtoken', response.idToken);
        setState({
          ...state,
          errorCode: 0,
          hasReturned: true,
          didError: false,
        });
      }).catch((error1) => {
        // in case if silent token acquisition fails, fallback to an interactive method
        if (error1 instanceof InteractionRequiredAuthError) {
          if (account && inProgress === 'none') {
            instance.acquireTokenPopup({
              scopes: protectedResources.graphMe.scopes,
            }).then((response) => {
              console.log(response);
            }).catch((error2) => console.log(error2));
          }
        }
      });
    }
  }, [account, inProgress, instance]);

  function clearError(): void {
    setState({
      ...state,
      errorCode: 0,
      hasReturned: false,
      didError: true,
    });
  }
  React.useEffect(() => {
    axios.interceptors.request.use((config) => {
      // Do something before request is sent
      const bearer = `Bearer ${sessionStorage.getItem('ADtoken')}`;
      console.log(bearer);
      config.headers.Authorization = bearer; // eslint-disable-line no-param-reassign
      // console.log(config.headers)
      console.log(config, sessionStorage.getItem('ADtoken'));
      return config;
    }, (error3) => Promise.reject(error3));
    axios.interceptors.response.use((response) => response, (error4) => {
      console.log(sessionStorage.getItem('ADtoken'));
      // Check if the status code is 401 (Unauthorized), which means the user is not yet authenticated
      if (error4.response.status !== undefined) {
        if (error4.response.status === 401 || error4.response.status === 403) {
          setState({
            ...state,
            errorCode: error4.response.status,
            hasReturned: false,
            didError: true,
          });
        }
      }
      return Promise.reject(error4);
    });
  }, []);
  switch (state.errorCode) {
    case 401: return <Axios401Dialog />;
    case 403: return <Axios403Dialog clearError={clearError} />;
    default: return (
      <>
        {' '}
        {state.hasReturned && !state.didError && (<>{props.children}</>)}
      </>
    );
  }
}
