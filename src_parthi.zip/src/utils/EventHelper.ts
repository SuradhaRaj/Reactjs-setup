function on(eventType: string, listener: (evt: CustomEvent) => void) {
  document.body.addEventListener(eventType, listener as EventListener, false);
}

function off(eventType: string, listener: (evt: CustomEvent) => void) {
  document.body.removeEventListener(eventType, listener as EventListener);
}

// function once(eventType, listener) {
//    on(eventType, handleEventOnce);

//    function handleEventOnce(event) {
//        listener(event);
//        off(eventType, handleEventOnce);
//    }
// }

function trigger(eventType: string, data: CustomEvent) {
  const event = new CustomEvent(eventType, { detail: data });
  document.body.dispatchEvent(event);
}

const EventHelper = { on, off, trigger };

export { on, off, trigger };
export default EventHelper;
