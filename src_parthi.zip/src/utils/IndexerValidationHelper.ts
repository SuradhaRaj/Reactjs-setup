import MediaArtifactDocument from '../interfaces/MediaIndexer/MediaArtifact';
import TextArtifact from '../interfaces/TextIndexer/TextArtifact';
import TextResourceTypes from '../interfaces/enums/TextResourceTypes';

interface ValidationResult {
  isValid: boolean;
  errors: Array<number>;
}

const authorReviewedById = 28;
const genreFictionId = 13;

const ValidateMinimumPublishReqs = (artifact: MediaArtifactDocument): ValidationResult => {
  const results: Array<number> = [];
  if (artifact.title.toUpperCase().includes('SPORT REPORTER')) {
    results.push(1);
  }
  if (artifact.title.toUpperCase().includes('FINANCE REPORTER')) {
    results.push(2);
  }
  if (artifact.title.toUpperCase().includes('WEATHER REPORTER')) {
    results.push(3);
  }

  if (artifact.resourceType === 'TV Program') {
    if (artifact.series == null || artifact.series === 0) {
      results.push(5);
    }

    if (artifact.episode == null || artifact.episode === 0) {
      results.push(6);
    }
  }

  return {
    isValid: results.length === 0,
    errors: results,
  };
};

const ValidateTextIndexerWarnings = (artifact: TextArtifact, advancedIndexing: boolean): ValidationResult => {
  const results: Array<number> = [];

  // Artifact Indexing
  if (artifact.title?.toLowerCase().includes('editorial') && artifact.resourceTypeId !== TextResourceTypes.JournalEditorial && artifact.resourceTypeId !== TextResourceTypes.JournalJournalArticle) {
    results.push(1);
  }
  if (artifact.title?.toLowerCase().includes('obituary') && artifact.resourceTypeId === TextResourceTypes.JournalJournalArticle) {
    results.push(2);
  }
  if ((artifact.title?.toLowerCase().includes('introduction') || artifact.title?.toLowerCase().includes('appendix')) && artifact.resourceTypeId !== TextResourceTypes.Book) {
    results.push(3);
  }
  if ((artifact.title?.toLowerCase().includes('news') || artifact.title?.toLowerCase().includes('interview')) && artifact.resourceTypeId !== TextResourceTypes.JournalJournalArticle) {
    results.push(4);
  }
  if ((artifact.title?.toLowerCase().includes('introduction') || artifact.title?.toLowerCase().includes('appendix')) && artifact.resourceTypeId !== TextResourceTypes.ConferenceConferencePaper) {
    results.push(5);
  }
  if (artifact.articleOrder === null || artifact.articleOrder === 0) {
    results.push(6);
  }
  if (artifact.title?.toLowerCase().includes('introduction') && (artifact.articleOrder != null && artifact.articleOrder > 5)) {
    results.push(7);
  }

  if (artifact.isPeerReviewedArticle) {
    if (artifact.authors?.length > 0) {
      for (let i = 0; i < artifact.authors.length; i++) {
        if (artifact.authors[i].roleTypeId === authorReviewedById && !results.includes(8)) {
          results.push(8);
          break;
        }
      }
    }
    if (artifact.corporateAuthors?.length > 0) {
      for (let i = 0; i < artifact.corporateAuthors.length; i++) {
        if (artifact.corporateAuthors[i].roleTypeId === authorReviewedById && !results.includes(8)) {
          results.push(8);
          break;
        }
      }
    }
  }

  if (artifact.isPeerReviewedArticle && (artifact.authors?.length === 0 && artifact.corporateAuthors?.length === 0)) {
    results.push(9);
  }
  if (artifact.isPeerReviewedArticle
    && (artifact.resourceTypeId === TextResourceTypes.Journal || artifact.resourceTypeId === TextResourceTypes.Conference
      || artifact.resourceTypeId === TextResourceTypes.Book)) {
    results.push(10);
  }
  if (artifact.isPeerReviewedArticle && (artifact.resourceTypeId === TextResourceTypes.JournalBookReview
        || artifact.resourceTypeId === TextResourceTypes.JournalReviewArticle)) {
    results.push(11);
  }
  if ((artifact.authors?.length === 0 && artifact.corporateAuthors?.length === 0) && (artifact.pagination === null || artifact.pagination === '-')
      && artifact.resourceTypeId === TextResourceTypes.JournalJournalArticle) {
    results.push(12);
  }

  if (artifact.resourceTypeId === TextResourceTypes.JournalBookReview) {
    if (artifact.authors?.length > 0) {
      for (let i = 0; i < artifact.authors.length; i++) {
        if (artifact.authors[i].roleTypeId === authorReviewedById && !results.includes(13)) {
          results.push(13);
          break;
        }
      }
    }
    if (artifact.corporateAuthors?.length > 0) {
      for (let i = 0; i < artifact.corporateAuthors.length; i++) {
        if (artifact.corporateAuthors[i].roleTypeId === authorReviewedById && !results.includes(13)) {
          results.push(13);
          break;
        }
      }
    }
  }

  if ((artifact.authors?.length === 0 && artifact.corporateAuthors?.length === 0)
        && artifact.resourceTypeId === TextResourceTypes.MonographBookChapter) {
    results.push(14);
  }
  if ((artifact.authors?.length === 0 && artifact.corporateAuthors?.length === 0)
      && artifact.resourceTypeId === TextResourceTypes.ConferenceConferencePaper) {
    results.push(15);
  }

  for (let i = 0; i < artifact.identifiers?.length; i++) {
    if (artifact.identifiers[i].name.includes('Sir ') || artifact.identifiers[i].name.includes('Professor ')
      || artifact.identifiers[i].name.includes('Dame ') || artifact.identifiers[i].name.includes('Dr ')) {
      results.push(16);
    }
  }

  if (!artifact.isPeerReviewedArticle && artifact.title?.toLowerCase().includes('peer reviewed')) {
    results.push(17);
  }

  // Advanced Indexing
  if (advancedIndexing) {
    for (let i = 0; i < artifact.fast?.length; i++) {
      if (artifact.fast[i].name.toLowerCase().includes('--book review')
          && artifact.resourceTypeId === TextResourceTypes.MonographBookChapter && !results.includes(18)) {
        results.push(18);
      }
      if (artifact.fast[i].name.toLowerCase().includes('--fiction') && artifact.genreID === genreFictionId && !results.includes(19)) {
        results.push(19);
      }
      if (artifact.fast[i].name.toLowerCase().includes('workshop') && artifact.title?.toLowerCase().includes('conference')
          && artifact.resourceTypeId === TextResourceTypes.ConferenceConferencePaper && !results.includes(20)) {
        results.push(20);
      }
      if (artifact.fast[i].name.toLowerCase().includes('competition') && !results.includes(21)) {
        results.push(21);
      }
      if (artifact.fast[i].name.toLowerCase().includes('awards') && !results.includes(22)) {
        results.push(22);
      }
      if (artifact.fast[i].name.toLowerCase().includes('bureau of statistics') && !results.includes(23)) {
        results.push(23);
      }
      if (artifact.fast[i].name.toLowerCase().includes('--statistics') && !results.includes(24)) {
        results.push(24);
      }
      if (artifact.fast[i].name.toLowerCase().includes('--research') && !results.includes(25)) {
        results.push(25);
      }
      if ((artifact.fast[i].name.toLowerCase().includes('associations') || artifact.fast[i].name.toLowerCase().includes('institutions')
        || artifact.fast[i].name.toLowerCase().includes('--membership')) && !results.includes(26)) {
        results.push(26);
      }
      if (artifact.fast[i].name.toLowerCase().includes('australian bureau of statistics') && !results.includes(27)) {
        results.push(27);
      }
    }
  }

  return {
    isValid: results.length === 0,
    errors: results,
  };
};

const ValidateMediaIndexerWarnings = (artifact: MediaArtifactDocument): ValidationResult => {
  const results: Array<number> = [];

  // Artifact Indexing
  if (artifact.fast.length > 3 && artifact.assetType === 'Segment') {
    results.push(1);
  }

  if (artifact.captions === '') {
    results.push(2);
  }
  if ((artifact.series === undefined) || (artifact.series === null)) {
    results.push(3);
  }
  if ((artifact.episode === undefined) || (artifact.episode === null)) {
    results.push(4);
  }
  if (artifact.programBroadcastStart === '') {
    results.push(5);
  }
  if (artifact.programBroadcastEnd === '') {
    results.push(6);
  }

  return {
    isValid: results.length === 0,
    errors: results,
  };
};

const ValidateWholeNumber = (value: string) => {
  if (value === undefined || value === null || value === '') return false;
  if (!(new RegExp(/^\d*?$/)).test(value)) return false;

  const numValue = parseInt(value);
  if (numValue < 0) return false;

  return true;
};

const ValidateWholeNumberInRange = (value: string, min: number, max: number) => {
  if (value === undefined || value === null || value === '') return true;
  if (!(new RegExp(/^\d*$/)).test(value)) return false;

  const numValue = parseInt(value);
  if (numValue < min) return false;
  if (numValue > max) return false;

  return true;
};

export default {
  ValidateMinimumPublishReqs,
  ValidateTextIndexerWarnings,
  ValidateWholeNumber,
  ValidateWholeNumberInRange,
  ValidateMediaIndexerWarnings,
};
