import {
  Record, Static, String, Null, Number,
} from 'runtypes';
import { NumberGreaterZero, ArrayWithElements } from '../../runtypeTypes';
import { ContactRoleValidator } from './ContactRole';

export const OrganisationContactValidator = Record({
  contactId: NumberGreaterZero,
  title: String.Or(Null),
  firstName: String.Or(Null),
  surname: String.Or(Null),
  email: String.Or(Null),
  address: String.Or(Null),
  suburb: String.Or(Null),
  country: String.Or(Null),
  state: String.Or(Null),
  postcode: String.Or(Null),
  homePhone: String.Or(Null),
  workPhone: String.Or(Null),
  hubSpotId: Number,
  roles: ArrayWithElements(ContactRoleValidator),
});

type OrganisationContact = Static<typeof OrganisationContactValidator>;

export default OrganisationContact;
