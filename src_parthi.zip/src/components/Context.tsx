import React, { useEffect, useState } from 'react';
import Axios from 'axios';
import UserInfo from '../classes/UserInfo';

export const AppContext = React.createContext<State & Functions>({
  userInfo: UserInfo.empty(),
  isBlocked: false,
  hideBlockUi: () => undefined,
  showBlockUi: () => undefined,
});

interface Functions {
  showBlockUi(): void;
  hideBlockUi(): void;
}

interface State{
  userInfo: UserInfo;
  isBlocked: boolean;
}

export const AppContextProvider: React.FC<React.PropsWithChildren<{}>> = ({ children }) => {
  const [state, setState] = useState<State>({
    userInfo: UserInfo.empty(),
    isBlocked: false,
  });

  const showBlockUi = (): void => {
    setState({
      ...state,
      isBlocked: true,
    });
  };
  const hideBlockUi = (): void => {
    setState({
      ...state,
      isBlocked: false,
    });
  };

  const contextValue = {
    ...state, showBlockUi, hideBlockUi,
  };

  useEffect(() => {
    Axios.interceptors.request.use((config) => {
      // Do something before request is sent
      const bearer = `Bearer ${sessionStorage.getItem('ADtoken')}`;
      // console.log(bearer);
      config.headers.Authorization = bearer; // eslint-disable-line no-param-reassign
      // console.log(config.headers)
      // console.log(config, sessionStorage.getItem('ADtoken'));
      return config;
    }, (error) => Promise.reject(error)); // Do something with request error
    // if (state.userInfo.data.name == '') {
    Axios.get(`${process.env.REACT_APP_API_URL}/api/user/userinfo`).then((response) => {
      setState({
        ...state,
        userInfo: new UserInfo(response.data),
      });
    }).catch(() => undefined);
    // }
  }, []);

  return (
    <AppContext.Provider value={contextValue}>
      {children}
    </AppContext.Provider>

  );
};
