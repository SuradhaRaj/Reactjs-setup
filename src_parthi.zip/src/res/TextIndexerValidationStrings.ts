import ResourceString from '../interfaces/res/ResourceString';

const strings: Array<ResourceString> = [
  { id: 1, message: 'The title for this article does not exist' },
  { id: 2, message: 'Resource type not provided' },
  { id: 3, message: 'Description was not provided' },
  { id: 4, message: 'Pagination was not provided' },
  { id: 5, message: 'Language(s) was not provided' },
  { id: 6, message: 'FAST Term(s) was not provided' },
  { id: 7, message: 'AGLIBS Subject(s) was not provided' },
  { id: 8, message: 'Jurisdiction(s) was not provided' },
];

export default strings;
