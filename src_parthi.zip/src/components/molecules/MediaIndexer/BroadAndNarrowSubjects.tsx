/* eslint @typescript-eslint/no-explicit-any: 0 */
import React from 'react';
import {
  Grid, Chip, Zoom, createStyles, withStyles, WithStyles, TextField,
} from '@material-ui/core';
import Autocomplete from '@material-ui/lab/Autocomplete';

import { find } from 'lodash';
import DocumentBroadSubject from '../../../interfaces/MediaIndexer/DocumentBroadSubject';
import DocumentItemNode from '../../../interfaces/MediaIndexer/DocumentItemNode';
import NarrowSubjectOption from '../../../interfaces/MediaIndexer/NarrowSubjectOption';
import TypedownCounter from '../../atoms/TypedownCounter';

const useStyles = createStyles({
  typedownContainer: {
    width: '100%',
  },
  addButton: {
    top: '-40px',
    left: '425px',
  },
  subjectContainer: {
    textAlign: 'left',
    marginTop: 5,
  },
  chip: {
    marginRight: '5px',
    marginBottom: '5px',
  },
  typedownInput: {
    width: '100%',
  },
  typedownTextField: {
    marginTop: '0px',
  },
});

interface State {
  broadSubjectLookup: DocumentBroadSubject[];
  broadSubjectsList: DocumentItemNode[];
  narrowSubjectsList: DocumentItemNode[];
}

interface BroadAndNarrowSubjectsProps {
  broadSubjectLookup: DocumentBroadSubject[];
  selectedBroadSubjects: DocumentItemNode[];
  selectedNarrowSubjects: DocumentItemNode[];
  broadSubjectKey: string;
  narrowSubjectKey: string;
  onChangeBroadSubjectFunction(values: DocumentItemNode[]): void;
  onChangeNarrowSubjectFunction(values: DocumentItemNode[]): void;
  broadSubjectError: boolean;
  broadSubjectErrorText: string|string[]|undefined;
  narrowSubjectError: boolean;
  narrowSubjectErrorText: string|string[]|undefined;
  broadSubjectTypedownLimit: number;
  narrowSubjectTypedownLimit: number;
  classes: any;
  readOnly?: boolean;
}

function getBroadSubjectOptionRender(option: DocumentBroadSubject): JSX.Element {
  return (
    <>
      <Grid item xs={11}>
        <span>{option.name}</span>
      </Grid>
    </>
  );
}

function getNarrowSubjectOptionRender(option: NarrowSubjectOption): JSX.Element {
  return (
    <>
      <Grid item xs={11}>
        <span>{option.value}</span>
      </Grid>
    </>
  );
}

class BroadAndNarrowSubjects extends React.Component<BroadAndNarrowSubjectsProps & WithStyles<typeof useStyles>, State, {}> {
  constructor(props: BroadAndNarrowSubjectsProps) {
    super(props);
    this.calculateNarrowSubjectOptions = this.calculateNarrowSubjectOptions.bind(this);
    this.handleDeleteBroadSubject = this.handleDeleteBroadSubject.bind(this);
    this.handleDeleteNarrowSubject = this.handleDeleteNarrowSubject.bind(this);
    this.addBroadSubjectToList = this.addBroadSubjectToList.bind(this);
    this.addNarrowSubjectToList = this.addNarrowSubjectToList.bind(this);
    this.renderBroadSubjectChips = this.renderBroadSubjectChips.bind(this);
  }

  handleDeleteBroadSubject = (broadSubjectToDelete: DocumentItemNode) => () => {
    const newList: DocumentItemNode[] = this.props.selectedBroadSubjects.filter((option) => option.name !== broadSubjectToDelete.name);
    this.props.onChangeBroadSubjectFunction(newList);

    const broadSubject = find(this.props.broadSubjectLookup, { name: broadSubjectToDelete.name });

    if (broadSubject !== undefined) {
      let newNarrowList = this.props.selectedNarrowSubjects;

      for (let i = 0; i < broadSubject.narrowSubjects.length; i++) {
        const subject = broadSubject.narrowSubjects[i];
        newNarrowList = newNarrowList.filter((option) => option.name !== subject.Value);
      }
      this.props.onChangeNarrowSubjectFunction(newNarrowList);
    }
  }

  handleDeleteNarrowSubject = (narrowSubjectToDelete: DocumentItemNode) => () => {
    const newList: DocumentItemNode[] = this.props.selectedNarrowSubjects.filter((option) => option.name !== narrowSubjectToDelete.name);
    this.props.onChangeNarrowSubjectFunction(newList);
  }

  calculateNarrowSubjectOptions(): NarrowSubjectOption[] {
    const narrowSubjectOptions: NarrowSubjectOption[] = [];

    if (this.props.selectedBroadSubjects !== undefined && this.props.selectedBroadSubjects.length > 0) {
      this.props.broadSubjectLookup.forEach((subject) => {
        this.props.selectedBroadSubjects.forEach((broadSubject) => {
          if (subject.name === broadSubject.name) {
            subject.narrowSubjects.forEach((narrowSubject) => {
              narrowSubjectOptions.push({ key: narrowSubject.Key, value: narrowSubject.Value });
            });
          }
        });
      });
    }

    return narrowSubjectOptions;
  }

  addBroadSubjectToList(event: any, values: Array<DocumentBroadSubject>): void {
    if (values !== undefined && values !== null && values[values.length - 1] !== undefined) {
      const value = values[values.length - 1];
      if (this.props.selectedBroadSubjects !== undefined) {
        if (this.props.selectedBroadSubjects.find((option) => option.name === value.name) === undefined
          && this.props.selectedBroadSubjects.length < this.props.broadSubjectTypedownLimit) {
          this.props.onChangeBroadSubjectFunction([...this.props.selectedBroadSubjects, {
            id: value.broadSubjectID, name: value.name, createdBy: '', createdDate: '',
          }]);
        }
      } else {
        this.props.onChangeBroadSubjectFunction([{
          id: value.broadSubjectID, name: value.name, createdBy: '', createdDate: '',
        }]);
      }
    }
  }

  addNarrowSubjectToList(event: any, values: NarrowSubjectOption[]): void {
    if (values !== undefined && values !== null && values[values.length - 1] !== undefined) {
      const value = values[values.length - 1];
      if (value !== undefined) {
        if (this.props.selectedNarrowSubjects !== undefined) {
          if (this.props.selectedNarrowSubjects.find((option) => option.name === value.value) === undefined
            && this.props.selectedNarrowSubjects.length < this.props.narrowSubjectTypedownLimit) {
            this.props.onChangeNarrowSubjectFunction([...this.props.selectedNarrowSubjects, {
              id: value.key, name: value.value, createdBy: '', createdDate: '',
            }]);
          }
        } else {
          this.props.onChangeNarrowSubjectFunction([{
            id: value.key, name: value.value, createdBy: '', createdDate: '',
          }]);
        }
      }
    }
  }

  renderBroadSubjectChips() {
    const { classes } = this.props;
    if (this.props.selectedBroadSubjects !== undefined && this.props.selectedBroadSubjects.length > 0) {
      return (
        this.props.selectedBroadSubjects.map((subject) => <Zoom in={this.props.selectedBroadSubjects.includes(subject)} key={subject.id}><Chip tabIndex={-1} disabled={this.props.readOnly} variant="outlined" className={classes.chip} label={subject.name} onDelete={this.handleDeleteBroadSubject(subject)} color="primary" /></Zoom>)
      );
    }

    return null;
  }

  renderNarrowSubjectChips() {
    const { classes } = this.props;
    if (this.props.selectedNarrowSubjects !== undefined && this.props.selectedNarrowSubjects.length > 0) {
      return (
        this.props.selectedNarrowSubjects.map((subject) => <Zoom in={this.props.selectedNarrowSubjects.includes(subject)} key={subject.id}><Chip tabIndex={-1} disabled={this.props.readOnly} variant="outlined" className={classes.chip} label={subject.name} onDelete={this.handleDeleteNarrowSubject(subject)} color="primary" /></Zoom>)
      );
    }

    return null;
  }

  render(): JSX.Element {
    const { classes } = this.props;

    return (
      <>
        <div className={classes.typedownContainer}>
          <Grid container item xs={12}>
            <Grid item xs={5}>
              <Grid item xs={12}>
                <Grid item xs={12} style={{ position: 'relative' }}>
                  <Autocomplete
                    multiple
                    id="tags-standard"
                    disabled={this.props.readOnly || this.props.selectedBroadSubjects.length >= this.props.broadSubjectTypedownLimit}
                    className={classes.typedownInput}
                    options={this.props.broadSubjectLookup}
                    onChange={this.addBroadSubjectToList}
                    renderInput={(params: any) => (
                      <TextField
                        {...params}
                        variant="outlined"
                        label="Broad Subject"
                        margin="normal"
                        className={classes.TypedownTextField}
                        fullWidth
                        error={this.props.broadSubjectError}
                        helperText={this.props.broadSubjectError ? this.props.broadSubjectErrorText : ''}
                      />
                    )}
                    renderOption={(option: DocumentBroadSubject) => getBroadSubjectOptionRender(option)}
                    getOptionLabel={(option) => option.name}
                    renderTags={() => <></>}
                  />
                  {!this.props.broadSubjectError && (
                  <TypedownCounter
                    limit={this.props.broadSubjectTypedownLimit}
                    selected={this.props.selectedBroadSubjects.length}
                  />
                  )}
                </Grid>
              </Grid>
              <Grid container item xs={12} className={classes.subjectContainer}>
                {this.renderBroadSubjectChips()}
              </Grid>
            </Grid>
            <Grid item xs={1} />
            <Grid item xs={5}>
              <Grid item xs={12}>
                <Grid item xs={12} style={{ position: 'relative' }}>
                  <Autocomplete
                    multiple
                    disabled={this.props.readOnly || this.props.selectedNarrowSubjects.length >= this.props.narrowSubjectTypedownLimit}
                    id="tags-standard"
                    className={classes.typedownInput}
                    options={this.calculateNarrowSubjectOptions()}
                    onChange={this.addNarrowSubjectToList}
                    renderInput={(params: any) => (
                      <TextField
                        {...params}
                        variant="outlined"
                        label="Narrow Subject"
                        margin="normal"
                        className={classes.TypedownTextField}
                        fullWidth
                        error={this.props.narrowSubjectError}
                        helperText={this.props.narrowSubjectError ? this.props.narrowSubjectErrorText : ''}
                      />
                    )}
                    renderOption={(option: NarrowSubjectOption) => getNarrowSubjectOptionRender(option)}
                    getOptionLabel={(option) => option.value}
                    renderTags={() => <></>}
                  />
                  {!this.props.narrowSubjectError && (
                    <TypedownCounter
                      limit={this.props.narrowSubjectTypedownLimit}
                      selected={this.props.selectedNarrowSubjects.length}
                    />
                  )}
                </Grid>
              </Grid>
              <Grid container item xs={12} className={classes.subjectContainer}>
                {this.renderNarrowSubjectChips()}
              </Grid>
            </Grid>
          </Grid>
        </div>
      </>
    );
  }
}

export default withStyles(useStyles)(BroadAndNarrowSubjects);
