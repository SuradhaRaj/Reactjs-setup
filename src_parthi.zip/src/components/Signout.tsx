import React, { useEffect } from 'react'; // useState
// import { Button } from '@material-ui/core';
import { useMsal } from '@azure/msal-react';
// import { IPublicClientApplication } from '@azure/msal-browser';
// import { AppContext } from './Context';
import HomeLogin from './Home';

export default function Logout() {
  const { instance } = useMsal();

  useEffect(() => {
    sessionStorage.clear();
    instance.logoutRedirect().catch((e) => {
      console.error(e);
    });
  }, []);

  return (
    <>
      {' '}
      <HomeLogin />
    </>

  );
}
