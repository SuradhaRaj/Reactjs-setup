/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect, useState } from 'react';
import {
  Typography,
  Grid,
  Divider,
  Button,
  makeStyles,
  InputBase,
  IconButton,
} from '@material-ui/core';
import { useDispatch } from 'react-redux';
import { useLocation, useHistory } from 'react-router-dom';
import Axios from 'axios';
import SearchIcon from '@material-ui/icons/Search';
import { boolean } from 'yup';
import data from '@iconify/icons-simple-icons/hubspot';
import SwitchField from '../../Shared/SwitchField';
import { useTypedSelector } from '../../../store/store';
import LookupOption from '../../../interfaces/LookupOption';
import Dropdown from '../../Shared/Dropdown';
import DropdownOption from '../../../interfaces/MediaIndexer/DropdownOption';
import ResourceResponse from '../../../interfaces/ResourceManagement/ResourceResponse';
import { setResourceData, initialState } from '../../../store/actions/ActnResourceData';
import TextInputField from '../../Shared/TextInputField';
import { TypedownOption, StrStrTypedownOption } from '../../../interfaces/TypedownOption';
import Typedown from '../Typedown';
import DataCollectionRes from '../../../interfaces/ResourceManagement/FullDataCollection';
// import { initialState } from '../../../store/reducers/RdcrTaskManagement';

interface StateResource {
  resourcetype: LookupOption[];
  // resource: DropdownOption[];
  resource: Array<TypedownOption | StrStrTypedownOption>;
  search: string;
  mediaType: LookupOption[];
  accessRights: LookupOption[];
  indexingCompany: LookupOption[];
  resourceManager: LookupOption[];
  // resourceSV: string;
  resourceSV: TypedownOption | StrStrTypedownOption;
  resourcetypeSV: string;
}
interface ResIHeader {
  Active: number;
  resourceId: number;
  resourceName: string | null | undefined;
  publishTitle: boolean;
  publishdate: string | null;
  resourceTypeval: number | null;
  mediaType: number | null;
  resourceManager: number | null;
  peerReviewIndicator: number;
  indexingCompany: number | null;
  accessRights: number | null;
  createdDate: string | null;
  modifiedDate: string | null;
  revisionDate: string | null;
  titleDocNum: string | null;
  resourceTitle: string | null;
}
interface Props {
  Resourcemgmtdata: DataCollectionRes;
  callback: any;
}

interface ConfrProp {
  ConferenceDate: string;
  ConferenceName: string;
  ConferenceNumber: string;
  ConferenceSponsor: string;
  ConferenceTheme: string;
}

const useStyles = makeStyles({
  root: {
    width: '300px',
    backgroundColor: '#f9f9fc',
    padding: '20px',
  },
  'switch_container MuiFormLabel': {
    color: '#000000',
    fontSize: '12px',

  },
  heading: {
    float: 'left',
    'font-size': '18px',
    'font-weight': '500',
  },
  notification: {},
  typo: {
    fontSize: '17px',
    'font-weight': '600',
    marginBottom: '0px',
  },
  cardheader: {},
  Lgroup: {
    fontSize: '12px',
    marginRight: '20px',
    color: '#000000',
  },
  Lname: {
    fontSize: '12px',
    'font-weight': '600',
    color: '#000000',
    marginRight: '8px',
    marginBottom: '0px',
  },
  success: {
    float: 'right',
  },
  workflowButton: {
    borderRadius: '50px',
    float: 'right',
    marginRight: '20px',
  },
  searchbarContainer: {
    textAlign: 'right',
  },
  searchbarInput: {
    width: '80%',
    float: 'left',
    marginRight: '15px',
  },
  inputRoot: {
    color: 'inherit',
  },
});

const ResourcemgmtHeader = (props: Props) => {
  const classes = useStyles();
  const dispatch = useDispatch();
  // const getReferenceData = useTypedSelector((store) => store.ResourceReferenceData);
  const getReferenceData = useTypedSelector((store) => store.TitleResourceReferenceData);
  const getResourceData = useTypedSelector((store) => store.ResourceDataOnId);

  // const getResoursceData = useTypedSelector((store) => store.ResourceDataOnId.ResourceOrganization);

  const [searchTerm, setSearchTerm] = useState('');
  const booleanValues: LookupOption[] = [
    { key: 1, value: 'True' }, { key: 0, value: 'False' },
  ];

  const [StateResource, setStateResource] = useState<StateResource>({
    resourcetype: [],
    resource: [],
    search: '',
    mediaType: [],
    accessRights: [],
    indexingCompany: [],
    resourceManager: [],
    resourceSV: { id: '', value: '' },
    resourcetypeSV: '',
  });
  const [StateResHeader, setStateResHeader] = useState<ResIHeader>(
    {
      Active: 0,
      resourceId: 0,
      resourceName: null,
      publishTitle: false,
      publishdate: null,
      resourceTypeval: null,
      mediaType: null,
      resourceManager: null,
      peerReviewIndicator: 0,
      indexingCompany: null,
      accessRights: null,
      createdDate: null,
      modifiedDate: null,
      revisionDate: null,
      titleDocNum: null,
      resourceTitle: null,
    },
  );

  /* const [checked, setChecked] = React.useState(true);
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setChecked(event.target.checked);
  }; */

  const history = useHistory();
  const location = useLocation();
  const query = new URLSearchParams(location.search);

  function resourcecall(resid: number) {
    Axios.get<ResourceResponse>(`${process.env.REACT_APP_API_URL}/api/resource/${resid}`)
      .then((resourceData) => {
        dispatch(setResourceData(resourceData.data));
      });
  }

  function onResourceChange(value: string, key: number) {
    setStateResource((prevStateResource) => ({
      ...prevStateResource,
      // resourceSV: key.toString(),
      resourceSV: { id: key, value },
    }));

    resourcecall(key);

    // Axios.get<ResourceResponse>(`${process.env.REACT_APP_API_URL}/api/resource/${key}`)
    //   .then((resourceData) => {
    //     dispatch(setResourceData(resourceData.data));
    //   });
  }

  function SetResourceDropdown(pResTypeId: number, pSelectedId: string) {
    // let sid: string = pSelectedId;
    let sid: TypedownOption | StrStrTypedownOption;
    const filterdDrop = getReferenceData.TitleResourceReferenceData.resourceslookup
      .filter((obj) => obj.resourceTypeID === pResTypeId);
    // const dropdownList: DropdownOption[] = [];
    const dropdownList: Array<TypedownOption | StrStrTypedownOption> = [];
    for (let i = 0; i < filterdDrop.length; i++) {
      dropdownList.push({ id: filterdDrop[i].resourceID, value: filterdDrop[i].resourceTitle });
    }
    if (dropdownList.length !== 0) {
      // if (pSelectedId === '0') {
      //   sid = { id: dropdownList[0].id.toString(), value: dropdownList[0].value };
      // }
      if (+pSelectedId > 0) {
        const selectedResource = dropdownList.filter((obj) => obj.id === +pSelectedId);
        if (selectedResource.length !== 0) {
          sid = { id: selectedResource[0].id.toString(), value: selectedResource[0].value };
        } else {
          sid = { id: dropdownList[0].id.toString(), value: dropdownList[0].value };
        }
      }
    }

    setStateResource((prevStateResource) => ({
      ...prevStateResource,
      resource: dropdownList,
      resourceSV: sid,
    }));

    // props.callback(StateResHeader);
  }
  function setFieldValue(value: string, key: number) {
    setStateResource((prevStateResource) => ({
      ...prevStateResource,
      resourcetypeSV: key.toString(),
    }));
    setStateResHeader({
      ...StateResHeader,
      resourceTypeval: key,
    });

    SetResourceDropdown(key, '0');
  }
  function getResourceTypeDropdownOptions(resourceType: LookupOption[]) {
    const dropdownList: DropdownOption[] = [];
    for (let i = 0; i < resourceType.length; i++) {
      dropdownList.push({ value: resourceType[i].key, display: resourceType[i].value });
    }
    return dropdownList;
  }
  function handleChangeSearchTerm(event: React.ChangeEvent<HTMLInputElement>) {
    setSearchTerm(event.target.value);
    if (event.target.value.trim().length > 0) {
      console.log(event.target.value);
    } else {
      console.log(event.target.value);
    }
  }

  function navigateToSearchPage() {
    if (searchTerm.trim().length > 0) {
      const foundResID = getReferenceData.TitleResourceReferenceData.resourceslookup.find((x) => (typeof x.resourceName === 'string' ? x.resourceName.toLowerCase() === searchTerm.toLowerCase() : x.resourceName === searchTerm) || (typeof x.resourceTitle === 'string' ? x.resourceTitle.toLowerCase() === searchTerm.toLowerCase() : x.resourceTitle === searchTerm));
      // const foundResTitle = taskManagement_new.ResourceReferenceData.resourceslookup.find((x) => (x.resourceTitle.toLowerCase().includes(searchTerm.toLowerCase())));
      if (foundResID) {
        let changeRestypeID = 1;
        let changeResID = 1;

        changeRestypeID = foundResID?.resourceTypeID == null ? 0 : foundResID?.resourceTypeID;
        changeResID = foundResID?.resourceID == null ? 0 : foundResID?.resourceID;

        setStateResource((prevStateResource) => ({
          ...prevStateResource,
          resourcetypeSV: changeRestypeID?.toString(),
        }));
        SetResourceDropdown(changeRestypeID, changeResID.toString());
        resourcecall(changeResID);
      }
    }
  }
  function addclick(val: any) {
    dispatch(setResourceData(initialState));
  }

  function saveclick(val: any) {
    if (props.Resourcemgmtdata.ResourceId === 0) {
      Axios.post(`${process.env.REACT_APP_API_URL}/api/resource/AddResourceManagement`, props.Resourcemgmtdata)
        .then((resourceData) => {
          console.log(resourceData);
          alert('Data added successfully');
        })
        .catch((err) => {
          const errorCode = 0;
          alert('Update failed');
        });
    } else if (props.Resourcemgmtdata.ResourceId > 0) {
      Axios.post(`${process.env.REACT_APP_API_URL}/api/resource/SaveResourceManagement`, props.Resourcemgmtdata)
        .then((resourceData) => {
          console.log(resourceData);
          alert('Data updated successfully');
        })
        .catch((err) => {
          const errorCode = 0;
          alert('Update failed');
        });
    }
  }

  useEffect(() => {
    const resourcetypename: LookupOption[] = getReferenceData.TitleResourceReferenceData.resourceTypes
      .map((x) => ({ key: x.resourceTypeID, value: x.name }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);
    const mediaType: LookupOption[] = getReferenceData.TitleResourceReferenceData.mediaType
      .map((x) => ({ key: x.Key, value: x.Value }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);
    const accessRights: LookupOption[] = getReferenceData.TitleResourceReferenceData.accessRight
      .map((x) => ({ key: x.Key, value: x.Value }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);
    const indexCompany: LookupOption[] = getReferenceData.TitleResourceReferenceData.indexingCompany
      .map((x) => ({ key: x.Key, value: x.Value }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);
    const resourceManager: LookupOption[] = getReferenceData.TitleResourceReferenceData.resourceManager
      .map((x) => ({ key: x.Key, value: x.Value }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);

    setStateResource((prevStateResource) => ({
      ...prevStateResource,
      resourcetype: resourcetypename,
      mediaType,
      accessRights,
      indexingCompany: indexCompany,
      resourceManager,
    }));
  }, [getReferenceData.TitleResourceReferenceData]);

  const mapBoolKey = (val: string) => {
    if (String(val).toLowerCase() === 'false' || String(val).toLowerCase() === '0' || String(val).toLowerCase() === 'null') {
      return 0;
    }
    return 1;
  };

  useEffect(() => {
    const fromdata = getResourceData.ResourceData;

    setStateResHeader((prevState) => ({
      ...prevState,
      Active: mapBoolKey(String(fromdata.active)),
      resourceId: fromdata.resourceId,
      resourceName: fromdata.resourceName,
      publishTitle: fromdata.publishResource == null ? false : fromdata.publishResource,
      publishdate: fromdata.dateOfPublication == null ? '-' : fromdata.dateOfPublication,
      resourceTypeval: fromdata.resourceTypeId,
      mediaType: fromdata.mediaTypeId,
      resourceManager: fromdata.resourceManagerId,
      peerReviewIndicator: mapBoolKey(String(fromdata.peerReviewed)),
      indexingCompany: fromdata.indexingCompanyId,
      accessRights: fromdata.accessRightID,
      createdDate: fromdata.dateCreated == null ? '-' : new Date(fromdata.dateCreated.split('T')[0]).toLocaleDateString(),
      modifiedDate: fromdata.lastModified == null ? '-' : new Date(fromdata.lastModified.split('T')[0]).toLocaleDateString(),
      revisionDate: fromdata.lastRevisiondate == null ? '-' : new Date(fromdata.lastRevisiondate.split('T')[0]).toLocaleDateString(),
      titleDocNum: fromdata.titleDocumentNumber == null ? '-' : fromdata.titleDocumentNumber,
      resourceTitle: fromdata.resourceTitle,
    }));
    // console.log(`stateResHeader: ${StateResHeader.Active}`);
  }, [getResourceData.ResourceData]);

  useEffect(() => {
    props.callback(StateResHeader);
  }, [StateResHeader]);

  return (
    <>
      <Grid
        container
        spacing={2}
        style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
      >
        <Grid item xs={12} style={{ textAlign: 'left' }}>
          <Typography className={classes.heading} variant="overline">
            Resource Management
          </Typography>
        </Grid>
        <Grid item xs={3}>
          <div className="custom_singledropdown">
            <Dropdown
              labelText="Resource Type"
              id="resourceTypeId"
              options={getResourceTypeDropdownOptions(StateResource.resourcetype)}
              value={StateResource.resourcetypeSV}
              keyName="resourceTypeId"
              onChangeFunction={(value: string, key: number) => setFieldValue(value, key)}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custom_autocomplete">
            {/* <Dropdown
                labelText="Resources"
                id="resourceId"
                options={StateResource.resource}
                value={StateResource.resourceSV}
                keyName="resourceId"
                onChangeFunction={(value: string, key: number) => onResourceChange(value, key)}
              /> */}
            <Typedown
              isLoading={false}
              label="Resources"
              options={StateResource.resource}
              selectedValue={StateResource.resourceSV}
              // onChange={(options) => { changeFilter('uniformtitle', options as unknown as TypedownOption[]); }}
              onChange={(Options) => { onResourceChange(Options.value, +Options.id); }}
              // onInputChange={(datav) => {
                  // setStateResHeader({
                  //   ...StateResHeader,
                  //   resourceTitle: datav,
                  // });
              // }}

            />
          </div>
        </Grid>
        <Grid item xs={2} />
        <Grid item xs={4}>
          <div className={classes.searchbarContainer}>
            <div className={classes.searchbarInput}>
              {/* <Searchbar isLoading={props.isLoading}  /> */}
              <InputBase
                onChange={handleChangeSearchTerm}
                placeholder="Search resource name"
                classes={{
                  root: classes.inputRoot,
                  // input: classes.inputInput,
                }}
                value={searchTerm}
                inputProps={{ 'aria-label': 'search' }}
              />

              <IconButton type="button" onClick={navigateToSearchPage}>
                <SearchIcon />
              </IconButton>

            </div>
            <Button
              onClick={(e: any) => { addclick(e); }}
              color="primary"
              variant="contained"
            >
              Add
            </Button>
          </div>
        </Grid>

        <Grid item xs={12}>
          <Divider />
        </Grid>
      </Grid>
      <Grid
        container
        spacing={2}
        style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
      >
        <Grid item xs={10}>
          <div className={classes.notification}>
            <h6 className={classes.typo}>
              {StateResHeader.resourceTitle}
            </h6>
          </div>
          <div className={classes.cardheader}>
            <span className={classes.Lgroup}>
              <span className={classes.Lname}>Title ID:</span>
              <span>{StateResHeader.resourceId}</span>
            </span>
            <span className={classes.Lgroup}>
              <span className={classes.Lname}>Resource ID:</span>
              <span>{StateResHeader.resourceName}</span>
            </span>
            <span className={classes.Lgroup}>
              <span className={classes.Lname}>Resource Number:</span>
              <span>{StateResHeader.titleDocNum}</span>
            </span>
            <span className={classes.Lgroup}>
              <span className={classes.Lname}>Late Revision Date:</span>
              <span>{StateResHeader.revisionDate}</span>
            </span>
            <span className={classes.Lgroup}>
              <span className={classes.Lname}>Date Last Modified:</span>
              <span>{StateResHeader.modifiedDate}</span>
            </span>
            <span className={classes.Lgroup}>
              <span className={classes.Lname}> Date Created:</span>
              <span>{StateResHeader.createdDate}</span>
            </span>
          </div>
        </Grid>
        <Grid item xs={2}>
          <Button
            onClick={(e: any) => { saveclick(e); }}
            variant="contained"
            color="primary"
            className={classes.success}
          >
            Save
          </Button>
        </Grid>
      </Grid>
      <Grid
        container
        spacing={2}
        style={{ paddingLeft: 20, paddingRight: 20, marginTop: 20 }}
      >
        <Grid item xs={3}>
          <div className="custom_singledropdown">
            <Dropdown
              labelText="Active"
              id="key"
              options={getResourceTypeDropdownOptions(booleanValues)}
              keyName="Active"
              value={StateResHeader.Active}
              onChangeFunction={(key: number, value: number) => {
                setStateResHeader({
                  ...StateResHeader,
                  Active: value,
                });
                // props.callback(StateResHeader);
              }}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custominput">
            <TextInputField
              keyName="ResourceId"
              labelText="Resource ID"
              value={StateResHeader.resourceName}
              onChangeFunction={(e: React.FormEvent<HTMLInputElement>) => {
                setStateResHeader({
                  ...StateResHeader,
                  resourceName: e.currentTarget.value,
                });
              }}
              error={false}
            />
          </div>
        </Grid>
        <Grid item xs={4}>
          <div className="switch_container">
            <SwitchField
              labelText="Publish Title"
              checked={StateResHeader.publishTitle}
              onChange={() => {
                const confirmBox = window.confirm(
                  'Do you really want to Change this?',
                );
                if (confirmBox === true) {
                  // console.log('working');
                  setStateResHeader((prevState) => ({
                    ...prevState,
                    publishTitle: !StateResHeader.publishTitle,
                  }));
                  // props.callback(StateResHeader);
                }
              }}
              name="publishtitle"
              oneLine
            />
            <span className="published_label">
              (Published on
              {' '}
              {StateResHeader.publishdate}
              )
            </span>
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custom_singledropdown">
            <Dropdown
              labelText="Resource Type"
              id="resourceTypeIdHrd"
              options={getResourceTypeDropdownOptions(StateResource.resourcetype)}
              keyName="resourceTypeIdHrd"
              value={StateResHeader.resourceTypeval}
              // onChangeFunction={(key: number, value:string) => onChangeSetStateVal(key, value)}
              onChangeFunction={(key: number, value: number) => {
                setStateResHeader({
                  ...StateResHeader,
                  resourceTypeval: value,
                });
                //  props.callback(StateResHeader);
              }}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custom_singledropdown">
            <Dropdown
              labelText="Media Type"
              isReadOnly
              id="MediaTypeId"
              options={StateResource.mediaType.map((o) => ({ display: o.value, value: o.key }))}
              keyName="MediaTypeId"
              value={StateResHeader.mediaType}
              // onChangeFunction={(key: number, value:string) => onChangeSetStateVal(key, value)}
              onChangeFunction={(key: number, value: number) => {
                setStateResHeader({
                  ...StateResHeader,
                  mediaType: value,
                });
                //  props.callback(StateResHeader);
              }}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custom_singledropdown">
            <Dropdown
              labelText="Resource Manager"
              id="ResmngrId"
              options={getResourceTypeDropdownOptions(StateResource.resourceManager)}
              keyName="ResmngrId"
              value={StateResHeader.resourceManager}
              onChangeFunction={(key: number, value: number) => {
                setStateResHeader({
                  ...StateResHeader,
                  resourceManager: value,
                });
                //  props.callback(StateResHeader);
              }}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custom_singledropdown">
            <Dropdown
              labelText="Peer Reviewed Indicator"
              id="PeerReviewIndicatorid"
              options={getResourceTypeDropdownOptions(booleanValues)}
              keyName="PeerReviewIndicatorid"
              value={StateResHeader.peerReviewIndicator}
              onChangeFunction={(key: number, value: number) => {
                setStateResHeader({
                  ...StateResHeader,
                  peerReviewIndicator: value,
                });
                //  props.callback(StateResHeader);
              }}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custom_singledropdown">
            <Dropdown
              labelText="Indexing Company"
              id="IndexingCompanyId"
              options={getResourceTypeDropdownOptions(StateResource.indexingCompany)}
              keyName="IndexingCompanyId"
              value={StateResHeader.indexingCompany}
              onChangeFunction={(key: number, value: number) => {
                setStateResHeader({
                  ...StateResHeader,
                  indexingCompany: value,
                });
                //   props.callback(StateResHeader);
              }}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custom_singledropdown">
            <Dropdown
              labelText="Access Rights"
              id="AccessRightsID"
              options={getResourceTypeDropdownOptions(StateResource.accessRights)}
              keyName="AccessRightsID"
              value={StateResHeader.accessRights}
              onChangeFunction={(key: number, value: number) => {
                setStateResHeader({
                  ...StateResHeader,
                  accessRights: value,
                });
                //  props.callback(StateResHeader);
              }}
            />
          </div>
        </Grid>
      </Grid>
    </>
  );
};

export default ResourcemgmtHeader;
