import React from 'react';
import { withStyles, makeStyles, createStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Menu, { MenuProps } from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import ListItemText from '@material-ui/core/ListItemText';
import PublishIcon from '@material-ui/icons/Publish';

interface SaveAndSubmitButtonProps {
  options: string[];
  submitFunction: Function;
}

const useStyles = makeStyles(() => createStyles({
  saveButton: {
    borderRadius: '50px',
    margin: 5,
  },
}));

const StyledMenu = withStyles({
  paper: {
    border: '1px solid #d3d4d5',
  },
})((props: MenuProps) => (
  <Menu
    elevation={0}
    getContentAnchorEl={null}
    anchorOrigin={{
      vertical: 'bottom',
      horizontal: 'center',
    }}
    transformOrigin={{
      vertical: 'top',
      horizontal: 'center',
    }}
    {...props}
  />
));

const StyledMenuItem = withStyles((theme) => ({
  root: {
    '&:focus': {
      backgroundColor: theme.palette.primary.main,
      '& .MuiListItemIcon-root, & .MuiListItemText-primary': {
        color: theme.palette.common.white,
      },
    },
  },
}))(MenuItem);

// function validateAndCallSubmit(validateFunction: Function) {
//   // Validate the form before doing anything by checking the response of the validate form method (if the object is empty then the form is valid)
//   validateFunction()
//     .then((result: any) => {
//       if (Object.keys(result).length === 0) {
//         console.log('Validation successful');
//       } else {
//         const element: Element = document.getElementsByClassName('Mui-error')[0];
//         element.scrollIntoView();
//       }
//     });
// }

export default function SaveAndSubmitButton(props: SaveAndSubmitButtonProps): JSX.Element {
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <>
      <Button
        aria-controls="customized-menu"
        aria-haspopup="true"
        variant="contained"
        color="primary"
        size="small"
        className={classes.saveButton}
        onClick={handleClick}
        startIcon={<PublishIcon />}
      >
        Save & Submit
      </Button>
      <StyledMenu
        id="customized-menu"
        anchorEl={anchorEl}
        keepMounted
        open={Boolean(anchorEl)}
        onClose={handleClose}
      >
        {props.options.map((option) => (
          <StyledMenuItem>
            <ListItemText
              primary={option}
              onClick={() => {
                props.submitFunction(option);
                handleClose();
              }}
            />
          </StyledMenuItem>
        ))}
      </StyledMenu>
    </>
  );
}
