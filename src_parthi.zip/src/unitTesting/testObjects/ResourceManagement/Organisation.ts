import faker from 'faker';
import Organisation from '../../../interfaces/ResourceManagement/Organisation';

const obj = (): Organisation => ({
  hubSpotOrgId: faker.random.number(),
  organisationId: faker.random.number(),
  organisationName: faker.company.companyName(),
  organisationWebsite: 'https://www.google.com',
});

export default obj;
