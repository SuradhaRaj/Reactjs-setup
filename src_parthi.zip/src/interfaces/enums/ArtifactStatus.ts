enum ArtifactStatus {
  NotPublished = 1,
  Withdrawn = 2,
  Published = 3,
  Expired = 4,
}

export default ArtifactStatus;
