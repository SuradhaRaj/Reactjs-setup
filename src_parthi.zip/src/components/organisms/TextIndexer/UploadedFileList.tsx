import React from 'react';
import {
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Divider,
  Typography,
  ListItemIcon,
  CircularProgress,
  makeStyles,
  Theme,
  createStyles,
  Tooltip,
} from '@material-ui/core';
import RemoveIcon from '@material-ui/icons/HighlightOff';
import ErrorIcon from '@material-ui/icons/Error';
import TickIcon from '@material-ui/icons/CheckCircle';
import Scrollbars from 'react-custom-scrollbars';
import UploadedFile from '../../../interfaces/TextIndexer/UploadedFile';
import FileUploadStatus from '../../../interfaces/enums/FileUploadStatus';
import LoadingButton from '../../molecules/LoadingButton';
import SmallChip from '../../molecules/SmallChip';

const useStyles = makeStyles((theme: Theme) => createStyles({
  SubmitButton: {
    width: 170,
    marginTop: theme.spacing(1),
    alignSelf: 'right',
  },
  VerifiedSecondaryText: {
    float: 'right',
    marginRight: theme.spacing(1),
  },
  ErrorChip: {
    color: theme.palette.secondary.main,
    background: '#ffcccc',
  },
  List: {
    marginRight: theme.spacing(2),
    marginBottom: 0,
    height: 275,
  },
  FileCount: {
    marginRight: theme.spacing(2),
    marginBottom: theme.spacing(1),
  },
  Tooltip: {
    whiteSpace: 'pre-line',
  },
}));

interface UploadedFileListItemProps {
  file: UploadedFile;
  removeFile(): void;
};

export const UploadedFileListItem = (props: UploadedFileListItemProps) => {
  const classes = useStyles();

  const getIcon = () => {
    switch (props.file.status) {
      case FileUploadStatus.Valid:
        return (
          <TickIcon
            style={{ color: 'green' }}
          />
        );
      case FileUploadStatus.Invalid:
        return (
          <ErrorIcon
            color="secondary"
          />
        );
      default:
        return (
          <CircularProgress
            disableShrink
            size={24}
          />
        );
    };
  };

  const isDisabled = () => (
    props.file.status !== FileUploadStatus.Invalid
    && props.file.status !== FileUploadStatus.Valid
  );

  const getSecondaryText = () => {
    switch (props.file.status) {
      case FileUploadStatus.Invalid:
        return (
          <Tooltip
            arrow
            title={(
              <div className={classes.Tooltip}>
                {props.file.errorMessages.join('\n')}
              </div>
            )}
            placement="top"
          >
            <div>
              <SmallChip
                variant="outlined"
                size="medium"
                className={classes.ErrorChip}
                label={props.file.errorMessages.length !== 1
                  ? `${props.file.errorMessages.length} Errors`
                  : '1 Error'}
              />
            </div>
          </Tooltip>
        );
      case FileUploadStatus.Valid:
        if (props.file.filetype === 'pdf') {
          return `${props.file.pageCount} page${props.file.pageCount === 1 ? '' : 's'}`;
        }
        return 'Valid HTML File';
      default:
        return 'Verifying...';
    }
  };

  return (
    <>
      <Divider variant="fullWidth" component="li" />
      <ListItem dense disableGutters>
        <ListItemIcon>
          {getIcon()}
        </ListItemIcon>
        <ListItemText
          primary={props.file.name}
          secondaryTypographyProps={{
            display: 'inline',
            className: classes.VerifiedSecondaryText,
          }}
          secondary={getSecondaryText()}
        />
        <ListItemSecondaryAction>
          {props.file.isDeleting ? (
            <CircularProgress size={24} />
          ) : (
            <IconButton
              edge="end"
              onClick={props.removeFile}
              disabled={isDisabled()}
            >
              <RemoveIcon />
            </IconButton>
          )}
        </ListItemSecondaryAction>
      </ListItem>
    </>
  );
};

interface UploadedFileListProps {
  files: UploadedFile[];
  removeFile(fileName: string): void;
  disabled: boolean;
  submitFiles(): void;
  submitting: boolean;
  maxFiles: number;
}

const UploadedFileList = (props: UploadedFileListProps) => {
  const classes = useStyles();

  const getFileCountMessage = () => {
    if (props.files.length === props.maxFiles) {
      return `Max number of files (${props.maxFiles}) reached`;
    }
    if (props.files.length > props.maxFiles) {
      return `Max number of files exceeded by ${props.files.length - props.maxFiles}`;
    }
    return `${props.files.length} file${props.files.length === 1 ? '' : 's'}`;
  };

  return (
    <>
      {props.files.length === 0
        ? (
          <Typography>No files added</Typography>
        )
        : (
          <>
            <Typography
              variant="body1"
              align="right"
              className={classes.FileCount}
            >
              {getFileCountMessage()}
            </Typography>
            <Scrollbars
              autoHeight
              autoHeightMax={275}
              autoHeightMin={0}
            >
              <List dense disablePadding className={classes.List}>
                {props.files.map((file) => (
                  <UploadedFileListItem
                    file={file}
                    removeFile={() => props.removeFile(file.name)}
                  />
                ))}
              </List>
            </Scrollbars>
            <div style={{ textAlign: 'right' }}>
              <LoadingButton
                onClick={props.submitFiles}
                disabled={props.disabled || props.submitting}
                variant="contained"
                color="primary"
                isLoading={props.submitting}
                className={classes.SubmitButton}
              >
                {props.files.length === 1 ? 'Submit File' : 'Submit Files'}
              </LoadingButton>
            </div>
          </>
        )}
    </>
  );
};

export default UploadedFileList;
