import React from 'react';
import { mount } from 'enzyme';
import ContactList, { noContactsMessage, ContactListItem } from '../../../components/organisms/Organisation/ContactList';
import RuntypeErrorPaper from '../../../components/organisms/RuntypeError';

jest.mock('notistack', () => ({
  useSnackbar: () => ({
    enqueueSnackbar: jest.fn(),
  }),
}));

describe('Contact List', () => {
  it('should show an appropriate message when no contacts are available', () => {
    const wrapper = mount(
      <ContactList
        organisationId={1}
        handleContactsChange={() => undefined}
        contactRoleTypeLookup={[]}
        contacts={[]}
      />,
    );

    expect(wrapper.text().includes(noContactsMessage)).toBeTruthy();
    expect(wrapper.find(ContactListItem).length).toBeFalsy();
  });

  it('should show the correct number of contacts', () => {
    const wrapper = mount(
      <ContactList
        organisationId={1}
        handleContactsChange={() => undefined}
        contactRoleTypeLookup={[]}
        contacts={[
          {
            hubSpotId: 0,
            contactId: 1,
            roles: [
              {
                name: 'test role',
                contactRoleId: 1,
                isCRM: false,
              },
            ],
            firstName: 'Peter',
            surname: 'John',
            email: null,
            homePhone: null,
            workPhone: null,
            title: null,
            address: null,
            suburb: null,
            country: null,
            state: null,
            postcode: null,
          },
          {
            hubSpotId: 0,
            contactId: 2,
            roles: [
              {
                name: 'test role',
                contactRoleId: 1,
                isCRM: false,
              },
            ],
            firstName: 'Peter2',
            surname: 'John2',
            email: null,
            homePhone: null,
            workPhone: null,
            title: null,
            address: null,
            suburb: null,
            country: null,
            state: null,
            postcode: null,
          },
        ]}
      />,
    );

    expect(wrapper.find(ContactListItem).length).toBe(2);
    expect(wrapper.find(RuntypeErrorPaper).length).toBeFalsy();
  });

  it('should render invalid contacts correctly', () => {
    const wrapper = mount(
      <ContactList
        organisationId={1}
        handleContactsChange={() => undefined}
        contactRoleTypeLookup={[]}
        contacts={[
          {
            hubSpotId: 0,
            contactId: 1,
            roles: [
              {
                name: 'test role',
                contactRoleId: 1,
                isCRM: false,
              },
            ],
            firstName: 'Peter',
            surname: 'John',
            email: null,
            homePhone: null,
            workPhone: null,
            title: null,
            address: null,
            suburb: null,
            country: null,
            state: null,
            postcode: null,
          },
          {
            hubSpotId: 0,
            contactId: -1,
            roles: [],
            firstName: 'InvalidContactFName',
            surname: 'InvalidContactLName',
            email: null,
            homePhone: null,
            workPhone: null,
            title: null,
            address: null,
            suburb: null,
            country: null,
            state: null,
            postcode: null,
          },
        ]}
      />,
    );

    expect(wrapper.find(ContactListItem).length).toBe(1);
    expect(wrapper.find(RuntypeErrorPaper).length).toBe(1);
    expect(wrapper.find(ContactListItem).text().includes('Peter')).toBeTruthy();
  });
});
