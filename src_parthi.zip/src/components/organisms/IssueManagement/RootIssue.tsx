import {
  Paper, makeStyles, Theme, createStyles, Button, Divider, Tabs, Tab, Grid, Typography,
} from '@material-ui/core';
import React, { useState, useEffect } from 'react';
import { useFormik } from 'formik';
import { useSnackbar } from 'notistack';
import Axios from 'axios';
import { useParams } from 'react-router';

import { useHistory } from 'react-router-dom';
import RootIssueForm, { RootIssueFormik } from './RootIssueForm';
import Issue from '../../../interfaces/IssueManagement/Issue';
import IssueResponse from '../../../interfaces/IssueManagement/IssueResponse';
import IssueValidationSchema from '../../../validationSchemas/IssueValidationSchema';
import LoadingButton from '../../molecules/LoadingButton';
import DateExtensions from '../../../utils/DateExtensions';
import UpdateIssueResponse, { UpdateIssueResponseValidator } from '../../../interfaces/IssueManagement/UpdateIssueResponse';
import TabPanel from '../ResourceManagement/Tabs/TabPanel';
import SmallChip from '../../molecules/SmallChip';
import { useTypedSelector } from '../../../store/store';
import IssueAdminTab from './IssueAdminTab';
import IssueDeliverTab from './IssueDeliverTab';
import ConfirmationDialog from '../../molecules/ConfirmationDialog';

const useStyles = makeStyles((theme: Theme) => createStyles({
  paper: {
    padding: theme.spacing(4),
    position: 'relative',
    paddingBottom: 0,
    marginTop: theme.spacing(4),
  },
  button: {
    borderRadius: 50,
    margin: 5,
  },
  backButton: {

  },
  divider: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(2),
  },
  buttonGroup: {
    position: 'absolute',
    top: theme.spacing(4),
    right: theme.spacing(4),
  },
  row: {
    display: 'flex',
  },
  titleRow: {
    alignItems: 'baseline',
    marginBottom: theme.spacing(2),
  },
  grouping: {
    fontSize: '0.85rem',
    fontWeight: 600,
    marginRight: theme.spacing(4),
    left: theme.spacing(4),
  },
  workflowStatus: {
    marginLeft: theme.spacing(2),
  },
}));

// Manage buttons
const ButtonGroup = (props: {
    readonly: boolean;
    dirty: boolean;
    isSubmitting: boolean;
    onEditIssue: Function;
    onDeleteIssue: Function;
    onBack: Function;
    onDiscardChanges: Function;
    onSaveIssue: Function;

}) => {
  const classes = useStyles();

  return (
    <>
      {props.readonly && (
        <Button
          className={classes.button}
          color="primary"
          type="button"
          variant="contained"
          data-testid="edit"
          onClick={() => { props.onEditIssue(); }}
        >
          Edit
        </Button>

      )}
      {props.readonly && (
      <Button
        className={classes.button}
        color="primary"
        type="button"
        variant="contained"
        data-testid="delete"
        onClick={() => { props.onDeleteIssue(); }}
      >
        Delete
      </Button>

      )}
      {!props.readonly && (
        <>
          {!props.dirty && (
          <Button variant="outlined" color="primary" onClick={() => { props.onBack(); }} className={classes.button}>back</Button>
          )}
          {props.dirty && (
          <>
            <Button className={classes.button} color="primary" variant="outlined" onClick={() => { props.onDiscardChanges(); }}>Discard Changes</Button>
            <LoadingButton color="primary" className={classes.button} data-testid="save" variant="contained" onClick={() => { props.onSaveIssue(); }} isLoading={props.isSubmitting}>Save</LoadingButton>
          </>
          )}
        </>
      )}
    </>
  );
};

// root of Issue  page
interface State {
    formFilterValue: string;
    readonly: boolean;
    isSubmitting: boolean;
    activeTab: number;
    backTo: number;
    showConfirmationDialog: boolean;
}

interface Props {
    data: IssueResponse;
    isLoading: boolean;
    updateIssue(issue: Issue): void;
}

const RootIssue = (props: Props) => {
  // get tab index and display tab accordingly.
  const TAB_NUMBER_LIMIT_FROM_URL = 3;
  const urlParams = useParams<{ tabIndex?: string }>();
  const tabIndexString = urlParams.tabIndex;
  let tabIndex: number = !Number.isNaN(Number(tabIndexString)) ? Number(tabIndexString) : 0;
  tabIndex = tabIndex < TAB_NUMBER_LIMIT_FROM_URL ? tabIndex : 0;// only 3 tabs in the issue page.
  const history = useHistory();

  const classes = useStyles();
  const [state, setState] = useState<State>({
    formFilterValue: '',
    readonly: true,
    isSubmitting: false,
    activeTab: tabIndex,
    // activeTab: 1,
    backTo: 0,
    showConfirmationDialog: false,
  });
  const snackbar = useSnackbar();
  const referenceData = useTypedSelector((store) => store.IssueReferenceData.IssueReferenceData);

  const issue: Issue = props.data.issue;
  const formik: RootIssueFormik = useFormik<Issue>({
    initialValues: {
      ...issue,
      // first we need to convert the response iso date strings to yyy-mm-dd format
      scheduleDate: DateExtensions.convertDateToFormFormat(issue.scheduleDate),
      issueHardCopyRcvdDate: DateExtensions.convertDateToFormFormat(issue.issueHardCopyRcvdDate),
      issueHardCopySentDate: DateExtensions.convertDateToFormFormat(issue.issueHardCopySentDate),
    },
    onSubmit: (values) => { console.error(values); },
    validationSchema: IssueValidationSchema,
    validateOnBlur: true,
    validateOnChange: true,
    enableReinitialize: true,
  });

  // patch
  useEffect(() => {
    /* [workaround] only update issueIndexingStatusId in form will not set  right value in field with API response's issueIndexingStatusId.
             * this code will force update issueIndexingStatusId field with API response's issueIndexingStatusId with when issue changed.
             */
    formik.setFieldValue('issueIndexingStatusId', issue.issueIndexingStatusId);
  }, [issue]);

  const saveIssue = () => {
    formik.validateForm().then((error) => {
      if (Object.keys(error).length === 0) {
        setState((prevState) => ({ ...prevState, isSubmitting: true }));

        Axios.patch<UpdateIssueResponse>(`${process.env.REACT_APP_API_URL}/api/issue`, { issue: formik.values }).then(({ data }) => {
          props.updateIssue(data.issue);
          if (UpdateIssueResponseValidator.guard(data)) {
            snackbar.enqueueSnackbar('Saved Successfully', { variant: 'success' });
          } else {
            snackbar.enqueueSnackbar('Saved successfully', { variant: 'warning' });
          }
          setState((prevState) => ({ ...prevState, readonly: true }));
        }).catch((remoteError) => {
          snackbar.enqueueSnackbar(`Unable to save issue, Error:${remoteError.response.data.messages.join()}`, { variant: 'error' });
        })
          .finally(() => {
            setState((prevState) => ({ ...prevState, isSubmitting: false }));
          });
      }
    });
  };

  const deleteIssue = () => {
    Axios.post(`${process.env.REACT_APP_API_URL}/api/issue/delete/${issue.issueId}`)
      .then(() => {
        snackbar.enqueueSnackbar('Issue deleted successfully.', {
          variant: 'success',
        });
        setState((prevState) => ({ ...prevState, readonly: true }));
      }).catch((remoteError) => {
        snackbar.enqueueSnackbar(`Unable to delete issue, Error:${remoteError.response.data.messages.join()}`, { variant: 'error' });
      })
      .finally(() => {
        setState((prevState) => ({ ...prevState, isSubmitting: false }));
      });

    if (history.length) {
      history.goBack();
    } else {
      history.push('/');
    }
  };

  const toggleConfirmationDialog = (open: boolean) => {
    setState((prevState) => ({ ...prevState, showConfirmationDialog: open }));
  };

  const handleConfirmationButtonClick = () => {
    toggleConfirmationDialog(true);
  };

  const handleConfirmationResponse = (shouldProceed: boolean) => {
    toggleConfirmationDialog(false);
    if (shouldProceed) deleteIssue();
  };

  const discardChanges = () => {
    window.location.reload();
    formik.resetForm();
  };

    interface Handles {
        customFunction: () => void;
    }
    const notesIssueManagementRef: React.RefObject<Handles> = React.useRef<Handles>() as React.RefObject<Handles>;

    const editIssue = () => {
      state.backTo = state.activeTab;
      setState({ ...state, readonly: false, activeTab: 0 });
    };
    const loadUpdateIssue = () => {
      formik.setFieldValue('issueIndexingStatusId', referenceData.issueWorkflowStates.find((x) => x.value === 'Problems see notes')?.key);
      editIssue();
      setTimeout(() => {
        if (notesIssueManagementRef.current) {
          notesIssueManagementRef.current.customFunction();
        }
      }, 1);
    };

    const back = () => {
      setState((prevState) => ({ ...prevState, readonly: true, activeTab: state.backTo }));
    };

    const handleChangeTab = (event: React.ChangeEvent<{}>, newValue: number) => {
      setState((prevState) => ({ ...prevState, activeTab: newValue }));

      if (newValue === 1) {
        // formik.values.re
      }
    };

    return (
      <>
        {!props.isLoading && (
        <>
          <Paper className={classes.paper}>
            <Grid container className={classes.titleRow}>
              <Grid item xs={12}>
                <div className={classes.buttonGroup}>

                  <ButtonGroup
                    readonly={state.readonly}
                    dirty={formik.dirty}
                    isSubmitting={state.isSubmitting}
                    onEditIssue={editIssue}
                    onBack={back}
                    onDiscardChanges={discardChanges}
                    onSaveIssue={saveIssue}
                    onDeleteIssue={handleConfirmationButtonClick}
                  />
                  <ConfirmationDialog
                    dialogTitle="Are you sure you want to delete this issue?"
                    dialogBodyText="This issue may have related articles. If you continue with deleting the issue,
                    you will lose all issue related data. "
                    onProceed={() => handleConfirmationResponse(true)}
                    onReturn={() => handleConfirmationResponse(false)}
                    isOpen={state.showConfirmationDialog}
                    successButtonText="Continue"
                  />
                </div>
              </Grid>
            </Grid>

            <Grid container className={classes.titleRow}>
              <Grid item xs={12}>
                <Grid container>
                  <Grid item xs={12} className={classes.row}>
                    <Typography className={classes.grouping}>{issue.grouping}</Typography>
                    <SmallChip className={classes.workflowStatus} label={referenceData.issueWorkflowStates.find((x) => x.key === issue.workflowStatusId)?.value ?? 'Unknown'} />

                  </Grid>
                </Grid>
                <Divider className={classes.divider} />
              </Grid>
            </Grid>

            <TabPanel value={state.activeTab} index={0}>
              <RootIssueForm
                formik={formik}
                filterValue={state.formFilterValue}
                readonly={state.readonly}
                ref={notesIssueManagementRef}
              />
            </TabPanel>
            <TabPanel value={state.activeTab} index={1}>
              <IssueDeliverTab issue={issue} isReplace={false} updateIssue={props.updateIssue} />
            </TabPanel>
            {' '}
            <TabPanel value={state.activeTab} index={2}>
              <IssueAdminTab issue={issue} />
            </TabPanel>

            <Divider className={classes.divider} />

            <Grid
              justify="space-between" // Add it here :)
              container
            >
              <Grid item>
                <Tabs value={state.activeTab} onChange={handleChangeTab}>
                  <Tab label="Issue" />
                  <Tab label="Deliver" />
                  <Tab label="Workflow & Admin" />
                </Tabs>
              </Grid>
              {state.activeTab === 1 && (
              <Grid item>
                <Button
                  key="Review"
                  size="small"
                  color="primary"
                  variant="contained"
                  className={classes.button}
                  onClick={() => { loadUpdateIssue(); }}
                >
                  Review
                </Button>
                {' '}

              </Grid>
              )}
            </Grid>

          </Paper>
        </>
        )}

      </>
    );
};

export default RootIssue;
