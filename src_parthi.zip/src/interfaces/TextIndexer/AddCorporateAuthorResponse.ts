import {
  Record, String, Static,
} from 'runtypes';
import { NumberGreaterZero } from '../../runtypeTypes';

export const AddCorporateAuthorResponseValidator = Record({
  corporateName: String,
  corporateAuthorId: NumberGreaterZero,
  status: NumberGreaterZero,
});

type AddCorporateAuthorResponse = Static<typeof AddCorporateAuthorResponseValidator>;
export default AddCorporateAuthorResponse;
