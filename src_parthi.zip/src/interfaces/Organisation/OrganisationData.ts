import {
  Record, Static, Number, String, Boolean, Null,
} from 'runtypes';

export const OrganisationDataValidator = Record({
  organisationId: Number,
  hubSpotId: Number,
  organisationName: String,
  organisationDepartment: String.Or(Null),
  organisationCode: String.Or(Null),
  organisationType: String.Or(Null),
  rcti: Boolean.Or(Null),
  organisationAbn: String.Or(Null),
  organisationGstStatus: String.Or(Null),
  organisationStreetAddress: String.Or(Null),
  organisationSuburb: String.Or(Null),
  organisationState: String.Or(Null),
  organisationPostcode: String.Or(Null),
  organisationCountry: String.Or(Null),
  organisationPhone: String.Or(Null),
  organisationFax: String.Or(Null),
  organisationEmail: String.Or(Null),
  organisationWebAddress: String.Or(Null),
  organisationActivityDescription: String.Or(Null),
  isPublisher: Boolean.Or(Null),
  isSubscriber: Boolean.Or(Null),
});

type OrganisationData = Static<typeof OrganisationDataValidator>;

export default OrganisationData;
