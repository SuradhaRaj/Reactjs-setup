import React, { useState, useEffect, useContext } from 'react';
import {
  makeStyles, createStyles, Theme, InputBase, Paper, IconButton, Popper, Grow, MenuList, MenuItem,
} from '@material-ui/core';

import SearchIcon from '@material-ui/icons/Search';
import { withRouter } from 'react-router-dom';
import Typography from '@material-ui/core/Typography';
import ClickAwayListener from '@material-ui/core/ClickAwayListener';
import Divider from '@material-ui/core/Divider';
import { useDispatch } from 'react-redux';
import SmallChip from './SmallChip';
import { useTypedSelector } from '../../store/store';
import { updateSearchFilters } from '../../store/actions/ActnSearch';
import SearchFilters from '../../classes/SearchFilters';
import SearchRoleHelper from '../../utils/SearchRoleHelper';
import { AppContext } from '../Context';
import ArtifactSearchIndex, { ArtifactSearchIndexNameMapping } from '../../interfaces/enums/ArtifactSearchIndex';

const useStyles = makeStyles((theme: Theme) => createStyles({
  menuButton: {
    marginRight: theme.spacing(2),
  },
  title: {
    flexGrow: 1,
  },
  root: {
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    // backgroundColor: fade(theme.palette.common.white, 0.15),
    // '&:hover': {
    //   backgroundColor: fade(theme.palette.common.white, 0.25),
    // },
    marginRight: theme.spacing(2),
    marginLeft: 0,
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing(3),
      width: 'auto',
    },
    display: 'flex',
    height: 36,
    alignItems: 'center',
  },
  divider: {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(1),
    height: 24,
  },
  searchIcon: {
    width: theme.spacing(7),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#00000059',
    zIndex: 1,
  },
  inputRoot: {
    color: 'inherit',
  },
  inputInput: {
    padding: theme.spacing(1, 1, 1, 1),
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('md')]: {
      width: 200,
      background: 'white',
      borderRadius: 50, // Was previously 4 when a rectangular box
      color: 'black',
      '&:focus': {
        width: 500,
      },
    },
  },
  searchDropdown: {
    position: 'absolute',
    top: 60,
    left: 0,
    background: '#fff',
    color: '#000',
    padding: theme.spacing(2),
    display: 'flex',
    cursor: 'pointer',
  },
  typography: {
    display: 'inline-block',
  },
  indexSelector: {
    '&:focus': { outline: 'none' },
  },
}));

const IndexSelector = (props: {indexes: ArtifactSearchIndex[]}) => {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const anchorRef = React.useRef<HTMLButtonElement>(null);
  const searchFilters = useTypedSelector((store) => store.Search.filters);
  const dispatch = useDispatch();
  const options = props.indexes.map((index) => ({ label: ArtifactSearchIndexNameMapping[index], value: index }));

  const handleMenuItemClick = (
    event: React.MouseEvent<HTMLLIElement, MouseEvent>,
    index: number,
  ) => {
    const item = options[index];
    const filters = searchFilters.updateFilter('index', item.value);
    dispatch(updateSearchFilters(filters));

    setOpen(false);
    event.stopPropagation();
  };

  const handleToggle = () => {
    if (options.length === 1) {
      return;
    }

    setOpen((prevOpen) => !prevOpen);
  };

  const handleClose = (event: React.MouseEvent<Document, MouseEvent>) => {
    if (anchorRef.current && anchorRef.current.contains(event.target as HTMLElement)) {
      return;
    }

    setOpen(false);
  };

  return (
    <IconButton className={classes.indexSelector} type="button" onClick={handleToggle} ref={anchorRef}>
      <SmallChip label={options.find((item) => item.value === searchFilters.data.index)?.label.toUpperCase()} />
      <Popper open={open} anchorEl={anchorRef.current} role={undefined} transition>
        {({ TransitionProps, placement }) => (
          <Grow
            {...TransitionProps}
            style={{
              transformOrigin: placement === 'bottom' ? 'center top' : 'center bottom',
            }}
          >
            <Paper>
              <ClickAwayListener onClickAway={handleClose}>
                <MenuList id="split-button-menu">
                  {options.map((option, index) => (
                    <MenuItem
                      key={option.value}
                      selected={option.value === searchFilters.data.index}
                      onClick={(event) => handleMenuItemClick(event, index)}
                    >
                      {option.label}
                    </MenuItem>
                  ))}
                </MenuList>
              </ClickAwayListener>
            </Paper>
          </Grow>
        )}
      </Popper>
    </IconButton>
  );
};

export default withRouter(({ history }) => {
  const classes = useStyles();
  const [showDropdown, setShowDropdown] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const searchFilters = useTypedSelector((store) => store.Search.filters);
  const dispatch = useDispatch();
  const context = useContext(AppContext);
  const availableIndexes = SearchRoleHelper.getAvailableIndexes(context.userInfo);

  useEffect(() => {
    setSearchTerm(searchFilters.data.text);
  }, [searchFilters]);

  useEffect(() => {
    const filters = SearchFilters.empty();
    filters.updateFilter('index', SearchRoleHelper.getInitialIndex(context.userInfo));
    dispatch(updateSearchFilters(filters));
  }, [context.userInfo]);

  function navigateToSearchPage() {
    const filters = searchFilters.updateFilter('text', searchTerm);
    dispatch(updateSearchFilters(filters));

    const query = new URLSearchParams('');
    query.set('q', searchFilters.getQueryString());
    history.push(`/search?${query.toString()}`);
    setShowDropdown(false);
  }

  function handleSubmit(event: React.KeyboardEvent<HTMLDivElement>): void {
    if (searchTerm.trim().length > 0) {
      setShowDropdown(true);
    } else {
      setShowDropdown(false);
    }

    if (event.key === 'Enter' && searchTerm.trim().length > 0) {
      navigateToSearchPage();
    }
  }

  function handleChangeSearchTerm(event: React.ChangeEvent<HTMLInputElement>) {
    setSearchTerm(event.target.value);
    if (event.target.value.trim().length > 0) {
      setShowDropdown(true);
    } else {
      setShowDropdown(false);
    }
  }

  // if you can't search, you can't search
  if (availableIndexes.length === 0) {
    return (<></>);
  }

  return (
    <ClickAwayListener onClickAway={() => setShowDropdown(false)}>
      <Paper className={classes.root}>
        <IndexSelector indexes={availableIndexes} />
        <Divider orientation="vertical" className={classes.divider} />
        <InputBase
          onKeyPress={handleSubmit}
          onChange={handleChangeSearchTerm}
          placeholder="Search..."
          classes={{
            root: classes.inputRoot,
            input: classes.inputInput,
          }}
          value={searchTerm}
          inputProps={{ 'aria-label': 'search' }}
        />
        <IconButton type="button" onClick={navigateToSearchPage}>
          <SearchIcon />
        </IconButton>
        {showDropdown && (
          <Paper className={classes.searchDropdown} onClick={navigateToSearchPage}>
            <SearchIcon />
            <Typography className={classes.typography} noWrap>
              Search for
              <span style={{ fontWeight: 'bold' }}>
                {' '}
                {searchTerm}
              </span>
            </Typography>
          </Paper>
        )}
      </Paper>
    </ClickAwayListener>
  );
});
