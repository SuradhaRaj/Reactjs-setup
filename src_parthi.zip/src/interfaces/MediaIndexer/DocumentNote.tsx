import {
  Record, String, Static,
} from 'runtypes';
import NoteCreatorType from '../enums/NoteCreatorType';

export const CosmosDocumentNoteValidator = Record({
  note: String,
  createdBy: String,
  createdDate: String,
});

type DocumentNote = Static<typeof CosmosDocumentNoteValidator> & { noteType?: NoteCreatorType };

export default DocumentNote;
