import React, { useEffect } from 'react';
import { useMsal } from '@azure/msal-react';
import { IPublicClientApplication } from '@azure/msal-browser';
import { loginRequest } from '../authConfig';

function handleLogin(instance: IPublicClientApplication) {
  instance.loginRedirect(loginRequest).catch((e) => {
    console.error(e);
  });
}

/**
 * Renders a button which, when selected, will open a popup for login
 */
export default function Autologin() {
  const { instance } = useMsal();
  useEffect(() => {
    if (window.location.href.indexOf('/Signout') < 0) {
      const indexofsign = window.location.href.indexOf('/Signout');
      localStorage.setItem('debugger', indexofsign.toString());
      handleLogin(instance);
    }
  });
  return (
    <h1>Redirecting to Azure login..</h1>
  );
}
