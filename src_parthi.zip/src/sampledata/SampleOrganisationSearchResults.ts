import OrganisationSearchResult from '../interfaces/Search/OrganisationSearchResult';

const SampleOrganisationSearchResults: OrganisationSearchResult[] = [
  {
    id: 1,
    name: 'Wiza, Huels and Simonis',
    code: '',
    searchIndex: 4,
    address: null,
    primaryContact: '',
    numberOfTitles: '5',
  }, {
    id: 3,
    name: 'Kozey Group',
    code: '',
    searchIndex: 4,
    address: null,
    primaryContact: '',
    numberOfTitles: '8',
  },
];

export default SampleOrganisationSearchResults;
