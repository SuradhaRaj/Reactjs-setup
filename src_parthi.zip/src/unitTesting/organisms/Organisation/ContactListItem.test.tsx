import React from 'react';
import { mount } from 'enzyme';
import { ContactListItem } from '../../../components/organisms/Organisation/ContactList';
import ContactRolesDialog from '../../../components/organisms/ContactRolesDialog';

jest.mock('notistack', () => ({
  useSnackbar: () => ({
    enqueueSnackbar: jest.fn(),
  }),
}));

const wrapper = mount(
  <ContactListItem
    organisationId={1}
    handleContactChange={() => undefined}
    contactRoleTypeLookup={[]}
    contact={
      {
        hubSpotId: 0,
        contactId: 1,
        roles: [
          {
            name: 'test role',
            contactRoleId: 1,
            isCRM: false,
          },
        ],
        firstName: 'Peter',
        surname: 'John',
        email: null,
        homePhone: null,
        workPhone: null,
        title: 'Mr',
        address: null,
        suburb: null,
        country: null,
        state: null,
        postcode: null,
      }
    }
  />,
);

describe('Contact List Item', () => {
  it('should render the contact', () => {
    expect(wrapper.text().includes('Mr Peter John')).toBeTruthy();
    expect(wrapper.text().includes('test role')).toBeTruthy();
  });

  it('should open the role dialog after the edit button is clicked', () => {
    // simulate button click
    wrapper.find('#edit-roles').at(1).simulate('click');
    expect(wrapper.find(ContactRolesDialog).prop('open')).toBeTruthy();
  });
});
