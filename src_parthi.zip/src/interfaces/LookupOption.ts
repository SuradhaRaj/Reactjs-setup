import {
  Record, Number, String, Static, Runtype,
} from 'runtypes';

interface LookIOption {
  key: number;
  value: string;
}

export const LookupOptionValidator: Runtype<LookIOption> = Record({
  key: Number.withConstraint((n) => n > 0),
  value: String,
});

type LookupOption = Static<typeof LookupOptionValidator>;
export default LookupOption;
