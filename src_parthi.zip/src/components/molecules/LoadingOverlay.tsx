import React from 'react';
import { createStyles, makeStyles } from '@material-ui/core/styles';
import { CircularProgress } from '@material-ui/core';

const useStyles = makeStyles(() => createStyles({
  root: {
    position: 'fixed',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    cursor: 'not-allowed',
    zIndex: 10000,
    display: 'flex',
    justifyContent: 'center',
  },
  spinner: {
    alignSelf: 'center',
  },
}));

const LoadingOverlay = (): JSX.Element => {
  const classes = useStyles();
  return (<div className={classes.root}><CircularProgress className={classes.spinner} /></div>);
};

export default LoadingOverlay;
