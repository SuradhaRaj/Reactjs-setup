import {
  Static, Record,
  // Array,
} from 'runtypes';
import { IssueValidator } from './Issue';
// import { NumberGreaterZero } from '../../runtypeTypes';
// import { OrganisationContactValidator } from '../Organisation/OrganisationContact';

export const IssueResponseValidator = Record({
  issue: IssueValidator,

});

type IssueResponse = Static<typeof IssueResponseValidator>;
export default IssueResponse;
