/* eslint-disable max-len */
import React from 'react';
import {
  Paper, Grid, makeStyles, createStyles, Theme, Typography, Badge, Divider,
} from '@material-ui/core';
import { useHistory } from 'react-router-dom';
// import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import Axios, { AxiosResponse } from 'axios';
import { useSnackbar } from 'notistack';
import { Static } from 'runtypes';
import Splitter from '../organisms/Splitter';
import IssueData, { IssueDataValidator } from '../../interfaces/TextIndexer/IssueData';
import RuntypeErrorPaper from '../organisms/RuntypeError';
import StickyNotification from '../molecules/StickyNotification';
import { MetadataItem } from '../Shared/MetadataItem';
import SmallChip from '../molecules/SmallChip';
import DialogWithCustomContent from '../molecules/DialogWithCustomContent';
import { FileValidator } from '../../interfaces/TextIndexer/IssueArtifact';
import DownloadFilesList from '../organisms/TextIndexer/DownloadFilesList';
import TitleWithSecondaryText from '../molecules/TitleWithSecondaryText';
import ExtraRequest from '../../interfaces/TextIndexer/ExtraRequest';

const useStyles = makeStyles((theme: Theme) => createStyles({
  paper: {
    padding: theme.spacing(4),
    position: 'relative',
  },
  notesGroup: {
    position: 'absolute',
    top: 5,
    right: 8,
  },
  chip: {
    marginLeft: theme.spacing(1),
  },
  divider: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(2),
  },
  row: {
    marginBottom: theme.spacing(2),
  },
  roundButton: {
    borderRadius: 50,
  },
}));

interface Props {
  artifact: IssueData;
}

interface State {
    publisherDialogOpen: boolean;
    extraFiles: Static<typeof FileValidator>[];
}

export default (props: Props): JSX.Element => {
  const classes = useStyles();
  const history = useHistory();
  const info = props.artifact.info;
  const [state, setState] = React.useState<State>({
    publisherDialogOpen: false,
    extraFiles: [],
  });
  const { enqueueSnackbar } = useSnackbar();

  const issuePath = `${props.artifact.info.resourceId}\\${props.artifact.info.grouping}`;

  React.useEffect(() => {
    Axios.get<ExtraRequest[]>(`${process.env.REACT_APP_API_URL}/api/issue/getextrafiles?IssuePath=${issuePath}`).then((extraResponse: AxiosResponse<ExtraRequest[]>) => {
      const newDownloadExtraFiles: Static<typeof FileValidator>[] = [];
      extraResponse.data.forEach((file) => {
        newDownloadExtraFiles.push({
          filename: file.filename,
          size: file.fileSize,
          date: '',
          isExisted: true, // this field is not used in this page.
        });
      });

      setState({
        ...state,
        extraFiles: newDownloadExtraFiles,
      });
    });
  }, []);

  const onUpdateNotes = (notes: string) => {
    Axios.post(`${process.env.REACT_APP_API_URL}/api/issue/updateissuenotes`, { issueId: props.artifact.info.publisherNote, notesForRmitPublishing: notes })
    // update the state of that file once it's uploaded
      .then(() => {
        info.publisherNote = notes;
        enqueueSnackbar('Notes saved Successfully', { variant: 'success' });
      })
      .catch(() => undefined);
  };

  try {
    IssueDataValidator.check(props.artifact);
  } catch (err) {
    return (<RuntypeErrorPaper error={err} data={props.artifact} />);
  }

  return (
    <>
      {props.artifact.isReadOnly && (
      <StickyNotification text="This artifact is not currently available to edit." />)}
      <Grid container>
        <Grid container justify="center" className={classes.row}>
          <Grid item xs={9}>
            {/* <Button startIcon={<ArrowBackIcon />} className={classes.roundButton} variant="outlined" color="primary" onClick={() => { history.goBack(); }}>Back</Button> */}
          </Grid>
        </Grid>
        <Grid container justify="center">
          <Grid item xs={9}>
            <Paper className={classes.paper}>
              <Typography variant="overline">Issue Metadata</Typography>
              <Grid container>
                <Grid item xs={4}>
                  <MetadataItem
                    title="Organisation Name"
                    value={props.artifact.info.organisationName}
                  />
                  <MetadataItem
                    title="Resource Name"
                    value={props.artifact.info.resourceName}
                  />
                  <MetadataItem
                    title="Publication Year"
                    value={props.artifact.info.publicationYear}
                  />
                </Grid>
                <Grid item xs={8}>
                  <MetadataItem
                    title="Volume Number"
                    value={props.artifact.info.volumeNumber}
                  />
                  <MetadataItem
                    title="Issue Number"
                    value={props.artifact.info.issueNumber}
                  />
                  <MetadataItem
                    title="Issue Edition"
                    value={props.artifact.info.issueEdition}
                  />
                </Grid>
              </Grid>
              <div className={classes.notesGroup}>
                {/* <Badge color="secondary" variant="dot">
                  <SmallChipDialog className={classes.chip} dialogContent="Lorem ipsum" dialogTitle="Indexer notes" label="Indexer notes" />
                </Badge> */}
                {props.artifact.info.publisherNote && (
                  <Badge color="secondary" variant="dot">
                    {/* <SmallChipDialog className={classes.chip} dialogContent={info.publisherNote} dialogTitle="Publisher notes" label="Publisher notes" /> */}
                    <SmallChip
                      className={classes.chip}
                      style={{ position: 'absolute', right: '0px' }}
                      label="Publisher Notes"
                      onClick={() => {
                        setState({
                          ...state,
                          publisherDialogOpen: !state.publisherDialogOpen,
                        });
                      }}
                    />
                    <DialogWithCustomContent
                      open={state.publisherDialogOpen}
                      title="Publisher notes"
                      cancelButtonText="Cancel"
                      confirmButtonText="Save Notes"
                      handleCloseFunction={() => {
                        setState({
                          ...state,
                          publisherDialogOpen: !state.publisherDialogOpen,
                        });
                      }}
                      handleConfirmOptionFunction={() => onUpdateNotes((document.getElementById('pubpopup') as HTMLFormElement)?.value || '')}
                      dialogContent={() => (<textarea id="pubpopup" rows={10} cols={60}>{info.publisherNote}</textarea>)}
                    />
                  </Badge>
                )}
              </div>
              <TitleWithSecondaryText
                title="Extra Files"
                secondaryText=""
              />
              <DownloadFilesList
                files={state.extraFiles}
                issuePath={issuePath}
                mode="extra"
              />
              <Divider className={classes.divider} />
              <Splitter
                handleSuccessfulCompletion={history.goBack}
                issuePath={`${props.artifact.info.resourceId}\\${props.artifact.info.grouping}`}
                issueId={props.artifact.info.issueId}
                downloadFiles={props.artifact.info.files}

                isDisabled={props.artifact.isReadOnly}
                isReplace={false}
              />
            </Paper>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};
