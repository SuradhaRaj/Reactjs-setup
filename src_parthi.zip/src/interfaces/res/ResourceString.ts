interface ResourceString {
  id: number;
  message: string;
}

export default ResourceString;
