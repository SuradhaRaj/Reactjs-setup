export default interface AddFileRequest {
  issuePath: string;
  filename: string;
  data: number[];
  issueId: number;
// eslint-disable-next-line semi
};
