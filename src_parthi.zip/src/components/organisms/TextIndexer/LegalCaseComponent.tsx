import React from 'react';
import {
  Grid, Button,
} from '@material-ui/core';
import { useSnackbar } from 'notistack';
import Axios from 'axios';
import { DateTime } from 'luxon';
import DocumentItemNode from '../../../interfaces/MediaIndexer/DocumentItemNode';
import TypedownDocumentItemNode from '../TypedownDocumentItemNode';
import AddLegalCaseRequest from '../../../interfaces/TextIndexer/AddLegalCaseRequest';
import AddLegalCaseResponse, { AddLegalCaseResponseValidator } from '../../../interfaces/TextIndexer/AddLegalCaseResponse';
import AddLegalCaseForm from './AddLegalCaseForm';

interface LegalCaseComponentProps {
  selectedLegalCases: DocumentItemNode[];
  initiallySelectedLegalCases: DocumentItemNode[];
  onChangeMultiple(data: DocumentItemNode[]): void;
  userName: string;
  disabled?: boolean;
  error?: boolean;
  errorMessage?: string | undefined;
  typedownLimit: number;
};

interface LegalCaseComponentState {
  isAddingNew: boolean;
  loading: boolean;
}

const LegalCaseComponent: React.SFC<LegalCaseComponentProps> = (props) => {
  const [state, setState] = React.useState<LegalCaseComponentState>({
    isAddingNew: false,
    loading: false,
  });

  const { enqueueSnackbar } = useSnackbar();

  const onFormCancel = () => {
    setState((prevState) => ({
      ...prevState,
      isAddingNew: false,
    }));
  };

  const onFormAdd = (requestData: AddLegalCaseRequest) => {
    setState((prevState) => ({
      ...prevState,
      loading: true,
    }));

    Axios.post<AddLegalCaseResponse>(`${process.env.REACT_APP_API_URL}/api/indexing/addnewlegalcase`, requestData)
      .then((response) => {
        AddLegalCaseResponseValidator.check(response.data);

        const newLegalCase: DocumentItemNode = {
          id: response.data.id,
          name: response.data.name,
          createdBy: props.userName,
          createdDate: DateTime.local().toString(),
        };

        props.onChangeMultiple([...props.selectedLegalCases, newLegalCase]);
        setState((prevState) => ({
          ...prevState,
          isAddingNew: false,
        }));
      })
      .catch(() => {
        enqueueSnackbar('There was an error adding the legal case', { variant: 'error' });
      })
      .finally(() => {
        setState((prevState) => ({
          ...prevState,
          loading: false,
        }));
      });
  };

  return (
    <>
      {state.isAddingNew ? (
        <AddLegalCaseForm
          loading={state.loading}
          onAdd={onFormAdd}
          onCancel={onFormCancel}
        />
      ) : (
        <Grid container>
          <Grid item xs={10}>
            <TypedownDocumentItemNode
              url={`${process.env.REACT_APP_API_URL}/api/indexing/searchlegalcases`}
              label="Legal Cases"
              selectedOptions={props.selectedLegalCases}
              initiallySelectedOptions={props.initiallySelectedLegalCases}
              onChangeMultiple={props.onChangeMultiple}
              disabled={props.disabled}
              error={props.error}
              errorMessage={props.errorMessage}
              typedownLimit={props.typedownLimit}
            />
          </Grid>
          <Grid item xs={2}>
            <Button
              onClick={() => setState((prevState) => ({ ...prevState, isAddingNew: true }))}
              disabled={props.disabled}
            >
              Add New
            </Button>
          </Grid>
        </Grid>
      )}
    </>
  );
};

export default LegalCaseComponent;
