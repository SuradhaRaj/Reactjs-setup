import React, { useEffect, useState } from 'react';
import {
  Typography,
  Grid,
  Card,
  makeStyles,
} from '@material-ui/core';
import { useTypedSelector } from '../../../store/store';
import LookupOption from '../../../interfaces/LookupOption';
import StrStrLookupOption from '../../../interfaces/StrStrLookupOption';
import Dropdown from '../../Shared/Dropdown';
import DropdownOption from '../../../interfaces/MediaIndexer/DropdownOption';

interface SalesIState {
  indexType: LookupOption[];
  productLibrary: StrStrLookupOption[];
  titleType: LookupOption[];
}
export interface SelectedOptionState {
  grouping: string[];
  publisher: string[];
  title: string[];
  id: string[];
  article: string[];
  documentNumber: string[];
  resource: string[];
  hasIndexerNotes?: boolean;
  hasPublisherNotes?: boolean;
  includeRelated?: boolean;
}

type NewType = boolean;

interface Props {
  isLoading: NewType;
}

const useStyles = makeStyles({
  resourceIdeContainer: {
    paddingBottom: '20',
  },

  heading: {
    'font-size': '13px',
    'font-weight': '500',
    'text-transform': 'none',
    color: '#000000',
  },
});

function Customerservice(props: Props): JSX.Element {
  const classes = useStyles();
  const referenceSalesData = useTypedSelector((store) => store.ResourceReferenceData);
  const [salesState, setSaleState] = useState<SalesIState>({
    indexType: [],
    productLibrary: [],
    titleType: [],
  });

  function getResourceTypeDropdownOptions(resourceType: LookupOption[]) {
    const dropdownList: DropdownOption[] = [];

    for (let i = 0; i < resourceType.length; i++) {
      dropdownList.push({ value: resourceType[i].key, display: resourceType[i].value });
    }
    return dropdownList;
  }
  useEffect(() => {
    const indexData: LookupOption[] = referenceSalesData.ResourceReferenceData.resourceIndexes
      .map((x) => ({ key: x.key, value: x.value }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);
    /* const productData: LookupOption[] = referenceSalesData.ResourceReferenceData.productLibrary
    .map((x) => ({ key: x.key, value: x.value }))
    .filter((x) => x !== null && x !== undefined)
    .filter((x) => x.value !== null); */
    const titleData: LookupOption[] = referenceSalesData.ResourceReferenceData.titleType
      .map((x) => ({ key: x.key, value: x.value }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);

    setSaleState((prevState) => ({
      ...prevState,
      indexType: indexData,
      // productLibrary: productData,
      titleType: titleData,
    }));
  }, [referenceSalesData.ResourceReferenceData]);
  return (
    <Card
      variant="outlined"
      className="resourceIdeContainer"
      style={{
        marginLeft: 20,
        marginRight: 20,
        paddingBottom: 20,
        marginTop: 20,
      }}
    >
      <Grid item xs={12} style={{ textAlign: 'left' }}>
        <Typography
          className={classes.heading}
          variant="overline"
          style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
        >
          Sales/Customer Service
        </Typography>
      </Grid>
      <Grid
        container
        spacing={2}
        style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
      >

        {/* <Grid item xs={3}>
          <div className="custom_autocomplete">
          <TypedownFilter
              isLoading={props.isLoading}
              title="Product"
              options={state.title}
              selectedOptions={referenceSalesData.Filters.data.title}
              onChange={(options) => {
                changeFilter("title", options as string[]);
              }}
            />
          </div>
        </Grid> */}
        <Grid item xs={3}>
          <div className="custom_singledropdown">
            <Dropdown
              labelText="Index Type"
              id="IndexTypeID"
              options={getResourceTypeDropdownOptions(salesState.indexType)}
              keyName="productid"
              onChangeFunction={(value: string, key: number) => key}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custom_singledropdown">
            <Dropdown
              labelText="Title Type"
              id="TitleTypeID"
              options={getResourceTypeDropdownOptions(salesState.titleType)}
              keyName="TitleTypeID"
              onChangeFunction={(value: string, key: number) => key}
            />
          </div>
        </Grid>
      </Grid>
    </Card>
  );
}

export default Customerservice;
