import {
  Static, Record,
  // Array,
} from 'runtypes';
import { IssueValidator } from './Issue';

export const UpdateIssueResponseValidator = Record({
  issue: IssueValidator,
});

type UpdateIssueResponse = Static<typeof UpdateIssueResponseValidator>;
export default UpdateIssueResponse;
