/* eslint @typescript-eslint/no-explicit-any: 0 */
import React from 'react';
import deburr from 'lodash/deburr';
import Autosuggest from 'react-autosuggest';
import match from 'autosuggest-highlight/match';
import parse from 'autosuggest-highlight/parse';
import TextField from '@material-ui/core/TextField';
import Paper from '@material-ui/core/Paper';
import MenuItem from '@material-ui/core/MenuItem';
import { createStyles, makeStyles } from '@material-ui/core/styles';

interface OptionType {
  label: string;
}

interface TypedownProps {
  labelText: string;
  inputValue: string;
  placeholderText: string;
  getSuggestionsListFunction: Function;
  onValueChangeFunction: Function;
}

// Create a context so that data can be cleanly passed to the different parts of the typedown
const TypedownContext = React.createContext({ label: '', inputValue: '', placeholder: '' });

function renderInputComponent(inputProps: any) {
  const {
    inputRef = () => undefined, ref, ...other
  } = inputProps;

  return (
    <TypedownContext.Consumer>
      { (value) => (
        <TextField
          label={value.label}
          InputProps={{
            inputRef: (node) => {
              ref(node);
              inputRef(node);
            },
          }}
          {...other}
        />
      )}
    </TypedownContext.Consumer>
  );
}

function renderSuggestion(
  suggestion: OptionType,
  { query, isHighlighted }: Autosuggest.RenderSuggestionParams,
) {
  const matches = match(suggestion.label, query);
  const parts = parse(suggestion.label, matches);

  return (
    <MenuItem selected={isHighlighted} component="div">
      <div>
        {parts.map((part) => (
          <span key={part.text} style={{ fontWeight: part.highlight ? 500 : 400 }}>
            {part.text}
          </span>
        ))}
      </div>
    </MenuItem>
  );
}

function filterResults(suggestions: OptionType[], inputLength: number, inputValue: string, count: number) {
  let filterCount: number = count;

  return inputLength <= 2
    ? []
    : suggestions.filter((suggestion) => {
      const keep = filterCount < 5 && suggestion.label.slice(0, inputLength).toLowerCase() === inputValue;

      if (keep) {
        filterCount += 1;
      }

      return keep;
    });
}

function getSuggestions(value: string, getSuggestionsListFunction: Function) {
  // Call the function that was passed into the typedown component along with the input value
  const inputValue = deburr(value.trim()).toLowerCase();

  // Return the result of the function (should be a promise with a list)
  return getSuggestionsListFunction(inputValue);
}

function getSuggestionValue(suggestion: OptionType) {
  return suggestion.label;
}

const useStyles = makeStyles((theme) => createStyles({
  root: {
    // height: 250,
    flexGrow: 1,
  },
  container: {
    position: 'relative',
  },
  suggestionsContainerOpen: {
    position: 'absolute',
    zIndex: 1,
    marginTop: theme.spacing(1),
    left: 0,
    right: 0,
  },
  suggestion: {
    display: 'block',
  },
  suggestionsList: {
    margin: 0,
    padding: 0,
    listStyleType: 'none',
  },
  divider: {
    height: theme.spacing(2),
  },
}));

export default function IntegrationAutosuggest(props: TypedownProps) {
  const classes = useStyles();
  // const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [state, setState] = React.useState({
    single: '',
    popper: '',
  });
  const [stateSuggestions, setSuggestions] = React.useState<OptionType[]>([]);

  // If there are 3 or more characters in the typedown then call the getSuggestions method
  // This will get a promise from the function passed into the component, allowing us to wait for the api to respond before moving on
  const handleSuggestionsFetchRequested = ({ value }: any) => {
    const inputValue = deburr(value.trim()).toLowerCase();
    const inputLength = inputValue.length;
    const count = 0;

    if (inputLength > 2) {
      getSuggestions(value, props.getSuggestionsListFunction)
        .then((result: Array<OptionType>) => {
          const suggestionList = filterResults(result, inputLength, inputValue, count);
          setSuggestions(suggestionList);
        });
    }
  };

  const handleSuggestionsClearRequested = () => {
    setSuggestions([]);
  };

  const handleChange = (name: keyof typeof state) => (
    event: React.ChangeEvent<{}>,
    { newValue }: Autosuggest.ChangeEvent,
  ) => {
    setState({
      ...state,
      [name]: newValue,
    });
    props.onValueChangeFunction(newValue);
  };

  const autosuggestProps = {
    renderInputComponent,
    suggestions: stateSuggestions,
    onSuggestionsFetchRequested: handleSuggestionsFetchRequested,
    onSuggestionsClearRequested: handleSuggestionsClearRequested,
    getSuggestionValue,
    renderSuggestion,
  };

  return (
    <div className={classes.root}>
      <TypedownContext.Provider value={{ label: props.labelText, inputValue: props.inputValue, placeholder: props.placeholderText }}>

        <Autosuggest
          {...autosuggestProps}
          inputProps={{
            id: 'react-autosuggest-simple',
            placeholder: props.placeholderText,
            value: state.single,
            onChange: handleChange('single'),
          }}
          theme={{
            container: classes.container,
            suggestionsContainerOpen: classes.suggestionsContainerOpen,
            suggestionsList: classes.suggestionsList,
            suggestion: classes.suggestion,
          }}
          renderSuggestionsContainer={(options) => (
            <Paper {...options.containerProps} square>
              {options.children}
            </Paper>
          )}
        />
      </TypedownContext.Provider>
    </div>
  );
}
