import React from 'react';
import {
  makeStyles, Theme, createStyles, Grid, Typography,
} from '@material-ui/core';
import SecondaryData from '../../../molecules/SecondaryData';
import Resource from '../../../../interfaces/ResourceManagement/Resource';
import { useTypedSelector } from '../../../../store/store';
import BooleanIndicatorCircle from '../../../molecules/BooleanIndicatorCircle';

interface Props {
  resource: Resource;
}

const useStyles = makeStyles((theme: Theme) => createStyles({
  tabContent: {
    '& > *': {
      display: 'inline-block',
      // width: 125,
    },
  },
  secondaryDataRow: {
    display: 'flex',
    paddingBottom: theme.spacing(2),
  },
  row: {
    display: 'flex',
  },
}));

export default (props: Props) => {
  const getManagerInitials = (managerName: string): string => managerName.split(' ').map((s) => s[0]).toString().replace(',', '');
  const classes = useStyles();
  const referenceData = useTypedSelector((store) => store.ResourceReferenceData.ResourceReferenceData);
  return (
    <>
      <Grid container>

        <Grid item xs={12} className={classes.secondaryDataRow}>
          <SecondaryData title="Type" content={referenceData.resourceTypes.find((x) => x.resourceTypeID === props.resource.resourceTypeId)?.name ?? ''} alwaysDisplay variantName="subtitle1" />
          <SecondaryData title="Publisher" content={props.resource.nameOfPublisher} alwaysDisplay variantName="subtitle1" />
          <SecondaryData title="Date Of Publication" content={props.resource.dateOfPublication} alwaysDisplay variantName="subtitle1" />
          <Typography>
            <SecondaryData title="Peer Reviewed" content="" alwaysDisplay variantName="subtitle1" />
            <Grid style={{ display: 'flex', justifyContent: 'left' }}>
              <BooleanIndicatorCircle name="Active" status={props.resource.peerReviewed} />
            </Grid>
          </Typography>
          <SecondaryData title="Manager" content="" alwaysDisplay variantName="subtitle1" initialsCol={getManagerInitials(referenceData.resourceManager.find((x) => x.Key === props.resource.resourceManagerId)?.Value ?? '')} />

        </Grid>

        <Grid item xs={12} container>
          <Grid item xs={8} container direction="column" spacing={2}>
            <Grid item xs className={classes.secondaryDataRow}>
              <SecondaryData title="ISSN" content={props.resource.issn} alwaysDisplay variantName="subtitle1" />
              <SecondaryData title="ISBN" content={props.resource.isbn} alwaysDisplay variantName="subtitle1" />
              <SecondaryData title="DOI" content={props.resource.doi} alwaysDisplay variantName="subtitle1" />

            </Grid>
            <Grid item xs className={classes.secondaryDataRow}>
              <SecondaryData title="eISSN" content={props.resource.eIssn} alwaysDisplay variantName="subtitle1" />
              <SecondaryData title="eISBN" content={props.resource.eIsbn} alwaysDisplay variantName="subtitle1" />
            </Grid>
          </Grid>
          <Grid item xs={4} style={{ textAlign: 'center' }}>
            {props.resource.imageData && (
            <img src={`data:image;base64, ${props.resource.imageData}`} alt="title cover" />
            )}
            {!props.resource.imageData && (
            <img src="assets/coverImage.png" alt=" title cover" />
            )}

          </Grid>
        </Grid>

        <Grid container style={{ paddingTop: '30px' }}>
          <Grid item xs={10} className={classes.secondaryDataRow}>
            <SecondaryData title="Abstract" content={props.resource.description} variantName="subtitle1" />
          </Grid>
          <Grid item xs={2} className={classes.row} style={{ textAlign: 'right' }}>
            <SecondaryData title="Active?" content="" alwaysDisplay variantName="subtitle1" />
            <BooleanIndicatorCircle name="Active" status={props.resource.active} />

          </Grid>
        </Grid>
        <Grid item xs={12} className={classes.secondaryDataRow}>
          <SecondaryData title="Notes" content={props.resource.notes} variantName="subtitle1" />
        </Grid>
      </Grid>

    </>
  );
};
