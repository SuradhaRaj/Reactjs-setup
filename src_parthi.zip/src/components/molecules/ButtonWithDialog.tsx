import React, { useState } from 'react';
import {
  Dialog, DialogTitle, Button, DialogActions, ButtonProps, DialogContent,
} from '@material-ui/core';

interface Props extends React.PropsWithChildren<{}> {
  buttonProps: ButtonProps;
  dialogTitle?: string;
  dialogContent(): JSX.Element;
  dialogActions(closeDialog: Function): JSX.Element;
}

export default function ButtonWithDialog(props: Props) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const closeDialog = () => {
    setDialogOpen(false);
  };

  return (
    <>
      <Button {...props.buttonProps} onClick={() => setDialogOpen(true)}>{props.children}</Button>
      <Dialog onClose={closeDialog} open={dialogOpen}>
        {props.dialogTitle && (
        <DialogTitle>{props.dialogTitle}</DialogTitle>
        )}
        <DialogContent>
          {props.dialogContent()}
        </DialogContent>
        {props.dialogActions && (
          <DialogActions>
            {props.dialogActions(closeDialog)}
          </DialogActions>
        )}
      </Dialog>
    </>
  );
}
