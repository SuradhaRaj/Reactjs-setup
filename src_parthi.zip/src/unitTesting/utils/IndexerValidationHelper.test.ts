import IndexerValidationHelper from '../../utils/IndexerValidationHelper';
import artifact from '../../sampledata/SampleMediaArtifact';

describe('Indexer validation helper - reporter title errors', () => {
  it('should return sport reporter error', () => {
    const artifactClone = { ...artifact };
    artifactClone.title = 'Sport reporter';

    const { isValid, errors } = IndexerValidationHelper.ValidateMinimumPublishReqs(artifactClone);

    expect(isValid).toBe(false);
    expect(errors).toContain(1);
  });

  it('should return finance reporter error', () => {
    const artifactClone = { ...artifact };
    artifactClone.title = 'Finance reporter';

    const { isValid, errors } = IndexerValidationHelper.ValidateMinimumPublishReqs(artifactClone);

    expect(isValid).toBe(false);
    expect(errors).toContain(2);
  });

  it('should return weather reporter error', () => {
    const artifactClone = { ...artifact };
    artifactClone.title = 'Weather reporter';

    const { isValid, errors } = IndexerValidationHelper.ValidateMinimumPublishReqs(artifactClone);

    expect(isValid).toBe(false);
    expect(errors).toContain(3);
  });

  it('should not return reporter error', () => {
    const artifactClone = { ...artifact };
    artifactClone.title = 'Weather report';

    const { errors } = IndexerValidationHelper.ValidateMinimumPublishReqs(artifactClone);

    expect(errors).not.toContain(3);
  });
});

describe('Indexer validation helper - Series No not supplied on TV Program', () => {
  it('should return error', () => {
    const artifactClone = { ...artifact };
    artifactClone.series = 0;
    artifactClone.episode = 10;
    artifactClone.resourceType = 'TV Program';
    artifactClone.resourceTypeId = 4;
    const { isValid, errors } = IndexerValidationHelper.ValidateMinimumPublishReqs(artifactClone);

    expect(isValid).toBe(false);
    expect(errors).toContain(5);
  });

  it('should not return error', () => {
    const artifactClone = { ...artifact };
    artifactClone.series = 8;
    artifactClone.episode = 10;
    artifactClone.resourceType = 'TV Program';
    artifactClone.resourceTypeId = 4;
    const { errors } = IndexerValidationHelper.ValidateMinimumPublishReqs(artifactClone);

    expect(errors).not.toContain(5);
  });
});

describe('Indexer validation helper - Episode No not supplied on TV Program', () => {
  it('should return error', () => {
    const artifactClone = { ...artifact };
    artifactClone.series = 8;
    artifactClone.episode = 0;
    artifactClone.resourceType = 'TV Program';
    artifactClone.resourceTypeId = 4;
    const { isValid, errors } = IndexerValidationHelper.ValidateMinimumPublishReqs(artifactClone);

    expect(isValid).toBe(false);
    expect(errors).toContain(6);
  });

  it('should not return error', () => {
    const artifactClone = { ...artifact };
    artifactClone.series = 8;
    artifactClone.episode = 10;
    artifactClone.resourceType = 'TV Program';
    artifactClone.resourceTypeId = 4;
    const { errors } = IndexerValidationHelper.ValidateMinimumPublishReqs(artifactClone);

    expect(errors).not.toContain(6);
  });
});

describe('Indexer validation helper - Episode and series not supplied where resource is not TV program', () => {
  it('should be valid', () => {
    const artifactClone = { ...artifact };
    artifactClone.series = 0;
    artifactClone.episode = 0;
    artifactClone.resourceType = 'Film';
    artifactClone.resourceTypeId = 1;
    const { isValid, errors } = IndexerValidationHelper.ValidateMinimumPublishReqs(artifactClone);

    expect(isValid).toBe(true);
    expect(errors).not.toContain(5);
    expect(errors).not.toContain(6);
  });
});

describe('Indexer validation helper - Episode and series supplied', () => {
  it('should be valid', () => {
    const artifactClone = { ...artifact };
    artifactClone.title = 'Sport report';
    artifactClone.episode = 1;
    artifactClone.series = 2;

    const { isValid, errors } = IndexerValidationHelper.ValidateMinimumPublishReqs(artifactClone);

    expect(isValid).toBe(true);
    expect(errors.length).toBe(0);
  });
});

describe('Indexer validation helper - Number Validator', () => {
  it('should be valid', () => {
    const isValid = IndexerValidationHelper.ValidateWholeNumber('1');

    expect(isValid).toBe(true);
  });

  it('should be valid - zero', () => {
    const isValid = IndexerValidationHelper.ValidateWholeNumber('0');

    expect(isValid).toBe(true);
  });

  it('should be invalid - contains letter e', () => {
    const isValid = IndexerValidationHelper.ValidateWholeNumber('1e10');

    expect(isValid).toBe(false);
  });

  it('should be invalid - negative number', () => {
    const isValid = IndexerValidationHelper.ValidateWholeNumber('-1');

    expect(isValid).toBe(false);
  });

  it('should be invalid - decimal number', () => {
    const isValid = IndexerValidationHelper.ValidateWholeNumber('1.0');

    expect(isValid).toBe(false);
  });

  it('should be invalid - two decimals', () => {
    const isValid = IndexerValidationHelper.ValidateWholeNumber('1.0.0');

    expect(isValid).toBe(false);
  });
});

describe('Indexer validation helper - Number Range Validator', () => {
  it('should be valid', () => {
    const isValid = IndexerValidationHelper.ValidateWholeNumberInRange('1', 0, 100);

    expect(isValid).toBe(true);
  });

  it('should be valid - zero', () => {
    const isValid = IndexerValidationHelper.ValidateWholeNumberInRange('0', 0, 100);

    expect(isValid).toBe(true);
  });

  it('should be invalid - contains letter e', () => {
    const isValid = IndexerValidationHelper.ValidateWholeNumberInRange('1e10', 0, 100);

    expect(isValid).toBe(false);
  });

  it('should be invalid - negative number', () => {
    const isValid = IndexerValidationHelper.ValidateWholeNumberInRange('-1', 0, 100);

    expect(isValid).toBe(false);
  });

  it('should be invalid - decimal number', () => {
    const isValid = IndexerValidationHelper.ValidateWholeNumberInRange('1.0', 0, 100);

    expect(isValid).toBe(false);
  });

  it('should be invalid - two decimals', () => {
    const isValid = IndexerValidationHelper.ValidateWholeNumberInRange('1.0.0', 0, 100);

    expect(isValid).toBe(false);
  });

  it('should be invalid - two decimals', () => {
    const isValid = IndexerValidationHelper.ValidateWholeNumberInRange('1.0.0', 0, 100);

    expect(isValid).toBe(false);
  });

  it('should be invalid - less than min', () => {
    const isValid = IndexerValidationHelper.ValidateWholeNumberInRange('1', 10, 100);

    expect(isValid).toBe(false);
  });

  it('should be invalid - greater than max', () => {
    const isValid = IndexerValidationHelper.ValidateWholeNumberInRange('11', 0, 10);

    expect(isValid).toBe(false);
  });
});

describe('Indexer validation helper - Series No', () => {
  it('should be valid', () => {
    const artifactClone = { ...artifact };
    artifactClone.title = 'Sport report';
    artifactClone.episode = 1;
    artifactClone.series = 2;

    const { isValid, errors } = IndexerValidationHelper.ValidateMinimumPublishReqs(artifactClone);

    expect(isValid).toBe(true);
    expect(errors.length).toBe(0);
  });
});
