import React from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, Button, Typography, ButtonProps,
} from '@material-ui/core';

interface Props {
  dialogTitle: string;
  dialogBodyText: string | JSX.Element;
  onProceed(): void;
  onReturn(): void;
  isOpen: boolean;
  successButtonText?: string;
  rejectButtonText?: string;
  successButtonProps?: Omit<ButtonProps, 'onClick'>;
  rejectButtonProps?: Omit<ButtonProps, 'onClick'>;
}

const ConfirmationDialog: React.FC<Props> = (props) => (
  <Dialog
    open={props.isOpen}
    keepMounted
    aria-labelledby="alert-dialog-slide-title"
    aria-describedby="alert-dialog-slide-description"
  >
    <DialogTitle id="alert-dialog-slide-title">{props.dialogTitle}</DialogTitle>
    <DialogContent>
      <DialogContentText id="alert-dialog-slide-description">
        {(typeof props.dialogBodyText === 'string') ? (<Typography>{props.dialogBodyText}</Typography>) : props.dialogBodyText}
      </DialogContentText>
    </DialogContent>
    <DialogActions>
      <Button onClick={props.onReturn} variant="outlined" color="primary" {...props.rejectButtonProps}>
        {props.rejectButtonText}
      </Button>
      <Button onClick={props.onProceed} variant="text" color="primary" {...props.successButtonProps}>
        {props.successButtonText}
      </Button>
    </DialogActions>
  </Dialog>
);

ConfirmationDialog.defaultProps = {
  successButtonText: 'Confirm',
  rejectButtonText: 'Return',
};

export default ConfirmationDialog;
