import StringExtensions from '../../utils/StringExtensions';

describe('String extensions - Strip HTML', () => {
  it('should remove tags', () => {
    const stringWithHtml = '<div>here is some <strong>html</strong></div>';
    const expectedResult = 'here is some html';

    const actualResult = StringExtensions.CleanHtmlString(stringWithHtml);

    expect(actualResult).toBe(expectedResult);
  });

  it('should remove script and image tags', () => {
    const stringWithHtml = '<div>here is some <script>alert()</script> html<img src=""/></div>';
    const expectedResult = 'here is some alert() html';

    const actualResult = StringExtensions.CleanHtmlString(stringWithHtml);

    expect(actualResult).toBe(expectedResult);
  });

  it('should decode encoded characters', () => {
    const stringWithHtml = '<div>here is some &quot;</div>';
    const expectedResult = 'here is some "';

    const actualResult = StringExtensions.CleanHtmlString(stringWithHtml);

    expect(actualResult).toBe(expectedResult);
  });

  it('should remove encoded html characters', () => {
    const stringWithHtml = 'of that&lt;br /&gt;&lt;br /&gt; Sorting scammers';
    const expectedResult = 'of that Sorting scammers';

    const actualResult = StringExtensions.CleanHtmlString(stringWithHtml);

    expect(actualResult).toBe(expectedResult);
  });
});
