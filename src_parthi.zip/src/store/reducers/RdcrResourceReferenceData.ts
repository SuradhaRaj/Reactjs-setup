import {
  ActionTypes, UPDATE_RESOURCE_REFERENCE_DATA,
} from '../actions/ActnResourceReferenceData';
import ResourceReferenceData from '../../interfaces/ResourceManagement/ResourceReferenceData';

export interface ResourceReferenceDataState {
  ResourceReferenceData: ResourceReferenceData;
}

export const initialState: ResourceReferenceDataState = {
  ResourceReferenceData: {
    broadSubjectLookup: [],
    contentType: [],
    descriptionType: [],
    fileType: [],
    frequency: [],
    indexingCompany: [],
    languages: [],
    mediaType: [],
    resourceManager: [],
    resourceTypes: [],
    titleType: [],
    resourceIndexes: [],
    seriesTitles: [],
    uniformTitles: [],
    resourceWorkflowStates: [],
    contactRoleType: [],
    accessRight: [],
    indexType: [],
    productLibrary: [],
    clearedBy: [],
    countryOfPublicationMarc: [],
    cclicenceType: [],
    accessType: [],
    clearanceStatus: [],
    royaltyOrganisation: [],
    resourceslookup: [],
    fasttermLookup: [],
    fastGeoLookup: [],
    subjectLC: [],
    identifierlookup: [],
  },
};

export default (state = initialState, action: ActionTypes): ResourceReferenceDataState => {
  switch (action.type) {
    case UPDATE_RESOURCE_REFERENCE_DATA:
      return {
        ...state,
        ResourceReferenceData: action.payload,
      };

    default:
      return state;
  }
};
