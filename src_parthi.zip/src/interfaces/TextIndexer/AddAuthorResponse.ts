import {
  Record, Number, String, Null, Static,
} from 'runtypes';
import { NumberGreaterZero } from '../../runtypeTypes';

export const AddAuthorResponseValidator = Record({
  authorId: Number.withConstraint((n) => n > 0),
  firstName: String,
  middleName: String.Or(Null),
  lastName: String,
  orcidCode: String.Or(Null),
  status: NumberGreaterZero,
});

type AddAuthorResponse = Static<typeof AddAuthorResponseValidator>;
export default AddAuthorResponse;
