import React, { useContext } from 'react';
import {
  Grid, Theme, createStyles,
} from '@material-ui/core';
import Axios from 'axios';
import { useLocation } from 'react-router-dom';
import { makeStyles } from '@material-ui/styles';
import { useDispatch } from 'react-redux';
import ErrorPaper from '../organisms/ErrorPaper';
import SearchResults from '../organisms/Search/SearchResults';
import SearchResult from '../../interfaces/Search/SearchResult';
import LoadingButton from '../molecules/LoadingButton';
import { updateSearchResults, updateSearchItem, updateSearchFilters } from '../../store/actions/ActnSearch';
import { useTypedSelector } from '../../store/store';
import SearchFilters from '../../classes/SearchFilters';
import SearchRoleHelper from '../../utils/SearchRoleHelper';
import { AppContext } from '../Context';
import ArtifactSearchIndex from '../../interfaces/enums/ArtifactSearchIndex';

const useStyles = makeStyles((theme: Theme) => createStyles({
  loadMoreRoot: {
    marginTop: theme.spacing(2),
    textAlign: 'center',
  },
}));

interface SearchPageState {
  isError: boolean;
  isLoading: boolean;
  isLoadingMore: boolean;

  page: number;
}

export default function Search() {
  const [state, setState] = React.useState<SearchPageState>({
    isError: false,
    isLoading: true,
    isLoadingMore: false,
    page: 1,
  });

  const classes = useStyles();
  const location = useLocation();
  const context = useContext(AppContext);

  const dispatch = useDispatch();
  const searchStore = useTypedSelector((store) => store.Search);

  const updateItem = (item: SearchResult): void => {
    dispatch(updateSearchItem(item));
  };

  const performSearch = (q: string, callback?: Function) => {
    Axios.get(`${process.env.REACT_APP_API_URL}/api/search?`, { params: { q } })
      .then((response) => {
        setState((prevState) => ({
          ...prevState,
          isLoading: false,
          isError: false,
        }));

        dispatch(updateSearchResults(response.data.results));

        if (callback != null) {
          callback();
        }
      })
      .catch(() => {
        setState((prevState) => ({
          ...prevState,
          isLoading: false,
          isError: true,
        }));
      });
  };

  const loadMore = () => {
    if (searchStore.filters.getQueryString() !== '') {
      setState((prevState) => ({
        ...prevState,
        isLoadingMore: true,
      }));

      const query = JSON.stringify({ ...searchStore.filters.getQueryObject(), pageNumber: state.page + 1 });
      performSearch(query, () => {
        setState((prevState) => ({
          ...prevState,
          page: prevState.page + 1,
          isLoadingMore: false,
        }));
      });
    }
  };

  React.useEffect(() => {
    const query = new URLSearchParams(location.search);
    const searchQuery = query.get('q');

    if (searchQuery != null) {
      setState((prevState) => ({
        ...prevState,
        isLoading: true,
      }));

      const newSearch = JSON.parse(searchQuery);
      const filters = new SearchFilters(newSearch);
      if (filters.data.index === ArtifactSearchIndex.All) {
        filters.updateFilter('index', SearchRoleHelper.getInitialIndex(context.userInfo));
      }
      dispatch(updateSearchFilters(filters));
      performSearch(searchQuery);
    }
  }, [location]); // does not re-render if the search term is the same

  return (
    <>
      {!state.isError ? (
        <>
          <Grid item xl={6} xs={11}>
            <SearchResults results={searchStore.results} isLoading={state.isLoading} updateItem={updateItem} />
          </Grid>
          {!state.isLoading && searchStore.results.length > 0 && (
          <Grid item xs={12} className={classes.loadMoreRoot}>
            <LoadingButton variant="contained" onClick={loadMore} isLoading={state.isLoadingMore}>Load more</LoadingButton>
          </Grid>
          )}
        </>
      ) : (
        <ErrorPaper
          text="Unable to retrieve search results"
        />
      )}
    </>
  );
}
