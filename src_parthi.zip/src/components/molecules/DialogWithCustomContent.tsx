import React from 'react';
import {
  Dialog, useTheme, useMediaQuery, DialogTitle, DialogContent, DialogActions, Button,
} from '@material-ui/core';

interface DialogBoxProps {
  open: boolean;
  title: string;
  dialogContent(): JSX.Element;
  handleCloseFunction: Function;
  handleConfirmOptionFunction: Function;
  cancelButtonText: string;
  confirmButtonText: string;
}

export default function DialogWithCustomContent(props: DialogBoxProps): JSX.Element {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));

  return (
    <Dialog
      fullScreen={fullScreen}
      open={props.open}
      onClose={() => props.handleCloseFunction()}
      aria-labelledby="responsive-dialog-title"
    >
      <DialogTitle id="responsive-dialog-title">{props.title}</DialogTitle>
      <DialogContent>
        {props.dialogContent()}
      </DialogContent>
      <DialogActions>
        <Button variant="outlined" onClick={() => props.handleCloseFunction()} color="primary">
          {props.cancelButtonText}
        </Button>
        <Button onClick={() => props.handleConfirmOptionFunction()} color="primary">
          {props.confirmButtonText}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
