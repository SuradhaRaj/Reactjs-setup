import * as Yup from 'yup';
import { DateTime } from 'luxon';
import TextResourceTypes from '../interfaces/enums/TextResourceTypes';
import DocumentFastNode from '../interfaces/MediaIndexer/DocumentFastNode';
import DocumentNodeStateEnum from '../interfaces/MediaIndexer/DocumentNodeStateEnum';

// const IssueIndexingSchema = Yup.object().shape({
//   publicationYear: Yup.number().required(),
//   grouping: Yup.string().required(),
//   volumeNumber: Yup.string().required(),
//   issueNumber: Yup.string().required(),
// });

// eslint-disable-next-line max-len
const FindSelectedDocumentFastNodes = (array: DocumentFastNode[]): number => array.filter((x) => x.state === DocumentNodeStateEnum.UserAdded || x.state === DocumentNodeStateEnum.UserVerified).length;

export const ArtifactIndexingSchema = Yup.object().shape({
  title: Yup.string().transform((x) => (x === null ? '' : x)).test('is-valid', 'You must enter a valid title', (value: string) => value.trim().length > 0 && value.toLowerCase() !== 'blank record').required(),
  pagination: Yup.string().transform((x) => (x === null ? '' : x))
    .test('pagination-is-required', 'Pagination or eLocation must be provided',
      function paginationValidation(value: string): boolean {
        return !((this.resolve(Yup.ref('eLocation')) === undefined || this.resolve(Yup.ref('eLocation')).toString().trim().length === 0) && (value === undefined || value.trim().length < 1));
      }),
  eLocation: Yup.string().transform((x) => (x === null ? '' : x))
    .test('elocation-is-required', 'Pagination or eLocation must be provided',
      function elocationValidation(value: string): boolean {
        return !((this.resolve(Yup.ref('pagination')) === undefined || this.resolve(Yup.ref('pagination')).toString().trim().length === 0) && (value === undefined || value.trim().length < 1));
      }),
  fPage: Yup.string().transform((x) => (x === null ? '' : x))
    .test('fpage-is-required', 'First Page is required',
      function fpageValidation(value): boolean {
        if (this.resolve(Yup.ref('pagination')) !== undefined && this.resolve(Yup.ref('pagination')).toString().trim().length > 0) {
          return value.toString().trim().length > 0;
        }
        return true;
      }),
  lPage: Yup.string().transform((x) => (x === null ? '' : x))
    // .test('lpage-less-than-fpage', 'Last Page can not be less than First Page',
    //   function lPageFpage(value): boolean {
    //     return !(value < this.resolve(Yup.ref('fPage')));
    //   })
    .test('lpage-is-required', 'Last Page is required',
      function lpageValidation(value): boolean {
        if (this.resolve(Yup.ref('pagination')) !== undefined && this.resolve(Yup.ref('pagination')).toString().trim().length > 0) {
          return value.toString().trim().length > 0;
        }
        return true;
      }),
  description: Yup.string().transform((x) => (x === null ? '' : x))
    .when(['isMinor', 'resourceTypeId'], {
      is: (isMinor, resourceTypeId) => !isMinor
      && (resourceTypeId === TextResourceTypes.MonographBookChapter
        || resourceTypeId === TextResourceTypes.OtherBookTypeBookChapter
        || resourceTypeId === TextResourceTypes.ConferenceConferencePaper
        || resourceTypeId === TextResourceTypes.JournalJournalArticle),
      then: Yup.string().required('Description is required'),
      otherwise: Yup.string().notRequired(),
    }),
  descriptionTypeId: Yup.number()
    .when(['description'], {
      is: (description) => description !== undefined && description?.trim().length > 0,
      then: Yup.number().transform((x) => (Number.isNaN(x) ? 0 : x)).positive('Description type is a required field'),
      otherwise: Yup.number().notRequired(),
    }),
  languages: Yup.array().required(),
  // resourceType: Yup.string().transform((x) => (x === null ? '' : x)).required('Resource type is a required field'),
  resourceTypeId: Yup.number().transform((x) => (Number.isNaN(x) ? 0 : x)).positive('Resource type is a required field'),
  articlePPVPrice: Yup.number().nullable().min(0, 'PPV Price must be a number that is 0 or greater').typeError('PPV Price must be a number'),
  fast: Yup.array()
    .when('isMinor', {
      is: true,
      then: Yup.array().test('Text FAST validation', 'No FAST Terms can be selected when Value Type is Minor',
        (valueList: DocumentFastNode[]) => FindSelectedDocumentFastNodes(valueList) === 0),
    }),
  fastGeo: Yup.array()
    .when('isMinor', {
      is: true,
      then: Yup.array().test('Text FAST Geo validation', 'No FAST Geolocations can be selected when Value Type is Minor',
        (valueList: DocumentFastNode[]) => FindSelectedDocumentFastNodes(valueList) === 0),
    }),
  identifiers: Yup.array()
    .when(['isMinor'], {
      is: true,
      then: Yup.array().max(0, 'No Identifiers can be selected when Value Type is Minor'),
    }),
  articlePublishDate: Yup.string().nullable().test('articlePublishDate', 'Date must be in the format "YYYY-MM-DD", and cannot be in the future.', (value: string) => {
    if (value === null || value.trim().length === 0) {
      return true;
    }

    const date = DateTime.fromISO(value);
    const CURRENT_YEAR = DateTime.local().year;
    const CURRENT_MONTH = DateTime.local().month;

    if (!date.isValid) { return false; }
    if (date.year < 1800 || date.year > CURRENT_YEAR) { return false; }
    if (date.year < 1800 || date.year > CURRENT_YEAR) { return false; }
    if (date.year === CURRENT_YEAR && date.month > CURRENT_MONTH) { return false; }
    if (date.diffNow().years > 0) { return false; }
    return true;
  }),
});

export const AdvancedIndexingSchema = Yup.object().shape({
  fast: Yup.array()
    .when('resourceTypeId', {
      is: TextResourceTypes.MonographBookChapter || TextResourceTypes.OtherBookTypeBookChapter
        || TextResourceTypes.ConferenceConferencePaper || TextResourceTypes.JournalJournalArticle,
      then: Yup.array().min(1),
      otherwise: Yup.array().notRequired(),
    }),
});

export const LegalIndexingSchema = Yup.object().shape({
  aglibsSubjects: Yup.array()
    .when(['isMinor'], {
      is: true,
      then: Yup.array().max(0, 'No AGLIBS Subjects can be selected when Value Type is Minor'),
    })
    .when(['isMinor', 'resourceTypeId'], {
      is: (isMinor, resourceTypeId) => !isMinor
      && (resourceTypeId === TextResourceTypes.MonographBookChapter
        || resourceTypeId === TextResourceTypes.OtherBookTypeBookChapter
        || resourceTypeId === TextResourceTypes.ConferenceConferencePaper
        || resourceTypeId === TextResourceTypes.JournalJournalArticle),
      then: Yup.array().min(1),
    }),
  jurisdiction: Yup.array()
    .when(['isMinor'], {
      is: true,
      then: Yup.array().max(0, 'No Jurisdiction can be selected when Value Type is Minor'),
    })
    .when(['isMinor', 'resourceTypeId'], {
      is: (isMinor, resourceTypeId) => !isMinor
      && (resourceTypeId === TextResourceTypes.MonographBookChapter
        || resourceTypeId === TextResourceTypes.OtherBookTypeBookChapter
        || resourceTypeId === TextResourceTypes.ConferenceConferencePaper
        || resourceTypeId === TextResourceTypes.JournalJournalArticle),
      then: Yup.array().min(1),
    }),
  legislation: Yup.array()
    .when(['isMinor'], {
      is: true,
      then: Yup.array().max(0, 'No Legislation can be selected when Value Type is Minor'),
    }),
  legalCase: Yup.array()
    .when(['isMinor'], {
      is: true,
      then: Yup.array().max(0, 'No Legal Cases can be selected when Value Type is Minor'),
    }),
  treaty: Yup.array()
    .when(['isMinor'], {
      is: true,
      then: Yup.array().max(0, 'No Treaties can be selected when Value Type is Minor'),
    }),
});
