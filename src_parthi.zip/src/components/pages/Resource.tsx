import React, { useState } from 'react';
import {
  makeStyles, createStyles,
  Grid, Theme, Breadcrumbs, Link, Typography,
} from '@material-ui/core';

import { useParams } from 'react-router-dom';
import Axios from 'axios';
import { useDispatch } from 'react-redux';
import RootResource from '../organisms/ResourceManagement/RootResource';
import { default as ResourceType } from '../../interfaces/ResourceManagement/Resource';
import { updateTextReferenceData } from '../../store/actions/ActnResourceReferenceData';
import ResourceReferenceData, { ResourceReferenceDataValidator } from '../../interfaces/ResourceManagement/ResourceReferenceData';
import ResourceResponse, { ResourceResponseValidator } from '../../interfaces/ResourceManagement/ResourceResponse';
import ErrorPaper from '../organisms/ErrorPaper';
import ResourceList from '../organisms/ResourceManagement/ResourceList';
import OrganisationContact from '../../interfaces/Organisation/OrganisationContact';
import useRuntypeError from '../hooks/useRuntypeError';

interface State {
    isLoading: boolean;
    hasError: boolean;
    data: ResourceResponse;
    errorCode: number;
}

export default function Resource() {
  const { resId } = useParams();

  const dispatch = useDispatch();
  const referenceDataValidator = useRuntypeError(ResourceReferenceDataValidator);
  const resourceValidator = useRuntypeError(ResourceResponseValidator);

  const useStyles = makeStyles((theme: Theme) => createStyles({
    nav: {
      position: 'absolute',
      top: theme.spacing(-6),
      left: theme.spacing(2),
    },
  }));
  const classes = useStyles();

  const [state, setState] = useState<State>({
    isLoading: true,
    hasError: false,
    data: {} as ResourceResponse,
    errorCode: 0,
  });

  React.useEffect(() => {
    const resourceRequest = Axios.get<ResourceResponse>(`${process.env.REACT_APP_API_URL}/api/resource/${resId}`);
    const referenceDataRequest = Axios.get<ResourceReferenceData>(`${process.env.REACT_APP_API_URL}/api/resource/referencedata`);
    Promise.all([referenceDataRequest, resourceRequest]).then(([referenceDataResp, resourceResp]) => {
      if (referenceDataValidator.validate(referenceDataResp.data)) {
        dispatch(updateTextReferenceData(referenceDataResp.data));
      }
      // if (resourceValidator.validate(resourceResp.data)) {
      setState((prevState) => ({
        ...prevState,
        data: resourceResp.data,
      }));
      // }
    }).catch((err) => {
      let errorCode = 0;
      if (err.response.status) {
        errorCode = err.response.status;
      }
      setState((prevState) => ({
        ...prevState,
        hasError: true,
        errorCode,
      }));
    }).finally(() => {
      setState((prevState) => ({
        ...prevState,
        isLoading: false,
      }));
    });
  }, []);

  const updateResource = (resource: ResourceType) => {
    setState((prevState) => ({
      ...prevState,
      data: {
        ...prevState.data,
        resource: {
          ...resource,
        },
      },
    }));
  };
  const updateContacts = (contacts: OrganisationContact[]) => {
    setState((prevState) => ({
      ...prevState,
      data: {
        ...prevState.data,
        contacts: [...contacts],
      },
    }));
  };

  if (!resourceValidator.isValid) {
    return resourceValidator.error();
  }
  if (!referenceDataValidator.isValid) {
    return referenceDataValidator.error();
  }
  if (state.hasError) {
    if (state.errorCode === 404) {
      return (<div data-testid="404Error"><ErrorPaper text="The specified resource does not exist" /></div>);
    }

    return (<div data-testid="genericError"><ErrorPaper text="Unable to load resource" /></div>);
  }

  return (
    <Grid container justify="center" style={{ position: 'relative' }}>
      {!state.isLoading && state.data.organisation.organisationName && (
        <Breadcrumbs className={classes.nav}>
          <Link href={`partner/${state.data.resource.organisationId}`}>{state.data.organisation.organisationName}</Link>
          <Typography>{state.data.resource.resourceTitle}</Typography>
        </Breadcrumbs>
      )}
      <Grid item xs={10} lg={8}>
        <RootResource
          data={state.data}
          updateResource={updateResource}
          updateContacts={updateContacts}
          isLoading={state.isLoading}
        />
        {!state.isLoading && (
        <>

          <ResourceList
            resource={state.data.resource}
            years={state.data.issueYears.map((x) => x.item1)}
          />
        </>
        )}
      </Grid>
    </Grid>
  );
}
