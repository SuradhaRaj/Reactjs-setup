import React from 'react';
import {
  Grid,
  makeStyles,
  createStyles,
  Box,
} from '@material-ui/core';
import { useSnackbar } from 'notistack';
import Axios, { AxiosResponse, AxiosError } from 'axios';
import { Static } from 'runtypes';
import Dropzone from './TextIndexer/Dropzone';
import RejectedFile from '../../interfaces/TextIndexer/RejectedFile';
import RejectedFilesDialog from './ErrorListDialog';
import { MaxFiles as MaxFilesConst, ErrorMessages } from '../../constants/FileUploadConstants';
import TitleWithSecondaryText from '../molecules/TitleWithSecondaryText';
import UploadedFileList from './TextIndexer/UploadedFileList';
import UploadedFile from '../../interfaces/TextIndexer/UploadedFile';
import FileUploadStatus from '../../interfaces/enums/FileUploadStatus';
import AddFileRequest from '../../interfaces/TextIndexer/AddFileRequest';
import SubmitFilesRequest from '../../interfaces/TextIndexer/SubmitFilesRequest';
import { SubmitFilesErrorResponse, SubmitFilesErrorResponseValidator } from '../../interfaces/TextIndexer/SubmitFilesErrorResponse';
import ResubmitFilesDialog from './TextIndexer/ResubmitFilesDialog';
import { UploadFileResponseValidator, UploadFileResponse } from '../../interfaces/TextIndexer/UploadFileResponse';
import { FileValidator } from '../../interfaces/TextIndexer/IssueArtifact';
import DownloadFilesList from './TextIndexer/DownloadFilesList';
import ConfirmationDialog from '../molecules/ConfirmationDialog';
import ReplaceArticleAArtifactRequest from '../../interfaces/TextIndexer/ReplaceArticleArtifactRequest';
import ReplacePublishedArticleRequest from '../../interfaces/TextIndexer/ReplacePublishedArticleRequest';

const useStyles = makeStyles(() => createStyles({
  root: {
    margin: 0,
  },
  contentWrapper: {
    paddingTop: 30,
    paddingRight: 30,
  },
}));

export interface SplitterProps {
  handleSuccessfulCompletion(shouldRestartWorkflow?: boolean): void;
  issueId: number;
  issuePath: string;
  downloadFiles: Static<typeof FileValidator>[];

  isDisabled: boolean;
  isReplace: boolean;
  isPublished?: boolean;
  artifactId?: number;

  addingToEndedIssueWorkflow?: boolean;
}

export interface SplitterState {
  uploadedFiles: UploadedFile[];
  submitting: boolean;
  rejectedErrorDialogOpen: boolean;
  failedErrorDialogOpen: boolean;
  rejectedFiles: RejectedFile[];
  failedFiles: string[];
  replaceDialogOpen: boolean;
}

const Splitter = (props: SplitterProps) => {
  const [state, setState] = React.useState<SplitterState>({
    uploadedFiles: [],
    submitting: false,
    rejectedErrorDialogOpen: false,
    rejectedFiles: [],
    failedErrorDialogOpen: false,
    failedFiles: [],
    replaceDialogOpen: false,
  });

  const MaxFiles = props.isReplace ? 1 : MaxFilesConst;
  const classes = useStyles();

  const { enqueueSnackbar } = useSnackbar();

  React.useEffect(() => {
    Axios.get(`${process.env.REACT_APP_API_URL}/api/articleindexer/getArtifactfiles?IssuePath=${props.issuePath}`).then((response: AxiosResponse<{ fileType: 'pdf' | 'html' | null; filename: string; pageCount: number; fileSize: number }[]>) => {
      const newUploadedFiles: UploadedFile[] = [];

      response.data.forEach((file) => {
        newUploadedFiles.push({
          name: file.filename,
          status: FileUploadStatus.Valid,
          errorMessages: [],
          pageCount: file.pageCount,
          filetype: file.fileType,
        });
      });
      setState({
        ...state,
        uploadedFiles: newUploadedFiles,

      });
    }).catch((e) => {
      console.error(e);
    });
  }, []);

  const updateFile = (filename: string, status: FileUploadStatus, responseData: UploadFileResponse) => {
    setState((prevState) => {
      const newUploadedFiles = [...prevState.uploadedFiles];

      const i = newUploadedFiles.findIndex((value) => value.name === filename);

      if (i !== -1) {
        newUploadedFiles[i] = {
          ...newUploadedFiles[i],
          status,
          filetype: responseData.fileType,
          pageCount: responseData.pageCount,
          errorMessages: responseData.messages,
        };
      }

      return {
        ...prevState,
        uploadedFiles: newUploadedFiles,
      };
    });
  };

  const startFileVerification = (file: File) => {
    const request: AddFileRequest = {
      issuePath: props.issuePath,
      issueId: props.issueId,
      filename: file.name,
      data: [],
    };

    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    file.arrayBuffer()
      .then((arrayBuffer: ArrayBuffer) => {
        request.data = Array.from(new Uint8Array(arrayBuffer));
        // send the request and update the state once complete
        Axios.post(`${process.env.REACT_APP_API_URL}/api/articleindexer/uploadfile`, request)
        // update the state of that file once it's uploaded
          .then((response: AxiosResponse<UploadFileResponse>) => {
            UploadFileResponseValidator.check(response.data);
            updateFile(request.filename, FileUploadStatus.Valid, response.data);
          })
          .catch((error: AxiosError<UploadFileResponse>) => {
            if (UploadFileResponseValidator.guard(error.response?.data)) {
              if (error.response?.data !== undefined) {
                updateFile(request.filename, FileUploadStatus.Invalid, error.response.data);
              }
            } else {
              updateFile(request.filename, FileUploadStatus.Invalid, {
                pageCount: 0,
                messages: ['Error reading verification response'],
                fileType: null,
                status: undefined,
              });
            }
          });
      });
  };

  const onFileDrop = async (uploadedFiles: File[], rejectedFiles: RejectedFile[]) => {
    const newUploadedFiles = [...state.uploadedFiles];
    // First check if any of the accepted files exist already and move them to rejected with the correct error message
    uploadedFiles.forEach((file) => {
      if (state.uploadedFiles.find((f) => f.name === file.name) !== undefined) {
        rejectedFiles.push({ filename: file.name, errorMessageId: 2 });
      } else {
        newUploadedFiles.push({
          name: file.name,
          status: FileUploadStatus.Verifying,
          errorMessages: [],
          pageCount: 0,
          filetype: null,
        });
        startFileVerification(file);
      }
    });

    const allUploadedFiles = [...newUploadedFiles];

    if (allUploadedFiles.length === MaxFiles) {
      enqueueSnackbar('Max number of files reached', {
        variant: 'info',
      });
    } else if (allUploadedFiles.length > MaxFiles) {
      enqueueSnackbar('Max number of files exceeded', {
        variant: 'error',
      });
    }

    // Then show an error message if there are any errors
    if (rejectedFiles.length > 0) {
      setState({
        ...state,
        rejectedErrorDialogOpen: true,
        rejectedFiles,
        uploadedFiles: allUploadedFiles,
      });
    } else {
      setState({
        ...state,
        uploadedFiles: allUploadedFiles,
        rejectedFiles: [],
      });
    }
  };

  const removeFile = (fileName: string) => {
    // set the file status to deleting
    setState((prevState) => {
      const newUploadedFiles = [...prevState.uploadedFiles];

      const i = newUploadedFiles.findIndex((value) => value.name === fileName);

      if (i !== -1) {
        newUploadedFiles[i] = {
          ...newUploadedFiles[i],
          isDeleting: true,
        };
      }

      return {
        ...prevState,
        uploadedFiles: newUploadedFiles,
      };
    });

    Axios.delete(`${process.env.REACT_APP_API_URL}/api/articleindexer?issuepath=${props.issuePath}&filename=${fileName}`)
      .then(() => {
        // remove the file from the file list
        const newFiles = state.uploadedFiles.filter((uploadedFile) => uploadedFile.name !== fileName);

        setState((prevState) => ({
          ...prevState,
          uploadedFiles: newFiles,
        }));
      })
      .catch(() => {
        // set the file status to not deleting
        setState((prevState) => {
          const newUploadedFiles = [...prevState.uploadedFiles];

          const i = newUploadedFiles.findIndex((value) => value.name === fileName);

          if (i !== -1) {
            newUploadedFiles[i] = {
              ...newUploadedFiles[i],
              isDeleting: false,
            };
          }

          return {
            ...prevState,
            uploadedFiles: newUploadedFiles,
          };
        });

        enqueueSnackbar(`Error removing ${fileName}`, {
          variant: 'error',
        });
      });
  };

  const closeRejectedErrorDialog = () => (
    setState({
      ...state,
      rejectedErrorDialogOpen: false,
    })
  );

  const closeFailedErrorDialog = () => {
    setState({
      ...state,
      failedErrorDialogOpen: false,
    });

    props.handleSuccessfulCompletion();
  };

  const replacePublishedArtifact = () => {
    if (props.artifactId && state.uploadedFiles[0].name) {
      setState({
        ...state,
        submitting: true,
      });

      const requestData: ReplacePublishedArticleRequest = {
        issuePath: props.issuePath,
        artifactId: props.artifactId,
        filename: state.uploadedFiles[0].name,
        issueId: props.issueId,
      };

      Axios.post(`${process.env.REACT_APP_API_URL}/api/articleindexer/replacepublished`, requestData)
        .then(() => {
          enqueueSnackbar('File submitted successfully', {
            variant: 'success',
          });

          props.handleSuccessfulCompletion();
        })
        .catch(() => {
          enqueueSnackbar('An unexpected error occurred while submitting the file', {
            variant: 'error',
          });
        })
        .finally(() => (
          setState((prevState) => ({
            ...prevState,
            submitting: false,
          }))
        ));
    } else {
      enqueueSnackbar('An unexpected error occurred while submitting the file', {
        variant: 'error',
      });
      setState((prevState) => ({
        ...prevState,
        submitting: false,
      }));
    };
  };

  const submitFiles = () => {
    if (props.isReplace && props.isPublished) {
      replacePublishedArtifact();
      return;
    }

    setState({
      ...state,
      submitting: true,
    });

    const requestData: SubmitFilesRequest = {
      issuePath: props.issuePath,
      issueId: props.issueId,

      addingToEndedIssueWorkflow: !!props.addingToEndedIssueWorkflow,
      filenames: state.uploadedFiles.map((file) => file.name),
    };

    Axios.post(`${process.env.REACT_APP_API_URL}/api/articleindexer/SubmitFiles`, requestData)
      .then(() => {
        enqueueSnackbar('Files submitted successfully', {
          variant: 'success',
        });

        props.handleSuccessfulCompletion();
      })
      .catch((error: AxiosError<SubmitFilesErrorResponse>) => {
        if (SubmitFilesErrorResponseValidator.guard(error.response?.data)) {
          setState((prevState) => ({
            ...prevState,
            submitting: false,
            failedErrorDialogOpen: true,
            failedFiles: error.response !== undefined ? error.response.data.fileNames : [],
          }));
        } else {
          enqueueSnackbar('An unexpected error occurred while submitting the files', {
            variant: 'error',
          });
          setState((prevState) => ({
            ...prevState,
            submitting: false,
          }));
        }
      });
  };

  const replaceArtifact = (shouldRestartWorkflow: boolean) => {
    if (props.artifactId && state.uploadedFiles[0].name) {
      setState({
        ...state,
        submitting: true,
        replaceDialogOpen: false,
      });

      const requestData: ReplaceArticleAArtifactRequest = {
        issuePath: props.issuePath,
        artifactId: props.artifactId,
        shouldRestartWorkflow,
        filename: state.uploadedFiles[0].name,

      };

      Axios.post(`${process.env.REACT_APP_API_URL}/api/articleindexer/replace`, requestData)
        .then(() => {
          enqueueSnackbar('File submitted successfully', {
            variant: 'success',
          });

          props.handleSuccessfulCompletion(shouldRestartWorkflow);
        })
        .catch(() => {
          enqueueSnackbar('An unexpected error occurred while submitting the file', {
            variant: 'error',
          });
        })
        .finally(() => (
          setState((prevState) => ({
            ...prevState,
            submitting: false,
          }))
        ));
    } else {
      enqueueSnackbar('An unexpected error occurred while submitting the file', {
        variant: 'error',
      });
      setState((prevState) => ({
        ...prevState,
        submitting: false,
      }));
    };
  };

  const getRejectedFileErrorMessages = () => {
    const errorMessages: JSX.Element[] = [];
    state.rejectedFiles.map((rejectedFile) => (
      errorMessages.push(
        <>
          <Box fontWeight="fontWeightBold" display="inline">
            {rejectedFile.filename}
          </Box>
          {` - ${ErrorMessages[rejectedFile.errorMessageId]}`}
        </>,
      )
    ));

    return errorMessages;
  };

  const isSubmitDisabled = () => (
    state.submitting
    || state.uploadedFiles.length > MaxFiles
    || state.uploadedFiles.find((uploadedFile) => uploadedFile.status !== FileUploadStatus.Valid || uploadedFile.isDeleting) !== undefined
    || state.failedErrorDialogOpen
  );

  const openReplaceDialog = () => {
    setState((prevState) => ({
      ...prevState,
      replaceDialogOpen: true,
    }));
  };

  return (
    <>
      <Grid container justify="center" className={classes.root}>
        <Grid item xs={4}>
          <TitleWithSecondaryText
            title="Download"
            secondaryText="Publisher supplied documents"
          />
          <div className={classes.contentWrapper}>
            <DownloadFilesList
              files={props.downloadFiles}
              issuePath={props.issuePath}
            />
          </div>
        </Grid>
        <Grid item xs={4}>
          <TitleWithSecondaryText
            title="Upload"
            secondaryText="Documents split by artifact"
          />
          <div className={classes.contentWrapper}>
            <Dropzone onFileDrop={onFileDrop} disabled={state.submitting || props.isDisabled} />
          </div>
        </Grid>
        <Grid item xs={4}>
          <TitleWithSecondaryText
            title="Confirm"
            secondaryText="Document name and submit"
          />
          <div className={classes.contentWrapper}>
            <UploadedFileList
              disabled={isSubmitDisabled()}
              files={state.uploadedFiles}
              removeFile={removeFile}
              submitFiles={(props.isReplace && !props.isPublished) ? openReplaceDialog : submitFiles}
              submitting={state.submitting}
              maxFiles={MaxFiles}
            />
          </div>
        </Grid>
      </Grid>
      <RejectedFilesDialog
        open={state.rejectedErrorDialogOpen}
        handleClose={closeRejectedErrorDialog}
        title="The following files could not be added"
        errors={getRejectedFileErrorMessages()}
      />
      <ResubmitFilesDialog
        issueId={props.issueId}
        open={state.failedErrorDialogOpen}
        handleClose={closeFailedErrorDialog}
        filenames={state.failedFiles}
        issuePath={props.issuePath}
      />
      {/* Restart workflow dialog */}
      <ConfirmationDialog
        dialogTitle="Would you like to restart this workflow?"
        dialogBodyText="Restarting the workflow for this article will cause all of the current and previous indexing of this article to be lost."
        successButtonText="Yes"
        rejectButtonText="No"
        onProceed={() => replaceArtifact(true)}
        onReturn={() => replaceArtifact(false)}
        isOpen={state.replaceDialogOpen}
      />
    </>
  );
};

export default Splitter;
