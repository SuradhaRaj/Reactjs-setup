import { reject } from 'lodash';
import {
  ActionTypes, UPDATE_SEARCH_FILTERS, UPDATE_SEARCH_RESULTS, UPDATE_SEARCH_ITEM,
} from '../actions/ActnSearch';
import SearchResult from '../../interfaces/Search/SearchResult';
import SearchFilters from '../../classes/SearchFilters';

export interface SearchState {
  results: SearchResult[];
  filters: SearchFilters;
}

export const initialState: SearchState = {
  results: [],
  filters: SearchFilters.empty(),
};

export default (state = initialState, action: ActionTypes): SearchState => {
  switch (action.type) {
    case UPDATE_SEARCH_RESULTS:
      return {
        ...state,
        results: [...action.payload],
      };
    case UPDATE_SEARCH_FILTERS:
      return {
        ...state,
        filters: action.payload,
      };
    case UPDATE_SEARCH_ITEM: {
      const rows = reject(state.results, { id: action.payload.id });
      return {
        ...state,
        results: [...rows, action.payload],
      };
    }
    default:
      return state;
  }
};
