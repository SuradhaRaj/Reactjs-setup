import React from 'react';
import {
  makeStyles, createStyles, Grid, Button, TextField,
} from '@material-ui/core';
import { useFormik } from 'formik';
import Autocomplete from '@material-ui/lab/Autocomplete';
import * as Yup from 'yup';
import LookupOption from '../../../interfaces/LookupOption';
import ArticleDocumentAuthor from '../../../interfaces/TextIndexer/ArticleDocumentAuthor';
import AuthorOption from '../../../interfaces/TextIndexer/AuthorOption';
import TextInputField from '../../Shared/TextInputField';
import AuthorTypedown, { getAuthorName } from './AuthorTypedown';
import Dropdown from '../../Shared/Dropdown';
import LoadingButton from '../../molecules/LoadingButton';
import AuthorRoleType from '../../../interfaces/TextIndexer/ReferenceData/AuthorRoleType';

const useStyles = makeStyles(createStyles({
  button: {
    paddingLeft: 10,
  },
}));

  interface AuthorFormProps {
    affiliationOptions: string[];
    updateAffiliationOptions(authorId: number): void;
    roleTypeLookup: AuthorRoleType[];
    handleCreateAuthor(authorToAdd: ArticleDocumentAuthor): void;
    handleAddAuthor(authorId: ArticleDocumentAuthor): void;
    clearAffiliationOptions(): void;
    readonly?: boolean;
    loading: boolean;
    isLegal: boolean;
  }

  interface AuthorFormState {
    addingNew: boolean;
  }

const AuthorForm = (props: AuthorFormProps) => {
  const [state, setState] = React.useState<AuthorFormState>({ addingNew: false });

  const classes = useStyles();

  const initialFormValues: ArticleDocumentAuthor = {
    authorId: 0,
    firstName: '',
    middleName: '',
    lastName: '',
    orcidCode: '',
    affiliationId: null,
    affiliation: null,
    createdBy: '',
    createdDate: '',
    roleTypeId: props.roleTypeLookup.findIndex((option) => option.name === 'Author') + 1,
    roleType: 'Author',
    isConference: null,
  };

  const formik = useFormik({
    initialValues: {
      ...initialFormValues,
    },
    onSubmit: () => undefined,
    validationSchema:
              Yup.object().shape({
                authorId: Yup
                  .number()
                  .required(),
                firstName: Yup
                  .string()
                  .required(),
                lastName: Yup
                  .string()
                  .required(),
                roleType: Yup
                  .string()
                  .required(),
                roleTypeId: Yup
                  .number()
                  .positive()
                  .required(),
              }),
    isInitialValid: false,
    validateOnMount: true,
  });

  React.useEffect(() => {
    formik.resetForm();
  }, [state.addingNew]);

  const onAuthorSelectHandler = (selectedAuthor?: AuthorOption) => {
    if (selectedAuthor !== undefined) {
      // get affiliation options
      props.updateAffiliationOptions(selectedAuthor.authorId);
      // populate the form with the new selected author
      formik.setValues({
        ...formik.values,
        ...selectedAuthor,
      });
    } else {
      formik.setValues({
        ...formik.values,
        authorId: 0,
        firstName: '',
        middleName: '',
        lastName: '',
        orcidCode: '',
      });
    }
  };

  const setFieldWithId = (
    valueKey: string,
    idKey: string,
    value: string,
    lookup: LookupOption[],
  ) => {
    // first update the field holding the string value
    formik.setFieldValue(valueKey, value, true);
    // then update the field holding the id
    const lookupOption = lookup.find((option) => option.value === value);
    formik.setFieldValue(idKey, lookupOption?.key || null, false);
  };

  const handleCreateAddButtonClick = () => {
    props.clearAffiliationOptions();
    if (state.addingNew) props.handleCreateAuthor(formik.values);
    else props.handleAddAuthor(formik.values);
    formik.resetForm();
    setState((prevState) => ({
      ...prevState,
      addingNew: false,
    }));
  };

  const handleNewCancelButtonClick = () => {
    props.clearAffiliationOptions();
    formik.resetForm();
    setState((prevState) => ({
      ...prevState,
      addingNew: !prevState.addingNew,
    }));
  };

  return (
    <>
      {state.addingNew ? (
        <>
          <Grid item xs={10}>
            {/* First Name */}
            <TextInputField
              labelText="First Name"
              inputText={formik.values.firstName}
              value={formik.values.firstName}
              keyName="firstName"
              onBlur={formik.handleBlur}
              error={!!formik.errors.firstName}
              errorMessage={formik.errors.firstName}
              onChangeFunction={formik.handleChange}
              readOnly={props.readonly}
            />
          </Grid>
          <Grid item xs={2} style={{ marginTop: 15 }}>
            <Button
              onClick={handleNewCancelButtonClick}
            >
              {state.addingNew ? 'cancel' : 'new'}
            </Button>
          </Grid>
          <Grid item xs={10}>
            {/* Middle Name */}
            <TextInputField
              labelText="Middle Name"
              inputText={formik.values.middleName}
              value={formik.values.middleName || undefined}
              keyName="middleName"
              onBlur={formik.handleBlur}
              error={!!formik.errors.middleName}
              errorMessage={formik.errors.middleName}
              onChangeFunction={formik.handleChange}
              readOnly={props.readonly}
              placeholder="Optional"
            />
          </Grid>
          <Grid item xs={10}>
            {/* Last Name */}
            <TextInputField
              labelText="Last Name"
              inputText={formik.values.lastName}
              value={formik.values.lastName}
              keyName="lastName"
              onBlur={formik.handleBlur}
              error={!!formik.errors.lastName}
              errorMessage={formik.errors.lastName}
              onChangeFunction={formik.handleChange}
              readOnly={props.readonly}
            />
          </Grid>
          <Grid item xs={10}>
            {/* ORCID */}
            <TextInputField
              labelText="ORCID Code"
              inputText={formik.values.orcidCode}
              value={formik.values.orcidCode || undefined}
              keyName="orcidCode"
              onBlur={formik.handleBlur}
              error={!!formik.errors.orcidCode}
              errorMessage={formik.errors.orcidCode}
              onChangeFunction={formik.handleChange}
              readOnly={props.readonly}
              placeholder="Optional"
            />
          </Grid>
        </>
      ) : (
        <>
          <Grid item xs={10} style={{ marginTop: 15 }}>
            {/* Author */}
            <AuthorTypedown
              readonly={props.readonly}
              isLegal={props.isLegal}
              selectedOption={formik.values.authorId === 0 ? undefined : { id: formik.values.authorId, value: getAuthorName(formik.values) }}
              onSelectHandler={onAuthorSelectHandler}
            />
          </Grid>
          <Grid item xs={2} style={{ marginTop: 15 }}>
            <Button
              onClick={handleNewCancelButtonClick}
              className={classes.button}
              disabled={props.readonly}
            >
              {state.addingNew ? 'cancel' : 'new'}
            </Button>
          </Grid>
        </>
      )}
      <Grid item xs={10}>
        {/* Role Type */}
        <Dropdown
          isReadOnly={props.readonly}
          id="RoleType"
          keyName="roleType"
          options={props.roleTypeLookup.map((lookupOption) => ({ display: lookupOption.name, value: lookupOption.name }))}
          selectedOption={formik.values.roleType}
          value={formik.values.roleType}
          labelText="Role Type"
          onChangeFunction={(key: string, value: string) => setFieldWithId(key, 'roleTypeId', value, props.roleTypeLookup.map((option) => ({ key: option.authorRoleTypeId, value: option.name })))}
        />
      </Grid>
      <Grid item xs={10}>
        {/* Affiliation */}
        <Autocomplete
          freeSolo
          options={props.affiliationOptions}
          value={formik.values.affiliation}
          onChange={formik.handleChange}
          onSelect={formik.handleChange}
          onBlur={formik.handleBlur}
          renderInput={(params) => (
            <TextField
              {...params}
              label="Affiliation"
              margin="normal"
              variant="outlined"
              name="affiliation"
              fullWidth
            />
          )}
        />
      </Grid>
      <Grid item xs={2} style={{ marginTop: 15 }}>
        <LoadingButton
          onClick={handleCreateAddButtonClick}
          disabled={!formik.isValid}
          isLoading={props.loading}
          className={classes.button}
        >
          {state.addingNew ? 'Create' : 'Add'}
        </LoadingButton>
      </Grid>
    </>
  );
};

export default AuthorForm;
