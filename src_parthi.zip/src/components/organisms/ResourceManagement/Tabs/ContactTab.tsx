import React from 'react';
import {
  Grid, makeStyles, Theme, createStyles, Typography, Button,
} from '@material-ui/core';
import HubspotIcon from '@iconify/icons-simple-icons/hubspot';
import Icon from '@iconify/react';
import ContactList from '../../Organisation/ContactList';
import OrganisationContact from '../../../../interfaces/Organisation/OrganisationContact';
import { hubSpotOrganisationLink } from '../../../../constants/HubSpotConstants';
import LookupOption from '../../../../interfaces/LookupOption';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    padding: theme.spacing(2),
    paddingRight: theme.spacing(2),
  },
  noContacts: {
    textAlign: 'center',
    marginTop: theme.spacing(4),
    '& a': {
      marginTop: theme.spacing(2),
    },
  },
}));

interface Props {
  contacts: OrganisationContact[];
  hubspotOrgId: number;
  updateContacts(contacts: OrganisationContact[]): void;
  organisationId: number;
  contactRoleTypeLookup: LookupOption[];
}

export default (props: Props) => {
  const classes = useStyles();

  return (
    <Grid container style={{ position: 'relative' }}>
      <Grid item xs={12}>
        <div className={classes.root}>
          {props.contacts.length > 0 && (
          <ContactList
            contactRoleTypeLookup={props.contactRoleTypeLookup}
            contacts={props.contacts}
            handleContactsChange={props.updateContacts}
            organisationId={props.organisationId}
            elevation={3}
          />
          )}
          {props.contacts.length === 0 && (
            <div data-testid="noContacts" className={classes.noContacts}>
              <Typography>There are no contacts assigned to this resource yet in yet HubSpot.</Typography>
              <Button
                target="_blank"
                href={hubSpotOrganisationLink(props.hubspotOrgId)}
                variant="contained"
                color="primary"
                startIcon={<Icon icon={HubspotIcon} />}
              >
                Take me to HubSpot
              </Button>
            </div>
          )}
        </div>
      </Grid>
    </Grid>
  );
};
