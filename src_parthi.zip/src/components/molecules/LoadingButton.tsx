import React from 'react';
import { CircularProgress, Button, ButtonProps } from '@material-ui/core';

interface Props extends ButtonProps {
  isLoading: boolean;
  disabled?: boolean;
}

const LoadingButton: React.FC<Props> = ({ isLoading, ...buttonProps }) => (
  <>
    {!isLoading && (
    <Button {...buttonProps} disabled={buttonProps.disabled} />
    )}
    { isLoading && (
      <Button {...buttonProps} disabled={buttonProps.disabled}><CircularProgress size={20} /></Button>
    )}
  </>
);

export default LoadingButton;
