// Typedowns
export const FastAndIndentifiersTypedownLimit = 6;
export const LanguageTypedownLimit = 10;
export const LegalCaseTypedownLimit = 3;
export const TreatyTypedownLimit = 6;
export const LegislationTypedownLimit = 3;
export const JurisdictionTypedownLimit = 10;
export const AGISSubjectsTypedownLimit = 6;
