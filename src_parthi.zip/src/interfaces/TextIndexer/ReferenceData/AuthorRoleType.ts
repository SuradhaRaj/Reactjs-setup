import {
  Record, Number, String, Static,
} from 'runtypes';

export const AuthorRoleTypeValidator = Record({
  authorRoleTypeId: Number.withConstraint((n) => n > 0),
  name: String,
  authorRoleCode: String,
});

type AuthorRoleType = Static<typeof AuthorRoleTypeValidator>;
export default AuthorRoleType;
