import OrganisationData from '../interfaces/Organisation/OrganisationData';

const SampleOrganisation: OrganisationData = {
  organisationId: 1,
  hubSpotId: 2,
  organisationName: 'smpl Name',
  organisationDepartment: 'smplDepartment',
  organisationCode: 'smpl Code',
  organisationType: 'spmlType',
  rcti: true,
  organisationAbn: '1234 5678',
  organisationGstStatus: 'smpl Gst Status',
  organisationStreetAddress: 'spml Address',
  organisationSuburb: 'smpl Suburb',
  organisationState: 'smpl State',
  organisationPostcode: '3030',
  organisationCountry: 'Country',
  organisationPhone: '040404040404',
  organisationFax: 'fax number',
  organisationEmail: 'email@gmail.com',
  organisationWebAddress: 'address.com.au',
  organisationActivityDescription: 'smpl Activity descriptiom',
  isPublisher: true,
  isSubscriber: false,
};

export default SampleOrganisation;
