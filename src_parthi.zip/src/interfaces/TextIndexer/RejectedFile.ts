export default interface RejectedFile {
  filename: string;
  errorMessageId: 0 | 1 | 2 | 3;
// eslint-disable-next-line semi
};
