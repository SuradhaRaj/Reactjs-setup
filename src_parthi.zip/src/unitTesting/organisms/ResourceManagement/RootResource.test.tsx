import React from 'react';
import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import Skeleton from '@material-ui/lab/Skeleton';
import { act } from 'react-dom/test-utils';
import Axios from 'axios';
import MockAdaptor from 'axios-mock-adapter';
import { MuiThemeProvider } from '@material-ui/core';
import store from '../../../store/store';
import RootResource from '../../../components/organisms/ResourceManagement/RootResource';
import ResourceObj from '../../testObjects/ResourceManagement/Resource';
import UpdateResourceResponse from '../../../interfaces/ResourceManagement/UpdateResourceResponse';
import ResourceResponse from '../../../interfaces/ResourceManagement/ResourceResponse';
import fakeResourceResponse from '../../testObjects/ResourceManagement/ResourceResponse';
import theme from '../../../config/theme';

const mockAxios = new MockAdaptor(Axios);

describe('Root resource', () => {
  it('loading display shows when loading', () => {
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider theme={theme}>
          <RootResource
            updateResource={() => undefined}
            isLoading
            updateContacts={() => undefined}
            data={{} as ResourceResponse}
          />
        </MuiThemeProvider>
      </Provider>,
    );
    expect(wrapper.find(Skeleton).length).toBeGreaterThan(0);
    // wrapper = undefined;
  });
  it('resource name shows when loaded', () => {
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider theme={theme}>
          <RootResource
            updateResource={() => undefined}
            isLoading={false}
            data={fakeResourceResponse}
            updateContacts={() => undefined}
          />
        </MuiThemeProvider>
      </Provider>,
    );
    expect(wrapper.text()).toContain(ResourceObj.resourceTitle);
  });
  it('clicking edit, shows the edit dialog', async () => {
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider theme={theme}>
          <RootResource
            updateResource={() => undefined}
            isLoading={false}
            data={fakeResourceResponse}
            updateContacts={() => undefined}
          />
        </MuiThemeProvider>
      </Provider>,
    );
    expect(wrapper.find('[data-testid="editDialog"]')).toHaveLength(0);
    await wrapper.find('button[data-testid="showEdit"]').simulate('click');
    wrapper.update();
    expect(wrapper.find('[data-testid="editDialog"]').length).toBeGreaterThan(0);
  });
  it('should show the save button when the form has a change', async () => {
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider theme={theme}>
          <RootResource
            updateResource={() => undefined}
            isLoading={false}
            data={fakeResourceResponse}
            updateContacts={() => undefined}
          />
        </MuiThemeProvider>
      </Provider>,
    );

    await act(async () => {
      await wrapper.find('button[data-testid="showEdit"]').simulate('click');
      wrapper.update();
    });

    expect(wrapper.find('button[data-testid="save"]')).toHaveLength(0);

    await act(async () => {
      wrapper.find('input[name="isbn"]').getDOMNode<HTMLInputElement>().value = '123';
      await wrapper.find('input[name="isbn"]').simulate('change');
      await wrapper.find('input[name="isbn"]').simulate('blur');
    });
    expect(wrapper.find('button[data-testid="save"]')).toHaveLength(1);
  });
  it('should show the close button when the form does not have a change', async () => {
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider theme={theme}>
          <RootResource
            updateResource={() => undefined}
            isLoading={false}
            data={fakeResourceResponse}
            updateContacts={() => undefined}
          />
        </MuiThemeProvider>
      </Provider>,
    );

    await act(async () => {
      await wrapper.find('button[data-testid="showEdit"]').simulate('click');
      wrapper.update();
    });

    expect(wrapper.find('button[data-testid="close"]')).toHaveLength(1);

    await act(async () => {
      wrapper.find('input[name="isbn"]').getDOMNode<HTMLInputElement>().value = '123';
      await wrapper.find('input[name="isbn"]').simulate('change');
      await wrapper.find('input[name="isbn"]').simulate('blur');
    });
    expect(wrapper.find('button[data-testid="close"]')).toHaveLength(0);
  });
  it('form does not submit when there are validation errors', async () => {
    const updateFn = jest.fn();
    const resourceData: ResourceResponse = {
      ...fakeResourceResponse,
    };
    resourceData.resource.isbn = '';
    resourceData.resource.issn = '';
    resourceData.resource.eIsbn = '';
    resourceData.resource.eIssn = '';

    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider theme={theme}>
          <RootResource
            updateResource={updateFn}
            isLoading={false}
            data={fakeResourceResponse}
            updateContacts={() => undefined}
          />
        </MuiThemeProvider>
      </Provider>,
    );

    await act(async () => {
      await wrapper.find('button[data-testid="showEdit"]').simulate('click');
      wrapper.update();
      wrapper.find('input[name="doi"]').getDOMNode<HTMLInputElement>().value = '123';
      await wrapper.find('input[name="doi"]').simulate('change');
      await wrapper.find('input[name="doi"]').simulate('blur');
      await wrapper.find('button[data-testid="save"]').simulate('click');
    });

    expect(updateFn).not.toHaveBeenCalled();
  });
  it('clicking save with a valid form, calls the update method', async () => {
    const axiosSpy = jest.spyOn(Axios, 'patch');
    const updateFn = jest.fn();
    mockAxios.onPatch('api/resource').reply(200, { resource: ResourceObj } as UpdateResourceResponse);

    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider theme={theme}>
          <RootResource
            updateResource={updateFn}
            isLoading={false}
            data={fakeResourceResponse}
            updateContacts={() => undefined}
          />
        </MuiThemeProvider>
      </Provider>,
    );

    await act(async () => {
      await wrapper.find('button[data-testid="showEdit"]').simulate('click');
      wrapper.update();
      wrapper.find('input[name="isbn"]').getDOMNode<HTMLInputElement>().value = '123';
      await wrapper.find('input[name="isbn"]').simulate('change');
      await wrapper.find('input[name="isbn"]').simulate('blur');
      await wrapper.find('button[data-testid="save"]').simulate('click');
    });

    expect(axiosSpy).toHaveBeenCalled();
    expect(updateFn).toHaveBeenCalled();
  });
});
