import {
  Record, Static, String, Number,
} from 'runtypes';
// import { number } from 'yup';
// import { NumberGreaterZero } from '../../runtypeTypes';

export const ResourcesLookupValidator = Record({

  resourceTypeID: Number,
  resourceTitle: String,
  resourceID: Number,
  resourceName: String,

});

  type ResourcesLookupOption = Static<typeof ResourcesLookupValidator>;
export default ResourcesLookupOption;
