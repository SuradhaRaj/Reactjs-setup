/* eslint-disable max-len */
import React, { useState } from 'react';

import {
  TableRow, TableCell, TableBody, Avatar, Tooltip, Button,
} from '@material-ui/core';
import { makeStyles, createStyles, Theme } from '@material-ui/core/styles';
import CheckIcon from '@material-ui/icons/Check';
import LocalOfferOutlinedIcon from '@material-ui/icons/LocalOfferOutlined';
import classnames from 'classnames';
import { useHistory } from 'react-router-dom';
import { DateTime } from 'luxon';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import { isEmpty } from 'lodash';
import Axios from 'axios';
import { useSnackbar } from 'notistack';
import EnhanceTaskTableHead, { HeadCell } from '../../molecules/EnhancedTableHead';
import SmallChipDialog from '../SmallChipDialog';
import { useSort } from '../../../utils/TableSortHelper';
import CopyableTooltip from '../../molecules/CopyableTooltipIconButton';
import TextTaskManagementIssueTask from '../../../interfaces/TaskManagementText/TextTaskManagementIssueTask';
import ArtifactLock from '../ArtifactLock';
import WorkflowStatus from '../../../interfaces/enums/WorkflowStatus';
import DialogWithCustomContent from '../../molecules/DialogWithCustomContent';
import SmallChip from '../../molecules/SmallChip';

interface Props {
    canUnlock: boolean;
    row: TextTaskManagementIssueTask;
    onUpdate(row: TextTaskManagementIssueTask): void;
    isQA: boolean;
}

interface State{
  publisherDialogOpen: boolean;
}

const useStyles = makeStyles((theme: Theme) => createStyles({
  row: {
    '&:hover': {
      '& $recordNumberIcon': {
        visibility: 'visible',
      },
      '& $navigationIcon': {
        visibility: 'visible',
      },
    },
    // transition: 'all 0s !important',
  },
  selectableCell: {
    cursor: 'pointer',
    padding: 5,
    textAlign: 'center',
    transition: 'all 0.2s',
  },
  emptyRowTd: {
    textAlign: 'center',
  },
  initials: {
    backgroundColor: theme.palette.primary.light,
    width: 'fit-content',
    height: 22,
    fontSize: 14,
    padding: 3,
    minWidth: 30,
  },
  check: {
    color: theme.palette.success.main,
  },
  initialsColumn: {
    width: 90,
  },
  filesColumn: {
    width: 60,
  },
  actionColumn: {
    width: 50,
  },
  deliveredColumn: {
    width: 100,
  },
  recordNumberColumn: {
    width: 35,
  },
  indexerColumn: {
    width: 35,
  },
  indexingCompanyColumn: {
    width: 160,
  },
  navigationColumn: {
    width: 110,
  },
  notesColumn: {
    width: 100,
  },
  publishDateColumn: {
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
  },
  scheduleDateColumn: {
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
  },
  notesChip: {
    marginRight: theme.spacing(1),
  },
  recordNumberIcon: {
    visibility: 'hidden',
  },
  navigationIcon: {
    visibility: 'hidden',
  },
  unlockIcon: {
    cursor: 'pointer',
  },
  button: {
    borderRadius: 50,
    '& .MuiButton-label': {
      maxHeight: '15px',
    },
  },
}));

const getManagerInitials = (managerName: string): string => managerName.split(' ').map((s) => s[0]).toString().replace(',', '');

const makeOpenActionLink = (row: TextTaskManagementIssueTask, isQA: boolean): string => {
  let link: string;
  const state: WorkflowStatus = row.workflowStatusId;
  const linkMap: { -readonly [key in WorkflowStatus]?: string } = {
    [WorkflowStatus.IssueFilesReceived]: `/issues/${row.issueId}/1`,
  };

  if (isQA) {
    link = `/artifact/${row.firstArticle?.artifactId}`;
  } else if (!isEmpty(linkMap[state]) && (linkMap[state] !== undefined)) {
    link = linkMap[state] ?? '';
  } else {
    link = `/artifact/${row.artifactId}`;
  }
  return link;
};

export const IssueTaskRow: React.FC<Props> = ({
  row, canUnlock, onUpdate, isQA,
}) => {
  const classes = useStyles();
  const history = useHistory();
  const onUnlocked = () => {
    onUpdate({
      ...row,
      indexer: '',
    });
  };

  // make state related column
  // need match with makeColumn() under IssueTaskTable components.
  const makeColumn = (isNeedQA: boolean, state: WorkflowStatus) => {
    let jsxString;
    const maplist: { -readonly [key in WorkflowStatus]?: JSX.Element } = {
      [WorkflowStatus.IssueFilesReceived]: <span />,
    };
    if (isQA) {
      jsxString = (
        <Tooltip title={row.numberOfArticles ?? ''}>
          <span>{row.numberOfArticles}</span>
        </Tooltip>
      );
    } else if (maplist[state] !== undefined) {
      jsxString = maplist[state];
    } else {
      jsxString = (
        <span>
          {' '}
          {row.files}
        </span>
      );
    }
    return (
      <TableCell align="right" className={classes.filesColumn}>
        {jsxString}
      </TableCell>
    );
  };

  const { enqueueSnackbar } = useSnackbar();

  const onUpdateNotes = (issueId: number, notes: string) => {
    Axios.post(`${process.env.REACT_APP_API_URL}/api/issue/updateissuenotes`, { issueId, notesForRmitPublishing: notes })
    // update the state of that file once it's uploaded
      .then(() => {
        onUpdate({
          ...row,
          publisherNotes: notes,
        });
        enqueueSnackbar('Notes saved Successfully', { variant: 'success' });
      })
      .catch(() => undefined);
  };
  const [state, setState] = useState<State>({
    publisherDialogOpen: false,
  });

  return (
    <TableRow className={classes.row} hover key={row.rmitNumber}>
      <TableCell align="center" className={classes.indexerColumn}>
        {row.indexer && (
        <ArtifactLock
          artifactId={row.artifactId}
          canUnlock={canUnlock}
          indexer={row.indexer}
          title={row.title}
          onUnlocked={onUnlocked}
        />
        )}
      </TableCell>
      <TableCell className={classes.recordNumberColumn}>
        <div className={classes.recordNumberIcon}>
          <CopyableTooltip title={row.rmitNumber}><LocalOfferOutlinedIcon fontSize="small" /></CopyableTooltip>
        </div>
      </TableCell>
      <TableCell><Tooltip title={row.resourceId}><span>{row.resourceId}</span></Tooltip></TableCell>
      <TableCell><Tooltip title={row.title}><span>{row.title}</span></Tooltip></TableCell>
      <TableCell><Tooltip title={row.grouping}><span>{row.grouping}</span></Tooltip></TableCell>
      <TableCell><Tooltip title={row.indexingCompany ?? ''}><span>{row.indexingCompany}</span></Tooltip></TableCell>
      <TableCell><Tooltip title={row.publisher ?? ''}><span>{row.publisher}</span></Tooltip></TableCell>
      <TableCell><Tooltip title={row.dateOfPublication}><span>{row.dateOfPublication}</span></Tooltip></TableCell>
      <TableCell><Tooltip title={DateTime.fromISO(row.scheduleDate).toFormat('d LLL yyyy')}><span>{DateTime.fromISO(row.scheduleDate).toFormat('d LLL yyyy')}</span></Tooltip></TableCell>
      <TableCell className={classes.deliveredColumn} align="center">{row.delivered ? (<Tooltip title={DateTime.fromISO(row.delivered).toFormat('d LLL yyyy')}><CheckIcon className={classes.check} /></Tooltip>) : (<></>)}</TableCell>
      <TableCell className={classes.initialsColumn}>
        <div style={{ display: 'flex', justifyContent: 'center' }}>
          <Tooltip title={row.manager}>
            <Avatar variant="rounded" className={classes.initials}>{getManagerInitials(row.manager)}</Avatar>
          </Tooltip>
        </div>
      </TableCell>
      {makeColumn(isQA, row.workflowStatusId)}
      <TableCell className={classes.notesColumn}>
        {row.indexerNotes !== null && row.indexerNotes.length > 0 && (
        <SmallChipDialog style={{ marginRight: 8 }} label="Indexer" dialogTitle="Indexer notes" dialogContent={row.indexerNotes} />
        )}
        <>
          <SmallChip
            label="Publisher"
            onClick={() => {
              setState({
                ...state,
                publisherDialogOpen: !state.publisherDialogOpen,
              });
            }}
          />
          <DialogWithCustomContent
            open={state.publisherDialogOpen}
            title="Publisher notes"
            cancelButtonText="Cancel"
            confirmButtonText="Save Notes"
            handleCloseFunction={() => {
              setState({
                ...state,
                publisherDialogOpen: !state.publisherDialogOpen,
              });
            }}
            handleConfirmOptionFunction={() => onUpdateNotes(row.issueId, (document.getElementById('pubpopup') as HTMLFormElement)?.value || '')}
            dialogContent={() => (<textarea id="pubpopup" rows={10} cols={60}>{row.publisherNotes}</textarea>)}
          />
        </>
      </TableCell>
      <TableCell
        className={classnames(classes.navigationColumn, classes.selectableCell)}
        onClick={() => { history.push(makeOpenActionLink(row, isQA)); }}
      >
        <Button
          size="small"
          color="primary"
          variant="outlined"
          onClick={() => undefined}
          endIcon={<ArrowForwardIcon />}
          className={classes.button}
        >
          Open
        </Button>
      </TableCell>

    </TableRow>
  );
};

interface TableProps {
    rows: TextTaskManagementIssueTask[];
    canUnlock: boolean;
    onUpdate(row: TextTaskManagementIssueTask): void;
    isQA: boolean;
}

const IssueTaskTable: React.FC<TableProps> = ({
  rows, canUnlock, onUpdate, isQA,
}) => {
  const classes = useStyles();

  const {
    handleRequestSort, order, orderBy, orderedData,
  } = useSort<TextTaskManagementIssueTask>(rows);

  let headCells: HeadCell[] = [];

  const workflowstate: WorkflowStatus = rows.length > 0 ? rows[0].workflowStatusId : WorkflowStatus.ReadyForIssueQA;
  const makeColumn = (isNeedQA: boolean, state: WorkflowStatus): Array<HeadCell> => {
    const headNameList: Array<HeadCell | undefined> = [
      {
        id: 'indexer', label: '', canSort: false, className: classes.indexerColumn,
      },
      {
        id: 'recordNumber', label: '', canSort: false, className: classes.recordNumberColumn,
      },
      { id: 'resourceId', label: 'Resource ID' },
      { id: 'title', label: 'Title' },
      { id: 'grouping', label: 'Grouping' },
      { id: 'indexingCompany', label: 'Company' },
      { id: 'publisher', label: 'Publisher' },
      {
        id: 'publishDate', label: 'Publish Date', canSort: false, className: classes.publishDateColumn,
      },
      {
        id: 'scheduleDate', label: 'Schedule Date', canSort: false, className: classes.scheduleDateColumn,
      },
      { id: 'delivered', label: 'Delivered', className: classes.deliveredColumn },
      {
        id: 'manager', label: 'Manager', className: classes.initialsColumn,
      },
    ];

    const headNameMap: { readonly [key in WorkflowStatus]?: HeadCell } = {
      [WorkflowStatus.IssueFilesReceived]: { id: 'hidden', label: '', className: classes.filesColumn },
    };

    // make a state related column.
    if (isNeedQA) {
      headNameList.push({ id: 'articles', label: 'Articles', className: classes.filesColumn });
    } else if (headNameMap[state] !== undefined) {
      headNameList.push(headNameMap[state]);
    } else {
      headNameList.push({ id: 'files', label: 'Files', className: classes.filesColumn });
    }

    headNameList.push({
      id: 'notes', label: 'Notes', canSort: false, className: classes.notesColumn,
    });
    headNameList.push({
      id: 'navCell', label: 'View/Edit', canSort: false, className: classes.navigationColumn,
    });

    // Type Guards, make sue type predicate.
    const isHeadCell = (value: HeadCell | undefined): value is HeadCell => (value as HeadCell) !== undefined;

    return headNameList.filter<HeadCell>(isHeadCell);
  };

  headCells = makeColumn(isQA, workflowstate);

  return (
    <>
      <EnhanceTaskTableHead
        order={order}
        orderBy={orderBy}
        onRequestSort={handleRequestSort}
        headCells={headCells}
      />
      <TableBody>
        {orderedData.length > 0 ? orderedData.map((row) => (
          <IssueTaskRow row={row} key={row.rmitNumber} canUnlock={canUnlock} onUpdate={onUpdate} isQA={isQA} />
        ))
          : (<EmptyTableRow />)}

      </TableBody>
    </>
  );
};

export const EmptyTableRow: React.FC = () => {
  const classes = useStyles();

  return (
    <TableRow className={classes.row}>
      <TableCell className={classes.emptyRowTd} colSpan={10}>There are no tasks available to complete.</TableCell>
    </TableRow>
  );
};

export default IssueTaskTable;
