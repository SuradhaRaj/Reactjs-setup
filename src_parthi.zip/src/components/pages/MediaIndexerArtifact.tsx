import React, { useEffect } from 'react';
import axios from 'axios';
import { createStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import { makeStyles } from '@material-ui/core';
import { useSnackbar } from 'notistack';
import { useHistory } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import Alert from '@material-ui/lab/Alert';
import MediaIndexerInputFields from '../molecules/MediaIndexer/MediaIndexerInputFields';
import MediaIndexerReadOnlyFields from '../molecules/MediaIndexer/MediaIndexerReadOnlyFields';
import ErrorPaper from '../organisms/ErrorPaperWithSecondaryText';
import StickyNotification from '../molecules/StickyNotification';
import MediaData from '../../interfaces/MediaIndexer/MediaData';
import { IndexerArtifactContext } from '../contexts/IndexerArtifact';
import { useTypedSelector } from '../../store/store';
import { MediaReferenceDataValidator } from '../../interfaces/MediaIndexer/Reference Data/MediaReferenceData';
import { updateMediaReferenceData } from '../../store/actions/ActnMediaReferenceData';
import MediaArtifact from '../../interfaces/MediaIndexer/MediaArtifact';
import { AppContext } from '../Context';
import { updateLogEventData } from '../../store/actions/ActnLogEventData';
import EventHelper from '../../utils/EventHelper';

const useStyles = makeStyles(() => createStyles({
  grid: {
    marginTop: 'none',
  },
  root: {
    flexGrow: 1,
  },
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  textField: {
    width: 200,
  },
  mainContent: {
    marginTop: '80px',
    marginBottom: '10px',
    minWidth: '1585px',
  },
  contentRow: {
    minHeight: '100px',
  },
  sectionHeading: {
    textAlign: 'left',
    paddingLeft: '15px',
    paddingTop: '15px',
  },
  thumbnailRow: {
    marginBottom: '30px',
  },
  thumbnailSubtitle: {
    textAlign: 'left',
    paddingLeft: '15px',
    marginBottom: '15px',
  },
  saveButton: {
    float: 'left',
    marginBottom: '20px',
    marginLeft: '20px',
  },
  switchMediaPlayer: {
    top: '15px',
    left: '15px',
    height: '99%',
  },
  indexerPannel: {
    paddingLeft: '12px',
    paddingRight: '12px',
  },
}));

interface MediaIndexerProps {
  artifact: MediaData;
}

export default function MediaIndexer(props: MediaIndexerProps): JSX.Element {
  const classes = useStyles();
  const history = useHistory();
  const snackBar = useSnackbar();
  const dispatch = useDispatch();
  const context = React.useContext(IndexerArtifactContext);
  const appContext = React.useContext(AppContext);

  const [isLoading, setIsLoading] = React.useState(true);
  const [validData, setValidData] = React.useState(true);
  const [errorsList, setErrorsList] = React.useState<Array<string>>();

  let referenceData = useTypedSelector((store) => store.MediaReferenceData.MediaReferenceData);
  let logInfo = useTypedSelector((store) => store.LogEventData.LogEventData);

  useEffect(() => {
    if (MediaReferenceDataValidator.validate(referenceData).success) {
      setIsLoading(false);
    } else {
      axios.get(`${process.env.REACT_APP_API_URL}/api/indexing/getmediareferencedata`)
        .then((response) => {
          dispatch(updateMediaReferenceData(response.data));
          referenceData = response.data;
        })
        .catch(() => {
          setValidData(false);
        })
        .finally(() => {
          setIsLoading(false);
        });
    }
  }, []);

  const updateWorkflowInfo = () => {
    const loginfoUrl = `${process.env.REACT_APP_API_URL}/api/indexing/indexer-events/${props.artifact.artifactId}`;
    context.getUpdatedArtifact();
    axios.get(loginfoUrl)
      .then((response) => {
        logInfo = response.data;
        dispatch(updateLogEventData(response.data));
      })
      .catch(() => {
        setValidData(false);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  useEffect(() => {
    // setup event
    const updateMediaArtifactHandler = (evt: CustomEvent): void => {
      if (props.artifact.artifactId !== evt.detail.EntityId) { return; }// prevent wrong trigger.
      /// /console.log('update-media-artifact event:', event.detail);
      /// /console.log(event.detail.EntityType);

      updateWorkflowInfo();
    };

    EventHelper.on('update-media-artifact', updateMediaArtifactHandler);
    updateWorkflowInfo();

    return () => {
      // Anything in here is fired on component unmount.
      // console.log('event off');
      EventHelper.off('update-media-artifact', updateMediaArtifactHandler);
    };
  }, []);

  useEffect(() => {
    const validateUrl = `${process.env.REACT_APP_API_URL}/api/MediaIndexer/validate/${props.artifact.artifactId}`;
    // validate error
    axios.get(validateUrl)
      .then(() => {
        setErrorsList([]);
      })
      .catch((error) => {
        if (error.response.status === 400 && error.response.data !== null && error.response.data !== undefined
                    && error.response.data.length > 0) {
          const errors: string[] = error.response.data.map((x: { errorMessage: string }) => x.errorMessage);
          if (errors) {
            const errorStringList: string[] = errors;
            setErrorsList(errorStringList);
          }
        }
      });
  }, [props.artifact]);
  const updateArtifactStatus = (newStatus: number) => {
    const artifact = { ...props.artifact };
    artifact.artifactStatusId = newStatus;
    context.updateArtifact<MediaData>(artifact);
  };

  const renderErrorSnackbar = (message: string) => {
    snackBar.enqueueSnackbar(message, {
      variant: 'error',
    });
  };

  const renderSuccessSnackbar = (message: string) => {
    snackBar.enqueueSnackbar(message, {
      variant: 'success',
    });
  };

  const saveArtifact = (data: MediaArtifact) => {
    appContext.showBlockUi();
    axios.post(`${process.env.REACT_APP_API_URL}/api/MediaIndexer/SaveMediaArtifact`, data)
      .then(() => {
        snackBar.enqueueSnackbar('Artifact Saved', {
          variant: 'success',
        });
        updateWorkflowInfo();
      })
      .catch(() => {
        snackBar.enqueueSnackbar('An error occured when trying to save the artifact', {
          variant: 'error',
        });
      })
      .finally(() => {
        appContext.hideBlockUi();
      });
  };

  if (isLoading) {
    return (
      <>
      </>
    );
  }

  return (
    <>
      {validData ? (
        <div className={classes.root}>
          {props.artifact.isReadOnly && (
          <StickyNotification text="This artifact is not currently available to edit." />)}

          <Grid container className={classes.grid}>
            <Grid item xs={6} className={classes.indexerPannel}>
              {errorsList ? (
                <>
                  {errorsList.map((x) => (
                    <div>
                      <Alert severity="error">
                        {x}
                        {' '}
                      </Alert>
                    </div>
                  ))}
                </>
              ) : (<></>)}
              <MediaIndexerInputFields
                mediaIndexerData={props.artifact.mediaArtifactDocument}
                genreLookup={referenceData.genreLookup}
                contentTypeLookup={referenceData.contentTypeLookup}
                resourceTypeLookup={referenceData.resourceTypeLookup}
                broadSubjectLookup={referenceData.broadSubjectLookup}
                languagesLookup={referenceData.languageLookup}
                locationSuggestions={props.artifact.locationSuggestions}
                classificationLookup={referenceData.classificationLookup}
                topicSuggestions={props.artifact.topicSuggestions}

                isReadOnly={props.artifact.isReadOnly}
                isPublishedViaWorkflow={props.artifact.isPublishedViaWorkflow}
                submitTasks={props.artifact.submitTasks}
                errorCodes={referenceData.errorCodes}
                setDoImplicitUnlockFunction={context.setDoImplicitUnlock}
                successSnackbarFunction={renderSuccessSnackbar}
                errorSnackbarFunction={renderErrorSnackbar}
                history={history}
                artifactStatus={props.artifact.artifactStatusId}
                updateArtifactStatus={updateArtifactStatus}
                artifactTypeId={props.artifact.artifactTypeId}
                saveArtifact={saveArtifact}
              />
            </Grid>
            <Grid item xs={6} className={classes.indexerPannel}>
              <MediaIndexerReadOnlyFields
                mediaData={props.artifact}
                logInfo={logInfo.logInfo}
                switchJwtToken={props.artifact.switchJWTToken}
              />
            </Grid>
          </Grid>
        </div>
      ) : (
        <ErrorPaper
          title="Unable to read data from retrieved artifact"
          secondaryText={`Artifact ID: ${props.artifact.mediaArtifactDocument.artifactId}`}
        />
      )}
    </>
  );
}
