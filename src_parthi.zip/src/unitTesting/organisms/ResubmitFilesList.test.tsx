/* eslint-disable @typescript-eslint/no-empty-function */
import React from 'react';
import { mount } from 'enzyme';
import ResubmitFilesList, { ResubmitFilesListItem } from '../../components/organisms/TextIndexer/ResubmitFilesList';

describe('Uploaded file list', () => {
  const wrapper = mount(
    <ResubmitFilesList
      guid=""
      issueId={123}
      fileNames={['file1.pdf', 'file2.html']}
    />,
  );

  it('should show the correct number of files', () => {
    expect(wrapper.find(ResubmitFilesListItem).length).toBe(2);
  });
});
