import React from 'react';
import {
  Paper, makeStyles, createStyles, Theme, Grid, Typography, Divider, IconButton,
} from '@material-ui/core';
import { useHistory } from 'react-router-dom';

import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import SmallChip from '../../molecules/SmallChip';
import TextSearchResult from '../../../interfaces/Search/TextSearchResult';
import RuntypeErrorPaper from '../RuntypeError';
import ArtifactLock from '../ArtifactLock';
import SecondaryData from '../../molecules/SecondaryData';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    padding: theme.spacing(2),
    transition: 'all 0.2s',
    paddingRight: theme.spacing(6),
    position: 'relative',
  },
  rmitNumber: {
    fontSize: '0.85rem',
    marginLeft: theme.spacing(2),
    fontWeight: 600,
  },
  title: {
    fontSize: '0.85rem',
    marginLeft: theme.spacing(2),
  },
  row: {
    display: 'flex',
  },
  divider: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(1),
  },
  workflowState: {
    alignSelf: 'center',
    marginLeft: 'auto',
  },
  unlock: {
    marginLeft: 'auto',
  },
  navigateChevron: {
    visibility: 'visible',
    position: 'absolute',
    right: 0,
    top: '50%',
    opacity: 1,
    transition: 'all 0.2s',
    transform: 'translateY(-50%)',
  },
}));

interface Props {
  result: TextSearchResult;
  canUnlock: boolean;
  updateItem(item: TextSearchResult): void;
}

export default function TextResult(props: Props) {
  const classes = useStyles();
  const history = useHistory();
  try {
    // TextSearchResultValidator.check(props.result);
  } catch (error) {
    return (<RuntypeErrorPaper data={props.result} error={error} />);
  }

  const navigateToIndexerUi = (): void => {
    history.push(`/artifact/${props.result.id.toString()}`);
  };
  const unlock = () => {
    props.updateItem({ ...props.result, indexer: '' });
  };

  return (
    <Grid container>
      <Grid item xs={12}>
        <Paper className={classes.root}>
          <Grid container>
            <Grid item xs={12}>
              <Grid container>
                <Grid item xs={12} className={classes.row}>
                  <SmallChip label="TEXT ARTICLE" />
                  <Typography className={classes.rmitNumber}>{props.result.masId}</Typography>
                  <Typography className={classes.title}>{props.result.itemTitle}</Typography>
                  {props.result.indexer && (
                  <ArtifactLock
                    className={classes.unlock}
                    artifactId={props.result.id}
                    canUnlock={props.canUnlock}
                    indexer={props.result.indexer}
                    title={props.result.itemTitle ?? props.result.masId}
                    onUnlocked={unlock}
                  />
                  )}
                </Grid>
              </Grid>
              <Divider className={classes.divider} />
              <Grid container>
                <Grid item xs={9} className={classes.row}>
                  <SecondaryData title="Publisher" content={props.result.publisher} />
                  <SecondaryData title="Title" content={props.result.resourceTitle} />
                  <SecondaryData title="Grouping" content={props.result.grouping} />
                  <SecondaryData title="Publication&nbsp;Year" content={props.result.publicationYear} alwaysDisplay />
                </Grid>
                <Grid item xs={3} className={classes.row}>
                  <SmallChip className={classes.workflowState} label={props.result.workflowState} />
                </Grid>
              </Grid>
            </Grid>

          </Grid>
          <IconButton className={classes.navigateChevron} onClick={navigateToIndexerUi}>
            <ChevronRightIcon />
          </IconButton>

        </Paper>
      </Grid>
    </Grid>
  );
}
