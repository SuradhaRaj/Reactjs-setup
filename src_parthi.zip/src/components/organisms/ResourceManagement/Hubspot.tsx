import React, { useEffect, useState } from 'react';
import {
  Typography, Grid, Card, makeStyles,
} from '@material-ui/core';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import { useTypedSelector } from '../../../store/store';
// import { RotateLeft } from '@material-ui/icons';

function createData(fname: string, lname: string, email: string, crole: string) {
  return {
    fname, lname, email, crole,
  };
}

// const rows = [
//   createData('Contact', 'One', 'contact.one@contact.com', 'Royalty Contact, File Provider'),
//   createData('Contact', 'Two', 'contact.two@contact.com', 'File Provider'),
//   createData('Contact', 'Three', 'contact.three@contact.com', ''),
// ];

export interface SelectedOptionState {
  grouping: string[];
  publisher: string[];
  title: string[];
  id: string[];
  article: string[];
  documentNumber: string[];
  resource: string[];
  hasIndexerNotes?: boolean;
  hasPublisherNotes?: boolean;
  includeRelated?: boolean;
  broadcastdate: Array<string>;
}
interface ContactListProp {
  contacts: Array<ContactProp>;
}

interface ContactProp {
  firstName: string | null;
  surname: string | null;
  email: string | null;
  homePhone: string | null;
  roles: Array<OrganisationContactRoleNode> | null;
}

interface OrganisationContactRoleNode
{
  name: string | null;
  isCRM: boolean | null;
  contactRoleId: number | null;
}

type NewType = boolean;

interface Props {
  isLoading: NewType;
}

const useStyles = makeStyles({
  resourceIdeContainer: {
    paddingBottom: '20',
    backgroundColor: '#cacaca',
  },

  heading: {
    'font-size': '13px',
    'font-weight': '500',
    'text-transform': 'none',
    color: '#000000',
  },
  value: {
    'font-size': '13px',
    color: '#666666',
    'font-weight': '500',
  },
  label: {
    'font-size': '13px',
    color: '#000000',
    'font-weight': '500',
  },
  table: {
    minWidth: 650,
  },
});

function Hubspot(_props: Props): JSX.Element {
  const getResourceData = useTypedSelector((store) => store.ResourceDataOnId);
  const [statecontact, setStateontact] = useState<ContactListProp>({
    contacts: [],
  });

  useEffect(() => {
    const cont: Array<ContactProp> = getResourceData.Contact.map((x) => ({
      firstName: x.firstName,
      surname: x.surname,
      email: x.email,
      homePhone: x.homePhone,
      roles: x.roles.map((y) => ({
        name: y.name,
        isCRM: y.isCRM,
        contactRoleId: +y.contactRoleId,
      })),
    }));

    setStateontact(
      ({
        contacts: cont,
      }),
    );
  }, [getResourceData.Contact]);

  const classes = useStyles();
  return (
    <div className="organisation_Container">
      <Card
        variant="outlined"
        className="resourceIdeContainer"
        style={{
          marginLeft: 20,
          marginRight: 20,
          paddingBottom: 20,
          marginTop: 20,
        }}
      >

        <Grid item xs={12} style={{ textAlign: 'left' }}>
          <Typography
            className={classes.heading}
            variant="overline"
            style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
          >
            Hubspot information
          </Typography>
        </Grid>
        <Grid
          xs={12}
          container
          spacing={2}
        >
          <div className="custom_table" style={{ paddingTop: 0 }}>
            <TableContainer>
              <Table className={classes.table} aria-label="simple table">
                <TableHead>
                  <TableRow>
                    <TableCell>First Name</TableCell>
                    <TableCell>Last Name</TableCell>
                    <TableCell>Email</TableCell>
                    <TableCell>Contact Role</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {
            statecontact.contacts.map((row) => (
              <TableRow key={row.firstName}>
                <TableCell component="th" scope="row">
                  {row.firstName}
                </TableCell>
                <TableCell>{row.surname}</TableCell>
                <TableCell>{row.email}</TableCell>
                <TableCell>
                  {Array.isArray(row.roles) ? row.roles.map((r) => r.name) : '' }
                  {' '}
                </TableCell>
              </TableRow>
            ))
          }

                </TableBody>
              </Table>
            </TableContainer>
          </div>
        </Grid>
      </Card>
    </div>
  );
}

export default Hubspot;
