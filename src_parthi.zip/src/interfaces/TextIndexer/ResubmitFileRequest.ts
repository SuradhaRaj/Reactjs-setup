export default interface ResubmitFileRequest {
    fileName: string;
    issuePath: string;
    issueId: number;
// eslint-disable-next-line semi
}
