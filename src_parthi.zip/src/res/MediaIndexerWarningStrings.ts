import ResourceString from '../interfaces/res/ResourceString';

const strings: Array<ResourceString> = [
  { id: 1, message: 'Maximum of 3 fast terms allowed for segment' },
  { id: 2, message: 'Could not find video transcript.' },
  { id: 3, message: 'A Series No. has not been provided' },
  { id: 4, message: 'An Episode No. has not been provided' },
  { id: 5, message: 'Program Broadcast Start was not set' },
  { id: 6, message: 'Program Broadcast End was not set' },
];

export default strings;
