import React from 'react';
import {
  makeStyles, Theme, createStyles, Grid, Typography, Paper, IconButton, CircularProgress, Button,
} from '@material-ui/core';
// import { useHistory } from 'react-router-dom';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import Axios from 'axios';
import classnames from 'classnames';
import ResourceArtifact from './ResourceArtifact';

import ResourceArticleList from '../../../interfaces/ResourceList/ResourceArticleList';
import ErrorPaper from '../ErrorPaper';
import ResourceIssueData from '../../../interfaces/ResourceList/ResourceIssueData';
import ArtifactSearchIndex from '../../../interfaces/enums/ArtifactSearchIndex';
import SecondaryData from '../../molecules/SecondaryData';
import DateExtensions from '../../../utils/DateExtensions';
import { ResourceArtifactExtendItem } from '../../../interfaces/ResourceList/ResourceArticleData';
import { useTypedSelector } from '../../../store/store';

const useStyles = makeStyles((theme: Theme) => createStyles({
  article: {
    paddingTop: theme.spacing(2),
  },
  loadingSpinner: {
    display: 'block',
    margin: 'auto',
    paddingTop: theme.spacing(2),
    width: 'fit-content',
  },
  errorPaper: {
    display: 'block',
    margin: 'auto',
    paddingTop: theme.spacing(2),
    width: 'fit-content',
  },
  issueData: {
    padding: theme.spacing(2),
  },
  arrowUp: {
    transition: '0.2s',
    transform: 'rotate(-180deg)',
  },
  arrowDown: {
    transition: '0.2s',
  },
  tabContent: {
    margin: '10px',
    '& > *': {
      display: 'inline-block',
      // width: 125,
    },
  },
  button: {
    borderRadius: 50,
    '& .MuiButton-label': {
      maxHeight: '15px',
    },
  },
}));

interface State {
    expanded: boolean;
    articles: ResourceArtifactExtendItem[];
    isLoading: boolean;
    error: boolean;
}

interface Props {
    issueData: ResourceIssueData;
    publisher: string;
    resourceTitle: string;

    resourceTypeId: number | null;
    displayArticle: boolean;
}

const ResourceIssue = (props: Props) => {
  const classes = useStyles();
  // const history = useHistory();
  const referenceData = useTypedSelector((store) => store.ResourceReferenceData.ResourceReferenceData);
  const [state, setState] = React.useState<State>({
    expanded: false,
    articles: [],
    isLoading: false,
    error: false,
  });

  const flipExpanded = () => {
    if (state.expanded) {
      setState((prevState) => ({
        ...prevState,
        expanded: false,
      }));
    } else {
      setState((prevState) => ({
        ...prevState,
        expanded: true,
        isLoading: prevState.articles.length === 0,
      }));

      // If there are no articles in the state then we want to get them from the controller
      if (state.articles.length === 0) {
        Axios.get<ResourceArticleList>(`${process.env.REACT_APP_API_URL}/api/resource/getarticlesforissue?issueId=${props.issueData.issueID}`)
          .then((response) => {
            const textResultList: ResourceArtifactExtendItem[] = response.data.articles.map((item) => ({
              artifactId: item.artifactId,
              masId: item.masId,
              sectionName: item.sectionName,
              itemTitle: item.itemTitle,
              indexer: item.indexer,
              workflowState: item.workflowState,
              articleOrder: item.articleOrder,
              publisher: props.publisher,
              pagination: item.pagination,
              peerReviewedArticleIndicator: item.peerReviewedArticleIndicator,
              publishArtefact: item.publishArtefact,
              resourceType: referenceData.resourceTypes.find((x) => x.resourceTypeID === props.resourceTypeId)?.name ?? '',
              grouping: props.issueData.grouping,
              resourceTitle: props.resourceTitle,
              publicationYear: `${props.issueData.publicationYear}`,
              searchIndex: ArtifactSearchIndex.Article,

            }));

            setState((prevState) => ({
              ...prevState,
              articles: textResultList,
            }));
          })
          .catch(() => {
            setState((prevState) => ({
              ...prevState,
              error: true,
            }));
          })
          .finally(() => {
            setState((prevState) => ({
              ...prevState,
              isLoading: false,
            }));
          });
      }
    }
  };

  function open(link: string) {
    window.open(link, '_blank');
  }

  const displayIssueSubTitle = (displayArticle: boolean) => {
    const articleNum = `${props.issueData.articleCount} Articles`;
    const volumeNumber = `Volume ${props.issueData.volumeNumber}`;
    const issueNumber = `Issue ${props.issueData.issueNumber}`;
    const volumeNumberAndIssueNumber = props.issueData.issueNumber ? `${volumeNumber},${issueNumber}` : volumeNumber;
    const displayText = displayArticle ? `${articleNum} in ${volumeNumberAndIssueNumber}` : volumeNumberAndIssueNumber;

    return (
      <Typography className={classes.issueData}>
        {displayText}
      </Typography>
    );
  };

  return (
    <>
      <Paper>
        <Grid container>
          <Grid item xs={1}>
            {props.issueData.articleCount > 0 && (
            <>
              <IconButton className={classes.issueData} onClick={flipExpanded}>
                <KeyboardArrowDownIcon className={classnames(classes.arrowDown, { [classes.arrowUp]: state.expanded })} />
              </IconButton>
            </>
            )}
          </Grid>
          <Grid item xs={9}>
            {displayIssueSubTitle(props.displayArticle)}

            <div className={classes.tabContent}>

              <SecondaryData title="Grouping" content={props.issueData.grouping !== null ? props.issueData.grouping : '(none)'} />
              <SecondaryData title="Volume Number" content={props.issueData.volumeNumber !== null ? props.issueData.volumeNumber : '(none)'} />
              <SecondaryData title="Issue Number" content={props.issueData.issueNumber !== null ? props.issueData.issueNumber : '(none)'} />
              <SecondaryData title="Issue Month Season" content={props.issueData.issueMonthSeason !== null ? props.issueData.issueMonthSeason : '(none)'} />
              <SecondaryData title="Issue Title" content={props.issueData.issueTitle !== null ? props.issueData.issueTitle : '(none)'} />
              <SecondaryData title="Publication Year" content={props.issueData.publicationYear !== null ? props.issueData.publicationYear : '(none)'} />
              <SecondaryData title="Date Of Publication" content={props.issueData.dateOfPublication !== null ? props.issueData.dateOfPublication : '(none)'} />
              <SecondaryData title="Schedule date" content={props.issueData.scheduleDate !== null ? DateExtensions.convertDateToFormFormat(props.issueData.scheduleDate) : '(none)'} />
              <SecondaryData title="Notes For Management" content={props.issueData.notesIssueManagement !== null ? props.issueData.notesIssueManagement : '(none)'} />
            </div>

          </Grid>
          <Grid item xs={2}>
            <Button
              size="small"
              color="primary"
              variant="outlined"
              onClick={() => open(`/issues/${props.issueData.issueID}`)}
              endIcon={<ArrowForwardIcon />}
              className={classes.button}
            >
              Open
            </Button>
          </Grid>
        </Grid>
      </Paper>
      {state.expanded && (
      <>
        {state.error ? (
          <div className={classes.errorPaper}>
            <ErrorPaper
              text="An error occured when trying to load articles"
            />
          </div>
        ) : (
          <>
            {state.isLoading ? (
              <div className={classes.loadingSpinner}>
                <CircularProgress />
              </div>
            ) : (
              <>
                {state.articles.length === 0 && (
                <div className={classes.errorPaper}>
                  <ErrorPaper
                    text="No articles found for this issue"
                  />
                </div>
                )}
                {state.articles.map((article: ResourceArtifactExtendItem) => (
                  <Grid container className={classes.article}>
                    <Grid item xs={1} />
                    <Grid item xs={11}>
                      <ResourceArtifact
                        result={article}
                        canUnlock={false}
                        updateItem={() => undefined}
                      />
                    </Grid>
                  </Grid>
                ))}
              </>
            )}
          </>
        )}
      </>
      )}
    </>
  );
};

export default ResourceIssue;
