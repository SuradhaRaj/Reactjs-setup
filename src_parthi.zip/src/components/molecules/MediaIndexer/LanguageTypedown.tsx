/* eslint @typescript-eslint/no-explicit-any: 0 */
import React from 'react';
import {
  Grid, Chip, Zoom, createStyles, withStyles, WithStyles, TextField,
} from '@material-ui/core';
import Autocomplete from '@material-ui/lab/Autocomplete';

import { DateTime } from 'luxon';
import LanguageOption from '../../../interfaces/MediaIndexer/LanguageOption';
import TypedownCounter from '../../atoms/TypedownCounter';
import DocumentLangNode from '../../../interfaces/MediaIndexer/DocumentLangNode';

const useStyles = createStyles({
  typedownContainer: {
    width: '100%',
    position: 'relative',
  },
  languagesContainer: {
    textAlign: 'left',
    marginTop: 5,
  },
  addButton: {
    position: 'absolute',
    top: '530px',
    left: '1125px',
  },
  suggestionsHeader: {
    textAlign: 'left',
    marginLeft: '20px',
  },
  suggestionsContainer: {
    textAlign: 'left',
    marginLeft: '15px',
  },
  chip: {
    marginRight: '5px',
    marginBottom: '5px',
  },
});

interface LanguageTypedownProps {
  selectedLanguages: DocumentLangNode[];
  languageLookup: LanguageOption[];
  keyName: string;
  onChangeFunction: Function;
  error: boolean;
  typedownLimit: number;
  classes: any;
  readOnly?: boolean;
  currentUser?: string;
}

function getOptionRender(option: LanguageOption): JSX.Element {
  return (
    <>
      <Grid item xs={12}>
        <span>{`${option.key} ${option.value}`}</span>
      </Grid>
    </>
  );
}

class LanguageTypedown extends React.Component<LanguageTypedownProps & WithStyles<typeof useStyles>, {}, {}> {
  constructor(props: LanguageTypedownProps) {
    super(props);
    this.addLanguageToList = this.addLanguageToList.bind(this);
    this.handleDeleteLanguage = this.handleDeleteLanguage.bind(this);
    this.renderChips = this.renderChips.bind(this);
  }

  handleDeleteLanguage = (languageToDelete: DocumentLangNode) => () => {
    const newList: DocumentLangNode[] = this.props.selectedLanguages.filter((language) => language.name !== languageToDelete.name);
    this.props.onChangeFunction(this.props.keyName, newList);
  }

  addLanguageToList(event: any, newValues: Array<LanguageOption>): void {
    if (newValues !== undefined && newValues !== null && newValues[newValues.length - 1] !== undefined) {
      const value = newValues[newValues.length - 1];
      if (this.props.selectedLanguages !== undefined) {
        if (this.props.selectedLanguages.length < 10) {
          if (this.props.selectedLanguages.find((location) => location.name === value.value) === undefined) {
            this.props.onChangeFunction(this.props.keyName, [...this.props.selectedLanguages, {
              id: value.key,
              name: value.value,
              createdBy: this.props.currentUser ? this.props.currentUser : '',
              createdDate: this.props.currentUser ? DateTime.local().toString() : '',
            }]);
          }
        }
      } else {
        this.props.onChangeFunction(this.props.keyName, [{
          id: value.key,
          name: value.value,
          createdBy: this.props.currentUser ? this.props.currentUser : '',
          createdDate: this.props.currentUser ? DateTime.local().toString() : '',
        }]);
      }
    }
  }

  renderChips() {
    const { classes } = this.props;

    if (this.props.selectedLanguages !== undefined && this.props.selectedLanguages.length > 0) {
      return (
        this.props.selectedLanguages.map((language: DocumentLangNode) => <Zoom in={this.props.selectedLanguages.includes(language)} key={language.id}><Chip className={classes.chip} tabIndex={-1} disabled={this.props.readOnly} variant="outlined" label={language.name} onDelete={this.handleDeleteLanguage(language)} color="primary" /></Zoom>)
      );
    }

    return null;
  }

  render(): JSX.Element {
    const { classes } = this.props;
    return (
      <>
        <div className={classes.typedownContainer}>
          <Grid item xs={6} style={{ position: 'relative' }}>
            <Autocomplete
              multiple
              className={classes.languagesInput}
              id="Languages"
              options={this.props.languageLookup}
              onChange={this.addLanguageToList}
              clearOnEscape
              disabled={this.props.readOnly || this.props.selectedLanguages.length >= this.props.typedownLimit}
              renderInput={(params: any) => (
                <TextField
                  {...params}
                  className={classes.languagesTextField}
                  variant="outlined"
                  label="Languages"
                  margin="normal"
                  fullWidth
                  error={this.props.error}
                  helperText={this.props.error ? 'At least 1 language must be added' : ''}
                  InputProps={
                    {
                      ...params.InputProps,
                      endAdornment: (<></>),
                    }
                }
                />
              )}
              renderOption={(option: LanguageOption) => getOptionRender(option)}
              getOptionLabel={(option) => option.value}
              renderTags={() => <></>}
            />
          </Grid>
          {!this.props.error && (
          <Grid item xs={6}>
            <TypedownCounter
              selected={this.props.selectedLanguages.length}
              limit={this.props.typedownLimit}
            />
          </Grid>
          )}
          <Grid container item xs={10} className={classes.languagesContainer}>
            {
              this.renderChips()
            }
          </Grid>
        </div>
      </>
    );
  }
}

export default withStyles(useStyles)(LanguageTypedown);
