import { useContext } from 'react';
import { DateTime } from 'luxon';
import { AppContext } from '../Context';
import DocumentItemNode from '../../interfaces/MediaIndexer/DocumentItemNode';

const useDocumentItemNode = () => {
  const context = useContext(AppContext);

  const setDocumentItemNode = (
    key: string,
    currentValues: DocumentItemNode[],
    initialArrayValues: DocumentItemNode[],
    setFieldValue: ((field: string, value: DocumentItemNode[], shouldValidate?: boolean | undefined) => void),
  ) => {
    const newValues: DocumentItemNode[] = [];

    // check if the node was present in the initial values
    currentValues.forEach((currentValue) => {
      const initiallyExistingNode = initialArrayValues.find((initialValue) => initialValue.id === currentValue.id);
      // if this is a new node, fill it with data
      if (initiallyExistingNode === undefined) {
        newValues.push({
          ...currentValue,
          createdBy: context.userInfo.data.name,
          createdDate: DateTime.local().toString(),
        });
      // if the node was already present initially, populate it with the same data
      } else {
        newValues.push({ ...initiallyExistingNode });
      }
      setFieldValue(key, newValues, true);
    });
  };

  return { setDocumentItemNode };
};
export default useDocumentItemNode;
