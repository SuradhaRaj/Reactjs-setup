import {
  ActionTypes, REMOVE_NOTIFICATION, ADD_NOTIFICATION,
} from '../actions/ActnNotification';
import Notification from '../../classes/Notification';

export interface NotificationState {
  Notification: Notification;
}

export const initialState: NotificationState = {
  Notification: Notification.empty(),
};

export default (state = initialState, action: ActionTypes): NotificationState => {
  switch (action.type) {
    case ADD_NOTIFICATION:
      return {
        ...state,
        Notification: { data: [...state.Notification.data, ...action.payload.data] },
      };
    case REMOVE_NOTIFICATION:
      return {
        ...state,
        Notification: { data: [...state.Notification.data.filter((item) => !(action.payload.data.includes(item)))] },
      };

    default:
      return state;
  }
};
