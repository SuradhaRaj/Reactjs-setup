/* eslint-disable @typescript-eslint/no-empty-function */

import IssueValidationSchema from '../../validationSchemas/IssueValidationSchema';

describe('Issue Validation Schema Tests', () => {
  it('publicationYear validation test', async () => {
    const validationErr2 = IssueValidationSchema.validateAt('publicationYear', { publicationYear: 3422223 });
    await expect(validationErr2).rejects.toThrowError('Date must be in the format "YYYY"');

    const validationValid1 = IssueValidationSchema.validateAt('publicationYear', { publicationYear: 2000 });
    await expect(validationValid1).resolves.toBe('2000');

    const validationValid2 = IssueValidationSchema.validateAt('publicationYear', { publicationYear: 2030 });
    await expect(validationValid2).resolves.toBe('2030');
  });

  it('dateOfPublication validation test', async () => {
    const validationErr1 = IssueValidationSchema.validateAt('dateOfPublication', { dateOfPublication: null });
    await expect(validationErr1).rejects.toThrowError("Enter your publication's details e.g. Summer 2013 or Mar / Apr 2013 or Sep - Dec 2013");

    const validationValid1 = IssueValidationSchema.validateAt('dateOfPublication', { dateOfPublication: 'Dec 2013' });
    await expect(validationValid1).resolves.toBe('Dec 2013');
  });

  it('scheduleDate validation test', async () => {
    const validationErr1 = IssueValidationSchema.validateAt('scheduleDate', { scheduleDate: '12-121-2003' });
    await expect(validationErr1).rejects.toThrowError('scheduleDate must be a `date` type, but the final value was: `Invalid Date` (cast from the value `"12-121-2003"`).');

    const validationErr2 = IssueValidationSchema.validateAt('scheduleDate', { scheduleDate: null });
    await expect(validationErr2).rejects.toThrowError('scheduleDate must be a `date` type, but the final value was: `Invalid Date`.');

    const validationValid1 = IssueValidationSchema.validateAt('scheduleDate', { scheduleDate: '12-12-2003' });
    await expect(validationValid1).resolves.toBeDefined();
  });

  it('oneOfFieldsRequired validation test', async () => {
    const testObject = {
      volumeNumber: null,
      issueNumber: null,
      issueMonthSeason: null,
    };

    const validationErr1 = IssueValidationSchema.validateAt('volumeNumber', testObject);
    await expect(validationErr1).rejects.toThrowError('At least one of Volume Number, Issue Number, Issue Month Season is required');

    const testObject2 = {
      volumeNumber: null,
      issueNumber: '123',
      issueMonthSeason: null,
    };

    const validationValid = IssueValidationSchema.validateAt('volumeNumber', testObject2);
    await expect(validationValid).resolves.toBeDefined();
  });

  it('completed validation test', async () => {
    const testObject = {
      volumeNumber: null,
      issueNumber: '123',
      issueMonthSeason: null,
      scheduleDate: '12-12-2003',
      publicationYear: 2000,
      dateOfPublication: 'Dec 2013',
    };

    const validationValid1 = IssueValidationSchema.isValidSync(testObject);
    expect(validationValid1).toBeTruthy();

    const testObject1 = {
      volumeNumber: null,
      issueNumber: '1',
      issueMonthSeason: null,
      scheduleDate: null,
      publicationYear: null,
      dateOfPublication: 'Dec 2013',
    };

    const validationErr1 = IssueValidationSchema.isValidSync(testObject1);
    expect(validationErr1).toBeFalsy();

    const testObject2 = {
      volumeNumber: null,
      issueNumber: null,
      issueMonthSeason: null,
      scheduleDate: '12-12-2003',
      publicationYear: 2000,
      dateOfPublication: 'Dec 2013',
    };

    const validationErr2 = IssueValidationSchema.isValidSync(testObject2);
    expect(validationErr2).toBeFalsy();
  });
});
