import {
  Record, Number, Static,
} from 'runtypes';

export const SearchResultValidator = Record({
  searchIndex: Number,
  id: Number,
});

type SearchResult = Static<typeof SearchResultValidator>
export default SearchResult;
