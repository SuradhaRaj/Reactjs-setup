import React from 'react';
import {
  Typography, makeStyles, Theme, createStyles, Grid, Tooltip, Avatar,
} from '@material-ui/core';
import { Variant } from '@material-ui/core/styles/createTypography';

const useStyles = makeStyles((theme: Theme) => createStyles({
  secondaryTitle: {
    fontSize: '0.75rem',
    fontWeight: 600,
  },
  secondaryContent: {
    fontSize: '0.85rem',
  },
  secondaryData: {
    marginRight: theme.spacing(4),
  },
  initials: {
    backgroundColor: theme.palette.primary.light,
    width: 'fit-content',
    height: 22,
    fontSize: 14,
    padding: 3,
    minWidth: 30,
  },
  initialsColumn: {
    width: 90,
  },
}));

const SecondaryData = (props: {title: string; content: string | number | null; className?: string; alwaysDisplay?: boolean;
  variantName?: Variant; initialsCol?: string; }) => {
  const classes = useStyles();

  return (
    <>
      {(props.content || (props.alwaysDisplay ?? false)) && (
        <div className={props.className || classes.secondaryData}>
          <Typography
            variant={props.variantName ?? 'overline'}
            className={classes.secondaryTitle}
          >
            {props.title}
          </Typography>
          <Typography className={classes.secondaryContent}>
            {(props.initialsCol && (
            <Grid className={classes.initialsColumn}>
              <Grid style={{ display: 'flex', justifyContent: 'left' }}>
                <Tooltip title={props.initialsCol}>
                  <Avatar variant="rounded" className={classes.initials}>{props.initialsCol}</Avatar>
                </Tooltip>
              </Grid>
            </Grid>
            )) || props.content}
          </Typography>
        </div>
      )}
    </>
  );
};

export default SecondaryData;
