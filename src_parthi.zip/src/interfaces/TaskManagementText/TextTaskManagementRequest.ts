import {
  Record, String, Static, Number,
} from 'runtypes';

export const KeyValueValidator = Record({
  id: Number,
  value: String,
});

export type KeyValue = Static<typeof KeyValueValidator>

export const isKeyValue = KeyValueValidator.guard;
