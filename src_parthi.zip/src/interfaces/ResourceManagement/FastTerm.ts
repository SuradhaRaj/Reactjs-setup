import {
  Record, Number, String, Static, Array, Runtype, Lazy,
} from 'runtypes';

  interface Fastobj {
    fastid: number;
    termid: string;
    term: string;
    termdisplayname: string;
  }

export const FasttermValidator: Runtype<Fastobj> = Record({
  fastid: Number,
  termid: String,
  term: String,
  termdisplayname: String,
});

  type Fasttermtype = Static<typeof FasttermValidator>;
export default Fasttermtype;
