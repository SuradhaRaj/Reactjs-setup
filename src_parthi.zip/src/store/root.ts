import { combineReducers } from 'redux';

import TaskManagementReducer from './reducers/RdcrTaskManagement';
import TextTaskManagementReducer from './reducers/RdcrTextTaskManagement';
import ClientConfigurationReducer from './reducers/RdcrClientConfiguration';
import NotificationReducer from './reducers/RdcrNotification';
import SearchReducer from './reducers/RdcrSearch';
import TextReferenceDataReducer from './reducers/RdcrTextReferenceData';
import MediaReferenceDataReducer from './reducers/RdcrMediaReferenceData';
import LogEventDataReducer from './reducers/RdcrLogEventData';
import RdcrResourceReferenceData from './reducers/RdcrResourceReferenceData';
import RdcrIssueReferenceData from './reducers/RdcrIssueReferenceData';
import RdcrResourceData from './reducers/RdcrResourceData';
import TitleResourceReference from './reducers/TitleResourceReference';

export const rootReducer = combineReducers({
  TaskManagement: TaskManagementReducer,
  TextTaskManagement: TextTaskManagementReducer,
  ClientConfiguration: ClientConfigurationReducer,
  Notification: NotificationReducer,
  Search: SearchReducer,
  TextReferenceData: TextReferenceDataReducer,
  MediaReferenceData: MediaReferenceDataReducer,
  ResourceReferenceData: RdcrResourceReferenceData,
  IssueReferenceData: RdcrIssueReferenceData,
  LogEventData: LogEventDataReducer,
  ResourceDataOnId: RdcrResourceData,
  TitleResourceReferenceData: TitleResourceReference,
});

export type RootState = ReturnType<typeof rootReducer>
