import React from 'react';
import { shallow } from 'enzyme';
import ConfirmationDialog from '../components/molecules/ConfirmationDialog';

describe('Validation dialog', () => {
  it('should render the correct title and body text', () => {
    const wrapper = shallow(
      <ConfirmationDialog
        isOpen
        onProceed={() => undefined}
        onReturn={() => undefined}
        dialogTitle="This is the title"
        dialogBodyText="This is the body text"
      />,
    );

    expect(wrapper.contains('This is the title')).toBe(true);
    expect(wrapper.contains('This is the body text')).toBe(true);
  });
});
