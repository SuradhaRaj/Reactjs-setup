import React from 'react';
import { Document, Page } from 'react-pdf/dist/entry.webpack';
import LazyLoad from 'react-lazyload';
import {
  Paper,
  makeStyles,
  IconButton,
} from '@material-ui/core';
import Scrollbars from 'react-custom-scrollbars';
import { PDFDocumentProxy, PDFPageProxy } from 'pdfjs-dist';
import ZoomInIcon from '@material-ui/icons/ZoomIn';
import ZoomOutIcon from '@material-ui/icons/ZoomOut';
import ErrorPaperWithSecondaryText from './ErrorPaperWithSecondaryText';

interface LoadingPdfPageProps {
  width: number;
  height: number;
  scale: number;
}

const LoadingPdfPage = (props: LoadingPdfPageProps) => (
  <div
    style={{
      width: props.width * props.scale,
      height: props.height * props.scale,
    }}
  />
);

// styles recommended on https://github.com/wojtekmaj/react-pdf/issues/332 that greatly increase alignment accuracy
const useStyles = makeStyles({
  document: {
    overflow: 'auto',
    textAlign: 'center',
    height: '100%',
    top: '-40px',
    '& .react-pdf__Page__textContent div': {
      opacity: 0.2,
      '&::selection': {
        // sets colour of highlight when highlighting text
        backgroundColor: 'black',
      },
    },
    '& .react-pdf__Document': {
      lineHeight: 'initial',
    },
  },
  errorMessage: {
    height: '100%',
    textAlign: 'center',
    width: '50%',
    display: 'inline-block',
  },
  page: {
    marginBottom: 20,
    float: 'left',
  },
  errorMessageText: {
    textAlign: 'left',
  },
});

interface PdfViewerProps {
    file: string;
    filename: string;
}

interface PdfViewerState {
    loading: boolean;
    errored: boolean;
    numPages: number;
    pageDimensions: number[];
    scale: number;
}

// also recommended on https://github.com/wojtekmaj/react-pdf/issues/332 to improve text align accuracy
const removeTextLayerOffset = () => {
  const textLayers = document.querySelectorAll('.react-pdf__Page__textContent');
  textLayers.forEach((layer) => {
    const { style } = layer as HTMLElement;
    style.top = '0';
    style.left = '0';
    style.transform = '';
  });
};

const PdfViewer: React.SFC<PdfViewerProps> = (props: PdfViewerProps) => {
  const [state, setState] = React.useState<PdfViewerState>({
    loading: true,
    errored: false,
    numPages: 0,
    scale: 1,
    pageDimensions: [0, 0],
  });

  const classes = useStyles();

  const scrollbarElement = React.useRef<Scrollbars>(null);

  const pagesContainer = React.createRef<HTMLDivElement>();

  // gets the width of the first page in the pdf
  const getPageDimensions = async (pdf: PDFDocumentProxy) => {
    let pageDimensions = [0, 0];
    await pdf.getPage(1).then((page: PDFPageProxy) => { pageDimensions = page.view.slice(2, 3); });
    return pageDimensions;
  };

  const onDocumentLoadSuccess = async (pdf: PDFDocumentProxy) => {
    const pageDimensions = await getPageDimensions(pdf);

    // sets the initial scale of the pdf so that it takes up the entire div
    // includes space for the vertical scrollbar
    const initialScale = ((pagesContainer.current?.offsetWidth || 0) - 20) / pageDimensions[0];

    setState({
      ...state,
      loading: false,
      errored: false,
      numPages: pdf.numPages,
      scale: initialScale,
      pageDimensions,
    });
  };

  const onDocumentLoadError = () => {
    setState({
      ...state,
      loading: false,
      errored: true,
    });
  };

  const onPageLoadSuccess = () => {
    removeTextLayerOffset();
    // manually rerenders the scrollbar whenever a page loads
    // eslint-disable-next-line no-unused-expressions
    scrollbarElement.current?.forceUpdate();
  };

  const handleZoomOut = () => {
    setState({
      ...state,
      scale: state.scale - 0.2,
    });
  };

  const handleZoomIn = () => {
    setState({
      ...state,
      scale: state.scale + 0.2,
    });
  };

  const renderPages = (): JSX.Element[] => {
    const pages: JSX.Element[] = [];

    for (let i = 0; i < state.numPages; i++) {
      pages.push(
        <Paper className={classes.page} key={i}>
          <LazyLoad
            overflow
            scroll
            resize
            offset={1000}
          >
            <Page
              pageIndex={i}
              scale={state.scale}
              onLoadSuccess={onPageLoadSuccess}
              loading={(
                <LoadingPdfPage
                  width={state.pageDimensions[0]}
                  height={state.pageDimensions[1]}
                  scale={state.scale}
                />
              )}
            />
          </LazyLoad>
        </Paper>,
      );
    }

    return pages;
  };

  return (
    <>
      {state.errored || !props.file
        ? (
          <div style={{ textAlign: 'center', paddingTop: 150 }}>
            <div className={classes.errorMessage}>
              <ErrorPaperWithSecondaryText
                title="Error Loading PDF File"
                secondaryText={props.filename}
              />
            </div>
          </div>
        )
        : (
          <>
            <span style={{ zIndex: 10 }}>
              <IconButton onClick={handleZoomOut} disabled={state.scale <= 1.0}>
                <ZoomOutIcon />
              </IconButton>
              <IconButton onClick={handleZoomIn}>
                <ZoomInIcon />
              </IconButton>
            </span>
            <div
              className={classes.document}
              ref={pagesContainer}
            >
              <Scrollbars ref={scrollbarElement}>
                <Document
                  file={props.file}
                  onLoadSuccess={onDocumentLoadSuccess}
                  onLoadError={onDocumentLoadError}
                  loading=""
                >
                  {state.loading ? null
                    : (
                      <>
                        {renderPages()}
                      </>
                    )}
                </Document>
              </Scrollbars>
            </div>
          </>
        )}
    </>
  );
};

export default PdfViewer;
