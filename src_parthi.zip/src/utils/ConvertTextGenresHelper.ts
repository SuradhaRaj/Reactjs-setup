import LookupOption from '../interfaces/LookupOption';
import DropdownOption from '../interfaces/MediaIndexer/DropdownOption';

const ConvertGenres = (list: LookupOption[]): DropdownOption[] => {
  const returnList: DropdownOption[] = [];

  // Loop through top level resource types
  for (let i = 0; i < list.length; i++) {
    // Add resource type to returnList
    returnList.push({
      display: list[i].value,
      value: list[i].key,
    });
  }

  return returnList;
};

export default {
  ConvertGenres,
};
