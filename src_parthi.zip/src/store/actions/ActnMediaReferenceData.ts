import MediaReferenceData from '../../interfaces/MediaIndexer/Reference Data/MediaReferenceData';

export const UPDATE_MEDIA_REFERENCE_DATA = 'UPDATE_MEDIA_REFERENCE_DATA';

interface UpdateMediaReferenceDataAction {
  type: typeof UPDATE_MEDIA_REFERENCE_DATA;
  payload: MediaReferenceData;
}

export type ActionTypes = UpdateMediaReferenceDataAction;

export function updateMediaReferenceData(data: MediaReferenceData): ActionTypes {
  return {
    type: UPDATE_MEDIA_REFERENCE_DATA,
    payload: data,
  };
}
