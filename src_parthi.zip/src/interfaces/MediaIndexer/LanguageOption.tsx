interface LanguageOption {
    key: number;
    value: string;
}

export default LanguageOption;
