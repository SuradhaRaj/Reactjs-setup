import {
  Record, String, Static, Null,
} from 'runtypes';
import { TextTaskManagementBaseTaskValidator } from './TextTaskManagementBaseTask';

export const TextTaskManagementArticleTaskValidator = Record({
  articleTitle: String,
  delivered: String,
  grouping: String,
  indexer: String.Or(Null),
  indexerNotes: String,
  manager: String,
  publisher: String.Or(Null),
  publisherNotes: String,
  rmitNumber: String,
  title: String,
  indexingCompany: String,
  dateOfPublication: String,
  resourceId: String,

}).And(TextTaskManagementBaseTaskValidator);

type TextTaskManagementArticleTask = Static<typeof TextTaskManagementArticleTaskValidator>
export default TextTaskManagementArticleTask;
