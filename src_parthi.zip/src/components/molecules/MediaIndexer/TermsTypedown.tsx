/* eslint @typescript-eslint/no-explicit-any: 0 */
import React from 'react';
import axios from 'axios';
import _ from 'lodash';
import {
  Grid, Chip, createStyles, Zoom, Typography, withStyles, WithStyles, TextField, CircularProgress,
} from '@material-ui/core';
import Autocomplete, { AutocompleteRenderOptionState } from '@material-ui/lab/Autocomplete';
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';
import match from 'autosuggest-highlight/match';
import parse from 'autosuggest-highlight/parse';
import AddCircleIcon from '@material-ui/icons/AddCircle';
import WarningDialogBox from '../../Shared/WarningDialogBox';

import TypedownCounter from '../../atoms/TypedownCounter';
import DocumentFastNode from '../../../interfaces/MediaIndexer/DocumentFastNode';
import DocumentNodeStateEnum from '../../../interfaces/MediaIndexer/DocumentNodeStateEnum';
import { TypedownDebounceTime } from '../../../constants/MediaIndexerConstants';
import ExpandedSearchDialogBox from '../../organisms/ExpandedSearchDialogBox';
import StringExtensions from '../../../utils/StringExtensions';

const useStyles = createStyles({
  typedownContainer: {
    width: '100%',
    position: 'relative',
  },
  termsInput: {
    width: '100%',
  },
  addButton: {
    position: 'absolute',
    top: '530px',
    left: '595px',
  },
  termsTextField: {
    marginTop: '0px',
  },
  termsContainer: {
    textAlign: 'left',
    marginTop: 5,
  },
  suggestionsHeader: {
    textAlign: 'left',
  },
  suggestionsContainer: {
    textAlign: 'left',
  },
  chip: {
    marginRight: '5px',
    marginBottom: '5px',
  },
  typedownCounter: {
    float: 'right',
    fontSize: '10pt',
    position: 'absolute',
    bottom: 10,
    right: -32,
  },
  renderOptionHighlighted: {
    fontWeight: 550,
  },
});

interface State {
  termsOptions: TermOption[];
  dialog: DialogData;
  loading: boolean;
  expandedSearchDialogOpen: boolean;
}

interface TermsTypedownProps {
  selectedTerms: DocumentFastNode[];
  topicSuggestions: string[];
  keyName: string;
  artifactTypeId: number;
  onChangeFunction(key: string, value: DocumentFastNode[]): void;
  fastAndIdentifierCount: number;
  fastAndIdentifierLimit: number;
  disabled?: boolean;
  error: boolean;
  errorText?: string | undefined;
  classes: any;
  readOnly?: boolean;
}

interface TermOption {
  termID: number;
  name: string;
  count: number;
  warningText: string;
}

interface DialogData {
  open: boolean;
  id: number;
  title: string;
  content: string;
}

export class TermsTypedown extends React.Component<TermsTypedownProps & WithStyles<typeof useStyles>, State, {}> {
  constructor(props: TermsTypedownProps) {
    super(props);
    this.handleCloseDialog = this.handleCloseDialog.bind(this);
    this.handleTermsChange = _.debounce(this.handleTermsChange, TypedownDebounceTime);
    this.handleTermsChange = this.handleTermsChange.bind(this);
    this.handleDeleteTerm = this.handleDeleteTerm.bind(this);
    this.addTermToList = this.addTermToList.bind(this);
    this.addTermToListFromDialog = this.addTermToListFromDialog.bind(this);
    this.clearTypedownOptions = this.clearTypedownOptions.bind(this);
    this.renderChips = this.renderChips.bind(this);
    this.renderSuggestions = this.renderSuggestions.bind(this);
    this.makeFastTermAvailable = this.makeFastTermAvailable.bind(this);
    this.addTermToListFromExpandedSearch = this.addTermToListFromExpandedSearch.bind(this);

    this.state = {
      termsOptions: [],
      dialog: {
        open: false, title: '', id: 0, content: '',
      },
      loading: false,
      expandedSearchDialogOpen: false,
    };
  }

  getTerms(searchTerm: string): Promise<TermOption[]> {
    const returnList: TermOption[] = [];
    const suggestionsPromise = new Promise<TermOption[]>((resolve, reject) => {
      this.setState((prevState) => ({
        ...prevState,
        termsOptions: [],
        loading: true,
      }));

      fetch(`${process.env.REACT_APP_API_URL}/api/Indexing/searchfast?searchTerm=${searchTerm}&artifactTypeId=${this.props.artifactTypeId}`)
        .then((res) => res.json())
        .then(
          (result) => {
            if (result.status === 200) {
              for (let i = 0; i < result.results.length; i += 1) {
                returnList.push({
                  termID: result.results[i].fastID,
                  name: result.results[i].name,
                  count: result.results[i].count,
                  warningText: result.results[i].warningText,
                });
              }

              returnList.push({
                termID: 0,
                name: 'Search from all FAST Terms...',
                count: 0,
                warningText: '',
              });
            }
            resolve(returnList);
          },
          (error: Error) => {
            reject(error);
          },
        ).finally(() => {
          this.setState((prevState) => ({
            ...prevState,
            loading: false,
          }));
        });
    });

    return suggestionsPromise;
  }

  getOptionRender(option: TermOption, renderOptionState: AutocompleteRenderOptionState): JSX.Element {
    if (option.termID === 0) {
      return (
        <>
          <Grid item xs={11}>
            <span>{option.name}</span>
          </Grid>
        </>
      );
    } if (option.warningText === '' || option.warningText === null) {
      const matches = match(option.name, renderOptionState.inputValue);
      const parts = parse(option.name, matches);
      const { classes } = this.props;

      return (
        <>
          <Grid item xs={11}>
            {parts.map((part) => (
              <span className={part.highlight ? classes.renderOptionHighlighted : ''}>
                {/* If the first character of a non-matched part is a non-ascii character, do not render it. */}
                {part.text && StringExtensions.RemoveInitialNonAscii(part.text)}
              </span>
            ))}
          </Grid>
        </>
      );
    }

    return (
      <>
        <Grid item xs={11}>
          <span>{option.name}</span>
        </Grid>
        <Grid item xs={1}>
          <ErrorOutlineIcon />
        </Grid>
      </>
    );
  }

  handleDeleteTerm = (termToDelete: DocumentFastNode) => () => {
    // If this was a historic term then we want to change it's state to user removed, otherwise delete the term outright
    if (!termToDelete.isNew) {
      const newList: DocumentFastNode[] = this.props.selectedTerms.filter((term) => term.id !== termToDelete.id);

      newList.push(termToDelete);
      newList[newList.length - 1] = {
        ...newList[newList.length - 1],
        state: DocumentNodeStateEnum.UserRemoved,
      };
      this.props.onChangeFunction(this.props.keyName, newList);
    } else {
      const newList: DocumentFastNode[] = this.props.selectedTerms.filter((term) => term.id !== termToDelete.id);
      this.props.onChangeFunction(this.props.keyName, newList);
    }
  }

  makeFastTermAvailable= (id: number): boolean => {
    // Makes a post to make the selected fast term available, returns TRUE if successful
    let success = false;

    axios.post(`${process.env.REACT_APP_API_URL}/api/Indexing/fastshowonui?fastId=${id}`)
      .then((response: any) => {
        if (response.status === 200) {
          success = true;
        }
      });

    return success;
  }

  handleCloseDialog(): void {
    this.setState((prevState) => ({
      ...prevState,
      dialog: {
        open: false,
        id: 0,
        title: '',
        content: '',
      },
    }));
  }

  handleTermsChange(event: any): void {
    const value: string = event.target.value;

    if (value.length > 2 && value.length < 100) {
      this.getTerms(value)
        .then((result: TermOption[]) => {
          this.setState({ termsOptions: result });
        });
    }
  }

  addTermToList(event: any, values: Array<TermOption>): void {
    if (values !== undefined && values !== null && values[values.length - 1]) {
      const value = values[values.length - 1];

      // First check if we clicked on the expanded search option, if not then we perform a normal add to list
      if (value.termID === 0 && value.name === 'Search from all FAST Terms...') {
        this.setState((prevState) => ({
          ...prevState,
          expandedSearchDialogOpen: true,
        }));
      } else if (this.props.selectedTerms !== undefined && this.props.fastAndIdentifierCount < this.props.fastAndIdentifierLimit) {
        const existingTerm = this.props.selectedTerms.find((term) => term.name === value.name);
        if (existingTerm !== undefined && existingTerm.state === DocumentNodeStateEnum.UserRemoved) {
          if (value.warningText === '' || value.warningText === null) {
            const newList = this.props.selectedTerms.filter((term) => term.name !== value.name);
            const newDocumentItemNode: DocumentFastNode = {
              ...existingTerm,
              state: DocumentNodeStateEnum.UserAdded,
              createdBy: '',
              createdDate: '',
            };
            this.props.onChangeFunction(this.props.keyName, [...newList, newDocumentItemNode]);
          } else {
            this.setState((prevState) => ({
              ...prevState,
              dialog: {
                open: true,
                title: value.name,
                id: value.termID,
                content: value.warningText,
              },
            }));
          }
        } else if (existingTerm === undefined) {
          if (value.warningText === '' || value.warningText === null) {
            const newDocumentItemNode: DocumentFastNode = {
              id: value.termID,
              name: value.name,
              createdBy: '',
              createdDate: '',
              state: DocumentNodeStateEnum.UserAdded,
              isNew: true,
            };
            this.props.onChangeFunction(this.props.keyName, [...this.props.selectedTerms, newDocumentItemNode]);
          } else {
            this.setState((prevState) => ({
              ...prevState,
              dialog: {
                open: true,
                title: value.name,
                id: value.termID,
                content: value.warningText,
              },
            }));
          }
        }
      } else if (value.warningText === '' || value.warningText === null) {
        const newDocumentItemNode: DocumentFastNode = {
          id: value.termID,
          name: value.name,
          createdBy: '',
          createdDate: '',
          state: DocumentNodeStateEnum.UserAdded,
          isNew: true,
        };
        this.props.onChangeFunction(this.props.keyName, [newDocumentItemNode]);
      } else {
        this.setState((prevState) => ({
          ...prevState,
          dialog: {
            open: true,
            title: value.name,
            id: value.termID,
            content: value.warningText,
          },
        }));
      }
    }
  }

  addTermToListFromDialog(termName: string, id: number): void {
    if (id !== 0 && id !== undefined && termName !== '' && termName !== undefined) {
      // Find the option that matches the selected value
      // const value = this.state.termsOptions.find((option) => option.name === termName);
      const value: TermOption = {
        termID: id, name: termName, count: 0, warningText: '',
      };

      // If we have found an option that has not already been entered then check if it has warning text, if so we want to display a dialog before adding it, otherwise add it
      if (this.props.selectedTerms !== undefined && this.props.fastAndIdentifierCount < this.props.fastAndIdentifierLimit) {
        const existingTerm = this.props.selectedTerms.find((term) => term.name === value.name);
        if (existingTerm !== undefined && existingTerm.state === DocumentNodeStateEnum.UserRemoved) {
          const newList = this.props.selectedTerms.filter((term) => term.name !== value.name);
          const newDocumentItemNode: DocumentFastNode = {
            ...existingTerm,
            state: DocumentNodeStateEnum.UserAdded,
            createdBy: '',
            createdDate: '',
          };

          this.setState((prevState) => ({
            ...prevState,
            dialog: {
              open: false,
              title: '',
              id: 0,
              content: '',
            },
          }));

          this.props.onChangeFunction(this.props.keyName, [...newList, newDocumentItemNode]);
        } else if (existingTerm === undefined) {
          const newValue: DocumentFastNode = {
            id: value.termID,
            name: value.name,
            createdBy: '',
            createdDate: '',
            state: DocumentNodeStateEnum.UserAdded,
            isNew: true,
          };

          this.setState((prevState) => ({
            ...prevState,
            dialog: {
              open: false,
              title: '',
              id: 0,
              content: '',
            },
          }));
          this.props.onChangeFunction(this.props.keyName, [...this.props.selectedTerms, newValue]);
        }
      } else {
        const newValue: DocumentFastNode = {
          id: value.termID,
          name: value.name,
          createdBy: '',
          createdDate: '',
          state: DocumentNodeStateEnum.UserAdded,
          isNew: true,
        };

        this.setState((prevState) => ({
          ...prevState,
          dialog: {
            open: false,
            title: '',
            id: 0,
            content: '',
          },
        }));
        this.props.onChangeFunction(this.props.keyName, [newValue]);
      }
    }
  }

  addTermToListFromExpandedSearch(id: number, name: string, warningText: string): void {
    this.makeFastTermAvailable(id);

    if (this.props.selectedTerms !== undefined && this.props.fastAndIdentifierCount < this.props.fastAndIdentifierLimit) {
      const existingTerm = this.props.selectedTerms.find((term) => term.id === id);
      if (existingTerm !== undefined && existingTerm.state === DocumentNodeStateEnum.UserRemoved) {
        if (warningText === '' || warningText === null) {
          const newList = this.props.selectedTerms.filter((term) => term.id !== id);
          const newDocumentItemNode: DocumentFastNode = {
            ...existingTerm,
            state: DocumentNodeStateEnum.UserAdded,
            createdBy: '',
            createdDate: '',
          };
          this.props.onChangeFunction(this.props.keyName, [...newList, newDocumentItemNode]);
        } else {
          // Close the expanded search dialog and open the warning text dialog
          this.setState((prevState) => ({
            ...prevState,
            expandedSearchDialogOpen: false,
            dialog: {
              open: true,
              id,
              title: name,
              content: warningText,
            },
          }));
        }
      } else if (existingTerm === undefined) {
        if (warningText === '' || warningText === null) {
          const newDocumentItemNode: DocumentFastNode = {
            id,
            name,
            createdBy: '',
            createdDate: '',
            state: DocumentNodeStateEnum.UserAdded,
            isNew: true,
          };
          this.props.onChangeFunction(this.props.keyName, [...this.props.selectedTerms, newDocumentItemNode]);
        } else {
          // Close the expanded search dialog and open the warning text dialog
          this.setState((prevState) => ({
            ...prevState,
            expandedSearchDialogOpen: false,
            dialog: {
              open: true,
              id,
              title: name,
              content: warningText,
            },
          }));
        }
      }
    } else if (warningText === '' || warningText === null) {
      const newDocumentItemNode: DocumentFastNode = {
        id,
        name,
        createdBy: '',
        createdDate: '',
        state: DocumentNodeStateEnum.UserAdded,
        isNew: true,
      };
      this.props.onChangeFunction(this.props.keyName, [newDocumentItemNode]);
    } else {
      // Close the expanded search dialog and open the warning text dialog
      this.setState((prevState) => ({
        ...prevState,
        expandedSearchDialogOpen: false,
        dialog: {
          open: true,
          id,
          title: name,
          content: warningText,
        },
      }));
    }

    // Close the expanded search dialog
    this.setState((prevState) => ({
      ...prevState,
      expandedSearchDialogOpen: false,
    }));
  }

  addTermToListFromSuggestion(verifiedValueId: number) {
    if (verifiedValueId !== undefined && verifiedValueId !== 0) {
      const termsList: DocumentFastNode[] = [...this.props.selectedTerms];

      for (let i = 0; i < termsList.length; i++) {
        if (termsList[i].id === verifiedValueId) {
          termsList[i] = {
            ...termsList[i],
            state: DocumentNodeStateEnum.UserVerified,
            isNew: false,
          };
        }
      }

      this.props.onChangeFunction(this.props.keyName, termsList);
    }
  }

  clearTypedownOptions(): void {
    this.setState({ termsOptions: [] });
  }

  renderChips(term: DocumentFastNode): JSX.Element {
    const { classes } = this.props;

    if (term.state !== DocumentNodeStateEnum.SystemSuggested && term.state !== DocumentNodeStateEnum.UserRemoved) {
      return (
        <Zoom in={this.props.selectedTerms.includes(term)} key={term.id}><Chip tabIndex={-1} className={classes.chip} data-key={`termChip${term.id}`} variant="outlined" label={term.name} disabled={this.props.readOnly} onDelete={this.handleDeleteTerm(term)} color="primary" /></Zoom>
      );
    }

    return (
      <></>
    );
  }

  renderSuggestedChips(term: DocumentFastNode): JSX.Element {
    const { classes } = this.props;

    if (term.state === DocumentNodeStateEnum.SystemSuggested) {
      return (
        <Zoom in={this.props.selectedTerms.includes(term)} key={term.id}>
          <Chip
            tabIndex={-1}
            className={classes.chip}
            data-key={`fastSuggestionChip${term.id}`}
            label={term.name}
            disabled={this.props.readOnly || this.props.disabled}
            onDelete={() => this.addTermToListFromSuggestion(term.id)}
            deleteIcon={<AddCircleIcon />}
          />
        </Zoom>
      );
    }

    return (
      <></>
    );
  }

  renderSuggestions() {
    const { classes } = this.props;

    if (this.props.topicSuggestions !== undefined && this.props.topicSuggestions.length > 0) {
      return (
        <div>
          <Grid container item xs={6}>
            <Grid item xs={12}>
              <Typography variant="overline" className={classes.suggestionsHeader}>
                Suggested topics
              </Typography>
            </Grid>
          </Grid>
          <Grid container item xs={9}>
            <Grid item xs={12} className={classes.suggestionsContainer}>
              {this.props.topicSuggestions.map((topic) => <Chip tabIndex={-1} className={classes.chip} data-key={`fastSuggestion${topic}`} label={topic} variant="outlined" key={topic} />)}
            </Grid>
          </Grid>
        </div>
      );
    }

    return null;
  }

  render(): JSX.Element {
    const { classes } = this.props;
    return (
      <>
        {this.renderSuggestions()}
        <div className={classes.typedownContainer}>
          <Grid container item xs={6} style={{ position: 'relative' }}>
            <Grid item xs={12}>
              <Autocomplete
                multiple
                filterOptions={(x) => (x)}
                disabled={this.props.disabled || this.props.readOnly || this.props.fastAndIdentifierCount >= this.props.fastAndIdentifierLimit}
                className={classes.termsInput}
                id="fast-terms"
                options={this.state.termsOptions}
                onChange={this.addTermToList}
                onOpen={this.clearTypedownOptions}
                renderInput={(params: any) => (
                  <TextField
                    {...params}
                    className={classes.termsTextField}
                    variant="outlined"
                    label="FAST Terms"
                    margin="normal"
                    fullWidth
                    onChange={(e: { persist: () => void }) => {
                      e.persist();
                      this.handleTermsChange(e);
                    }}
                    error={this.props.error}
                    helperText={this.props.error ? this.props.errorText : ''}
                    InputProps={{
                      ...params.InputProps,
                      endAdornment: (
                        <>
                          {this.state.loading ? <CircularProgress color="inherit" size={20} /> : null}
                          {params.InputProps.endAdornment}
                        </>
                      ),
                    }}
                  />
                )}
                // eslint-disable-next-line max-len
                renderOption={(option: TermOption, renderOptionState: AutocompleteRenderOptionState) => this.getOptionRender(option, renderOptionState)}
                renderTags={() => <></>}
              />
              {!this.props.error && (
              <Grid item xs={12}>
                <TypedownCounter
                  limit={this.props.fastAndIdentifierLimit}
                  selected={this.props.fastAndIdentifierCount}
                />
              </Grid>
              )}
            </Grid>
          </Grid>
          <Grid container item xs={9} className={classes.termsContainer}>
            {this.props.selectedTerms.map((term: DocumentFastNode) => this.renderChips(term))}
          </Grid>
          <Grid container item xs={9} className={classes.termsContainer}>
            {this.props.selectedTerms.map((term: DocumentFastNode) => this.renderSuggestedChips(term))}
          </Grid>
        </div>

        {/* Warning Text Dialog */}
        <WarningDialogBox
          open={this.state.dialog.open}
          id={this.state.dialog.id}
          title={this.state.dialog.title}
          content={this.state.dialog.content}
          handleCloseFunction={this.handleCloseDialog}
          handleAddOptionFunction={this.addTermToListFromDialog}
        />

        {/* Expanded Search Dialog */}
        <ExpandedSearchDialogBox
          open={this.state.expandedSearchDialogOpen}
          title="Expanded search - FAST Terms"
          subheading="Choose a FAST Term from this expanded list, any items added from here will appear on the regular search afterwards"
          handleCloseFunction={() => {
            this.setState((prevState) => ({
              ...prevState,
              expandedSearchDialogOpen: false,
            }));
          }}
          handleAddOptionFunction={this.addTermToListFromExpandedSearch}
          searchApiEndpoint="Indexing/searchfastexpanded"
          artifactTypeId={this.props.artifactTypeId}
        />
      </>
    );
  }
}

export default withStyles(useStyles)(TermsTypedown);
