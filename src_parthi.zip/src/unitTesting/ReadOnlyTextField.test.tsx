import React from 'react';
import { mount } from 'enzyme';
import ReadOnlyTextField from '../components/Shared/ReadOnlyTextField';

const wrapper = mount(
  <ReadOnlyTextField labelText="This is a test label" displayText="This is test display text" />,
);

describe('ReadOnlyTextField Tests', () => {
  it('should display label that is passed into props', () => {
    expect(
      wrapper.contains('This is a test label'),
    ).toBe(true);
  });

  it('should display display text that is passed into props', () => {
    expect(
      wrapper.contains('This is test display text'),
    ).toBe(true);
  });
});
