/*eslint-disable*/
export default interface NarrowSubjectOption {
    key: number;
    value: string;
}