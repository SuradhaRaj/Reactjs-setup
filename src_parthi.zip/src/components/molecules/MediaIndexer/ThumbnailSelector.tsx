import React from 'react';
import {
  Grid, makeStyles, Theme, createStyles,
} from '@material-ui/core';

import classnames from 'classnames';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import ThumbnailNode from '../../../interfaces/MediaIndexer/ThumbnailNode';

const useStyles = makeStyles((theme: Theme) => createStyles({
  thumbnailHover: {
    '&:hover': {
      cursor: 'pointer',
    },
  },
  thumbnailImg: {
    width: '100%',
  },
  thumbnailRoot: {
    position: 'relative',
    padding: theme.spacing(2),
  },
  selectedThumbnail: {
    border: '3px solid',
    borderColor: '#5d78ff',
    boxSizing: 'border-box',
    borderRadius: '4px',
    '&:hover': {
      cursor: 'auto',
    },
  },
  checkIcon: {
    top: '0px',
    right: '0px',
    position: 'absolute',
    borderRadius: '55px',
    backgroundColor: 'white',
  },
}));

interface ThumbnailSelectorProps {
  thumbnails: ThumbnailNode[];
  onChangeFunction: Function;
  readOnly?: boolean;
}

export default function MediaIndexer(props: ThumbnailSelectorProps): JSX.Element {
  const classes = useStyles();
  const handleThumbnailClick = (chosenIndex: number): void => {
    // Prevents array variables referencing the same array
    const newList: ThumbnailNode[] = [...props.thumbnails];

    for (let i = 0; i < newList.length; i += 1) {
      if (i !== chosenIndex && props.thumbnails[i].isSelected === true) {
        newList[i] = {
          ...props.thumbnails[i],
          isSelected: false,
        };
      } else if (i === chosenIndex && props.thumbnails[i].isSelected === false) {
        newList[i] = {
          ...props.thumbnails[i],
          isSelected: true,
        };
      }
    }

    props.onChangeFunction(newList);
  };

  return (
    <Grid container item xs={12}>
      {props.thumbnails.map((thumbnail: ThumbnailNode, i) => (
        <Grid item xs={4} className={classnames(classes.thumbnailRoot)}>
          {thumbnail.isSelected && (
          <CheckCircleIcon
            color="primary"
            fontSize="large"
            className={classes.checkIcon}
          />
          )}

          <img
            className={classnames(
              classes.thumbnailImg,
              { [classes.thumbnailHover]: !props.readOnly },
              { [classes.selectedThumbnail]: thumbnail.isSelected },
            )}
            key={thumbnail.thumbnailUrl}
            src={thumbnail.thumbnailUrl}
            alt=""
            onClick={() => {
              if (!props.readOnly) {
                handleThumbnailClick(i);
              }
            }}
          />
        </Grid>
      ))}
    </Grid>
  );
}
