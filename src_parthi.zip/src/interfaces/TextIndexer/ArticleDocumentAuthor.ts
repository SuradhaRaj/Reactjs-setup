import {
  Record, Number, String, Null, Static, Boolean,
} from 'runtypes';

export const ArticleDocumentAuthorValidator = Record({
  authorId: Number,
  firstName: String,
  middleName: String.Or(Null),
  lastName: String,
  orcidCode: String.Or(Null),
  roleTypeId: Number.Or(Null),
  roleType: String,
  createdBy: String,
  createdDate: String,
  affiliationId: Number.Or(Null),
  affiliation: String.Or(Null),
  isConference: Boolean.Or(Null),
});

type ArticleDocumentAuthor = Static<typeof ArticleDocumentAuthorValidator>;
export default ArticleDocumentAuthor;
