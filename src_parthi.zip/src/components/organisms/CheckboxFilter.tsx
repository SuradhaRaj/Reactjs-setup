import React from 'react';
import {
  Typography, Grid, FormControl, FormControlLabel, Checkbox, FormGroup, makeStyles, createStyles,
} from '@material-ui/core';
import Skeleton from '@material-ui/lab/Skeleton';
import { random } from 'lodash';

const useStyles = makeStyles(() => createStyles({
  checkboxRoot: {
    '& .MuiTypography-root': {
      fontSize: '0.8rem',
    },
    '& .MuiSvgIcon-root': {
      width: '0.8em',
      height: '0.8em',
    },
    '& .MuiIconButton-root': {
      padding: 0,
      paddingLeft: 9,
      paddingRight: 9,
    },
    '& .MuiCheckbox-colorPrimary.Mui-checked:hover': {
      background: 'none',
    },
  },
  checkbox: {
    '&:hover': {
      background: 'none',
    },
  },
  title: {
    fontSize: '0.8rem',
  },
}));

interface Props {
  title: string;
  options: Array<string>;
  selectedOptions: Array<string>;
  onChange(newOptions: Array<string>): void;
  isLoading: boolean;
}

export default (props: Props) => {
  const classes = useStyles();

  const isChecked = (item: string) => props.selectedOptions.includes(item);

  const toggleCheckbox = (itemToChange: string, checked: boolean) => {
    if (checked) {
      props.onChange([...props.selectedOptions, itemToChange]);
    } else {
      props.onChange(props.selectedOptions.filter((item) => item !== itemToChange));
    }
  };

  return (
    <Grid item xs={12}>
      {!props.isLoading && (
      <FormControl component="fieldset">
        <Typography className={classes.title}>{props.title}</Typography>
        <FormGroup>
          {props.options.map((item) => (
            <FormControlLabel
              key={item}
              className={classes.checkboxRoot}
              control={<Checkbox data-checkbox className={classes.checkbox} color="primary" />}
              label={item}
              checked={isChecked(item)}
              onChange={(e: React.ChangeEvent<{}>, checked) => { toggleCheckbox(item, checked); }}

            />
          ))}

        </FormGroup>
      </FormControl>
      )}

      {props.isLoading && (
        <Grid container>
          <Grid item xs={12}>
            <Skeleton animation="wave" width={100} />
          </Grid>
          {
            [...Array(3)].map(() => (
              <>
                <Grid item xs={1}>
                  <Skeleton animation="wave" />
                </Grid>
                <Grid item xs={1} />
                <Grid item xs={10}>
                  <Skeleton animation="wave" width={random(100, 200)} />
                </Grid>
              </>
            ))
          }

        </Grid>
      )}
    </Grid>
  );
};
