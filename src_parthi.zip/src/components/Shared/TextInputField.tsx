/* eslint @typescript-eslint/no-explicit-any: 0 */
import React from 'react';
import {
  TextField, FormControl, createStyles, makeStyles,
} from '@material-ui/core';

const useStyles = makeStyles(() => createStyles({
  textInputField: {
    width: '100%',
  },

}));

interface TextInputFieldProps {
  labelText: string;
  inputText?: string | number | Date | null | undefined;
  required?: boolean;
  keyName: string;
  onChangeFunction: any;
  onBlur?: any;
  error: boolean;
  type?: string;
  errorMessage?: string;
  inputProps?: any;
  readOnly?: boolean;
  value?: string | number | Date | null | undefined;
  placeholder?: string;
  customHandleChangeFunction?: boolean;
}

const TextInputField = (props: TextInputFieldProps) => {
  const classes = useStyles();

  const handleChange = (event: any): void => {
    props.onChangeFunction(props.keyName, event.target.value);
  };

  return (
    <FormControl className={classes.textInputField}>
      <TextField
        InputLabelProps={{
          shrink: true,

        }}
        name={props.keyName}
        required={props.required}
        label={props.labelText}
        defaultValue={props.inputText}
        margin="normal"
        variant="outlined"
        onChange={(e: any) => (props.customHandleChangeFunction ? handleChange(e) : props.onChangeFunction(e))}
        onBlur={props.onBlur}
        error={props.error}
        type={props.type}
        helperText={props.error ? props.errorMessage : ''}
        inputProps={props.inputProps}
        disabled={props.readOnly}
        value={props.value}
        placeholder={props.placeholder}
      />
    </FormControl>
  );
};

export default TextInputField;
