export default interface GenreOption {
    id: number;
    name: string;
    // eslint-disable-next-line semi
}
