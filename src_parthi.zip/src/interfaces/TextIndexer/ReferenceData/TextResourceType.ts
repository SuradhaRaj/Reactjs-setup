import {
  Record, Number, String, Static, Array, Runtype, Lazy,
} from 'runtypes';

interface TextResourceTypeObj {
  resourceTypeID: number;
  name: string;
  displayOrder: number;
  children: TextResourceTypeObj[];
}

export const TextResourceTypeValidator: Runtype<TextResourceTypeObj> = Record({
  resourceTypeID: Number.withConstraint((n) => n > 0),
  name: String,
  displayOrder: Number,
  children: Lazy(() => Array(TextResourceTypeValidator)),
});

type TextResourceType = Static<typeof TextResourceTypeValidator>;
export default TextResourceType;
