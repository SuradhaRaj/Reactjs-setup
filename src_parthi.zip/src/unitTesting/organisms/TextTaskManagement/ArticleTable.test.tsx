import { shallow } from 'enzyme';
import React from 'react';
import TextTaskManagementArticleTask from '../../../interfaces/TaskManagementText/TextTaskManagementArticleTask';
import ArticleTaskTable, { ArticleTaskRow } from '../../../components/organisms/TextTaskManagement/ArticleTaskTable';
import WorkflowStatus from '../../../interfaces/enums/WorkflowStatus';

describe('Article table', () => {
  it('should render the correct number of rows', () => {
    const data: TextTaskManagementArticleTask[] = [
      {
        artifactId: 1,
        articleTitle: 'Removal of Radioactive Element from Respiratory Tract, Open Approach',
        grouping: 'Seldom',
        publisher: 'Dabjam',
        delivered: Date.now.toString(),
        manager: 'MY',
        publisherNotes: '',
        indexerNotes: 'Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante.',
        indexer: 'Elita Seagrave',
        title: 'envisioneer dynamic schemas',
        workflowStatusId: WorkflowStatus.ReadyForIndexing,
        indexingCompany: 'Test Company',
        dateOfPublication: Date.now.toString(),
        resourceId: 'Test',
        rmitNumber: '',
      }, {
        artifactId: 2,
        articleTitle: 'Drainage of Left Shoulder Tendon, Open Approach',
        grouping: 'Weekly',
        publisher: 'Abata',
        delivered: Date.now.toString(),
        manager: 'UA',
        publisherNotes: 'Etiam faucibus cursus urna. Ut tellus.',
        indexerNotes: '',
        indexer: null,
        title: 'deploy turn-key e-markets',
        workflowStatusId: WorkflowStatus.ReadyForIndexing,
        indexingCompany: 'Test Company',
        dateOfPublication: Date.now.toString(),
        resourceId: 'Test',
        rmitNumber: '',
      }, {
        artifactId: 3,
        articleTitle: 'Insertion of Infusion Device into Head and Neck Subcutaneous Tissue and Fascia, Percutaneous Approach',
        grouping: 'Seldom',
        publisher: 'Katz',
        delivered: Date.now.toString(),
        manager: 'CN',
        publisherNotes: 'In tempor, turpis nec euismod scelerisque, quam turpis adipiscing lorem, vitae mattis nibh ligula nec sem. Duis aliquam convallis nunc.',
        indexerNotes: '',
        indexer: null,
        title: 'reinvent plug-and-play experiences',
        workflowStatusId: WorkflowStatus.ReadyForIndexing,
        indexingCompany: 'Test Company',
        dateOfPublication: Date.now.toString(),
        resourceId: 'Test',
        rmitNumber: '',
      },
    ];
    const wrapper = shallow(<ArticleTaskTable rows={data} canUnlock={false} onUpdate={() => undefined} />);
    expect(wrapper.find(ArticleTaskRow)).toHaveLength(3);
  });
});
