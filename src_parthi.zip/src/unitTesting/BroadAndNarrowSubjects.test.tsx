/* eslint-disable @typescript-eslint/no-empty-function */

import React from 'react';
import { mount } from 'enzyme';
import BroadAndNarrowSubjects from '../components/molecules/MediaIndexer/BroadAndNarrowSubjects';

describe('Terms Typedown Tests', () => {
  it('should display the number of remaining selections left', () => {
    const wp = mount((
      <BroadAndNarrowSubjects
        broadSubjectLookup={[]}
        selectedBroadSubjects={
          [
            {
              id: 1,
              name: 'Broad Subject 1',
              createdBy: '',
              createdDate: '',
            },
            {
              id: 2,
              name: 'Broad Subject 2',
              createdBy: '',
              createdDate: '',
            },
          ]
        }
        selectedNarrowSubjects={
          [
            {
              id: 1,
              name: 'Narrow Subject 1',
              createdBy: '',
              createdDate: '',
            },
          ]
        }
        broadSubjectKey="broadSubject"
        narrowSubjectKey="narrowSubject"
        readOnly={false}
        onChangeBroadSubjectFunction={() => {}}
        onChangeNarrowSubjectFunction={() => {}}
        broadSubjectError={false}
        narrowSubjectError={false}
        broadSubjectTypedownLimit={4}
        narrowSubjectTypedownLimit={4}
      />
    ));

    // number of remaining selections should be displayed
    // Broad
    expect(wp.find('[data-remaining]').at(0).text()).toBe('2');

    // Narrow
    expect(wp.find('[data-remaining]').at(1).text()).toBe('3');
  });
});
