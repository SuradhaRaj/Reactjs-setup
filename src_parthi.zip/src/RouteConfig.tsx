import React from 'react';
import Error404 from './components/pages/Error404';
import SearchBar from './components/molecules/SearchBar';

export default [
  {

    path: '/',
    component: React.lazy(() => import('./components/pages/Dashboard')),
    header: SearchBar,
    exact: true,
  },
  {
    path: '/resource-management',
    component: React.lazy(() => import('./components/pages/ResourceManagement')),
    header: SearchBar,
    exaxt: true,
  },

  {
    path: '/signin-oidc',
    component: React.lazy(() => import('./components/pages/Dashboard')),
    header: SearchBar,
    exact: true,
  },
  {
    path: '/Signout',
    component: React.lazy(() => import('./components/Signout')),
    header: SearchBar,
    exact: true,
  },
  {
    path: '/search',
    component: React.lazy(() => import('./components/pages/Search')),
    header: SearchBar,
  },
  {
    path: '/tasks/media',
    component: React.lazy(() => import('./components/pages/TaskManagement')),
    header: SearchBar,
    exact: true,
  },
  {
    path: '/tasks/text',
    component: React.lazy(() => import('./components/pages/TextTaskManagement')),
    header: SearchBar,
    exact: true,
  },
  {
    path: '/partner/:partnerId/resources',
    component: React.lazy(() => import('./components/pages/ResourcesList')),
    header: SearchBar,
    exact: true,
  },
  {
    path: '/resources/:resId',
    component: React.lazy(() => import('./components/pages/Resource')),
    header: SearchBar,
    exact: true,
  },
  {
    path: '/resources/:resId/addIssue',
    component: React.lazy(() => import('./components/pages/Issue')),
    header: SearchBar,
    exact: true,
  },
  {
    path: '/issues/:issueId/:tabIndex?',
    component: React.lazy(() => import('./components/pages/Issue')),
    header: SearchBar,
    exact: true,
  },
  {
    path: '/artifact/:artifactid',
    component: React.lazy(() => import('./components/pages/IndexerArtifact')),
    header: SearchBar,
  },
  {
    path: '/partner/:partnerId',
    component: React.lazy(() => import('./components/pages/Organisation')),
    header: SearchBar,
    exact: true,
  },
  {
    path: '/',
    component: Error404,
    header: SearchBar,
  },

];
