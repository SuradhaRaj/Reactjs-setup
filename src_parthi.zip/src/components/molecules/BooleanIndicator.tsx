import React from 'react';
import {
  makeStyles, Theme, createStyles, Chip,
} from '@material-ui/core';
import classnames from 'classnames';
import CheckIcon from '@material-ui/icons/Check';
import ClearIcon from '@material-ui/icons/Clear';

interface Props {
  name: string;
  status: boolean | null;
  className?: string;
}

const BooleanIndicator = (props: Props) => {
  const classes = makeStyles((theme: Theme) => createStyles({
    chip: {
      borderRadius: 8,
      '& .MuiChip-icon': {
        color: 'inherit',
      },
    },
    false: {
      background: theme.palette.grey[600],
      color: theme.palette.common.white,
    },
    true: {
      background: theme.palette.success.light,
      color: theme.palette.error.contrastText,
    },
  }))();
  return (
    <Chip
      icon={props.status ? (<CheckIcon />) : (<ClearIcon />)}
      title={props.name}
      label={props.name}
      className={classnames(props.className, classes.chip, { [classes.true]: props.status, [classes.false]: !props.status })}
    />
  );
};

export default BooleanIndicator;
