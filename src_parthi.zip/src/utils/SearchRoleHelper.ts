import { uniq } from 'lodash';
import UserInfo from '../classes/UserInfo';
import ArtifactSearchIndex from '../interfaces/enums/ArtifactSearchIndex';
import Role from '../interfaces/Role';

type RoleIndexMapping = {
  [roleName in Role]: ArtifactSearchIndex[];
}

const mapping: RoleIndexMapping = {
  Indexer: [],
  MediaIndexer: [ArtifactSearchIndex.Media],
  TextIndexer: [ArtifactSearchIndex.Article],
  IndexersAdmin: [],
  InformitAdmin: [ArtifactSearchIndex.Media, ArtifactSearchIndex.Article, ArtifactSearchIndex.Organisation, ArtifactSearchIndex.Title],
  TextEduIndexer: [ArtifactSearchIndex.Article],
  TextLgealIndexer: [ArtifactSearchIndex.Article],
  IssueSplitter: [ArtifactSearchIndex.Issue, ArtifactSearchIndex.Article],
};

const getAvailableIndexes = (user: UserInfo): ArtifactSearchIndex[] => {
  let allowedIndexes: ArtifactSearchIndex[] = [];

  Object.keys(mapping).forEach((value: string) => {
    const roleName: Role = value as Role;
    if (user.isInRole(roleName)) {
      allowedIndexes = [...allowedIndexes, ...mapping[roleName]];
    }
  });

  return uniq(allowedIndexes);
};

const getInitialIndex = (user: UserInfo): ArtifactSearchIndex => {
  const indexes = getAvailableIndexes(user);
  if (indexes.length > 0) {
    return indexes[0];
  }
  // this will not actually allow the user to see them all
  return ArtifactSearchIndex.All;
};

export default {
  getInitialIndex,
  getAvailableIndexes,
};
