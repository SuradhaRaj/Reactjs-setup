import React from 'react';
import { shallow } from 'enzyme';
import SearchResults from '../../../components/organisms/Search/SearchResults';
import MediaSearchResult from '../../../interfaces/Search/MediaSearchResult';
import TextSearchResult from '../../../interfaces/Search/TextSearchResult';
import ArtifactSearchIndex from '../../../interfaces/enums/ArtifactSearchIndex';
import SearchResult from '../../../interfaces/Search/SearchResult';
import MediaResult from '../../../components/organisms/Search/MediaResult';
import TextResult from '../../../components/organisms/Search/TextResult';

describe('Search results', () => {
  it('should render the correct number of media items', () => {
    const mediaItems: MediaSearchResult[] = [
      {
        broadcastDate: '10 Apr 2020', channel: 'Channel', masId: 'RMIT1', id: 4, indexer: '', itemTitle: '', searchIndex: ArtifactSearchIndex.Media, programTitle: '', workflowState: '',
      },
      {
        broadcastDate: '10 Apr 2020', channel: 'Channel', masId: 'RMIT1', id: 5, indexer: '', itemTitle: '', searchIndex: ArtifactSearchIndex.Media, programTitle: '', workflowState: '',
      },
      {
        broadcastDate: '10 Apr 2020', channel: 'Channel', masId: 'RMIT1', id: 6, indexer: '', itemTitle: '', searchIndex: ArtifactSearchIndex.Media, programTitle: '', workflowState: '',
      },
    ];

    const searchItems: SearchResult[] = [...mediaItems];

    const wrapper = shallow(<SearchResults isLoading={false} results={searchItems} updateItem={() => undefined} />);
    expect(wrapper.find(MediaResult)).toHaveLength(3);
  });

  it('should render the correct number of text items', () => {
    const articleItems: TextSearchResult[] = [
      {
        grouping: 'Group1', workflowState: 'State1', searchIndex: ArtifactSearchIndex.Article, id: 1, indexer: '', itemTitle: 'Title', masId: '123', publicationYear: '2020', publisher: 'Publisher', resourceTitle: 'title name',
      },
      {
        grouping: 'Group1', workflowState: 'State1', searchIndex: ArtifactSearchIndex.Article, id: 2, indexer: '', itemTitle: 'Title', masId: '123', publicationYear: '2020', publisher: 'Publisher', resourceTitle: 'title name',
      },
    ];

    const searchItems: SearchResult[] = [...articleItems];

    const wrapper = shallow(<SearchResults isLoading={false} results={searchItems} updateItem={() => undefined} />);
    expect(wrapper.find(TextResult)).toHaveLength(2);
  });

  it('should show the loading animation', () => {
    const articleItems: TextSearchResult[] = [
      {
        grouping: 'Group1', workflowState: 'State1', searchIndex: ArtifactSearchIndex.Article, id: 1, indexer: '', itemTitle: 'Title', masId: '123', publicationYear: '2020', publisher: 'Publisher', resourceTitle: 'title name',
      },
      {
        grouping: 'Group1', workflowState: 'State1', searchIndex: ArtifactSearchIndex.Article, id: 2, indexer: '', itemTitle: 'Title', masId: '123', publicationYear: '2020', publisher: 'Publisher', resourceTitle: 'title name',
      },
    ];

    const searchItems: SearchResult[] = [...articleItems];

    const wrapper = shallow(<SearchResults isLoading results={searchItems} updateItem={() => undefined} />);
    expect(wrapper.find('[data-loading-group]').length).toBeGreaterThan(0);
  });

  it('show the no results paper', () => {
    const wrapper = shallow(<SearchResults isLoading={false} results={[]} updateItem={() => undefined} />);
    expect(wrapper.find('[data-no-results]')).toHaveLength(1);
  });
});
