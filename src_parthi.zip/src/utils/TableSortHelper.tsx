import React from 'react';

export type Order = 'asc' | 'desc';

const defaultExport = {
  desc<T>(a: T, b: T, orderBy: (keyof T) | undefined) {
    if (orderBy === undefined) {
      return 0;
    }

    if (b[orderBy] < a[orderBy]) {
      return -1;
    }
    if (b[orderBy] > a[orderBy]) {
      return 1;
    }
    if ((b[orderBy] === null || b[orderBy] === undefined) && (a[orderBy] !== null && a[orderBy] !== undefined)) {
      return -1;
    }
    if ((b[orderBy] !== null && b[orderBy] !== undefined) && (a[orderBy] === null || a[orderBy] === undefined)) {
      return 1;
    }
    return 0;
  },
  stableSort<T>(array: T[], cmp: (a: T, b: T) => number) {
    const stabilizedThis = array.map((el, index) => [el, index] as [T, number]);
    stabilizedThis.sort((a, b) => {
      const order = cmp(a[0], b[0]);
      if (order !== 0) return order;
      return a[1] - b[1];
    });
    return stabilizedThis.map((el) => el[0]);
  },

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  getSorting<K extends keyof any, T>(
    order: Order,
    orderBy: (K | undefined),
  ): (a: { [key in K]: T}, b: { [key in K]: T }) => number {
    return order === 'desc' ? (a, b) => this.desc(a, b, orderBy) : (a, b) => -this.desc(a, b, orderBy);
  },
};

export const useSort = function useSort<T>(data: Array<T>) {
  const [order, setOrder] = React.useState<Order>('asc');
  const [orderBy, setOrderBy] = React.useState<(keyof T) | undefined>(undefined);

  const handleRequestSort = (event: React.MouseEvent<unknown>, property: keyof T) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const sorting = defaultExport.getSorting(order, orderBy);
  let orderedData = data;
  orderedData = defaultExport.stableSort<T>(data, sorting);

  return {
    handleRequestSort, order, orderBy, orderedData,
  };
};

export default defaultExport;
