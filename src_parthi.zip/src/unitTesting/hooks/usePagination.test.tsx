import React from 'react';
import { shallow } from 'enzyme';
import usePagination from '../../components/hooks/usePagination';
import HookWrapper from './HookWrapper';

type usePaginationReturn = ReturnType<typeof usePagination>;

const data = ['Item1', 'Item2', 'Item3', 'Item4', 'Item5', 'Item6'];

describe('usePagination hook', () => {
  it('should return the first page of results for getInitialPage', () => {
    const wrapper = shallow(<HookWrapper hook={() => usePagination({ resultsPerPage: 2 })} />);
    const hook = wrapper.find('div').prop('data-hook') as usePaginationReturn;

    const result = hook.getInitialPage(data);
    expect(result).toHaveLength(2);
    expect(result[0]).toBe('Item1');
    expect(result[1]).toBe('Item2');
  });

  it('should return the nth page of results for getNextPage', () => {
    const wrapper = shallow(<HookWrapper hook={() => usePagination({ resultsPerPage: 2 })} />);
    const hook = wrapper.find('div').prop('data-hook') as usePaginationReturn;

    const result = hook.getNextPage(data);
    expect(result).toHaveLength(2);
    expect(result[0]).toBe('Item3');
    expect(result[1]).toBe('Item4');
  });
  it('should set the page number to page 2 for reset', () => {
    const wrapper = shallow(<HookWrapper hook={() => usePagination({ resultsPerPage: 2 })} />);
    const hook = wrapper.find('div').prop('data-hook') as usePaginationReturn;

    let _ = hook.getNextPage(data); // get page 2
    _ = hook.getNextPage(data); // get page 3
    hook.reset();

    const result = hook.getNextPage(data); // get page 2
    expect(result).toHaveLength(2);
    expect(result[0]).toBe('Item3');
    expect(result[1]).toBe('Item4');
  });
});
