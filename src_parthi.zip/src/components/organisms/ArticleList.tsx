/* eslint-disable max-len */
import React from 'react';
import {
  makeStyles, Theme, createStyles, useTheme,
} from '@material-ui/core/styles';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import ErrorIcon from '@material-ui/icons/Error';
import LockIcon from '@material-ui/icons/Lock';
import { Tooltip, Paper, Typography } from '@material-ui/core';
import Scrollbars from 'react-custom-scrollbars';
import Axios, { AxiosResponse } from 'axios';
import { Static } from 'runtypes';
import ArticleStatus from '../../interfaces/enums/ArticleStatus';
import SmallChip from '../molecules/SmallChip';
import ExtraRequest from '../../interfaces/TextIndexer/ExtraRequest';
import { FileValidator } from '../../interfaces/TextIndexer/IssueArtifact';
import DownloadFilesList from './TextIndexer/DownloadFilesList';

export interface ArticleStep {
  title: string;
  fallbackTitle: string;
  id: number;
  status: ArticleStatus;
  indexer?: string;
  workflowStatus: string;
}

interface ArticleQueueProps {
  articles: ArticleStep[];
  activeArticleId: number;
    handleChange(id: number): void;
    issuePath: string;

}

interface State {
    extraFiles: Static<typeof FileValidator>[];
}

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    width: '100%',
    zIndex: 1000,
    // opacity: 0.3,
    transition: 'all 0.8s',
    position: 'relative',
    marginTop: 60,
    height: '100%',
    '& .MuiPaper-root': {
      background: 'none',
      transition: 'all 0.5s',
      boxShadow: 'none',
      width: 350,
      opacity: 1,
      '& $stepTitle': {
        maxWidth: 280,
      },
      '& .MuiPaper-root': {
        background: 'white',
      },
      '& $overlay': {
        opacity: 0.4,
      },
      '& $workflowStatus': {
        height: 20,
        visibility: 'visible',
      },
    },
  },
  button: {
    marginTop: theme.spacing(1),
    marginRight: theme.spacing(1),
  },
  actionsContainer: {
    marginBottom: theme.spacing(2),
  },
  resetContainer: {
    padding: theme.spacing(3),
  },
  step: {
    cursor: 'pointer',
    paddingBottom: '8px',
  },
  stepTitle: {
    maxWidth: 64,
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    transition: 'all 0.8s',
  },
  stepperContainer: {
    position: 'sticky',
    top: 108,
  },
  stepper: {
    padding: 0,
    paddingRight: theme.spacing(2),
  },
  paper: {
    position: 'relative',
    height: '100%',
    padding: theme.spacing(2),
  },
  tocTitle: {
    textAlign: 'right',
    marginBottom: theme.spacing(2),
  },
  overlay: {
    position: 'fixed',
    top: 0,
    bottom: 0,
    right: 0,
    left: 0,
    background: 'black',
    opacity: 0,
    transition: 'all 0.2s',
    pointerEvents: 'none',
  },
  workflowStatus: {
    height: 0,
    visibility: 'hidden',
    transition: 'all 0.4s',
  },
  activeStepTitle: {
    fontWeight: 'bold',
  },
}));

const useStepIconStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    display: 'flex',
    height: 22,
    alignItems: 'center',
    position: 'relative',
  },
  circle: {
    width: 20,
    height: 20,
    borderRadius: '50%',
    backgroundColor: theme.palette.primary.main,
  },
  step: {
    zIndex: 1,
    fontSize: 18,
    display: 'flex',
    height: 22,
    alignItems: 'center',
  },
}));

function StepIcon(status: ArticleStatus, indexer?: string): JSX.Element {
  const classes = useStepIconStyles();
  const theme = useTheme();

  switch (status) {
    case ArticleStatus.Available:
      return (
        <div className={classes.step} style={{ paddingLeft: '2px', paddingRight: '2px' }}>
          <div className={classes.circle} />
        </div>
      );

    case ArticleStatus.Complete:
      return (
        <div className={classes.step}>
          <CheckCircleIcon htmlColor={theme.palette.success.main} />
        </div>
      );

    case ArticleStatus.Locked:
      return (
        <div className={classes.step}>
          <Tooltip title={indexer ?? ''}><LockIcon htmlColor="black" /></Tooltip>
        </div>
      );

    case ArticleStatus.Error:
      return (
        <div className={classes.step}>
          <ErrorIcon color="secondary" />
        </div>
      );

    default:
      return (
        <>
        </>
      );
  }
}

const ArticleList: React.FC<ArticleQueueProps> = (props) => {
  const classes = useStyles();
  const issuePath = props.issuePath;
  let activeStep = 0;
  const [state, setState] = React.useState<State>({
    extraFiles: [],
  });
  React.useEffect(() => {
    Axios.get<ExtraRequest[]>(`${process.env.REACT_APP_API_URL}/api/issue/getextrafiles?IssuePath=${issuePath}`).then((extraResponse: AxiosResponse<ExtraRequest[]>) => {
      const newDownloadExtraFiles: Static<typeof FileValidator>[] = [];

      extraResponse.data.forEach((file) => {
        newDownloadExtraFiles.push({
          filename: file.filename,
          size: file.fileSize,
          date: '',
          isExisted: true, // this field is not used in this page.
        });
      });

      setState({
        ...state,
        extraFiles: newDownloadExtraFiles,
      });
    });
  }, []);

  for (let i = 0; i < props.articles.length; i++) {
    if (props.articles[i].id === props.activeArticleId) {
      activeStep = i;
    }
  }

  return (
    <>
      <div className={classes.root}>
        <div className={classes.overlay} />
        <Paper className={classes.paper}>
          <div className={classes.stepperContainer}>

            <div style={{ width: '250px' }}>
              <Typography variant="overline">Extra Files</Typography>
              <DownloadFilesList
                files={state.extraFiles}
                issuePath={issuePath}
                mode="extra"
              />
            </div>
            <div className={classes.tocTitle}>
              <Typography variant="overline">ISSUE NAV</Typography>
            </div>

            <Scrollbars autoHeight autoHeightMax="70vh" autoHide style={{ overflowX: 'hidden' }}>
              <Stepper className={classes.stepper} nonLinear activeStep={activeStep} orientation="vertical">
                {props.articles.map((step: ArticleStep, i) => (
                  <Step key={step.id} className={classes.step}>
                    <StepLabel StepIconComponent={() => StepIcon(step.status, step.indexer)} onClick={() => props.handleChange(step.id)}>
                      <div className={classes.activeStepTitle}>
                        <Tooltip title={step.title}>
                          <>
                            {step.title ? (
                              <>
                                {i === activeStep ? (
                                  <span className={classes.activeStepTitle}>{step.title}</span>
                                ) : (<span>{step.title}</span>)}
                              </>
                            ) : (
                              <>
                                {i === activeStep ? (
                                  <span className={classes.activeStepTitle}>{step.fallbackTitle}</span>
                                ) : (<span>{step.fallbackTitle}</span>)}
                              </>
                            )}
                          </>
                        </Tooltip>
                      </div>
                      <div className={classes.workflowStatus}>
                        <SmallChip label={step.workflowStatus} />
                      </div>
                    </StepLabel>
                  </Step>
                ))}
              </Stepper>
            </Scrollbars>
          </div>
        </Paper>
      </div>
    </>
  );
};

export default ArticleList;
