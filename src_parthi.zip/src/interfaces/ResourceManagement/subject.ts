import { Record, Static } from 'runtypes';
import { custLookupOptionValidator } from './customLookup';
import { ArrayWithElements } from '../../runtypeTypes';

export const SubjectDataValidatior = Record({
  fasttermLookup: ArrayWithElements(custLookupOptionValidator),
  fastGeoLookup: ArrayWithElements(custLookupOptionValidator),
  subjectLC: ArrayWithElements(custLookupOptionValidator),
  identifierlookup: ArrayWithElements(custLookupOptionValidator),
});

type subjectData = Static<typeof SubjectDataValidatior>;
export default subjectData;
