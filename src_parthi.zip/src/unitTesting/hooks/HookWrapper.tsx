import React from 'react';

export default (props: {hook(): void}): JSX.Element => {
  const hook = props.hook ? props.hook() : undefined;
  return (<div data-hook={hook} />);
};
