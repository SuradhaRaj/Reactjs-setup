import React from 'react';
import { mount } from 'enzyme';
import LongTextInputField from '../components/Shared/LongTextInputField';

const wrapper = mount(
  <LongTextInputField
    labelText="This is a test label"
    inputText="This is test input text"
    keyName=""
    onChangeFunction={() => undefined}
  />,
);

describe('LongTextInputField Tests', () => {
  it('should display label that is passed into props', () => {
    expect(
      wrapper.contains('This is a test label'),
    ).toBe(true);
  });
});
