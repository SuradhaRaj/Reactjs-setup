import React from 'react';
import {
  Dialog, useTheme, useMediaQuery, DialogTitle, DialogContent, DialogContentText, DialogActions, Button,
} from '@material-ui/core';

interface DialogBoxProps {
  open: boolean;
  id: number;
  title: string;
  content: string;
  handleCloseFunction: Function;
  handleAddOptionFunction: Function;
}

export default function WarningDialogBox(props: DialogBoxProps): JSX.Element {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('sm'));

  return (
    <Dialog
      fullScreen={fullScreen}
      open={props.open}
      onClose={() => props.handleCloseFunction()}
      aria-labelledby="responsive-dialog-title"
    >
      <DialogTitle id="responsive-dialog-title">{props.title}</DialogTitle>
      <DialogContent>
        <DialogContentText>
          <p><strong>Here is the definition of the FAST Term you have selected:</strong></p>
          <p>{props.content}</p>
          <br />
          <p><strong>Do you still wish to add this FAST Term?</strong></p>
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button autoFocus onClick={() => props.handleCloseFunction()} color="primary">
          No
        </Button>
        <Button onClick={() => props.handleAddOptionFunction(props.title, props.id)} color="primary" autoFocus>
          Yes
        </Button>
      </DialogActions>
    </Dialog>
  );
}
