import * as Yup from 'yup';
import * as Schemas from '../validationSchemas/TextIndexingValidationSchema';
import WorkflowStatus from '../interfaces/enums/WorkflowStatus';

interface CombinedSchemaData {
  schemaNames: string[];
  schema: Yup.ObjectSchema;
};

const GetSchema = (workflowStatus: WorkflowStatus): CombinedSchemaData => {
  // Use .concat() to combine schemas

  const returnSchemaData: CombinedSchemaData = {
    schemaNames: [],
    schema: Yup.object(),
  };

  switch (workflowStatus) {
    // case WorkflowStatus.AdvancedIndexingInProgress:
    //   returnSchemaData.schema = Schemas.ArtifactIndexingSchema.concat(Schemas.AdvancedIndexingSchema);
    //   returnSchemaData.schemaNames = ['Standard', 'Advanced'];
    //   break;

    case WorkflowStatus.LegalIndexingInProgress:
      returnSchemaData.schema = Schemas.ArtifactIndexingSchema.concat(Schemas.AdvancedIndexingSchema).concat(Schemas.LegalIndexingSchema);
      returnSchemaData.schemaNames = ['Standard', 'Advanced', 'Legal'];
      break;

    case WorkflowStatus.IndexingInProgress:
    default:
      returnSchemaData.schema = Schemas.ArtifactIndexingSchema;
      returnSchemaData.schemaNames = ['Standard'];
      break;
  }

  return returnSchemaData;
};

export default {
  GetSchema,
};
