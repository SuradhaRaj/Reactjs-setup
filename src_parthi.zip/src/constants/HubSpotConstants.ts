export const hubSpotOrganisationLink = (hubSpotId: number): string => `https://app.hubspot.com/contacts/6292970/company/${hubSpotId}`;

export const hubSpotContactLink = (hubSpotId: number): string => `https://app.hubspot.com/contacts/6292970/contact/${hubSpotId}`;
