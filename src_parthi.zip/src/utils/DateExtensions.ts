import { DateTime } from 'luxon';

const convertDateToFormFormat = (date: string | null): string | null => (
  date && DateTime.isDateTime(DateTime.fromISO(date)) ? DateTime.fromISO(date).toFormat("yyyy'-'MM'-'dd") : null
);

const convertLiveDateTimeToFormFormat = (date: string | null): string | null => (
  date && DateTime.isDateTime(DateTime.fromISO(date, { zone: 'UTC' })) ? DateTime.fromISO(date, { zone: 'UTC' }).toLocal().toFormat("yyyy'-'MM'-'dd'T'HH':'mmZZ") : null
);

const convertSQLDateToFormFormat = (date: string | null): string | null => (
  date && DateTime.isDateTime(DateTime.fromISO(date, { zone: 'UTC' })) ? DateTime.fromISO(date, { zone: 'UTC' }).toLocal().toFormat("yyyy'-'MM'-'dd'T'HH':'mm':'ssZZ") : null
);

const convertFormDatesToIso = (formDate: string | null) => (
  formDate && DateTime.isDateTime(DateTime.fromFormat(formDate, "yyyy'-'MM'-'dd"))
    ? DateTime.fromFormat(formDate, "yyyy'-'MM'-'dd").toISO()
    : null
);

export default {
  convertDateToFormFormat,
  convertFormDatesToIso,
  convertSQLDateToFormFormat,
  convertLiveDateTimeToFormFormat,
};
