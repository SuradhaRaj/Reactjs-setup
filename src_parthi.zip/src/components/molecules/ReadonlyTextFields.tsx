import React from 'react';
import { Grid } from '@material-ui/core';
import ReadOnlyTextField from '../Shared/ReadOnlyTextField';

interface ReadonlyTextFieldsProps {
  fields: Array<{label: string; displayText: string | number | null}>;
  oneLine?: boolean;
}

const ReadonlyTextFields = (props: ReadonlyTextFieldsProps) => (
  <Grid container>
    {props.fields.map((field) => (
      <>
        {field.displayText ? (
          <Grid item xs={3}>
            <ReadOnlyTextField
              labelText={field.label}
              displayText={field.displayText}
              oneLine={props.oneLine || false}
            />
          </Grid>
        ) : (null)}
      </>
    ))}
  </Grid>
);

export default ReadonlyTextFields;
