import React, { useEffect, useState } from 'react';
import {
  Typography,
  Grid,
  Card,
  makeStyles,

} from '@material-ui/core';
import { useTypedSelector } from '../../../store/store';

interface OrganizationIState {
  organisationName: string|null;
  organisationId: number|null;
  companyWebsite: string|null;
}

type NewType = boolean;

interface Props {
  isLoading: NewType;
}

const useStyles = makeStyles({
  resourceIdeContainer: {
    paddingBottom: '20',
    backgroundColor: '#cacaca',
  },

  heading: {
    'font-size': '13px',
    'font-weight': '500',
    'text-transform': 'none',
    color: '#000000',
  },
  value: {
    'font-size': '13px',
    color: '#666666',
    'font-weight': '500',
  },
  label: {
    'font-size': '13px',
    color: '#000000',
    'font-weight': '500',
  },
});

function Organisation(_props: Props): JSX.Element {
  const classes = useStyles();
  const getResourceData = useTypedSelector((store) => store.ResourceDataOnId.ResourceOrganization);
  const [organizationData, setorganizationData] = useState<OrganizationIState>({
    organisationName: '-',
    organisationId: null,
    companyWebsite: '-',
  });
  useEffect(() => {
    if (getResourceData != null) {
      setorganizationData((prevState) => ({
        ...prevState,
        organisationName: getResourceData.organisationName === '' ? '-' : getResourceData.organisationName,
        organisationId: getResourceData.organisationId,
        companyWebsite: getResourceData.organisationWebsite === '' ? '-' : getResourceData.organisationWebsite,
      }));
    }
  }, [getResourceData]);
  return (
    <div className="organisation_Container">
      <Card
        variant="outlined"
        className="resourceIdeContainer"
        style={{
          marginLeft: 20,
          marginRight: 20,
          paddingBottom: 20,
          marginTop: 20,
        }}
      >
        <Grid item xs={12} style={{ textAlign: 'left' }}>
          <Typography
            className={classes.heading}
            variant="overline"
            style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
          >
            Organisation
          </Typography>
        </Grid>
        <Grid
          container
          spacing={2}
          style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
        >
          <Grid item xs={4}>
            <Grid container>
              <Grid item xs={5}>
                <span className={classes.label}>
                  Organisation Name:
                </span>
              </Grid>
              <Grid item xs={7}>
                <span className={classes.value}>{organizationData.organisationName}</span>
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={4}>
            <Grid container>
              <Grid item xs={5}>
                <span className={classes.label}>OrganisationID:</span>
              </Grid>
              <Grid item xs={7}>
                <span className={classes.value}>{organizationData.organisationId}</span>
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={4}>
            <Grid container>
              <Grid item xs={5}>
                <span className={classes.label}>Company Website:</span>
              </Grid>
              <Grid item xs={7}>
                <span className={classes.value}>{organizationData.companyWebsite}</span>
                {/* <span className={classes.value} /> */}
              </Grid>
            </Grid>
          </Grid>

        </Grid>
      </Card>
    </div>
  );
}

export default Organisation;
