import {
  Record, Array as RtArray, Static, String, Number, Undefined,
} from 'runtypes';
import { some } from 'lodash';
import Filters from './Filters';
import { KeyValue } from '../interfaces/TaskManagementText/TextTaskManagementRequest';
import LookupOption, { LookupOptionValidator } from '../interfaces/LookupOption';
import { TypedownOption, StrStrTypedownOption } from '../interfaces/TypedownOption';

interface TitleInformationFiltersData {
    titleLeadingArticle: string;
    title: string;
    edition: string;
    alternativetitle: string;
    uniformtitle: Array<TypedownOption | StrStrTypedownOption>;
    language: Array<TypedownOption | StrStrTypedownOption>;
    frequency: Array<TypedownOption | StrStrTypedownOption>;
    lifestartdate: string;
    lifeenddate: string;
    titlenotes: string;
    seriesvolume: string;
}
const RuntypeDeclaration = Record({
  titleLeadingArticle: String,
  title: String,
  edition: String,
  alternativetitle: String,
  uniformtitle: RtArray(Record({ id: Number, value: String })).Or(Undefined),
  language: RtArray(Record({ id: Number, value: String })).Or(Undefined),
  frequency: RtArray(Record({ id: Number, value: String })).Or(Undefined),
  lifestartdate: String.withConstraint((d) => Math.max(0, parseInt(d)).toString().length <= 4 || 'Number with not more than 4 digits required'),
  lifeenddate: String.withConstraint((d) => Math.max(0, parseInt(d)).toString().length <= 4 || 'Number with not more than 4 digits required'),
  titlenotes: String,
  seriesvolume: String,
});
type TitleInformationFiltersDataRt = Static<typeof RuntypeDeclaration>;

class TitleInformationFilters extends Filters<TitleInformationFiltersData> {
  constructor(filterContent: TitleInformationFiltersDataRt) {
    try {
      RuntypeDeclaration.check(filterContent);
      super({
        titleLeadingArticle: filterContent.titleLeadingArticle === '' ? '' : filterContent.titleLeadingArticle,
        title: filterContent.title === '' ? '' : filterContent.title,
        edition: filterContent.edition === '' ? '' : filterContent.edition,
        alternativetitle: filterContent.alternativetitle === '' ? '' : filterContent.alternativetitle,
        uniformtitle: filterContent.uniformtitle === undefined ? [] : filterContent.uniformtitle,
        language: filterContent.language === undefined ? [] : filterContent.language,
        frequency: filterContent.frequency === undefined ? [] : filterContent.frequency,
        lifestartdate: filterContent.lifestartdate === '' ? '' : filterContent.lifestartdate,
        lifeenddate: filterContent.lifeenddate === '' ? '' : filterContent.lifeenddate,
        titlenotes: filterContent.titlenotes === '' ? '' : filterContent.titlenotes,
        seriesvolume: filterContent.seriesvolume === '' ? '' : filterContent.seriesvolume,
      });
    } catch (error) {
      console.error(error);
      throw error;
    }
  }

  static empty() {
    return new TitleInformationFilters({
      titleLeadingArticle: '',
      title: '',
      edition: '',
      alternativetitle: '',
      uniformtitle: [],
      language: [],
      frequency: [],
      lifestartdate: '',
      lifeenddate: '',
      titlenotes: '',
      seriesvolume: '',
    });
  }
}

export default TitleInformationFilters;
