import React from 'react';
import { Runtype } from 'runtypes';
import RuntypeErrorPaper from '../organisms/RuntypeError';

interface State {
  isValid: boolean;
  errorString: string|undefined;
  errorKey: string;
}

const useRuntypeError = <T extends Runtype>(validator: T) => {
  const [state, setState] = React.useState<State>({
    isValid: true,
    errorString: '',
    errorKey: '',
  });
  const validate = (data: unknown) => {
    const status = validator.validate(data);
    if (!status.success) {
      setState((prevState) => ({
        ...prevState,
        isValid: false,
        errorKey: status.key ?? 'unknown',
        errorString: status.message,
      }));
    }

    return status.success;
  };
  const error = () => {
    if (state.isValid) { return null; };
    return (<RuntypeErrorPaper data={{ [state.errorKey]: state.errorString }} />);
  };

  return {
    validate,
    isValid: state.isValid,
    error,
  };
};

export default useRuntypeError;
