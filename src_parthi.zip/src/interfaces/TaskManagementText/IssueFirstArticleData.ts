import {
  Record, String, Static, Null, Number,
} from 'runtypes';

export const IssueFirstArticleDataValidator = Record({
  articleTitle: String.Or(Null),

  artifactId: Number.Or(Null),
});

type IssueFirstArticleData = Static<typeof IssueFirstArticleDataValidator>
export default IssueFirstArticleData;
