import React from 'react';
import { shallow } from 'enzyme';
import { ValidationDialog, ValidationError } from '../components/molecules/MediaIndexer/ValidationDialog';

describe('Validation dialog', () => {
  it('should render the correct number of errors', () => {
    let wrapper = shallow(<ValidationDialog isOpen onProceed={() => undefined} onReturn={() => undefined} errors={[1]} />);
    expect(wrapper.find(ValidationError)).toHaveLength(1);

    wrapper = shallow(<ValidationDialog isOpen onProceed={() => undefined} onReturn={() => undefined} errors={[1, 2, 3]} />);
    expect(wrapper.find(ValidationError)).toHaveLength(3);

    wrapper = shallow(<ValidationDialog isOpen onProceed={() => undefined} onReturn={() => undefined} errors={[]} />);
    expect(wrapper.find(ValidationError)).toHaveLength(0);
  });
});
