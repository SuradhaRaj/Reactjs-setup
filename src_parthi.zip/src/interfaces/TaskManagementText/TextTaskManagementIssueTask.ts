import {
  Record, String, Static, Number, Null,
} from 'runtypes';
import { TextTaskManagementBaseTaskValidator } from './TextTaskManagementBaseTask';
import { IssueFirstArticleDataValidator } from './IssueFirstArticleData';

export const TextTaskManagementIssueTaskValidator = Record({
  issueId: Number,
  title: String,
  grouping: String,
  publisher: String.Or(Null),
  delivered: String.Or(Null),
  manager: String,
  files: Number,
  publisherNotes: String,
  indexerNotes: String,
  indexer: String.Or(Null),
  rmitNumber: String,
  resourceId: String,
  indexingCompany: String.Or(Null),
  dateOfPublication: String,
  scheduleDate: String,
  numberOfArticles: Number.Or(Null),
  firstArticle: IssueFirstArticleDataValidator.Or(Null),
}).And(TextTaskManagementBaseTaskValidator);

type TextTaskManagementIssueTask = Static<typeof TextTaskManagementIssueTaskValidator>
export default TextTaskManagementIssueTask;
