import { createMuiTheme } from '@material-ui/core';

import colors from './colors';

export default createMuiTheme(
  /**
   * @see https://material-ui.com/customization/themes/#theme-configuration-variables
   */
  {
    // direction: "rtl",
    typography: {
      fontFamily: ['Poppins', 'Roboto'].join(','),
    },

    palette: {
      contrastThreshold: 2,
      primary: {
        // light: will be calculated from palette.primary.main,
        main: colors.primary,
        // dark: will be calculated from palette.primary.main,
        // contrastText: will be calculated to contrast with palette.primary.main
      },
      secondary: {
        // light: will be calculated from palette.primary.main,
        main: colors.secondary,
        // dark: will be calculated from palette.primary.main,
        // contrastText: '#ffffff',
      },
      error: {
        // light: will be calculated from palette.primary.main,
        main: '#fd397a',
        // dark: will be calculated from palette.primary.main,
        // contrastText: will be calculated to contrast with palette.primary.main
      },
    },

    /**
       * @see https://material-ui.com/customization/globals/#default-props
       */
    props: {
      // Name of the component ⚛️
      MuiButtonBase: {
        // The properties to apply
        disableRipple: true, // No more ripple, on the whole application 💣!
      },

      // Set default elevation to 1 for popovers.
      MuiPopover: {
        elevation: 1,
      },

      MuiOutlinedInput: {
        notched: false,
      },
    },
    overrides: {
      MuiSkeleton: {
        root: {
          backgroundColor: 'rgba(0, 0, 0, 0.2)',
        },
      },
      MuiAutocomplete: {
        inputRoot: {
          '&&[class*="MuiOutlinedInput-root"] $input': {
            padding: 2,
          },
        },
      },
      MuiOutlinedInput: {
        multiline: {
          padding: '10px 14px',
          fontSize: '0.8rem',
        },
        input: {
          padding: '11px 14px',
          fontSize: '0.8rem',
        },
      },
      MuiSelect: {
        select: {
          padding: '9.5px 14px',
        },
      },
      MuiInputLabel: {
        root: {
          backgroundColor: 'white',
        },
        outlined: {
          transform: 'translate(14px, 14px) scale(1)',
          fontSize: '0.8rem',
        },
        shrink: {
          padding: '0px 5px',
          left: '-4px',
        },
      },
      MuiFormControl: {
        marginNormal: {
          marginTop: 12,
          marginBottom: 0,
        },
      },
    },
  },
);
