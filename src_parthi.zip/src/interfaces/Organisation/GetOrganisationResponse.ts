import OrganisationData from './OrganisationData';
import OrganisationContact from './OrganisationContact';
import LicenceTemplate from './LicenceTemplate';

interface GetOrganisationResponse {
  organisation: OrganisationData;
  licenceTemplates: LicenceTemplate[];
  contacts: OrganisationContact[];
}

export default GetOrganisationResponse;
