import {
  Record, String, Array as RtArray, Static,
} from 'runtypes';
import Role from '../interfaces/Role';

const UserInfoRuntype = Record({
  username: String,
  name: String,
  roles: RtArray(String),
});

type UserInfoData = Static<typeof UserInfoRuntype>;

class UserInfo {
  data: UserInfoData;

  constructor(userInfo: UserInfoData) {
    try {
      UserInfoRuntype.check(userInfo);
      this.data = userInfo;
    } catch (error) {
      console.error(`Unable to process UserInfoData. [${error.key} - ${error.message}]`, error);
      throw error;
    }
  }

  static empty() {
    return new UserInfo({ name: '', roles: [], username: '' });
  }

  isInRole(role: Role): boolean {
    return this.data.roles.includes(role);
  }

  isInAnyRole(rolesToCheck: Array<Role>): boolean {
    let allowed = false;
    rolesToCheck.forEach((role: Role) => {
      if (this.isInRole(role)) {
        allowed = true;
      }
    });

    return allowed;
  }
}

export default UserInfo;
