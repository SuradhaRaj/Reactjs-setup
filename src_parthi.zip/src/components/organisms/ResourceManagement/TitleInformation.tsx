/* eslint @typescript-eslint/no-explicit-any: 0 */
import React, { useEffect, useState } from 'react';
import {
  Typography,
  Grid,
  Divider,
  Drawer,
  Card,
  Button,
  Color,
  makeStyles,
  FormControl,
  FormLabel,
  FormHelperText,
  FormGroup,
  FormControlLabel,
  Box,
  Icon,
  Tooltip,
} from '@material-ui/core';
import { values } from 'lodash';
import {
  Formik, FormikConfig, FormikValues as Values, useFormik,
} from 'formik';
import { useDispatch } from 'react-redux';
import { id } from 'date-fns/locale';
import { array } from 'yup';
import TextInputField from '../../Shared/TextInputField';
import {
  updateFilters,
  clearFilters,
} from '../../../store/actions/ActnTextTaskManagement';
import { default as FiltersObj } from '../../../classes/TextTaskManagementFilters';
import TaskManagementFilterHelper from '../../../utils/TaskManagementFilterHelper';
import TypedownFilter from '../TypedownFilter';
import { useTypedSelector } from '../../../store/store';

import TextareaField from '../../Shared/TextareaField';
import DropdownOption from '../../../interfaces/MediaIndexer/DropdownOption';
import {
  LifeStartEndDate,
} from '../../../runtypeTypes';
import Dropdown from '../../Shared/Dropdown';
import LookupOption from '../../../interfaces/LookupOption';
import TitleInformationFilters from '../../../classes/TitleInformationFilters';
import { KeyValue } from '../../../interfaces/TaskManagementText/TextTaskManagementRequest';
import Typedown from '../Typedown';
import Resource from '../../../interfaces/ResourceManagement/Resource';
import { TypedownOption, StrStrTypedownOption } from '../../../interfaces/TypedownOption';

interface SelectedTitleInformation {
  titleLeadingArticle: string;
  title: string;
  edition: string;
  alternativetitle: string;
  uniformtitle: Array<TypedownOption | StrStrTypedownOption>;
  language: Array<TypedownOption | StrStrTypedownOption>;
  lifestartdate: string;
  lifeenddate: string;
  titlenotes: string;
  frequency: Array<TypedownOption | StrStrTypedownOption>;
  seriesvolume: string;
}

interface TitleInfoError {

  lifestarterror: boolean;
  lifeenderror: boolean;
}
interface FilterFields {
  uniformtitleId: number;
  languageId: number;
  frequencyId: number;
}

type NewType = boolean;

interface Props {
  isLoading: NewType;
}

const useStyles = makeStyles({
  resourceIdeContainer: {
    paddingBottom: '20',
  },

  heading: {
    'font-size': '13px',
    'font-weight': '500',
    'text-transform': 'none',
    color: '#000000',
  },
});

function TitleInformation(props: any): JSX.Element {
  const classes = useStyles();
  const getReferencedata = useTypedSelector((store) => store.ResourceReferenceData);
  const getTitleReferencedata = useTypedSelector((store) => store.TitleResourceReferenceData.TitleResourceReferenceData);
  const getResourceData = useTypedSelector((store) => store.ResourceDataOnId);

  const refData = getTitleReferencedata;
  const resData = getResourceData.ResourceData;
  const dispatch = useDispatch();
  const [error, setError] = useState<TitleInfoError>({
    lifestarterror: false,
    lifeenderror: false,
  });
  const [titleinfo, setTileInformation] = useState<SelectedTitleInformation>({
    titleLeadingArticle: '',
    title: '',
    edition: '',
    alternativetitle: '',
    uniformtitle: [],
    language: [],
    lifestartdate: '',
    lifeenddate: '',
    titlenotes: '',
    frequency: [],
    seriesvolume: '',
  });
  const uTitelId: number = resData.uniformTitleID as number;
  const uValue: string = refData.uniformTitles.find((x) => x.Key === resData.uniformTitleID)?.Value ?? '';
  const [filterFields, setFilterFields] = useState<FilterFields>(
    {
      uniformtitleId: 0,
      languageId: 0,
      frequencyId: 0,
    },
  );

  console.log(filterFields.uniformtitleId);
  const [titleoptions, setTitleOptions] = useState<TitleInformationFilters>(TitleInformationFilters.empty());

  function setTitleFieldValue(e: any, filterName: 'titleLeadingArticle' | 'title' | 'edition' | 'alternativetitle' | 'lifestartdate' | 'lifeenddate' | 'seriesvolume' | 'titlenotes') {
    const fieldvalue = e.target.value;

    const verifiedValue = fieldvalue === '' ? '' : fieldvalue;
    const regex = /^\d{3}[0-9u]{1}$/;
    if (filterName === 'lifestartdate' || filterName === 'lifeenddate') {
      if (regex.test(verifiedValue)) {
        setError((prevState) => ({
          ...prevState,
          lifestarterror: false,
          lifeenderror: false,
        }));
        // update state
        setTileInformation((pre) => {
          const newState = { ...pre };
          newState[filterName] = verifiedValue;
          return newState;
        });
        // console.log(state);
        setTitleOptions(titleoptions.updateFilter<keyof SelectedTitleInformation>(filterName, verifiedValue));
      } else {
        let setStart = false;
        let setEnd = false;
        if (filterName === 'lifestartdate') setStart = true;
        else setEnd = true;
        setError((prevState) => ({
          ...prevState,
          lifestarterror: setStart,
          lifeenderror: setEnd,
        }));
        // update state
        setTileInformation((pre) => {
          const newState = { ...pre };
          newState[filterName] = '';
          return newState;
        });
        // console.log(state);
        setTitleOptions(titleoptions.updateFilter<keyof SelectedTitleInformation>(filterName, verifiedValue));
      }
    } else {
      // update state
      setTileInformation((pre) => {
        const newState = { ...pre };
        newState[filterName] = verifiedValue;
        return newState;
      });
      // console.log(state);
      setTitleOptions(titleoptions.updateFilter<keyof SelectedTitleInformation>(filterName, verifiedValue));
    }
  }

  const setSelectedValueField = (result: any, filter: 'uniformtitleId' | 'languageId' | 'frequencyId'): void => {
    setFilterFields((prev) => {
      const newState = { ...prev };
      newState[filter] = Number(result);
      return newState;
    });
  };

  function changeFilter<T extends keyof SelectedTitleInformation>(
    filterName: T,
    value: SelectedTitleInformation[T],
  ) {
    setTitleOptions(titleoptions.updateFilter<keyof SelectedTitleInformation>(filterName, value));

    // set filtered value to selectedValue field
    const result = Object.values(titleoptions.data[filterName])[0];
    if (filterName === 'uniformtitle') setSelectedValueField(result, 'uniformtitleId');
    else if (filterName === 'language') setSelectedValueField(result, 'languageId');
    else if (filterName === 'frequency') setSelectedValueField(result, 'frequencyId');
  }

  const handleChange = (event: any, filterName: 'titleLeadingArticle' | 'title' | 'edition' | 'alternativetitle' | 'lifestartdate' | 'lifeenddate' | 'seriesvolume' | 'titlenotes'): void => {
    const fieldvalue = event.target.value;

    const verifiedValue = fieldvalue === '' ? '' : fieldvalue;
    // update state
    setTileInformation((pre) => {
      const newState = { ...pre };
      newState[filterName] = verifiedValue;
      return newState;
    });
    // console.log(state);
    setTitleOptions(titleoptions.updateFilter<keyof SelectedTitleInformation>(filterName, verifiedValue));
  };

  // useEffect(() => {
  //    debugger;
  //    if (resData.uniformTitleID != null) {
  //        setTitleOptions(titleoptions.updateFilter<keyof SelectedTitleInformation>('uniformtitle', {
  //                id: resData.uniformTitleID ?? undefined,
  //                value: refData.uniformTitles.find((x) => x.Key === resData.uniformTitleID)?.Value ?? '',
  //            } as unknown  as TypedownOption[],
  //        ));
  //    }
  //    console.log(titleoptions);
  //
  // }, [titleoptions]);

  useEffect(() => {
    // debugger;
    const uniformTitleLookup: Array<TypedownOption | StrStrTypedownOption> = refData.uniformTitles
      .map((x) => ({ id: x.Key, value: x.Value }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);
    const languageLookup: Array<TypedownOption | StrStrTypedownOption> = refData.languages
      .map((x) => ({ id: x.Key, value: x.Value }))
      .filter((x) => x !== null && x !== undefined);
    const frequencyLookup: Array<TypedownOption | StrStrTypedownOption> = refData.frequency
      .map((x) => ({ id: x.Key, value: x.Value }))
      .filter((x) => x !== null && x !== undefined);

    setTileInformation((prevState) => ({
      ...prevState,
      titleLeadingArticle: resData.titleLeadingArticle ?? '',
      title: resData.resourceTitle ?? '',
      edition: resData.edition ?? '',
      alternativetitle: resData.resourceAlternativeTitle ?? '',
      uniformtitle: uniformTitleLookup,
      language: languageLookup,
      lifestartdate: resData.lifeStartDate,
      lifeenddate: resData.lifeEndDate,
      titlenotes: resData.notes ?? '',
      frequency: frequencyLookup,
      seriesvolume: resData.seriesVolume ?? '',
    }));
    setFilterFields((prev) => ({
      ...prev,
      uniformtitleId: resData.uniformTitleID ?? 0,
      languageId: resData.resourceLanguage[0] ?? 0,
      frequencyId: resData.frequencyId ?? 0,
    }));
  }, [resData, refData]);

  useEffect(() => {
    if (titleinfo.titleLeadingArticle !== '') props.callback({ titledata: { titleinfo }, filterdata: { filterFields } });
  }, [titleinfo, filterFields]);

  console.log(resData);
  return (
    <Card
      variant="outlined"
      className="resourceIdeContainer"
      style={{
        marginLeft: 20,
        marginRight: 20,
        paddingBottom: 20,
        marginTop: 20,
      }}
    >
      <Grid item xs={12} style={{ textAlign: 'left' }}>
        <Typography
          className={classes.heading}
          variant="overline"
          style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
        >
          Title Information
        </Typography>
      </Grid>
      <Grid
        container
        spacing={2}
        style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
      >
        <Grid item xs={3}>
          <div className="custominput">
            <TextInputField
              keyName="titleLeadingArticle"
              labelText="The Leading Article"
              // inputText={""}
              onChangeFunction={(e: any) => { setTitleFieldValue(e, 'titleLeadingArticle'); }}
              onBlur={(e: any) => { setTitleFieldValue(e, 'titleLeadingArticle'); }}
              error={false}
              value={titleinfo.titleLeadingArticle}
            />
          </div>
        </Grid>
        <Grid item xs={6}>
          <div className="custominput">
            <TextInputField
              labelText="Title"
              // inputText={titleinfo.title ?? ''}
              keyName="title"
              onChangeFunction={(e: any) => { setTitleFieldValue(e, 'title'); }}
              onBlur={(e: any) => { setTitleFieldValue(e, 'title'); }}
              error={false}
              value={titleinfo.title}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custominput">
            <TextInputField
              keyName="edition"
              labelText="Edition"
              // inputText={titleinfo.edition}
              onChangeFunction={(e: any) => { setTitleFieldValue(e, 'edition'); }}
              onBlur={(e: any) => { setTitleFieldValue(e, 'edition'); }}
              error={false}
              value={titleinfo.edition}
            />
          </div>
        </Grid>
        <Grid item xs={6}>
          <div className="custominput">
            <TextInputField
              labelText="Alternative Title"
              // inputText={titleinfo.alternativetitle}
              keyName="alternativetitle"
              onChangeFunction={(e: any) => { setTitleFieldValue(e, 'alternativetitle'); }}
              onBlur={(e: any) => { setTitleFieldValue(e, 'alternativetitle'); }}
              error={false}
              value={titleinfo.alternativetitle}
            />
          </div>
        </Grid>
        <Grid item xs={6}>
          <div className="custom_autocomplete">
            <Typedown
              isLoading={props.isLoading}
              label="Series Title"
              options={titleinfo.uniformtitle}
              // selectedValue={titleoptions.data.uniformtitle[0]}
              selectedValue={filterFields.uniformtitleId ? {
                id: filterFields.uniformtitleId,
                value: refData.uniformTitles.find((x) => x.Key === filterFields.uniformtitleId)?.Value ?? '',
              } : null}
              onChange={(options) => { changeFilter('uniformtitle', options as unknown as TypedownOption[]); }}
            />
          </div>
        </Grid>
        <Grid item xs={2}>
          <div className="custom_autocomplete">
            <Typedown
              isLoading={props.isLoading}
              label="Language"
              options={titleinfo.language}
              selectedValue={filterFields.languageId ? {
                id: filterFields.languageId,
                value: refData.languages.find((x) => x.Key === filterFields.languageId)?.Value ?? '',
              } : null}
              onChange={(options) => { changeFilter('language', options as unknown as TypedownOption[]); }}
            />
          </div>
        </Grid>
        <Grid item xs={2} />
        <Grid item xs={2}>
          <div className="custominput">
            <TextInputField
              keyName="lifestartdate"
              labelText="Life Start Date"
              // inputText={titleinfo.lifestartdate}
              onChangeFunction={(e: any) => { handleChange(e, 'lifestartdate'); }}
              onBlur={(e: any) => { setTitleFieldValue(e, 'lifestartdate'); }}
              error={error.lifestarterror}
              errorMessage="Life start date should be four digits"
              value={titleinfo.lifestartdate}
            />
          </div>
        </Grid>
        <Grid item xs={2}>
          <div className="custominput">
            <TextInputField
              keyName=""
              labelText="Life End Date"
              // inputText={titleinfo.lifeenddate}
              onChangeFunction={(e: any) => { handleChange(e, 'lifeenddate'); }}
              onBlur={(e: any) => { setTitleFieldValue(e, 'lifeenddate'); }}
              error={error.lifeenderror}
              errorMessage="Life end date should be four digits"
              value={titleinfo.lifeenddate}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custom_singledropdown">
            <Typedown
              isLoading={props.isLoading}
              label="Frequency"
              options={titleinfo.frequency}
              selectedValue={filterFields.frequencyId ? {
                id: filterFields.frequencyId,
                value: refData.frequency.find((x) => x.Key === filterFields.frequencyId)?.Value ?? '',
              } : null}
              onChange={(options) => { changeFilter('frequency', options as unknown as TypedownOption[]); }}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custominput">
            <TextInputField
              keyName=""
              labelText="Series Volume/Number"
              // inputText={titleinfo.seriesvolume}
              onChangeFunction={(e: any) => { setTitleFieldValue(e, 'seriesvolume'); }}
              onBlur={(e: any) => { setTitleFieldValue(e, 'seriesvolume'); }}
              error={false}
              value={titleinfo.seriesvolume}
            />
          </div>
        </Grid>
        <Grid item xs={12}>
          <div className="customtextarea">
            {/* eslint jsx-a11y/label-has-associated-control: ["error", { assert: "either" } ] */}
            <FormControl>
              <label htmlFor="Textarea-text">
                Title Notes
              </label>
              <textarea
                id="Textarea-text"
                // inputText={titleinfo.titlenotes}
                // error={false}
                // labelText=""
                name="titlenotes"
                onChange={(e: any) => { setTitleFieldValue(e, 'titlenotes'); }}
                onBlur={(e: any) => { setTitleFieldValue(e, 'titlenotes'); }}
                value={titleinfo.titlenotes}
              />
            </FormControl>
          </div>

        </Grid>
      </Grid>
    </Card>
  );
}

export default TitleInformation;
