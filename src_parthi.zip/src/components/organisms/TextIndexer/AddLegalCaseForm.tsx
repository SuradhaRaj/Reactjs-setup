import React from 'react';
import {
  Grid, Typography, Tooltip, Chip, Button,
} from '@material-ui/core';
import { Formik } from 'formik';
import * as Yup from 'yup';
import AddLegalCaseRequest from '../../../interfaces/TextIndexer/AddLegalCaseRequest';
import TypedownOption from '../../../interfaces/TypedownOption';
import TextInputField from '../../Shared/TextInputField';
import SingleCheckbox from '../../molecules/SingleCheckbox';
import TypedownAsync from '../TypedownAsync';
import LoadingButton from '../../molecules/LoadingButton';

interface AddLegalCaseFormProps {
    loading: boolean;
    onCancel(): void;
    onAdd(request: AddLegalCaseRequest): void;
  }

const initialFormValues: AddLegalCaseRequest & { chosenGroupCaseName: string } = {
  isPrimary: true,
  newGroup: true,
  name: '',
  groupId: null,
  chosenGroupCaseName: '',
};

const AddLegalCaseForm: React.SFC<AddLegalCaseFormProps> = (props) => (
  <Grid container>
    <Formik
      initialValues={{ ...initialFormValues }}
      onSubmit={() => undefined}
      isInitialValid={false}
      validationSchema={Yup.object().shape({
        name: Yup
          .string()
          .required(),
        isPrimary: Yup
          .boolean()
          .required(),
        newGroup: Yup
          .boolean()
          .required(),
        groupId: Yup
          .number()
          .when('newGroup', {
            is: true,
            then: Yup.number().nullable(),
            otherwise: Yup
              .number()
              .moreThan(0)
              .required(),
          }),
      })}
    >
      {(formikProps) => {
        const {
          values,
          errors,
          handleChange,
          handleBlur,
          isValid,
          setFieldValue,
        } = formikProps;

        const onAdd = () => {
          const request: AddLegalCaseRequest = {
            isPrimary: values.isPrimary,
            newGroup: values.newGroup,
            groupId: values.groupId,
            name: values.name,
          };

          props.onAdd(request);
        };

        const deleteSelectedGroup = () => {
          setFieldValue('groupId', null, true);
          setFieldValue('chosenGroupCaseName', '', true);
        };

        const onSwitchNewGroup = () => {
          // if we are switching to the new group option, set is primary to true
          // and clear selected group
          if (!values.newGroup) {
            setFieldValue('isPrimary', true, true);
            deleteSelectedGroup();
          }

          setFieldValue('newGroup', !values.newGroup, true);
        };

        const onSelectGroup = (legalCase: TypedownOption) => {
          setFieldValue('groupId', legalCase.id, true);
          setFieldValue('chosenGroupCaseName', legalCase.value, true);
        };

        return (
          <>
            {/* Legal Case Name */}
            <Grid item xs={10}>
              <TextInputField
                inputText={values.name}
                labelText="Legal Case Name"
                keyName="name"
                onChangeFunction={handleChange}
                onBlur={handleBlur}
                error={!!errors.name}
              />
            </Grid>

            {/* New Group */}
            <Grid item xs={12}>
              <SingleCheckbox
                checked={values.newGroup}
                keyName="newGroup"
                onBlur={handleBlur}
                onChange={onSwitchNewGroup}
                label="New Group"
              />
            </Grid>

            {/* Group Id */}
            {!values.newGroup && (
              <Grid item xs={10}>
                {/* Is Primary */}
                <SingleCheckbox
                  checked={values.isPrimary}
                  keyName="isPrimary"
                  onBlur={handleBlur}
                  onChange={() => setFieldValue('isPrimary', !values.isPrimary, true)}
                  label="Primary"
                />
                {values.groupId === null ? (
                // Show typedown if not selected yet
                  <TypedownAsync
                    url={`${process.env.REACT_APP_API_URL}/api/indexing/searchlegalcases/groupids`}
                    label="Case Group Search"
                    onChange={onSelectGroup}
                  />
                ) : (
                // Otherwise show the selected group member with a delete option
                  <>
                    <Typography noWrap>
                      Selected group:
                    </Typography>
                    <Tooltip
                      title={values.chosenGroupCaseName}
                    >
                      <Chip
                        label={values.chosenGroupCaseName}
                        onDelete={deleteSelectedGroup}
                      />
                    </Tooltip>
                  </>
                )}
              </Grid>
            )}

            <Grid item xs={10}>
              <LoadingButton
                isLoading={props.loading}
                disabled={!isValid}
                onClick={onAdd}
              >
                Add
              </LoadingButton>
              <Button
                disabled={props.loading}
                onClick={props.onCancel}
              >
                Cancel
              </Button>
            </Grid>
          </>
        );
      }}
    </Formik>
  </Grid>
);

export default AddLegalCaseForm;
