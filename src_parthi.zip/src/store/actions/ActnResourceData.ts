// import {  Record, Array,} from 'runtypes';
// import { NumberGreaterZero } from '../../runtypeTypes';
import ResourceData from '../../interfaces/ResourceManagement/Resource';
import ResourceOrganisations from '../../interfaces/ResourceManagement/Organisation';
import ResourceContact from '../../interfaces/Organisation/OrganisationContact';

export const SET_RESOURCE_DATA = 'SET_RESOURCE_DATA';
// export const RESET_ACTION = {
//   type: 'RESET',
// };
interface UpdateResourceDataAction {
  type: typeof SET_RESOURCE_DATA;
  resource: ResourceData;
  organisation: ResourceOrganisations;
  contacts: ResourceContact[];
  issueYears: { item1: number; item2: number }[];
}
interface GetData {
  resource: ResourceData;
  organisation: ResourceOrganisations;
  contacts: ResourceContact[];
  issueYears: { item1: number; item2: number }[];
}
export type ActionTypes = UpdateResourceDataAction;

export const initialState: GetData = {
  resource: {
    resourceId: 0,
    resourceName: '', // not supplied
    titleLeadingArticle: '', // null
    resourceTitle: '',
    resourceSubtitle: '', // null
    resourceAlternativeTitle: '', // null
    resourceShortName: '', // null
    edition: '',
    resourceVariantTitle: '',
    statementOfResponsibility: '',
    frequencyId: null,
    notes: '',
    description: '',
    descriptionTypeId: null,
    lifeStartDate: '',
    lifeEndDate: '',
    placeOfPublication: '',
    nameOfPublisher: '',
    nameOfPublisherDisplay: '',
    dateOfPublication: '',
    publicationYear: null,
    doi: '',
    persistentIdentifier: '',
    isFullText: null,
    hasFullText: null,
    fullTextUrl: '',
    eIsbn: '',
    eIssn: '',
    isbn: '',
    issn: '',
    prevIssn: '',
    laterIssn: '',
    indexingCompanyId: 3,
    rmplist: '',
    currentlyComprehensive: null,
    seriesVolume: '',
    seriesIssn: '',
    nameOfConference: '',
    numberOfConference: '',
    sponsorOfConference: '',
    themeOfConference: '',
    dateOfConference: '',
    placeOfConference: '',
    nameOfOrganiser: '',
    mediaTypeId: 3,
    publishResource: null,
    liveDate: '',
    titleDocumentNumber: '',
    dateCreated: null,
    lastModified: null,
    lastRevisiondate: null,
    resourceTypeId: null,
    contentTypeId: null,
    fileTypeId: null,
    titleIndexingStatusId: null,
    titleTypeId: null,
    scholarlyLevel: '',
    resourceRating: '',
    logo: '',
    peerReviewed: false,
    source: '',
    sourceImportDate: '',
    licenceId: null,
    organisationId: null,
    resourceManagerId: null,
    seriesTitleID: null,
    uniformTitleID: null,
    resourceBroadSubject: [],
    resourceNarrowSubject: [],
    resourceFast: [],
    resourceIdentifier: [],
    resourceLanguage: [],
    resourceSubjectLc: [],
    resourceIndexers: [],
    resourceIndexTypeCode: [],
    resourceProductCode: [],
    resourceCollectionCode: [],
    urLs: [],
    resourceFastGeo: [],
    workflowStatusId: null,
    imageData: '',
    hubSpotId: 0,
    active: false,
    accessRightID: null,
    extent: '',
    website: '',
    clearedById: null,
    agreementNumber: '',
    perpetualAccess: null,
    contractStartDate: '',
    contractEndDate: '',
    embargoPeriod: '',
    royaltiesDue: null,
    royaltyRate: '',
    archiveRoyaltyRate: '',
    sourceDocumentNumber: '',
    countryOfPublicationMarc: '',
    price: '',
    individualSubscriptions: null,
    cclicenceTypeId: null,
    ppvavailable: null,
    accessTypeId: null,
    clearanceStatusId: null,
    readyForMetadataDate: '',
    readyForFilesDate: '',
    readyForCataloguingDate: '',
    readyForQaDate: '',
    managementNotes: '',
    licenceManagementNotes: '',
    contentSource: '',
    ielcopyright: '',
    noticeProvidedDate: '',
    noticePeriod: '',
    archivePeriodStartDate: '',
    archivalPeriod: '',
    withdrawalDate: '',
    royaltyOrganisationId: null,
    broadSubjectLookup: [],
  },
  organisation: {
    organisationName: '',
    organisationId: 0,
    hubSpotOrgId: 0,
    organisationWebsite: '',
  },
  contacts: [{
    contactId: 0,
    title: '',
    firstName: '',
    surname: '',
    email: '',
    address: '',
    suburb: '',
    country: '',
    state: '',
    postcode: '',
    homePhone: '',
    workPhone: '',
    hubSpotId: 0,
    roles: [],
  }],
  issueYears: [{ item1: 0, item2: 0 }],
};

export function setResourceData(data: GetData): ActionTypes {
  return {
    type: SET_RESOURCE_DATA,
    resource: data.resource,
    organisation: data.organisation,
    contacts: data.contacts,
    issueYears: data.issueYears,
  };
}
