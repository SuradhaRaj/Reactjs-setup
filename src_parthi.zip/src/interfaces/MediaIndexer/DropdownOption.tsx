interface DropdownOption {
  value: string | number;
  display: string | JSX.Element | JSX.Element[];
}

export default DropdownOption;
