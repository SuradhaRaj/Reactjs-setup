import {
  Record, Static, Number,
} from 'runtypes';
import { NumberGreaterZero } from '../../runtypeTypes';

export const TextTaskManagementBaseTaskValidator = Record({
  artifactId: Number,
  workflowStatusId: NumberGreaterZero,
  artifactTypeId: Number,
});

type TextTaskManagementBaseTask = Static<typeof TextTaskManagementBaseTaskValidator>
export default TextTaskManagementBaseTask;
