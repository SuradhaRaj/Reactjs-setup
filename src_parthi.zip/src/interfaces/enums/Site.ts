enum Site {
  TvNews = '211',
  EduTv = '213'
}

export default Site;
