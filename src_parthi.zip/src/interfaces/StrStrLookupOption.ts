import {
  Record, String, Static,
} from 'runtypes';

export const StrStrLookupOptionValidator = Record({
  key: String,
  value: String,
});

type StrStrLookupOption = Static<typeof StrStrLookupOptionValidator>;
export default StrStrLookupOption;
