/* eslint-disable @typescript-eslint/class-name-casing */
/* eslint-disable @typescript-eslint/camelcase */
import {
  Record, Static, String, Number, Null,
} from 'runtypes';
import { IsoDate } from '../../runtypeTypes';

export const ResourceIssueValidator = Record({
  issueID: Number,
  issueNumber: String.Or(Null),
  volumeNumber: String,
  articleCount: Number,
  grouping: String,
  issueMonthSeason: String.Or(Null),
  issueTitle: String.Or(Null),
  publicationYear: Number.Or(Null),
  scheduleDate: IsoDate.Or(Null),
  dateOfPublication: String.Or(Null),
  notesIssueManagement: String.Or(Null),
});

type ResourceIssueData = Static<typeof ResourceIssueValidator>;
export default ResourceIssueData;
