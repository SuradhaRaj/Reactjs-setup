import {
  Record, String, Static,
} from 'runtypes';

const ClientConfigurationRuntype = Record({
  appInsightsInstrumentationKey: String,
  firebaseConfigApiKey: String,
  firebaseConfigAppId: String,
  firebaseConfigAuthDomain: String,
  firebaseConfigMeasurementId: String,
  firebaseConfigMessagingSenderId: String,
  firebaseConfigProjectId: String,
  firebaseConfigStorageBucket: String,
});

type ClientConfigurationData = Static<typeof ClientConfigurationRuntype>;

class ClientConfiguration {
  data: ClientConfigurationData;

  constructor(data: ClientConfigurationData) {
    try {
      ClientConfigurationRuntype.check(data);
      this.data = data;
    } catch (error) {
      console.error(`Unable to process ClientConfigurationData. [${error.key} - ${error.message}]`, error);
      throw error;
    }
  }

  static empty() {
    return new ClientConfiguration({
      appInsightsInstrumentationKey: '',
      firebaseConfigApiKey: '',
      firebaseConfigAppId: '',
      firebaseConfigAuthDomain: '',
      firebaseConfigMeasurementId: '',
      firebaseConfigMessagingSenderId: '',
      firebaseConfigProjectId: '',
      firebaseConfigStorageBucket: '',
    });
  }
}

export default ClientConfiguration;
