import React from 'react';
import {
  makeStyles, createStyles, Box, Theme,
} from '@material-ui/core';
import { FormikErrors } from 'formik';
import TextInputField from '../../Shared/TextInputField';
import Dropdown from '../../Shared/Dropdown';
import LookupOption from '../../../interfaces/LookupOption';
import SingleCheckbox from '../../molecules/SingleCheckbox';
import MaskedInputField from '../../molecules/MaskedInputField';
import LongTextInputField from '../../Shared/LongTextInputField';
import LicenceTemplate from '../../../interfaces/Organisation/LicenceTemplate';

const DateMask = [/[1-9]/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/];

const useStyles = makeStyles((theme: Theme) => createStyles({
  row: {
    paddingRight: theme.spacing(3),
  },
}));

interface LicenceFormProps {
  licenceTemplateValues: LicenceTemplate | undefined;
  submitting?: boolean;
  handleChange(e: React.ChangeEvent): void;
  handleBlur?(e: unknown): void;
  setFieldValue(field: string, value: unknown, shouldValidate?: boolean): void;
  errors?: FormikErrors<LicenceTemplate>;
  clearanceStatusLookup: LookupOption[];
  accessRightsLookup: LookupOption[];
  clearedByLookup: LookupOption[];
  ccLicenceTypeLookup: LookupOption[];
  accessTypeLookup: LookupOption[];
}

const LicenceForm: React.FC<LicenceFormProps> = (props) => {
  const classes = useStyles();

  // autoassign individual subscriptions to yes if cleared by RMIT
  React.useEffect(() => {
    props.setFieldValue('individualSubscriptions', props.clearedByLookup.find((lo) => lo.key === props.licenceTemplateValues?.clearanceStatusId)?.value === 'RMIT');
  }, [props.licenceTemplateValues?.clearedById]);

  const handleDropdownChange = (key: string, value: number) => (props.setFieldValue(key, value));

  return (
    <>
      <Box width={1} className={classes.row}>
        {/* Management Notes */}
        <LongTextInputField
          inputText={props.licenceTemplateValues?.terminationNote}
          labelText="Management Note"
          keyName="terminationNote"
          onChangeFunction={props.handleChange}
          onBlur={props.handleBlur}
          error={!!props.errors?.terminationNote}
          errorMessage={props.errors?.terminationNote}
          readOnly={props.submitting}
        />
      </Box>

      <Box width={1 / 2} display="inline-block" className={classes.row}>
        {/* Contract Start Date */}
        <MaskedInputField
          value={props.licenceTemplateValues?.contractStartDate}
          labelText="Contract Start Date"
          name="contractStartDate"
          onChange={props.handleChange}
          onBlur={props.handleBlur}
          error={!!props.errors?.contractStartDate}
          helperText={props.errors?.contractStartDate}
          disabled={props.submitting}
          mask={DateMask}
        />
      </Box>

      <Box width={1 / 2} display="inline-block" className={classes.row}>
        {/* Contract End Date */}
        <MaskedInputField
          value={props.licenceTemplateValues?.contractEndDate}
          labelText="Contract End Date"
          name="contractEndDate"
          onChange={props.handleChange}
          onBlur={props.handleBlur}
          error={!!props.errors?.contractEndDate}
          helperText={props.errors?.contractEndDate}
          disabled={props.submitting}
          mask={DateMask}
        />
      </Box>

      <Box width={1 / 2} display="inline-block" className={classes.row}>
        {/* Clearance Status */}
        <Dropdown
          labelText="Clearance Status"
          keyName="clearanceStatusId"
          id="ClearanceStatus"
          value={props.licenceTemplateValues?.clearanceStatusId ? props.licenceTemplateValues.clearanceStatusId.toString() : ''}
          onChangeFunction={handleDropdownChange}
          onBlur={props.handleBlur}
          isReadOnly={props.submitting}
          options={props.clearanceStatusLookup.map((lo) => ({ display: lo.value, value: lo.key }))}
        />
      </Box>

      <Box width={1 / 2} display="inline-block" className={classes.row}>
        {/* Cleared By */}
        <Dropdown
          labelText="Cleared By"
          keyName="clearedById"
          id="ClearedById"
          onBlur={props.handleBlur}
          isReadOnly={props.submitting}
          value={props.licenceTemplateValues?.clearanceStatusId ? props.licenceTemplateValues?.clearanceStatusId.toString() : ''}
          onChangeFunction={handleDropdownChange}
          options={props.clearedByLookup.map((lo) => ({ display: lo.value, value: lo.key }))}
        />
      </Box>

      <Box width={1 / 2} className={classes.row}>
        {/* IEL Copyright Statement */}
        <TextInputField
          inputText={props.licenceTemplateValues?.ielcopyright}
          labelText="IEL Copyright Statement"
          keyName="ielcopyright"
          onChangeFunction={props.handleChange}
          onBlur={props.handleBlur}
          error={!!props.errors?.ielcopyright}
          readOnly={props.submitting}
        />
      </Box>

      <Box width={1 / 2} display="inline-block" className={classes.row}>
        {/* Access Rights */}
        <Dropdown
          labelText="Access Rights"
          keyName="accessRightId"
          id="accessRights"
          onBlur={props.handleBlur}
          isReadOnly={props.submitting}
          value={props.licenceTemplateValues?.accessRightId ? props.licenceTemplateValues.accessRightId.toString() : ''}
          onChangeFunction={handleDropdownChange}
          options={props.accessRightsLookup.map((lo) => ({ display: lo.value, value: lo.key }))}
        />
      </Box>

      <Box width={1 / 2} display="inline-block" className={classes.row}>
        {/* Access Type */}
        <Dropdown
          labelText="Access Type"
          keyName="accessTypeId"
          id="accessType"
          isReadOnly={props.submitting}
          onBlur={props.handleBlur}
          value={props.licenceTemplateValues?.accessTypeId ? props.licenceTemplateValues.accessTypeId.toString() : ''}
          onChangeFunction={handleDropdownChange}
          options={props.accessTypeLookup.map((lo) => ({ display: lo.value, value: lo.key }))}
        />
      </Box>

      <Box width={1 / 2} className={classes.row}>
        {/* Creative Commons Licence Type */}
        <Dropdown
          labelText="Creative Commons Licence Type"
          keyName="cclicenceTypeId"
          id="cclicenceTypeId"
          isReadOnly={props.submitting}
          onBlur={props.handleBlur}
          value={props.licenceTemplateValues?.cclicenceTypeId ? props.licenceTemplateValues.cclicenceTypeId.toString() : ''}
          onChangeFunction={handleDropdownChange}
          options={props.ccLicenceTypeLookup.map((lo) => ({ display: lo.value, value: lo.key }))}
        />
      </Box>

      <Box width={1 / 2} className={classes.row}>
        {/* Embargo Period */}
        <TextInputField
          inputText={props.licenceTemplateValues?.embargoPeriod}
          labelText="Embargo Period"
          keyName="embargoPeriod"
          type="number"
          onChangeFunction={props.handleChange}
          onBlur={props.handleBlur}
          error={!!props.errors?.embargoPeriod}
          readOnly={props.submitting}
        />
      </Box>

      <Box width={1 / 2} className={classes.row}>
        {/* Price */}
        <TextInputField
          inputText={props.licenceTemplateValues?.price}
          labelText="Price"
          keyName="price"
          type="number"
          onChangeFunction={props.handleChange}
          onBlur={props.handleBlur}
          error={!!props.errors?.price}
          readOnly={props.submitting}
        />
      </Box>

      <Box width={1 / 2} display="inline-block" className={classes.row}>
        {/* Perpetual Access */}
        <SingleCheckbox
          labelPlacement="end"
          label="Perpetual Access"
          checked={!!props.licenceTemplateValues?.perpetualAccess}
          keyName="perpetualAccess"
          onBlur={props.handleBlur}
          onChange={() => props.setFieldValue('perpetualAccess', !props.licenceTemplateValues?.perpetualAccess, true)}
          error={!!props.errors?.perpetualAccess}
          disabled={props.submitting}
        />
      </Box>

      <Box width={1 / 2} display="inline-block" className={classes.row}>
        {/* PPV Available */}
        <SingleCheckbox
          labelPlacement="end"
          label="PPV Available"
          checked={!!props.licenceTemplateValues?.ppvavailable}
          keyName="ppvavailable"
          onBlur={props.handleBlur}
          onChange={() => props.setFieldValue('ppvavailable', !props.licenceTemplateValues?.ppvavailable, true)}
          error={!!props.errors?.ppvavailable}
          disabled={props.submitting}
        />
      </Box>

      <Box width={1 / 2} display="inline-block" className={classes.row}>
        {/* Royalties Due */}
        <SingleCheckbox
          labelPlacement="end"
          label="Royalties Due"
          checked={!!props.licenceTemplateValues?.royaltiesDue}
          keyName="royaltiesDue"
          onBlur={props.handleBlur}
          onChange={() => props.setFieldValue('royaltiesDue', !props.licenceTemplateValues?.royaltiesDue, true)}
          error={!!props.errors?.royaltiesDue}
          disabled={props.submitting}
        />
      </Box>

      <Box width={1 / 2} display="inline-block" className={classes.row}>
        {/* Individual Subscriptions Available */}
        <SingleCheckbox
          labelPlacement="end"
          label="Individual Subscriptions Available"
          checked={!!props.licenceTemplateValues?.individualSubscriptions}
          keyName="individualSubscriptions"
          onBlur={props.handleBlur}
          onChange={() => props.setFieldValue('individualSubscriptions', !props.licenceTemplateValues?.individualSubscriptions, true)}
          error={!!props.errors?.individualSubscriptions}
          disabled={props.submitting}
        />
      </Box>

      <Box width={1 / 2} display="inline-block" className={classes.row}>
        {/* Royalty Rate */}
        <TextInputField
          inputText={props.licenceTemplateValues?.royaltyRate}
          labelText="Royalty Rate"
          keyName="royaltyRate"
          type="number"
          onChangeFunction={props.handleChange}
          onBlur={props.handleBlur}
          error={!!props.errors?.royaltyRate}
          errorMessage={props.errors?.royaltyRate}
          readOnly={props.submitting}
        />
      </Box>

      <Box width={1 / 2} display="inline-block" className={classes.row}>
        {/* Archive Royalty Rate */}
        <TextInputField
          inputText={props.licenceTemplateValues?.archiveRoyaltyRate}
          labelText="Archive Royalty Rate"
          keyName="archiveRoyaltyRate"
          type="number"
          onChangeFunction={props.handleChange}
          onBlur={props.handleBlur}
          error={!!props.errors?.archiveRoyaltyRate}
          errorMessage={props.errors?.archiveRoyaltyRate}
          readOnly={props.submitting}
        />
      </Box>

      <Box width={1 / 2} display="inline-block" className={classes.row}>
        {/* Notice Period */}
        <TextInputField
          inputText={props.licenceTemplateValues?.noticePeriod}
          labelText="Notice Period"
          placeholder="(Months)"
          keyName="noticePeriod"
          type="number"
          onChangeFunction={props.handleChange}
          onBlur={props.handleBlur}
          error={!!props.errors?.noticePeriod}
          readOnly={props.submitting}
        />
      </Box>

      <Box width={1 / 2} display="inline-block" className={classes.row}>
        {/* Archival Period */}
        <TextInputField
          inputText={props.licenceTemplateValues?.archivalPeriod}
          labelText="Archival Period"
          keyName="archivalPeriod"
          type="number"
          onChangeFunction={props.handleChange}
          onBlur={props.handleBlur}
          error={!!props.errors?.archivalPeriod}
          readOnly={props.submitting}
        />
      </Box>
    </>
  );
};

export default LicenceForm;
