import React, { useEffect, useState } from 'react';
import {
  Typography, Grid, Card, makeStyles,
} from '@material-ui/core';
import { number } from 'yup';
import TextInputField from '../../Shared/TextInputField';
import { useTypedSelector } from '../../../store/store';
import Dropdown from '../../Shared/Dropdown';
import DropdownOption from '../../../interfaces/MediaIndexer/DropdownOption';

interface Descriptionprop {
  description: string;
  descriptiontypeid: number;
  extent: string;
  descriptiontype: DropdownOption[];

}
interface Props {
  isLoading: boolean;
}

// function getDescriptionOption(descDropdown: DropdownOption[]) {

//   const dropdownList: DropdownOption[] = [];

//   for (let i = 0; i < descDropdown.length; i++) {
//    dropdownList.push({ value: descDropdown[i].value, display: descDropdown[i].display });
//  }

//  setStateDescription((prevState) => ({
//    ...prevState,
//    descriptiontype: dropdownList,
//  }));

//  return dropdownList;
// }

const useStyles = makeStyles({
  resourceIdeContainer: {
    paddingBottom: '20',
  },

  heading: {
    'font-size': '13px',
    'font-weight': '500',
    'text-transform': 'none',
    color: '#000000',
  },
});

function Description(props: any): JSX.Element {
  const classes = useStyles();
  // const dispatch = useDispatch();
  const getResourceData = useTypedSelector((store) => store.ResourceDataOnId);
  const getReferenceData = useTypedSelector((store) => store.TitleResourceReferenceData);
  // const [checked, setChecked] = useState(true);

  const [StateDescription, setStateDescription] = useState<Descriptionprop>({
    description: '',
    descriptiontypeid: 0,
    extent: '',
    descriptiontype: [],
  });

  // const clearAllFilters = (): void => {
  //   dispatch(clearFilters());
  //   // history.push(location.pathname);
  // };
  function ontextchange(e: React.FormEvent<HTMLInputElement>, control: string) {
    if (control === 'Description') {
      setStateDescription({
        ...StateDescription,
        description: e.currentTarget.value,
      });
    } else if (control === 'extent') {
      setStateDescription({
        ...StateDescription,
        extent: e.currentTarget.value,
      });
    }
    props.callback({ StateDescription });
  }

  function onChangeSetStateVal(key: number, val: string) {
    setStateDescription({
      ...StateDescription,
      descriptiontypeid: +val,
    });
    props.callback({ StateDescription });
  }

  useEffect(() => {
    const desctDrop: DropdownOption[] = getReferenceData.TitleResourceReferenceData.descriptionType.map((x) => ({ value: x.Key, display: x.Value }));
    const tmpdescriptypeId: number = getResourceData.ResourceData.descriptionTypeId != null ? getResourceData.ResourceData.descriptionTypeId : 0;
    const tmpdescription: string = getResourceData.ResourceData.description != null ? getResourceData.ResourceData.description : '';
    const tmpextent: string = getResourceData.ResourceData.extent != null ? getResourceData.ResourceData.extent : '';

    // getDescriptionOption(desctDrop);

    setStateDescription((prevState) => ({

      descriptiontypeid: tmpdescriptypeId,
      description: tmpdescription,
      extent: tmpextent,
      descriptiontype: desctDrop,
    }));
  }, [getResourceData.ResourceData]);

  useEffect(() => {
    const desctDrop: DropdownOption[] = getReferenceData.TitleResourceReferenceData.descriptionType.map((x) => ({ value: x.Key, display: x.Value }));
    setStateDescription((prevState) => ({
      ...prevState,

      descriptiontype: desctDrop,
    }));
  }, [getReferenceData.TitleResourceReferenceData.descriptionType]);

  useEffect(() => {
    if (StateDescription.description !== '') props.callback(StateDescription);
  }, [StateDescription]);

  return (
    <Card
      variant="outlined"
      className="resourceIdeContainer"
      style={{
        marginLeft: 20,
        marginRight: 20,
        paddingBottom: 20,
        marginTop: 20,
      }}
    >
      <Grid item xs={12} style={{ textAlign: 'left' }}>
        <Typography
          className={classes.heading}
          variant="overline"
          style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
        >
          Description
        </Typography>
      </Grid>
      <Grid
        container
        spacing={2}
        style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
      >
        <Grid item xs={6}>
          <div className="custominput mt0">
            <TextInputField
              keyName="description"
              labelText="Description"
              inputText={StateDescription.description}
              value={StateDescription.description}
              onChangeFunction={(e: React.FormEvent<HTMLInputElement>) => {
                ontextchange(e, 'Description');
              }}
              // onBlur={(e: any) => { }}
              error={false}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custom_singledropdown">
            <Dropdown
              labelText="Resource Type"
              id="resourceTypeId"
              options={StateDescription.descriptiontype}
              value={StateDescription.descriptiontypeid}
              keyName="resourceTypeId"
             // onChangeFunction={(e: any) => e}
              onChangeFunction={(key: number, value: string) => {
                onChangeSetStateVal(key, value);
              }}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custominput mt0">
            <TextInputField
              keyName="extent"
              labelText="Extent"
              inputText={StateDescription.extent}
              value={StateDescription.extent}
              onChangeFunction={(e: React.FormEvent<HTMLInputElement>) => {
                ontextchange(e, 'extent');
              }}
              // onBlur={(e: any) => { }}
              error={false}
            />
          </div>
        </Grid>
      </Grid>
    </Card>
  );
};

export default Description;
