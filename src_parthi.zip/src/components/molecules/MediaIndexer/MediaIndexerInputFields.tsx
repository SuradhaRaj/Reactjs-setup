/*eslint-disable*/
import React, { useState } from 'react';
import axios from 'axios';
import { Formik, FormikValues as Values } from 'formik';
import * as Yup from 'yup';
import { createStyles } from '@material-ui/core/styles';
import { withStyles, WithStyles } from '@material-ui/styles';
import Grid from '@material-ui/core/Grid';
import { Paper, Button, Typography, Divider, ButtonGroup, Checkbox, FormControlLabel, Tabs, Tab, Badge } from '@material-ui/core';
import MediaArtifact from '../../../interfaces/MediaIndexer/MediaArtifact';
import TextInputField from '../../Shared/TextInputField';
import Dropdown from '../../Shared/Dropdown';
import LongTextInputField from '../../Shared/LongTextInputField';
import LanguageTypedown from './LanguageTypedown';
import GenreCheckboxList from './GenreCheckboxList';
import TermsTypedown from './TermsTypedown';
import ContributorsTypedown from './ContributorsTypedown';
import GeolocationsTypedown from './GeolocationsTypedown';
import BroadAndNarrowSubjects from './BroadAndNarrowSubjects';
import Identifiers from './Identifiers';
import ThumbnailSelector from './ThumbnailSelector';
import SaveAndSubmitButton from './SaveAndSubmitButton';
import ErrorButton from './ErrorButton';
import NotesButton from './NotesButton';
import { withRouter, RouteComponentProps } from 'react-router-dom'
import { isEqual } from 'lodash';
import * as H from 'history';
import * as Constants from '../../../constants/MediaIndexerConstants'

import SaveIcon from '@material-ui/icons/Save';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';

import DocumentItemNode from '../../../interfaces/MediaIndexer/DocumentItemNode';
import DocumentFastNode from '../../../interfaces/MediaIndexer/DocumentFastNode';
import DocumentLangNode from '../../../interfaces/MediaIndexer/DocumentLangNode';
import DocumentNodeStateEnum from '../../../interfaces/MediaIndexer/DocumentNodeStateEnum';
import DocumentContributor from '../../../interfaces/MediaIndexer/DocumentContributor';
import ThumbnailNode from '../../../interfaces/MediaIndexer/ThumbnailNode';
import NarrowSubjectOption from '../../../interfaces/MediaIndexer/NarrowSubjectOption';
import ArtifactErrorCode from '../../../interfaces/MediaIndexer/ArtifactErrorCode';
import SaveAndSubmitMediaArtifactRequest from '../../../interfaces/MediaIndexer/SaveAndSubmitMediaArtifactRequest';
import SendErrorRequest from '../../../interfaces/MediaIndexer/SendErrorRequest';
import DoucmentNote from '../../../interfaces/MediaIndexer/DocumentNote';
import { AppContext } from '../../Context';
import StickyActionBar from '../../atoms/StickyActionBar';
import { ValidationDialog } from './ValidationDialog';
import IndexerValidationHelper from '../../../utils/IndexerValidationHelper';
import GenreOption from '../../../interfaces/MediaIndexer/GenreOption';
import ContentTypeOption from '../../../interfaces/MediaIndexer/ContentTypeOption';
import DocumentBroadSubject from '../../../interfaces/MediaIndexer/DocumentBroadSubject';
import LanguageOption from '../../../interfaces/MediaIndexer/LanguageOption';
import { DateTime } from 'luxon';
import { ValidationErrorDialog } from './ValidationErrorDialog';
import classname from 'classnames';
import WithdrawButton from './WithdrawButton';
import PublishIcon from '@material-ui/icons/Publish';
import ArtifactStatus from '../../../interfaces/enums/ArtifactStatus';
import ClassificationOption from '../../../interfaces/MediaIndexer/ClassificationOption';
import DropdownOption from '../../../interfaces/MediaIndexer/DropdownOption';
import LookupOption from '../../../interfaces/LookupOption';
import ArtifactType from '../../../interfaces/enums/ArtifactType';
import ResourceStringHelper from '../../../utils/ResourceStringHelper';
import MediaIndexerWarningStrings from '../../../res/MediaIndexerWarningStrings';
import ConfirmationDialogForList from '../../molecules/ConfirmationDialogForList';
import { withSnackbar, SnackbarMessage, OptionsObject, SnackbarKey  } from 'notistack';
import { TabContext, TabList, TabPanel } from '@material-ui/lab';

const useStyles = createStyles({
  root: {
    flexGrow: 1,
    backgroundColor: '#f9f9fc',
  },
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  textField: {
    width: 200,
  },
  mainContent: {
    marginTop: '80px',
    marginBottom: '10px',
    minWidth: '1585px',
  },
  contentRow: {
    // minHeight: '100px',
    // marginBottom: '10px',
    marginBottom: 0,
  },
  sectionHeading: {
    textAlign: 'left',
    paddingTop: '15px',
  },
  thumbnailRow: {
    marginBottom: '30px',
  },
  thumbnailSubtitle: {
    textAlign: 'left',
    marginBottom: '15px',
  },
  button: {
    borderRadius: 50,
    margin: 5
  },
  saveButton: {
  },
  backButton: {
  },
  switchMediaPlayer: {
    top: '15px',
    left: '15px',
    height: '99%',
  },
  buttonContainer: {
    paddingTop: '20px',
  },
  divider: {
    marginTop: 20
  },
  dividerContainer: {
    textAlign: "right",
    '& .MuiTypography-overline': {
      fontWeight: 600
    }
  },
  '@global': {
    '.MuiOutlinedInput-input': {
      padding: '10px 14px',
      fontSize: '0.8rem'
    },
    '.MuiOutlinedInput-multiline': {
      padding: '0px',
      fontSize: '0.8rem'
    },
    '.MuiChip-label': {
      fontSize: '0.7rem'
    },
    '.MuiChip-root': {
      height: 24
    },
    '.MuiChip-deleteIcon': {
      height: 16
    },
    '.MuiFormControl-marginNormal': {
      marginTop: 12,
      marginBottom: 0
    },
    '.MuiAutocomplete-inputRoot[class*="MuiOutlinedInput-root"] .MuiAutocomplete-input': {
      padding: '3px 0'
    },
    '.MuiInputLabel-outlined': {
      transform: 'translate(14px, 14px) scale(1)',
      fontSize: '0.8rem'
    },
    '.MuiOutlinedInput-root legend': {
      fontSize: '0.6rem'
    }
  },
  checkbox:{
    '& .MuiFormControlLabel-label': {
      fontSize: '0.8rem',
    },
    '&.MuiFormControlLabel-root': {
      margin: 0,
    },
    '& .MuiCheckbox-root': {
      padding: 0,
    },
  }
});

const resourceTypes = [
  { value: 1, display: 'Film' },
  { value: 2, display: 'TV Item' },
  { value: 3, display: 'TV Segment' },
  { value: 4, display: 'TV Program' },
];

interface State {
  Tabvalue : string;
  documentData: MediaArtifact;
  narrowSubjectOptions: NarrowSubjectOption[];
  fastTermAndIdentifierCount: number;
  showValidationDialog: boolean;
  showValidationErrorDialog: boolean;
  dialogValidationErrors: Array<number>;
  saveAndSubmitRequest: SaveAndSubmitMediaArtifactRequest;
    warningDialogData: WarningDialogData 
}

interface MediaIndexerInputFieldsProps {
  mediaIndexerData: MediaArtifact;
  genreLookup: LookupOption[];
  contentTypeLookup: LookupOption[];
  resourceTypeLookup: LookupOption[];
  broadSubjectLookup: DocumentBroadSubject[];
  languagesLookup: LanguageOption[];
  classificationLookup: LookupOption[];
  locationSuggestions: string[];
  topicSuggestions: string[];

  isPublishedViaWorkflow: boolean;
  isReadOnly: boolean;
  submitTasks: string[];
  errorCodes: ArtifactErrorCode[];
  setDoImplicitUnlockFunction: Function;
  successSnackbarFunction: Function;
  errorSnackbarFunction(error:string): void;
  classes: any;
  history: H.History;
  artifactStatus: ArtifactStatus;
  artifactTypeId: number;
  updateArtifactStatus(newStatus: ArtifactStatus): void;
    saveArtifact(ata: MediaArtifact): void;
    enqueueSnackbar: (message: SnackbarMessage, options?: OptionsObject) => SnackbarKey;
    closeSnackbar: (key?: SnackbarKey) => void;

}

interface ThumbnailSectionProps {
  thumbnails: ThumbnailNode[];
  classes: any;
  validateThumbnails: Function;
  setFieldValue: Function;
  isReadOnly: boolean;
}

interface WarningDialogData {
    isOpen: boolean;
    warnings: string[];
}




export function ThumbnailSection(props: ThumbnailSectionProps): JSX.Element {
  if (props.thumbnails.length > 0) {
    return (<div>
      <Grid item xs={12} className={props.classes.dividerContainer}>
        <Divider className={props.classes.divider} />
        <Typography variant="overline">Thumbnail</Typography>
      </Grid>
      <Grid item xs={10} className={props.classes.thumbnailRow}>
        <Typography className={props.classes.thumbnailSubtitle} variant="caption" display="block" gutterBottom>
          Please select a suitable thumbnail image for this media artifact
          </Typography>
        <ThumbnailSelector
          thumbnails={props.thumbnails}
          onChangeFunction={(value: ThumbnailNode[]) => {
            props.validateThumbnails(value);
            props.setFieldValue('thumbnails', value);
          }}
          readOnly={props.isReadOnly}
        />
      </Grid>
    </div>
    );
  }
  else {
    return (
      <></>
    );
  }
}


class MediaIndexerInputFields extends React.Component<MediaIndexerInputFieldsProps & WithStyles<typeof useStyles>, State, {}> {
  static contextType = AppContext;
    context!: React.ContextType<typeof AppContext>;
     // enqueueSnackbar  = useSnackbar();

    
  constructor(props: MediaIndexerInputFieldsProps) {
    super(props);
    this.onChange = this.onChange.bind(this);
    this.handleTabChange = this.handleTabChange.bind(this);
    this.onChangeDocumentItemNodeList = this.onChangeDocumentItemNodeList.bind(this);
    this.onChangeDocumentContributorList = this.onChangeDocumentContributorList.bind(this);
    this.onChangeFastTermOrIdentifier = this.onChangeFastTermOrIdentifier.bind(this);
    this.calculateNarrowSubjectOptions = this.calculateNarrowSubjectOptions.bind(this);
    this.saveArtifact = this.saveArtifact.bind(this);
    this.saveAndSubmitArtifact = this.saveAndSubmitArtifact.bind(this);
    this.sendError = this.sendError.bind(this);
    this.getFastTermAndIdentifierCount = this.getFastTermAndIdentifierCount.bind(this);
    // this.renderErrorSnackbar = this.renderErrorSnackbar.bind(this);
    // this.renderSuccessSnackbar = this.renderSuccessSnackbar.bind(this);
     
     
      

    //alert(this.props.match.params.SN);
    this.state = {
      Tabvalue: "1",
      documentData: props.mediaIndexerData,
      narrowSubjectOptions: [],
      fastTermAndIdentifierCount: 0,
      showValidationDialog: false,
      showValidationErrorDialog: false,
        dialogValidationErrors: [],
        warningDialogData: {
            isOpen: false,
            warnings: [],
        },
      saveAndSubmitRequest: {
        action: "",
          
        documentData: props.mediaIndexerData,
        validateArtifact: true,
      }
      };

     
  }

  handleTabChange(event: any, newValue: string): void {
    this.setState((prevState) => ({
      ...prevState,
      Tabvalue: newValue
    }));;
  };

  onChange(key: string, value: any): void {
    this.setState((prevState) => ({
      ...prevState,
      documentData: {
        ...prevState.documentData,
        [key]: value
      }
    }));
  }

  onChangeDocumentItemNodeList(key: string, valueList: DocumentItemNode[]): void {
    this.setState((prevState) => ({
      ...prevState,
      documentData: {
        ...prevState.documentData,
        [key]: valueList,
      }
    }));
  }

  onChangeFastTermOrIdentifier(key: string, valueList: DocumentItemNode[]): void {
    let count: number = 0;

    if (key === 'fast') {
      count = valueList.length + this.state.documentData.identifiers.length;
    } else {
      count = valueList.length + this.state.documentData.fast.length;
    }

    this.setState((prevState) => ({
      ...prevState,
      documentData: {
        ...prevState.documentData,
        [key]: valueList,
      },
      fastTermAndIdentifierCount: count,
    }));
  }

  transformGenreList(valueList: number[]) {
    let genreList: DocumentItemNode[] = [];

    for (let i: number = 0; i < valueList.length; i += 1) {
      this.props.genreLookup.forEach(genre => {
        if (valueList[i] === genre.key) {
          genreList.push({ id: genre.key, name: genre.value, createdBy: '', createdDate: '' });
        }
      });
    }

    return genreList;
  }

  onChangeDocumentContributorList(valueList: any): void {
    let documentContributorList: DocumentContributor[] = [];

    for (let i: number = 0; i < valueList.length; i += 1) {
      let typeId = 0;

      if (valueList[i].role === "Host") {
        typeId = 1;
      } else if (valueList[i].role === "Reporter") {
        typeId = 2;
      } else if (valueList[i].role === "Contributor") {
        typeId = 3;
      } else if (valueList[i].role === "Actor") {
        typeId = 4;
      } else if (valueList[i].role === "Director") {
        typeId = 5;
      }

      documentContributorList.push({
        contributorID: i + 1,
        contributorConfidence: valueList[i].contributorConfidence,
        firstName: valueList[i].firstName,
        middleName: valueList[i].middleName,
        lastName: valueList[i].lastName,
        typeID: typeId,
        type: valueList[i].role,
        createdBy: "",
        createdDate: "",
        state: valueList[i].state,
        isNew: valueList[i].isNew
      });
    }

    this.setState((prevState) => ({
      ...prevState,
      documentData: {
        ...prevState.documentData,
        contributors: documentContributorList
      }
    }));
  }

  calculateNarrowSubjectOptions(selectedBroadSubjects: DocumentItemNode[]): NarrowSubjectOption[] {
    let narrowSubjectOptions: NarrowSubjectOption[] = [];

    if (selectedBroadSubjects !== undefined && selectedBroadSubjects.length > 0) {
      this.props.broadSubjectLookup.forEach(subject => {
        selectedBroadSubjects.forEach(broadSubject => {
          if (subject.broadSubjectID === broadSubject.id) {
            subject.narrowSubjects.forEach(narrowSubject => {
              narrowSubjectOptions.concat(...narrowSubjectOptions, { key: narrowSubject.Key, value: narrowSubject.Value });
            });
          }
        });
      });
    }

    return narrowSubjectOptions;
  }

  hideValidationDialog = () => {
    this.setState((prevState) => ({
      ...prevState,
      showValidationDialog: false,
      dialogValidationErrors: [],
    }));
  }

  hideValidationErrorDialog = () => {
    this.setState((prevState) => ({
      ...prevState,
      showValidationErrorDialog: false,
      dialogValidationErrors: [],
    }));
  }

 
  proceedSaveAndSubmitAfterMinReqs(validate: boolean) {
    var request = this.state.saveAndSubmitRequest;
    request.validateArtifact = validate;

    this.setState({
      ...this.state,
      saveAndSubmitRequest: request,
    })
    this.proceedSaveAndSubmit();
  }

  proceedSaveAndSubmit = () => {

    this.setState((prevState) => ({
      ...prevState,
      showValidationDialog: false,
      showValidationErrorDialog: false,
      dialogValidationErrors: [],
    }));

    this.context.showBlockUi();

    let requestUrl = this.context.userInfo?.isInRole("InformitAdmin")
        ? process.env.REACT_APP_API_URL +'/api/MediaIndexer/SaveAndPublishMediaArtifact'
        : process.env.REACT_APP_API_URL +'/api/MediaIndexer/SaveAndSubmitMediaArtifact';

     // this.context.showBlockUi();
      //validate from back-end.
      axios.post(process.env.REACT_APP_API_URL +'/api/MediaIndexer/validate', this.state.saveAndSubmitRequest.documentData)
          .then(() => axios.post(requestUrl, this.state.saveAndSubmitRequest)).then((response) => {
            if (response !== undefined) {
                this.props.successSnackbarFunction('Artifact Saved', {
                    variant: 'success',
                });

                this.props.setDoImplicitUnlockFunction(false);

                this.props.history.push('/tasks/media');
            } else {
                this.props.errorSnackbarFunction('An error occured when trying to save the artifact');
            }
          }).catch((error) => {
              if (error.response.status === 400 && error.response.data !== null && error.response.data !== undefined
                  && error.response.data.length > 0) {
                  const errorNumberList: number[] = error.response.data.map((x: { id: number }) => x.id);
                  this.setState((prevState) => ({
                      ...prevState,
                      dialogValidationErrors: errorNumberList,
                      showValidationErrorDialog: true,
                  }));
              } else {
                  this.props.enqueueSnackbar('An error occurred when trying to save the artifact', {
                      variant: 'error',
                  });
              }
          }).finally(() => {
              this.context.hideBlockUi();
          });


    //axios.post(requestUrl, this.state.saveAndSubmitRequest)
    //  .then((response: any) => {
    //    if (response !== undefined) {
    //      this.props.successSnackbarFunction('Artifact Saved');

    //      this.props.setDoImplicitUnlockFunction(false);

    //      this.props.history.push('/tasks/media');
    //    } else {
    //      this.props.errorSnackbarFunction('An error occured when trying to save the artifact');
    //    }
    //  })
    //  .catch((error: any) => {
    //      if (error.response.status === 400 && error.response.data !== null && error.response.data !== undefined
    //          && error.response.data.length > 0) {
    //      this.setState((prevState) => ({
    //        ...prevState,
    //        dialogValidationErrors: error.response.data,
    //        showValidationErrorDialog: true,
    //      }));
    //    } else {
    //      this.props.errorSnackbarFunction('An error occured when trying to save the artifact');
    //    }
    //  })
    //  .finally(() => {
    //    this.context.hideBlockUi();
    //  });
  }

  navigateBack = () => {
    this.props.history.goBack();
  }

  processArtifact(documentData: MediaArtifact): MediaArtifact {

    //Trim text input fields
    for (let [key, value] of Object.entries(documentData)) {
      if (typeof (value) === "string") {
        documentData[key] = value.trim()
      }
    }

    if (documentData.episode !== undefined && documentData.episode?.toString().indexOf('e') > -1) {
      documentData.episode.toString().replace('e', '');
    }

    if (documentData.series !== undefined && documentData.series?.toString().indexOf('e') > -1) {
      documentData.series.toString().replace('e', '');
    }

    // ClassificationId
      if (documentData.classification !== null && documentData.classification !== undefined && documentData.classification !== '') {
         // documentData.classificationId = this.props.classificationLookup.filter(c => c.key == documentData.classificationId)[0].key;
    } else {
      documentData.classificationId = undefined;
    }

    // Identifiers
    documentData.identifiers.forEach(newId => {
      if (newId.createdDate === '') {
        newId.createdDate = DateTime.local().toString();
      }

      this.props.mediaIndexerData.identifiers.forEach(oldId => {
        if (newId.name === oldId.name) {
          newId.createdBy = oldId.createdBy;
          newId.createdDate = oldId.createdDate;
        }
      })
    });

    // Languages
    documentData.languages.forEach(newLanguage => {
      if (newLanguage.createdDate === '') {
        newLanguage.createdDate = DateTime.local().toString();
      }

      this.props.mediaIndexerData.languages.forEach(oldLanguage => {
        if (newLanguage.id === oldLanguage.id) {
          newLanguage.createdBy = oldLanguage.createdBy;
          newLanguage.createdDate = oldLanguage.createdDate;
        }
      })
    });

    // BroadSubjects
    documentData.broadSubject.forEach(newSubject => {
      if (newSubject.createdDate === '') {
        newSubject.createdDate = DateTime.local().toString();
      }

      this.props.mediaIndexerData.broadSubject.forEach(oldSubject => {
        if (newSubject.name === oldSubject.name) {
          newSubject.createdBy = oldSubject.createdBy;
          newSubject.createdDate = oldSubject.createdDate;
        }
      })
    });

    // Contributors
    documentData.contributors.forEach(newContributor => {
      if (newContributor.createdDate === '') {
        newContributor.createdDate = DateTime.local().toString();
      }
        
        this.props.mediaIndexerData.contributors.forEach(oldContributor => {
            
            if (oldContributor.type === "Host") {
                oldContributor.typeID = 1;
            } else if (oldContributor.type === "Reporter") {
                oldContributor.typeID = 2;
            } else if (oldContributor.type === "Contributor") {
                oldContributor.typeID = 3;
            } else if (oldContributor.type === "Actor") {
                oldContributor.typeID = 4;
            } else if (oldContributor.type === "Director") {
                oldContributor.typeID = 5;
            }

            if (newContributor.firstName === oldContributor.firstName && newContributor.middleName === oldContributor.middleName
                && newContributor.lastName === oldContributor.lastName && newContributor.type === oldContributor.type
                && newContributor.state === oldContributor.state) {
                newContributor.createdBy = oldContributor.createdBy;
                newContributor.createdDate = oldContributor.createdDate;
            }

            if (newContributor.type === "Host") {
                newContributor.typeID = 1;
            } else if (newContributor.type === "Reporter") {
                newContributor.typeID = 2;
            } else if (newContributor.type === "Contributor") {
                newContributor.typeID = 3;
            } else if (newContributor.type === "Actor") {
                newContributor.typeID = 4;
            } else if (newContributor.type === "Director") {
                newContributor.typeID = 5;
            }
        });
    });

    // FAST Terms
    documentData.fast.forEach(newFast => {
      if (newFast.createdDate === '') {
        newFast.createdDate = DateTime.local().toString();
      }

      this.props.mediaIndexerData.fast.forEach(oldFast => {
        if (newFast.name === oldFast.name && newFast.state === oldFast.state) {
          newFast.createdBy = oldFast.createdBy;
          newFast.createdDate = oldFast.createdDate;
        }
      })
    });

    // Geolocations
    documentData.fastGeo.forEach(newGeo => {
      if (newGeo.createdDate === '') {
        newGeo.createdDate = DateTime.local().toString();
      }

      this.props.mediaIndexerData.fastGeo.forEach(oldGeo => {
        if (newGeo.name === oldGeo.name && oldGeo.state === newGeo.state) {
          newGeo.createdBy = oldGeo.createdBy;
          newGeo.createdDate = oldGeo.createdDate;
        }
      })
    });

    // Genres
    documentData.genre.forEach(newGenre => {
      if (newGenre.createdDate === '') {
        newGenre.createdDate = DateTime.local().toString();
      }

      this.props.mediaIndexerData.genre.forEach(oldGenre => {
        if (newGenre.id === oldGenre.id) {
          newGenre.createdBy = oldGenre.createdBy;
          newGenre.createdDate = oldGenre.createdDate;
        }
      })
    });
      
      // ContentType
      //documentData.contentTypeId = this.props.contentTypeLookup.filter(c => c.key === documentData.contentTypeId)[0].key;

      //// ResourceType
      //documentData.resourceTypeId = this.props.resourceTypeLookup.filter(c => c.key === documentData.resourceTypeId)[0].key;
      //console.log('resourceTypeId:' + documentData.resourceTypeId);
    // Narrow Subjects
    documentData.narrowSubject.forEach(newSubject => {
      if (newSubject.createdDate === '') {
        newSubject.createdDate = DateTime.local().toString();
      }

      this.props.mediaIndexerData.narrowSubject.forEach(oldSubject => {
        if (newSubject.name === oldSubject.name) {
          newSubject.createdBy = oldSubject.createdBy;
          newSubject.createdDate = oldSubject.createdDate;
        }
      })
    });

    return documentData;
  }

  setItemsToExisting(documentData: MediaArtifact): void {
    documentData.contributors.forEach(contributor => {
      contributor.isNew = false;
    });

    documentData.fast.forEach(term => {
      term.isNew = false;
    });

    documentData.fastGeo.forEach(location => {
      location.isNew = false;
    });
    }

   

  saveArtifact(documentData: MediaArtifact, validateFunction: Function): void {

    // First we need to work through Identifiers, Broad Subjects, Contributors, FAST Terms, Geolocations, Genres, Narrow Subjects and Notes
    // to find out which ones were created by the system and which ones are new
    documentData = this.processArtifact(documentData);

    this.props.saveArtifact(documentData);
  }


    saveAndSubmitArtifact(documentData: MediaArtifact, validateFunction: Function, actionName: string): void {
    
    // First validate the form
    validateFunction()
      .then((formKeys: any) => {
        if (Object.keys(formKeys).length === 0) {
          // First we need to work through Identifiers, Broad Subjects, Contributors, FAST Terms, Geolocations, Genres, Narrow Subjects and Notes
          // to find out which ones were created by the system and which ones are new
          documentData = this.processArtifact(documentData);

          const request: SaveAndSubmitMediaArtifactRequest = {
            action: actionName,
            
            documentData: documentData,
            validateArtifact: true,
          }

          this.setState((prevState) => ({
            ...prevState,
            saveAndSubmitRequest: request,
          }));
            
          const { isValid, errors } = IndexerValidationHelper.ValidateMinimumPublishReqs(documentData);
            if (isValid) {
                const warnings = IndexerValidationHelper.ValidateMediaIndexerWarnings(documentData);

                // If we have any warnings and the warning dialog is not already open then we want to open the warning dialog
                if (!this.state.warningDialogData.isOpen && !warnings.isValid) {
                    const warningMessages = ResourceStringHelper.MapNumberListToStringList(MediaIndexerWarningStrings, warnings.errors);
                    this.setState((prevState) => ({
                        ...prevState,
                        warningDialogData: {
                            isOpen: true,
                            warnings: warningMessages,
                        }

                    }));

                }
                else {
                    this.proceedSaveAndSubmit();
                }

            } else if (errors !== undefined && errors !== null && errors.length > 0) {
                this.setState((prevState) => ({
                    ...prevState,
                    dialogValidationErrors: errors,
                    showValidationDialog: true,
                }));
            } else {
                this.props.errorSnackbarFunction('An error occured when trying to save the artifact');
                }
                
            
        } else {
          const element: Element = document.getElementsByClassName('Mui-error')[0];

          if (element !== undefined) {
            window.scrollBy({
              top: element.getBoundingClientRect().top - 100,
              behavior: 'smooth'
            });
          }

        }
      });

  }

  isFromSearchPage(): boolean {
      return this.props.submitTasks.length === 0;
  }

  formHasChange(initialValues: MediaArtifact, currentValues: MediaArtifact):boolean {
    const mediaItemArraysEqual = (arr: any[], otherArr: any[]): boolean => {
      if (arr.length !== otherArr.length) {
        return false;
      }

      if (arr.length === 0 && otherArr.length == 0) {
        return true;
      }

      return (isEqual(
          arr.filter(a => a.state !== DocumentNodeStateEnum.UserRemoved).map(a => a.id).sort(),
          otherArr.filter(a => a.state !== DocumentNodeStateEnum.UserRemoved).map(a => a.id).sort()
        ));
    };

    let changed = false;

    for (const key in currentValues) {
      if (currentValues.hasOwnProperty(key)) {
        const newValue = currentValues[key];
        const oldValue = initialValues[key];

        if (!Array.isArray(newValue)) {
          if (oldValue !== newValue) {
            changed = true;
          }
        } else {
          switch (key) {
            // thumbnails can be compared without checking order as the order never changes
            case 'thumbnails':
              changed = !isEqual(newValue, oldValue);
              break;
            // contributors need to check changes in role id and contributor id
            case 'contributors':
              changed = !isEqual(newValue.filter((c: DocumentContributor) => c.state !== DocumentNodeStateEnum.UserRemoved).map((c: DocumentContributor) => `${c.typeID} ${c.contributorID}`).sort(),
                                oldValue.filter((c: DocumentContributor) => c.state !== DocumentNodeStateEnum.UserRemoved).map((c: DocumentContributor) => `${c.typeID} ${c.contributorID}`).sort());
              break;
            // otherwise check if the items are equal ignoring order and user removed items
            default:
              changed = !mediaItemArraysEqual(newValue, oldValue);
          }
        }
        if (changed) {
          return true;
        }
      }
    }

    return false;
  }

  sendError(error: ArtifactErrorCode, reason: string): void {
    // Send data back to the controller
    const request: SendErrorRequest = {
      ArtifactID: this.props.mediaIndexerData.artifactId,
     
      ArtifactErrorTypeID: error.errorID,
      Text: reason
    };
    this.context.showBlockUi();
    axios.post('/api/MediaIndexer/SendError', request)
      .then(
        (result: any) => {
          //this.renderSuccessSnackbar('Error successfully processed');
          this.props.successSnackbarFunction('Error successfully processed');
          this.props.history.push('/');
        }
      )
      .catch((error: any) => {
        //this.renderErrorSnackbar('An error has occured, please try again soon');
        this.props.errorSnackbarFunction('An error has occured, please try again soon');
      })
      .finally(() => {
        this.context.hideBlockUi();
      });
  }

  getSelectedFastTermsLength(fastList: DocumentFastNode[]): number {
    return fastList.filter((term) => term.state === DocumentNodeStateEnum.UserAdded || term.state === DocumentNodeStateEnum.UserVerified).length;
  }

  getFastTermAndIdentifierCount(): number {
    return this.state.fastTermAndIdentifierCount;
  }

  getClassificationDropdownOptions(): DropdownOption[] {
    let dropdownOptionList: DropdownOption[] = [];

    for (let i: number = 0; i < this.props.classificationLookup.length; i++) {
      dropdownOptionList.push({ display: this.props.classificationLookup[i].value, value: this.props.classificationLookup[i].key });
    }

    return dropdownOptionList;
  }
  
  transformContentTypeDropdownOptions(contentTypes: LookupOption[]) {
    let dropdownList: DropdownOption[] = [];
    
    for (let i: number = 0; i < contentTypes.length; i++) {
      dropdownList.push({ value: contentTypes[i].key, display: contentTypes[i].value });
    }

    return dropdownList;
    }

  getResourceTypeDropdownOptions(resourceType: LookupOption[]) {
      let dropdownList: DropdownOption[] = [];

      for (let i: number = 0; i < resourceType.length; i++) {
          dropdownList.push({ value: resourceType[i].key, display: resourceType[i].value });
        }

        return dropdownList;
    }

  validateSelectedFastTermsCount(fastList: DocumentFastNode[], isTvItem: boolean): boolean {
    if (isTvItem) {
      return this.getSelectedFastTermsLength(fastList) === 0
    } else {
      const length: number = fastList.filter((term) => term.state === DocumentNodeStateEnum.UserAdded || term.state === DocumentNodeStateEnum.UserVerified).length;
      return length >= 1 && length <= Constants.FastAndIndentifiersTypedownLimit;
    }
  }

  validateSelectedFastGeoCount(geoList: DocumentFastNode[], isTvItem: boolean): boolean {
    if (isTvItem) {
      return geoList.filter((location) => location.state === DocumentNodeStateEnum.UserAdded || location.state === DocumentNodeStateEnum.UserVerified).length === 0
    } else {
      const length: number = geoList.filter((location) => location.state === DocumentNodeStateEnum.UserAdded || location.state === DocumentNodeStateEnum.UserVerified).length;
      return length <= Constants.GeolocationsTypedownLimit;
    }
  }

  renderValidationDialog(): JSX.Element
  {
    return (
      <ValidationDialog
        isOpen={this.state?.showValidationDialog}
        onProceed={this.proceedSaveAndSubmit}
        onReturn={this.hideValidationDialog}
        errors={this.state?.dialogValidationErrors}
      />
    );
  }

    renderWarningDialog(): JSX.Element {
        return (
            <ConfirmationDialogForList
                dialogTitle="Warning"
                dialogBodyText="There seem to be some issues with this artifact, please confirm the warnings below before continuing"
                dialogBodyList={this.state.warningDialogData.warnings}
                onProceed= {this.proceedSaveAndSubmit}
                onReturn={() => {
                    this.setState((prevState) => ({
                        ...prevState,
                        warningDialogData: {
                            isOpen: false,
                            warnings: [],
                        }

                    }));
                }}
                isOpen={this.state.warningDialogData.isOpen}
            />

        );
    }

  renderValidationErrorDialog(): JSX.Element
  {
    return (
      <ValidationErrorDialog
        isOpen={this.state?.showValidationErrorDialog}
        onReturn={this.hideValidationErrorDialog}
        errors={this.state?.dialogValidationErrors}
            onProceed={() => {
              
          this.proceedSaveAndSubmitAfterMinReqs(false);
        }}
        allowSkip={this.context.userInfo?.isInRole('InformitAdmin')}
      />
    );
  }

  render(): JSX.Element {
    const { classes } = this.props;
    return (
      <Formik
        initialValues={this.props.mediaIndexerData}
        // eslint-disable-next-line @typescript-eslint/no-empty-function
        onSubmit={() => {}}
        validationSchema={Yup.object().shape({
          fullTitle: Yup.string()
            .required('Full Title is required'),
          programName: Yup.string()
            .when('resourceType', {
              is: 'Film',
              then: Yup.string().length(0),
              otherwise: Yup.string().required()
            }),
          description: Yup.string()
            .required('Description is required'),
          productionYear: Yup.number()
            .integer()
            .min(1000)
            .max(9999)
            .positive()
            .required('Year of Production is required'),
          // mixed used instead of series and episode so it allows empty strings
          episode: Yup.mixed()
            .test('is-valid', 'You must enter a whole number greater than 0 with no exponent', (value: string) => {
              return IndexerValidationHelper.ValidateWholeNumberInRange(value, 0, 1000);
            })
            .transform((value) => (value === '' ? null : value))
            .when('resourceType', {
              is: (type) => (type !== 'TV Program'),
              then: Yup.mixed()
                .nullable(),
              otherwise: Yup.mixed()
                .required(),
            }),
          series: Yup.mixed()
            .test('is-valid', 'You must enter a whole number greater than 0 with no exponent', (value: string) => {
              return IndexerValidationHelper.ValidateWholeNumberInRange(value, 0, 1000);
            })
            .transform((value) => (value === '' ? null : value))
            .when('resourceType', {
              is: (type) => (type !== 'TV Program'),
              then: Yup.mixed()
                .nullable(),
              otherwise: Yup.mixed()
                .required(),
            }),
          genre: Yup.array()
            .required(`Genres are required (Minimum of 1, Maximum of ${Constants.GenreChecklistLimit})`)
            .min(1)
            .max(2),
          fast: Yup.array()
            .when('resourceTypeId', {
              is: 2,
              then: Yup.array().test('FAST TV Item validation', 'No FAST Terms can be selected when resource type is TV Item',
                (valueList: DocumentFastNode[]) => { return this.validateSelectedFastTermsCount(valueList, true) }
              ),
              otherwise: Yup.array().test('FAST Standard validation', `FAST Terms are required (Minimum of 1, Maximum of ${Constants.FastAndIndentifiersTypedownLimit})`,
                (valueList: DocumentFastNode[]) => { return this.validateSelectedFastTermsCount(valueList, false) }
              )
            }),
          fastGeo: Yup.array()
            .when('resourceTypeId', {
              is: 2,
              then: Yup.array().test('FASTGeo TV Item validation', 'No FAST Geolocations can be selected when resource type is TV Item',
                (valueList: DocumentFastNode[]) => { return this.validateSelectedFastGeoCount(valueList, true) }
              ),
              otherwise: Yup.array().test('FASTGeo Standard validation', `FAST Geolocations are required (Minimum of 1, Maximum of ${Constants.GeolocationsTypedownLimit})`,
                (valueList: DocumentFastNode[]) => { return this.validateSelectedFastGeoCount(valueList, false) }
              )
            }),
          identifiers: Yup.array()
            .when('resourceTypeId', {
              is: 2,
              then: Yup.array().max(0),
              otherwise: Yup.array().max(Constants.FastAndIndentifiersTypedownLimit)
            }),
          languages: Yup.array()
            .min(1)
            .max(Constants.LanguageTypedownLimit)
            .required('A language must be supplied'),
          broadSubject: Yup.array()
            .min(1)
            .max(Constants.BroadSubjectTypedownLimit)
            .required(`Broad Subject(s) are required (Minimum of 1, Maximum of ${Constants.BroadSubjectTypedownLimit})`),
          narrowSubject: Yup.array()
            .max(Constants.NarrowSubjectTypedownLimit),
        })}
      >
        {(props) => {
          const {
            values,
            touched,
            errors,
            dirty,
            setFieldValue,
            isSubmitting,
            handleChange,
            handleBlur,
            handleSubmit,
            handleReset,
            validateForm,
            initialValues
          } = props;

          function validateThumbnails(valueList: ThumbnailNode[]): void {
            if (valueList.length === 0)
              return;

            let foundSelected = false;

            valueList.forEach((value) => {
              if (value.isSelected) {
                foundSelected = true;
              }
            });

            if (!foundSelected) {
              errors.thumbnails = 'A thumbnail must be chosen';
            } else {
              delete errors.thumbnails;
            }
          }

          const ErrorBtn = withRouter(ErrorButton);

          const onNoteRemove = (noteToDelete: DoucmentNote) => {
            setFieldValue('notes', [...values.notes.filter((note) => (
              note.note !== noteToDelete.note || note.createdBy !== noteToDelete.createdBy || note.createdDate !== noteToDelete.createdDate
              ))])
          };

          const onNoteAdd = (newNote: string) => {
            const noteToAdd: DoucmentNote = {
              note: newNote,
              createdBy: this.context.userInfo.data.name,
              createdDate: DateTime.local().toString(),
            }

            setFieldValue('notes', [...values.notes, noteToAdd]);
                };
               
                
          return (
            <div style={{ position: 'relative', marginLeft: "30px" }}>

              <StickyActionBar offset={this.props.isReadOnly ? 1 : 0}>

                <Button
                  size="small"
                  color="primary"
                  variant="outlined"
                  className={classname(classes.backButton, classes.button)}
                  onClick={this.navigateBack}
                  startIcon={<ArrowBackIcon />}
                >
                  Back
                  </Button>
                <div style={{ float: 'right' }}>
                  <NotesButton
                    isReadOnly={this.props.isReadOnly}
                    notes={values.notes}
                    removeNoteFunction={onNoteRemove}
                    addNoteFunction={onNoteAdd}
                    currentUser={this.context.userInfo.data.name}
                  />
                  {!this.props.isReadOnly && !this.isFromSearchPage() && (
                    <>
                      <ErrorBtn
                        errorCodes={this.props.errorCodes}
                        onSendFunction={this.sendError}
                      />
                                  <SaveAndSubmitButton
                                      options={this.props.submitTasks.filter(v =>v=== "Indexing Complete")}
                        submitFunction={(action: string) => this.saveAndSubmitArtifact(values, validateForm, action)}
                      />
                      <Button
                        className={classname(classes.saveButton, classes.button)}
                        variant="contained"
                        color="primary"
                        size="small"
                        type="button"
                        startIcon={<SaveIcon />}
                        onClick={(event) => {
                          event.preventDefault();
                          this.saveArtifact(values, validateForm);
                        }}
                      >
                        Save
                      </Button>
                    </>
                  )}
                  {this.context.userInfo?.isInRole("InformitAdmin") && (
                    <>
                      {this.isFromSearchPage() && this.props.isPublishedViaWorkflow && (
                        <ErrorBtn
                          errorCodes={this.props.errorCodes}
                          onSendFunction={this.sendError}
                        />
                      )}

                      {this.isFromSearchPage() && this.props.artifactStatus == ArtifactStatus.Published && (
                        <WithdrawButton artifactId={this.props.mediaIndexerData.artifactId} onWithdrawCallback={() => { this.props.updateArtifactStatus(ArtifactStatus.Withdrawn) }} />
                      )}

                      {this.isFromSearchPage() && !this.props.isReadOnly && (
                        <Button color="primary" size="small" className={classes.button} disabled={!this.formHasChange(initialValues, values)} variant="contained" startIcon={<PublishIcon />} onClick={() => this.saveAndSubmitArtifact(values, validateForm, "")}>Save &amp; Publish</Button>
                      )}

                    </>
                  )}
                </div>
              </StickyActionBar>

              <Paper style={{ paddingLeft: '40px', paddingRight: '40px', paddingBottom: '40px' }}>
                <Grid item xs={12}>
                <TabContext value={this.state.Tabvalue}>
                <TabList onChange={this.handleTabChange} aria-label="styled tabs example">

<Tab value="1" label={<Badge badgeContent={(errors.showOnWeb ? 1 : 0) + (errors.title ? 1 : 0) + (errors.fullTitle ? 1 : 0) + (errors.programName ? 1 : 0) + (errors.episodeTitle ? 1 : 0) + (errors.series ? 1 : 0) + (errors.episode ? 1 : 0) + (errors.description ? 1 : 0) + (errors.productionYear ? 1 : 0) } color="error">Main Details</Badge>} />

<Tab value="2" label={<Badge badgeContent={(errors.contributors ? 1 : 0) + (errors.languages ? 1 : 0) + (errors.fast ? 1 : 0) + (errors.fastGeo ? 1 : 0) + (errors.identifiers ? 1 : 0)} color="error">Contributors & Subjects</Badge>} />

<Tab value="3" label={<Badge badgeContent={(errors.genre ? 1 : 0) + (errors.resourceType ? 1 : 0) + (errors.contentType ? 1 : 0) + (errors.broadSubject ? 1 : 0) + (errors.narrowSubject ? 1 : 0) } color="error">Additional</Badge>} />

</TabList>


                  <TabPanel value="1">

                  {this.context.userInfo.isInRole('InformitAdmin') && (
                  <>
                  
                    <Grid item xs={12} className={classes.dividerContainer}>
                      <Typography variant="overline">Admin</Typography>
                    </Grid>
                    <Grid item xs={12} className={classes.contentRow}>
                      <FormControlLabel
                        className={classes.checkbox}
                        control={
                          <Checkbox
                            checked={values.showOnWeb}
                            onChange={handleChange}
                            value={values.showOnWeb}
                            name="showOnWeb"
                            disabled={this.props.isReadOnly}
                          />
                        }
                        label="Show on web"
                      />
                    </Grid>
                    <Grid item xs={12} className={classes.dividerContainer}>
                      <Divider className={classes.divider} />
                    </Grid>
                  </>)}
                  
                  <Grid container item xs={12} className={classes.dividerContainer}>
                    <Typography variant="overline" style={{ width: "100%" }}>Core Summary</Typography>
                  </Grid>

                  <Grid item xs={9} className={classes.contentRow}>
                    {/* Title */}
                    <TextInputField
                      labelText="Title"
                      inputText={values.title}
                      keyName="title"
                      onChangeFunction={handleChange}
                      onBlur={handleBlur}
                      error={!!(errors.title && touched.title)}
                      readOnly={this.props.isReadOnly}
                    />
                  </Grid>

                  <Grid item xs={9} className={classes.contentRow}>
                    {/* Full Title */}
                    <LongTextInputField
                      labelText="Full Title"
                      inputText={values.fullTitle}
                      keyName="fullTitle"
                      onChangeFunction={handleChange}
                      onBlur={handleBlur}
                      error={(!!(errors.fullTitle)) && (!this.props.isReadOnly)}
                      readOnly={this.props.isReadOnly}
                    />
                  </Grid>

                  <Grid item xs={6} className={classes.contentRow}>
                    {/* Program Title */}
                    <TextInputField
                      labelText="Program Title"
                      inputText={values.programName}
                      keyName="programName"
                      onChangeFunction={handleChange}
                      onBlur={handleBlur}
                      error={!!(errors.programName)}
                      errorMessage={'Must be empty when Resource Type is Film. Required all other times'}
                      readOnly={this.props.isReadOnly}
                    />
                  </Grid>

                  <Grid item xs={6} className={classes.contentRow}>
                    {/* Episode Title */}
                    <TextInputField
                      labelText="Episode Title"
                      inputText={values.episodeTitle}
                      keyName="episodeTitle"
                      onChangeFunction={handleChange}
                      onBlur={handleBlur}
                      error={!!(errors.episodeTitle)}
                      readOnly={this.props.isReadOnly}
                    />
                  </Grid>

                  <Grid item xs={2} className={classes.contentRow}>
                    {/* Series No. */}
                    <TextInputField
                      labelText="Series No."
                      inputText={values.series}
                      keyName="series"
                      onChangeFunction={handleChange}
                      onBlur={handleBlur}
                      error={!!(errors.series)}
                      type={'number'}
                      errorMessage={'When added series number must be a whole number between 0 and 1000'}
                      inputProps={{
                        max: '1000',
                        min: '0'
                      }}
                      readOnly={this.props.isReadOnly}
                    />
                  </Grid>

                  <Grid item xs={2} className={classes.contentRow}>
                    {/* Episode No. */}
                    <TextInputField
                      labelText="Episode No."
                      inputText={values.episode}
                      keyName="episode"
                      onChangeFunction={handleChange}
                      onBlur={handleBlur}
                      errorMessage={'When required episode number must be be a whole number between 0 and 1000'}
                      error={!!(errors.episode)}
                      type={'number'}
                      inputProps={{
                        max: '1000',
                        min: '0'
                      }}
                      readOnly={this.props.isReadOnly}
                    />
                  </Grid>

                  <Grid item xs={9} className={classes.contentRow}>
                    {/* Description */}
                    <LongTextInputField
                      labelText="Description"
                      inputText={values.description}
                      keyName="description"
                      onChangeFunction={handleChange}
                      onBlur={handleBlur}
                      error={(!!(errors.description)) && (!this.props.isReadOnly)}
                      readOnly={this.props.isReadOnly}
                    />
                  </Grid>

                  <Grid item xs={2} className={classes.contentRow}>
                    {/* Production Year */}
                    <TextInputField
                      labelText="Production Year"
                      inputText={values.productionYear}
                      keyName="productionYear"
                      onChangeFunction={handleChange}
                      onBlur={handleBlur}
                      error={!!(errors.productionYear)}
                      type={'number'}
                      errorMessage={'Year of Production is required and must be 4 digits in length'}
                      inputProps={{
                        min: '1000'
                      }}
                      readOnly={this.props.isReadOnly}
                    />
                  </Grid>
                 </TabPanel>
                  <TabPanel value="2">
                  <Grid item xs={12} style={{ marginBottom: 15 }} className={classes.dividerContainer}>
                    <Divider className={classes.divider} />
                    <Typography variant="overline">CONTRIBUTORS</Typography>
                  </Grid>

                  <Grid item xs={12} className={classes.contentRow} >
                    {/* Contributors */}
                    <ContributorsTypedown
                      selectedContributors={values.contributors}
                      onChangeFunction={(value: DocumentContributor) => setFieldValue('contributors', value)}
                      errorSnackbarFunction={this.props.errorSnackbarFunction}
                      readOnly={this.props.isReadOnly}
                    />
                  </Grid>

                  <Grid item xs={12} className={classes.dividerContainer}>
                    <Divider className={classes.divider} />
                    <Typography variant="overline">Languages</Typography>
                  </Grid>

                  <Grid item xs={12} className={classes.contentRow}>
                    {/* Language */}
                    <LanguageTypedown
                      selectedLanguages={values.languages}
                      languageLookup={this.props.languagesLookup}
                      keyName="languages"
                      onChangeFunction={(key: string, value: DocumentLangNode[]) => setFieldValue(key, value)}
                      error={!!(errors.languages)}
                      readOnly={this.props.isReadOnly}
                      typedownLimit={Constants.LanguageTypedownLimit}
                    />
                  </Grid>

                  <Grid item xs={12} className={classes.dividerContainer}>
                    <Divider className={classes.divider} />
                    <Typography variant="overline">FAST Geolocations</Typography>
                  </Grid>

                  <Grid item xs={12} className={classes.contentRow}>
                    {/* FAST Geolocations */}
                    <GeolocationsTypedown
                      selectedGeolocations={values.fastGeo}
                      locationSuggestions={this.props.locationSuggestions}
                      keyName="fastGeo"
                      artifactTypeId={this.props.artifactTypeId}
                      onChangeFunction={(key: string, value: DocumentFastNode[]) => setFieldValue(key, value)}
                      disabled={values.resourceTypeId === 2}
                      error={!!(errors.fastGeo)}
                      errorText='Min. 1, Max. 3. Must be empty if TV Item'
                      readOnly={this.props.isReadOnly}
                      typedownLimit={Constants.GeolocationsTypedownLimit}
                    />
                  </Grid>

                  <Grid item xs={12} className={classes.dividerContainer}>
                    <Divider className={classes.divider} />
                    <Typography variant="overline">FAST Terms &amp; Identifiers</Typography>
                  </Grid>

                  <Grid item xs={12} className={classes.contentRow}>
                    {/* FAST Terms */}
                    <TermsTypedown
                      selectedTerms={values.fast}
                      topicSuggestions={this.props.topicSuggestions}
                      keyName="fast"
                      artifactTypeId={this.props.artifactTypeId}
                      onChangeFunction={(key: string, value: DocumentFastNode[]) => setFieldValue(key, value)}
                      fastAndIdentifierCount={this.getSelectedFastTermsLength(values.fast) + values.identifiers.length}
                      fastAndIdentifierLimit={Constants.FastAndIndentifiersTypedownLimit}
                      disabled={values.resourceTypeId === 2}
                      error={!!errors.fast}
                      errorText='Min. 1, Max. 6 (combined with Identifiers). Must be empty if TV Item'
                      readOnly={this.props.isReadOnly}
                    />
                  </Grid>

                  <Grid item xs={12} className={classes.contentRow}>
                    {/* Identifiers */}
                    <Identifiers
                      selectedIdentifiers={values.identifiers}
                      keyName="identifiers"
                      onChangeFunction={(key: string, value: DocumentItemNode[]) => setFieldValue(key, value)}
                      fastAndIdentifierCount={this.getSelectedFastTermsLength(values.fast) + values.identifiers.length}
                      fastAndIdentifierLimit={Constants.FastAndIndentifiersTypedownLimit}
                      disabled={values.resourceTypeId === 2}
                      error={!!(errors.identifiers)}
                      errorText='Max. 6 (combined with FAST Terms). Must be empty if TV Item'
                      errorSnackbarFunction={this.props.errorSnackbarFunction}
                      readOnly={this.props.isReadOnly}
                      artifactType={ArtifactType.Media}
                    />
                  </Grid>
                              </TabPanel>

                  <TabPanel value="3">
                  <Grid item xs={12} className={classes.dividerContainer}>
                    <Divider className={classes.divider} />
                    <Typography variant="overline">Additional</Typography>
                  </Grid>

                  <Grid item xs={10} className={classes.contentRow}>
                    {/* Genre */}
                    <GenreCheckboxList
                      labelText="Informit Genre"
                      preSelectedOptions={values.genre}
                      keyName="genre"
                      onChangeFunction={(key: string, value: DocumentItemNode[]) => setFieldValue(key, value)}
                      readOnly={this.props.isReadOnly}
                      checkboxLimit={Constants.GenreChecklistLimit}
                      checkboxOptions={this.props.genreLookup}
                    />
                  </Grid>
                  
                  <Grid item xs={4} className={classes.contentRow}>
                    {/* Resource Type */}
                    <Dropdown
                      labelText="Resource Type"
                                          id="resourceTypeId"
                      options={this.getResourceTypeDropdownOptions(this.props.resourceTypeLookup)}
                                          selectedOption={values.resourceTypeId}
                      //value={values.resourceTypeId}
                                          keyName="resourceTypeId"
                      onChangeFunction={(key: string, value: string) => setFieldValue(key, value)}
                      isReadOnly={this.props.isReadOnly}
                    />
                  </Grid>

                  <Grid item xs={4} className={classes.contentRow} style={{ marginTop: 15 }}>
                    {/* Content Type */}
                    <Dropdown
                      labelText="Content Type"
                                          id="contentTypeId"
                      options={this.transformContentTypeDropdownOptions(this.props.contentTypeLookup)}
                                          selectedOption={values.contentTypeId}
                      // value={values.contentTypeId}
                                          keyName="contentTypeId"
                      onChangeFunction={(key: string, value: string) => setFieldValue(key, value)}
                      isReadOnly={this.props.isReadOnly}
                    />
                  </Grid>

                  <Grid item xs={4} className={classes.contentRow} style={{ marginTop: 15 }}>
                    {/* Classification */}
                    <Dropdown
                      labelText="Classification"
                                          id="classification"
                                          options={this.getClassificationDropdownOptions()}
                                          selectedOption={values.classification}
                                          keyName="classification"
                      onChangeFunction={(key: string, value: string) => setFieldValue(key, value)}
                      isReadOnly={this.props.isReadOnly}
                    />
                  </Grid>

                  <Grid item xs={10} className={classes.contentRow}>
                    {/* Broad and Narrow Subjects */}
                    <BroadAndNarrowSubjects
                      broadSubjectLookup={this.props.broadSubjectLookup}
                      selectedBroadSubjects={values.broadSubject}
                      selectedNarrowSubjects={values.narrowSubject}
                      broadSubjectKey="broadSubject"
                      narrowSubjectKey="narrowSubject"
                      readOnly={this.props.isReadOnly}
                      onChangeBroadSubjectFunction={(valueList: DocumentItemNode[]) => {
                        setFieldValue('broadSubject', valueList);
                      }}
                      onChangeNarrowSubjectFunction={(valueList: DocumentItemNode[]) => {
                        setFieldValue('narrowSubject', valueList);
                      }}
                      broadSubjectError={!!(errors.broadSubject)}
                      broadSubjectErrorText='Min. 1, Max. 4'
                      narrowSubjectError={!!(errors.narrowSubject)}
                      narrowSubjectErrorText='Max. 4'
                      broadSubjectTypedownLimit={Constants.BroadSubjectTypedownLimit}
                      narrowSubjectTypedownLimit={Constants.NarrowSubjectTypedownLimit}
                    />
                  </Grid>
                  </TabPanel>
                  </TabContext>
                  <ThumbnailSection thumbnails={values.thumbnails ? values.thumbnails : new Array<ThumbnailNode>()} classes={this.props.classes} validateThumbnails={validateThumbnails} setFieldValue={setFieldValue} isReadOnly={this.props.isReadOnly} />
                </Grid>
             
                {/* {this.props.isReadOnly && (<DisabledOverlay />)} */}
                {this.renderValidationDialog()}
                {this.renderWarningDialog()}
                { this.renderValidationErrorDialog() }
                  </Paper>
                  
            </div>
          );
        }}
      </Formik>
    );
  }
}

export default withStyles(useStyles)(withSnackbar(MediaIndexerInputFields));
