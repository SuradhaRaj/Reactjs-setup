type TaskManagementTask = {
  rmitNumber: string;
  indexer: string;
  workflowState: string;
  isLocked: boolean;
  documentId: string;
  itemTitle: string;
  programTitle: string;
  channel: string;
  broadcastDate: string;
  artifactId: number;
  siteId: string;
}

export default TaskManagementTask;
