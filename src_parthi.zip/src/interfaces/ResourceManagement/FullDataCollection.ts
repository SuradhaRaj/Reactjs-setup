import { StrStrTypedownOption, TypedownOption } from '../TypedownOption';

interface DataCollectionRes {
        ResourceId: number ;
        ResourceName: string;
        PeerReviewed: boolean ;
        ResourceTitle: string ;
        ResourceSubtitle: string ;
        ResourceAlternativeTitle: string ;
        ResourceShortName: string ;
        ResourceTypeId: number ;
        AccessRightId: number ;
        MediaTypeId: number ;
        ResourceManagerId: number ;
        Description: string ;
        DescriptionTypeId: number ;
        Extent: string;
        PlaceOfPublication: string ;
        NameOfPublisher: string ;
        NameOfPublisherDisplay: string ;
        DateOfPublication: string ;
        PublicationYear: number ;
        IndexingCompanyId: number ;
        NameOfConference: string ;
        NumberOfConference: string ;
        ThemeOfConference: string ;
        DateOfConference: string ;
        PlaceOfConference: string ;
        SponsorOfConference: string;
        isActive: boolean;
        ResourceIdentifiers: Array<{UID: number; RI: string; Values: Array<string | null>}>;
        ProductList: Array<StrStrTypedownOption>;
        CollectionList: Array<StrStrTypedownOption>;
        TitleLeadingArticle: string ;
        Edition: string ;
        LifeStartDate: string ;
        LifeEndDate: string ;
        Notes: string ;
        SeriesVolume: string ;
        SeriesTitleID: number | null ;
        FrequencyId: number | null ;
        LanguageId: number | null ;
        ResourceFast: Array<number| null> ;
        ResourceFastGeo: Array<number| null> ;
        ResourceIdentifier: Array<number| null> ;
        ResourceSubjectLc: Array<number| null> ;
        ResourceNarrowSubject: Array<number| null> ;
        ResourceBroadSubject: Array<number| null> ;

}

export default DataCollectionRes;
