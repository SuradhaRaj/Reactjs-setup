import React from 'react';
import { shallow } from 'enzyme';
import { CircularProgress } from '@material-ui/core';
import LoadingButton from '../../components/molecules/LoadingButton';

describe('Loading button', () => {
  it('should render the loading spinner', () => {
    const wrapper = shallow(<LoadingButton isLoading />);
    expect(wrapper.find(CircularProgress)).toHaveLength(1);
  });

  it('should render the children', () => {
    const content = 'Content rendered!';
    const wrapper = shallow(<LoadingButton isLoading={false}><p>{content}</p></LoadingButton>);
    expect(wrapper.contains(content));
  });
});
