import React, { useState } from 'react';
import RootIssueAddForm from './RootIssueAddForm';
import Issue from '../../../interfaces/IssueManagement/Issue';

interface State {
    formFilterValue: string;
}

interface Props {
    resourceId: number;
    isLoading: boolean;
    updateIssue(issue: Issue): void;
}

const RootIssue = (props: Props) => {
  const [state] = useState<State>({
    formFilterValue: '',
  });

  const saveIssue = (issue: Issue) => {
    props.updateIssue(issue);
  };

  return (
    <>

      {!props.isLoading && (
      <>
        <RootIssueAddForm
          filterValue={state.formFilterValue}
          resourceId={props.resourceId}
          onSave={saveIssue}
        />
      </>
      )}

    </>
  );
};

export default RootIssue;
