import React from 'react';
import {
  Dialog,
  DialogTitle,
  DialogActions,
  Button,
  DialogContent,
  DialogContentText,
  Typography,
  makeStyles,
  Theme,
  createStyles,
} from '@material-ui/core';
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';

const useStyles = makeStyles((theme: Theme) => createStyles({
  errorMessage: {
    margin: theme.spacing(0),
  },
}));

interface ErrorListDialogProps {
  open: boolean;
  handleClose(): void;
  title: string;
  errors: JSX.Element[];
};

const ErrorListDialog = (props: ErrorListDialogProps) => {
  const classes = useStyles();

  return (
    <Dialog
      open={props.open}
      onClose={props.handleClose}
    >
      <DialogTitle>
        <ErrorOutlineIcon color="secondary" />
        {` ${props.title}`}
      </DialogTitle>
      <DialogContent>
        <DialogContentText>
          {props.errors.map((error) => (
            <Typography className={classes.errorMessage}>
              {error}
            </Typography>
          ))}
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button
          onClick={props.handleClose}
          color="primary"
          variant="outlined"
        >
          Okay
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ErrorListDialog;
