import React from 'react';
import {
  makeStyles, Theme, createStyles, Grid, Typography, Button,
} from '@material-ui/core';
import { DateTime } from 'luxon';
import OpenInNewIcon from '@material-ui/icons/OpenInNew';
import Resource from '../../../../interfaces/ResourceManagement/Resource';
import SecondaryData from '../../../molecules/SecondaryData';
import LuxonExtensions from '../../../../utils/LuxonExtensions';
import BooleanIndicator from '../../../molecules/BooleanIndicator';

interface Props {
  resource: Resource;
}

const useStyles = makeStyles((theme: Theme) => createStyles({
  booleanIndicator: {
    marginLeft: theme.spacing(2),
  },
  tabContent: {
    '& > *': {
      display: 'inline-block',
      // width: 125,
    },
  },
}));
export default (props: Props) => {
  const classes = useStyles();
  return (
    <>
      <Grid container style={{ position: 'relative' }}>
        <Grid item xs={12}>
          <Typography variant="overline">WORKFLOW &amp; ADMIN</Typography>
          <div className={classes.tabContent}>
            <SecondaryData
              title="Last Revision Date"
              content={props.resource.lastRevisiondate !== null ? LuxonExtensions.ToFriendlyDateString(DateTime.fromISO(props.resource.lastRevisiondate)) : 'Never'}
            />
            <SecondaryData
              title="Date Last modified"
              content={props.resource.lastModified !== null ? LuxonExtensions.ToFriendlyDateString(DateTime.fromISO(props.resource.lastModified)) : 'Never'}
            />
            <SecondaryData
              title="Date Created"
              content={props.resource.dateCreated !== null ? LuxonExtensions.ToFriendlyDateString(DateTime.fromISO(props.resource.dateCreated)) : 'Not Available'}
            />
            {/* <SecondaryData title="Title ID" content="123*" /> */}
            <SecondaryData title="Resource ID" content={props.resource.resourceId} />
            {/* <SecondaryData title="File Size" content={1} /> */}
            <SecondaryData title="Content Source" content={props.resource.source} />
            {/* <SecondaryData title="Content DN" content={props.resource.dn} /> */}
            <SecondaryData
              title="Content Import Date"
              content={props.resource.sourceImportDate !== null ? LuxonExtensions.ToFriendlyDateString(DateTime.fromISO(props.resource.sourceImportDate)) : ''}
            />
            <SecondaryData
              title="Live Date"
              content={props.resource.liveDate !== null ? LuxonExtensions.ToFriendlyDateString(DateTime.fromISO(props.resource.liveDate)) : ''}
            />
          </div>
        </Grid>
      </Grid>
      <Grid container style={{ position: 'relative', marginTop: 'auto' }}>
        <Grid item xs={12}>
          <Button href={props.resource.fullTextUrl ?? ''} disabled={!!props.resource.fullTextUrl} endIcon={<OpenInNewIcon />}>Full Text</Button>
          <div style={{ float: 'right' }}>
            <BooleanIndicator className={classes.booleanIndicator} name="Has Full Text" status={props.resource.hasFullText} />
            <BooleanIndicator className={classes.booleanIndicator} name="Has DOI" status={!!props.resource.doi} />
            <BooleanIndicator className={classes.booleanIndicator} name="Has URI" status={props.resource.urLs.length > 0} />
            <BooleanIndicator className={classes.booleanIndicator} name="Has PI" status={!!props.resource.persistentIdentifier} />
            {/* <BooleanIndicator className={classes.booleanIndicator} name="Full Text Indicator" status={props.resource.hasFullText} /> */}
          </div>
        </Grid>
      </Grid>
    </>
  );
};
