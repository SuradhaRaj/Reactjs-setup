import React from 'react';
import {
  makeStyles, Theme, createStyles, Dialog, Button, ListItemIcon, ListItemText,
} from '@material-ui/core';
import AddIcon from '@material-ui/icons/NoteAdd';
import { IndexerArtifactContext } from '../../contexts/IndexerArtifact';
import TextData from '../../../interfaces/TextIndexer/TextData';
import Splitter from '../Splitter';
import StyledMenuItem from '../../molecules/StyledMenuItem';

const useStyles = makeStyles((theme: Theme) => createStyles({
  button: {
    borderRadius: 50,
    margin: 5,
  },
  dialog: {
    padding: theme.spacing(4),
  },
}));

interface AddNewArticlesButtonState {
  splitterDialogOpen: boolean;
}

interface AddNewArticlesButtonProps {
  menuOption?: boolean;
}

const AddNewArticlesButton: React.SFC<AddNewArticlesButtonProps> = (props) => {
  const [state, setState] = React.useState<AddNewArticlesButtonState>({
    splitterDialogOpen: false,
  });

  const classes = useStyles();
  const context = React.useContext(IndexerArtifactContext);
  const artifact = context.Artifact as TextData;

  const toggleSplitterDialog = (open: boolean) => {
    setState((prevState) => ({
      ...prevState,
      splitterDialogOpen: open,
    }));
  };

  const handleCloseDialog = () => (toggleSplitterDialog(false));

  return (
    <>
      {props.menuOption ? (
        <>
          <StyledMenuItem>
            <ListItemIcon>
              <AddIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText
              primary="Add"
              onClick={() => toggleSplitterDialog(true)}
            />
          </StyledMenuItem>
        </>
      ) : (
        <>
          <Button
            variant="contained"
            color="primary"
            size="small"
            type="button"
            startIcon={<AddIcon />}
            onClick={() => toggleSplitterDialog(true)}
            className={classes.button}
          >
            Add
          </Button>
        </>
      )}
      <Dialog
        open={state.splitterDialogOpen}
        fullWidth
        maxWidth="lg"
        onClose={handleCloseDialog}
      >
        <div className={classes.dialog}>
          <Splitter
            handleSuccessfulCompletion={handleCloseDialog}
            isDisabled={false}
            issueId={artifact.dropboxIssue.issueId}
            downloadFiles={artifact.dropboxIssue.files}
            issuePath={`${artifact.dropboxIssue.resourceId}\\${artifact.dropboxIssue.grouping}`}

            addingToEndedIssueWorkflow
            isReplace={false}
          />
        </div>
      </Dialog>
    </>
  );
};

export default AddNewArticlesButton;
