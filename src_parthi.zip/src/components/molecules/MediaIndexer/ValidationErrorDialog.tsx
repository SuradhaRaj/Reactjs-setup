import React from 'react';
import {
  createStyles, Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, Button, makeStyles, Theme, Typography,
} from '@material-ui/core';
import ErrorIcon from '@material-ui/icons/Error';
import ResourceStringHelper from '../../../utils/ResourceStringHelper';
import IndexerValidationStrings from '../../../res/IndexerValidationStrings';

const useStyles = makeStyles((theme: Theme) => createStyles({
  typography: {
    display: 'inline',
    marginLeft: theme.spacing(1),
  },
  errorContainer: {
    marginTop: theme.spacing(2),
  },
  errorRoot: {
    marginBottom: theme.spacing(1),
  },
  errorIcon: {
    color: theme.palette.error.main,
  },
}));

interface Props {
  errors: Array<number>;
  onReturn(): void;
  onProceed(): void;
  isOpen: boolean;
  allowSkip: boolean;
}

interface ErrorProps {
  Error: string;
}

export const ValidationError: React.FC<{ error: number }> = ({ error }) => {
  const classes = useStyles();

  return (
    <div className={classes.errorRoot}>
      <ErrorIcon className={classes.errorIcon} />
      <Typography className={classes.typography}>{ResourceStringHelper.MapNumberToString(IndexerValidationStrings, error)}</Typography>
    </div>
  );
};

export const ValidationErrorDialog: React.FC<Props> = (props) => {
  const classes = useStyles();

  let errorContent: Array<JSX.Element> = [];
  errorContent = props.errors.map((error) => <ValidationError key={error} error={error} />);

  return (
    <Dialog
      open={props.isOpen}
      keepMounted
      aria-labelledby="alert-dialog-slide-title"
      aria-describedby="alert-dialog-slide-description"
    >
      <DialogTitle id="alert-dialog-slide-title">Artifact did not pass minimum requirements</DialogTitle>
      <DialogContent>
        <DialogContentText id="alert-dialog-slide-description">
          {
            props.allowSkip && (
              <Typography>
                <p>By submitting the artifact you will skip minimum requirements.</p>
                <p>Please resolve the following requirements issues if you don&apos;t want to skip:</p>
              </Typography>
            )
          }
          {
            !props.allowSkip && (
              <Typography>Please resolve the following requirements issues:</Typography>
            )
          }
          <div className={classes.errorContainer}>
            {errorContent}
          </div>
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button onClick={props.onReturn} variant="text" color="primary">
          Return
        </Button>
        {props.allowSkip && (
          <Button onClick={props.onProceed} variant="outlined" color="primary" data-skip-min-reqs-btn>
            Submit
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
};
