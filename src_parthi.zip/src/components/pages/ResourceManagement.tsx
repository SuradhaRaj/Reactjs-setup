import React, {
  useState, useEffect, useContext, createRef, useCallback,
} from 'react';
import Grid from '@material-ui/core/Grid';

import { values } from 'lodash';
import {
  makeStyles, createStyles, Theme, Paper, Typography, Hidden, CircularProgress, Drawer, Button, AppBar, Toolbar, IconButton,
} from '@material-ui/core';
import CheckIcon from '@material-ui/icons/Check';
// import { useDispatch } from 'react-redux';
import FilterListIcon from '@material-ui/icons/FilterList';
import Axios, { AxiosResponse } from 'axios';
// import ExpansionPanelForTable from '../organisms/ExpansionPanelForTable';

import { ExportToCsv } from 'export-to-csv';

import RemoveIcon from '@material-ui/icons/Remove';
import SettingsBackupRestoreIcon from '@material-ui/icons/SettingsBackupRestore';
import ArrowLeftIcon from '@material-ui/icons/KeyboardArrowLeft';
import ArrowRightIcon from '@material-ui/icons/KeyboardArrowRight';
import { useDispatch } from 'react-redux';
import { useParams } from 'react-router-dom';
import LoadingExpansionPanel from '../molecules/LoadingExpansionPanel';
import ResourcemgmtHeader from '../organisms/ResourceManagement/ResourceMgmtHeader';
import ResourceIdentifier from '../organisms/ResourceManagement/ResourceIdentifier';
import TitleInformation from '../organisms/ResourceManagement/TitleInformation';
import Publisher from '../organisms/ResourceManagement/publisher';
import Customerservice from '../organisms/ResourceManagement/Customerservice';
// import OrganisationContactinfo from '../organisms/ResourceManagement/OrganisationContact';
import Description from '../organisms/ResourceManagement/Description';
import Workflow from '../organisms/ResourceManagement/Workflow';
import AddSubject from '../organisms/ResourceManagement/AddSubject';
import Organisation from '../organisms/ResourceManagement/Organisation';
import Conference from '../organisms/ResourceManagement/Conference';
import Hubspot from '../organisms/ResourceManagement/Hubspot';
import ProductsCollection from '../organisms/ResourceManagement/Productscollection';

// import { updateTaskManagementList } from '../../store/actions/ActnTextTaskManagement';
// import { useTypedSelector } from '../../store/store';
import ErrorPaper from '../organisms/ErrorPaper';
import TextTaskManagementTasks, { TextTaskManagementTasksValidator } from '../../interfaces/TaskManagementText/TextTaskManagementTasks';
import { AppContext } from '../Context';
// import {  TextWorkflowOrder, WorkflowStatusDisplayNames} from '../../interfaces/enums/WorkflowStatus';
import useRuntypeError from '../hooks/useRuntypeError';
import TextTaskManagementArtifactTask from '../../interfaces/TaskManagementText/TextTaskManagementArtifactTask';
import ArtifactTextTaskTable from '../organisms/TextTaskManagement/ArtifactTextTaskTable';
import { isKeyValue } from '../../interfaces/TaskManagementText/TextTaskManagementRequest';
import DenseFixedLayoutTable from '../organisms/DenseFixedLayoutTable';
import { DateFromToField } from '../organisms/TextTaskManagement/DateFromToField';
import { saveStorageZoomPercent, getStorageZoomPercent } from '../../utils/LocalStorage';

import ResourceReferenceData, { ResourceReferenceDataValidator } from '../../interfaces/ResourceManagement/ResourceReferenceData';
import ResourceResponse, { ResourceResponseValidator } from '../../interfaces/ResourceManagement/ResourceResponse';
import { updateTextReferenceData } from '../../store/actions/ActnResourceReferenceData';
import { UserContext } from '../Layout';
import TitleResourceReferenceData from '../../interfaces/ResourceManagement/TitleInformation';
import { updateTitleReferenceData } from '../../store/actions/ActnTitleResourceReference';
import DataCollectionRes from '../../interfaces/ResourceManagement/FullDataCollection';

const csvoptions = {
  fieldSeparator: ',',
  quoteStrings: '"',
  decimalSeparator: '.',
  showLabels: true,
  showTitle: true,
  filename: 'Exported_CSV',
  useTextFile: false,
  useBom: true,
  useKeysAsHeaders: true,
};

interface CombineData {
  componentdata: DataCollectionRes;
}

interface QueryTextTask {
  IncludeRelated: boolean;
  Groupings: string[];
  WorkflowStatusIds: number[];
  ResourceManagers: number[];
  Publishers: string[];
  Titles: string[];
  currentPage: number;
  pageSize: number;
  priority: number[];
  exportCSV: boolean;
}
interface Pager {
  totalItems: number;
  currentPage: number;
  pageSize: number;
  totalPages: number;
  startPage: number;
  endPage: number;
  startIndex: number;
  endIndex: number;
  pages: number[];
}

interface State {
  isError: boolean;
  isLoading: boolean;
  filterDrawerOpen: boolean;
  isUpdating: boolean;
  isFiltered: boolean;
  // filterSelected?: SelectedOptionState;
  pageSize: number;
  zoom: number;
  childvalue: string;
  coferencep: ConfrProp;
  // isApplyFilter: boolean;
}

interface ConfrProp {
  ConferenceDate: string;
  ConferenceName: string;
  ConferenceNumber: string;
  ConferenceSponsor: string;
  ConferenceTheme: string;
}

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    paddingLeft: theme.spacing(2),
    paddingRight: theme.spacing(2),
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
    marginBottom: theme.spacing(2),
  },
  container: {
    marginBottom: theme.spacing(2),
  },
  noTasks: {
    padding: theme.spacing(4),
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkIcon: {
    display: 'inline',
    color: theme.palette.success.main,
    marginRight: theme.spacing(1),
  },
  loadingContainer: {
    flexDirection: 'column',
  },
  updatingSpinner: {
    position: 'absolute',
    top: -36,
    right: 12,
    display: 'flex',
    alignItems: 'center',
  },
  filterButton: {
    position: 'absolute',
    top: -36,
    left: 12,
  },
  paper: {
    position: 'sticky',
    top: theme.spacing(2),
  },
  filterIcon: {
    marginLeft: theme.spacing(1),
  },
  hiddenTasksPaper: {
    padding: theme.spacing(2),
    textAlign: 'center',
  },
  changeFilterText: {
    fontWeight: 600,
    marginTop: theme.spacing(1),
  },
  appBar: {
    top: 'auto',
    bottom: 0,
  },
  grow: {
    flexGrow: 1,
  },
  pagination: {
    backgroundColor: '#fefefe',
    borderRadius: '10px',
  },

}));

export default () => {
  // const { resId } = useParams();

  const [state, setState] = useState<State>({
    filterDrawerOpen: false,
    isError: false,
    isLoading: true,
    isUpdating: true,
    isFiltered: false,
    pageSize: 100,
    zoom: getStorageZoomPercent(),
    childvalue: '',
    coferencep: {
      ConferenceDate: '',
      ConferenceName: '',
      ConferenceNumber: '',
      ConferenceSponsor: '',
      ConferenceTheme: '',
    },
  });

  const [pager, setPager] = useState<Pager>({
    totalItems: 0,
    currentPage: 0,
    pageSize: 0,
    totalPages: 0,
    startPage: 0,
    endPage: 0,
    startIndex: 0,
    endIndex: 0,
    pages: [],
  });
  function clearDataCollection() {
    return {
      ResourceId: 0,
      ResourceName: '',
      PeerReviewed: false,
      ResourceTitle: '',
      ResourceSubtitle: '',
      ResourceAlternativeTitle: '',
      ResourceShortName: '',
      ResourceTypeId: 0,
      AccessRightId: 0,
      MediaTypeId: 0,
      ResourceManagerId: 0,
      Description: '',
      DescriptionTypeId: 0,
      PlaceOfPublication: '',
      NameOfPublisher: '',
      NameOfPublisherDisplay: '',
      DateOfPublication: '',
      PublicationYear: 0,
      IndexingCompanyId: 0,
      NameOfConference: '',
      NumberOfConference: '',
      ThemeOfConference: '',
      DateOfConference: '',
      PlaceOfConference: '',
      SponsorOfConference: '',
      Extent: '',
      isActive: false,
      ResourceIdentifiers: [],
      ProductList: [],
      CollectionList: [],
      TitleLeadingArticle: '',
      Edition: '',
      LifeStartDate: '',
      LifeEndDate: '',
      Notes: '',
      SeriesVolume: '',
      SeriesTitleID: 0,
      FrequencyId: 0,
      LanguageId: 0,
      ResourceFast: [],
      ResourceFastGeo: [],
      ResourceIdentifier: [],
      ResourceSubjectLc: [],
      ResourceNarrowSubject: [],
      ResourceBroadSubject: [],
    };
  }

  const [alldata, setAlldata] = useState<DataCollectionRes>(
    clearDataCollection(),
  );

  const context = useContext(AppContext);
  // const [tasks, setTasks] = useState<TextTaskManagementTasks>([]);
  const [tasks, setTasks] = useState<TitleResourceReferenceData>();
  // const [hasTasks, setHasTasks] = useState<boolean>(false);
  // const taskManagementValidator = useRuntypeError(TextTaskManagementTasksValidator);
  const classes = useStyles();

  const isAdmin = context.userInfo.isInAnyRole(['InformitAdmin', 'IndexersAdmin']);
  const canUnlock = isAdmin;

  // const isAdmin = false;
  const ref = createRef<HTMLDivElement>();
  const dispatch = useDispatch();
  const referenceDataValidator = useRuntypeError(ResourceReferenceDataValidator);
  const resourceValidator = useRuntypeError(ResourceResponseValidator);

  function zoom(zoomPercent: number) {
    if (ref !== null && ref.current !== null) {
      // ref.current.style.zoom = `${zoomPercent}%`;

      setState((prestate) => ({
        ...prestate,
        zoom: zoomPercent,
      }));
    }
  }

  function zoomIn() {
    const zoomPercent = state.zoom - 5;
    zoom(zoomPercent);
    saveStorageZoomPercent(zoomPercent);
  }

  function zoomRest() {
    const zoomPercent = 100;
    zoom(zoomPercent);
    saveStorageZoomPercent(zoomPercent);
  }

  function scroll(move: number) {
    if (ref !== null && ref.current !== null) {
      const scrollbar = ref.current?.scrollLeft;
      ref.current.scrollLeft = scrollbar + move;
    }
  }

  // @ts-ignore
  const { navstate, setNavState } = useContext(UserContext);
  useEffect(() => {
    setNavState({ type: 'TEXT_TILE', payload: true });
  }, []);

  useEffect(() => {
    setState((prevState) => ({
      ...prevState,
      isLoading: true,
      isUpdating: true,
      childvalue: state.childvalue,
    }));

    Axios.get<TitleResourceReferenceData>(`${process.env.REACT_APP_API_URL}/api/resource/referencedata`)
      .then((referenceDataResp) => {
        console.log(referenceDataValidator.validate(referenceDataResp.data));
        // if (referenceDataValidator.validate(referenceDataResp.data)) {

        dispatch(updateTitleReferenceData(referenceDataResp.data));
        //   }

        setState((prevState) => ({
          ...prevState,
          isLoading: false,
          isError: false,
          isUpdating: false,
        }));

        const records = referenceDataResp.data;
        //  const pager1 = response.data.pager;
        //  setPager(pager1);
        setTasks(records);
        // setHasTasks(true);
      })
      .catch(() => {
        setState((prevState) => ({
          ...prevState,
          isError: true,
        }));
      }).finally(() => {
        setState((prevState) => ({
          ...prevState,
          isLoading: false,
          isUpdating: false,
        }));
      });
  }, []);

  const toggleDrawer = () => {
    setState((prevState) => ({
      ...prevState,
      filterDrawerOpen: !prevState.filterDrawerOpen,
    }));
  };
  const getResourceHeadercallback = useCallback((data: any) => {
    console.log(data);
    setAlldata((prevState) => ({
      ...prevState,
      ResourceId: data.resourceId,
      ResourceName: data.resourceName,
      PeerReviewed: data.peerReviewIndicator === 1,
      // ResourceTitle: data.resourceId == 0 ?  alldata.ResourceTitle: data.resourceTitle,
      ResourceSubtitle: data.resourceName,
      ResourceShortName: data.resourceName,
      ResourceTypeId: data.resourceTypeval,
      AccessRightId: data.accessRights,
      MediaTypeId: data.mediaType,
      ResourceManagerId: data.resourceManager === undefined ? 0 : data.resourceManager,
      IndexingCompanyId: data.indexingCompany,
      isActive: data.Active === 1,
    }));
  }, []);

  const getTitlecallback = useCallback((data: any) => {
    console.log(data);
    setAlldata((prev) => ({
      ...prev,
      TitleLeadingArticle: data.titledata.titleinfo.titleLeadingArticle,
      Edition: data.titledata.titleinfo.edition,
      LifeStartDate: data.titledata.titleinfo.lifestartdate,
      LifeEndDate: data.titledata.titleinfo.lifeenddate,
      Notes: data.titledata.titleinfo.titlenotes,
      SeriesVolume: data.titledata.titleinfo.seriesvolume,
      SeriesTitleID: data.filterdata.filterFields.uniformtitleId,
      FrequencyId: data.filterdata.filterFields.frequencyId,
      LanguageId: data.filterdata.filterFields.languageId,
      ResourceAlternativeTitle: data.titledata.titleinfo.alternativetitle,
      ResourceTitle: data.titledata.titleinfo.title,
    }));
  }, []);

  const getConferencecallback = useCallback((data: any) => {
    console.log('confstate', data);
    setAlldata((prev) => ({
      ...prev,
      DateOfConference: data.ConferenceDate,
      NameOfConference: data.ConferenceName,
      NumberOfConference: data.ConferenceNumber,
      SponsorOfConference: data.ConferenceSponsor,
      ThemeOfConference: data.ConferenceTheme,
    }));
  }, []);

  const getPublishercallback = useCallback((data: any) => {
    console.log(data);
    setAlldata((prevState) => ({
      ...prevState,
      NameOfPublisher: data.publisherName,
      NameOfPublisherDisplay: data.publisherDisplay,
      PlaceOfPublication: data.publisherPlace,
      DateOfPublication: data.publisherDate,
    }));
  }, []);

  const getDiscriptioncallback = useCallback((data: any) => {
    console.log(data);
    setAlldata((prevState) => ({
      ...prevState,
      Description: data.description,
      DescriptionTypeId: data.descriptiontypeid,
      Extent: data.extent,
    }));
  }, []);

  const getSubjectncallback = useCallback((data: any) => {
    console.log(data);

    setAlldata((prevState) => ({
      ...prevState,
      ResourceFast: data.listchpfastid,
      ResourceFastGeo: data.listchpfastgeoid,
      ResourceIdentifier: data.listchpidentid,
      ResourceSubjectLc: data.listchpsubjid,
      ResourceNarrowSubject: data.listchpnarrowid,
      ResourceBroadSubject: data.listchpbroadid,

    }));
  }, []);

  const getResIdentifiercallback = useCallback((data: any) => {
    console.log(data);
    setAlldata((prevState) => ({
      ...prevState,
      ResourceIdentifiers: data,
    }));
  }, []);

  const prodCollectionCallBack = useCallback((data: any) => {
    console.log(data);
    setAlldata((prevState) => ({
      ...prevState,
      ProductList: data.prodList,
      CollectionList: data.collectionList,
    }));
  }, []);
  // const updateArtifactRow = (row: TextTaskManagementArtifactTask) => {
  //   const index = tasks.findIndex((x) => x.artifactId === row.artifactId);
  //   const newTasks = [...tasks];
  //   newTasks.splice(index, 1, row);

  //   setTasks({ ...newTasks });
  // };

  // function paginationHandleChange(event: React.ChangeEvent<unknown>, value: number) {
  //  setState({
  //    ...state,
  //    isLoading: true,
  //  });
  //  // console.log(state.filterSelected);
  //  requestFilter(state.filterSelected, value, state.pageSize);
  // }

  // const taskList = values(tasks);

  // const textTables: JSX.Element[] = [];
  // textTables.push(
  //   <Grid container className={classes.container} data-issue-group>
  //     <Grid item xs={12}>
  //       <ArtifactTextTaskTable
  //         rows={taskList}
  //         canUnlock={canUnlock}
  //         onUpdate={updateArtifactRow}
  //         isAdmin={isAdmin}
  //       />
  //     </Grid>
  //   </Grid>,
  // );

  if (state.isError) {
    return (<ErrorPaper text="Unable to load the list of tasks." />);
  }

  // if (!taskManagementValidator.isValid) {
  //   return taskManagementValidator.error();
  // }

  // if (!hasTasks && !state.isFiltered && !state.isLoading) {
  //   return (
  //     <>
  //       <Grid container justify="center">
  //         <Grid item xs={3}>
  //           <Paper className={classes.noTasks}>
  //             <CheckIcon className={classes.checkIcon} />
  //             <Typography component="span">There are no tasks to complete!</Typography>
  //           </Paper>
  //         </Grid>
  //       </Grid>
  //     </>
  //   );
  // }

  return (
    <>
      <Grid container justify="center" spacing={2} className={classes.root}>
        <Hidden mdDown>
          <Grid item xs={12} lg={12} xl={12}>
            <Paper className={classes.paper}>

              <ResourcemgmtHeader Resourcemgmtdata={alldata} callback={getResourceHeadercallback} />

              <ResourceIdentifier isLoading={state.isLoading} callback={getResIdentifiercallback} />

              <TitleInformation isLoading={state.isLoading} callback={getTitlecallback} />

              <Publisher isLoading={state.isLoading} callback={getPublishercallback} />

              <Conference isLoading={state.isLoading} childvalue="from parent" callback={getConferencecallback} />

              <Organisation isLoading={state.isLoading} />

              <Hubspot isLoading={state.isLoading} />

              <AddSubject isLoading={state.isLoading} callback={getSubjectncallback} />

              <Description isLoading={state.isLoading} callback={getDiscriptioncallback} />

              <Workflow isLoading={state.isLoading} />

              <Customerservice isLoading={state.isLoading} />

              <ProductsCollection isLoading={state.isLoading} callback={prodCollectionCallBack} />
            </Paper>
          </Grid>
        </Hidden>
      </Grid>
    </>
  );
};

const LoadingPanels = () => {
  const classes = useStyles();
  return (
    <>
      {
        [...Array(3)].map(() => (
          <Grid container justify="center">
            <Grid item xs={12}>
              <LoadingExpansionPanel className={classes.container} />
            </Grid>
          </Grid>
        ))
      }
    </>

  );
};
