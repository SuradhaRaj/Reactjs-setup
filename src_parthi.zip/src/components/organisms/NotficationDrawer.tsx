import React from 'react';

import {
  Drawer, Button, makeStyles,
} from '@material-ui/core';
import NotificationsIcon from '@material-ui/icons/Notifications';
import NotificationsActiveIcon from '@material-ui/icons/NotificationsActive';
import Badge from '@material-ui/core/Badge';

const useStyles = makeStyles({
  root: {
    width: '300px',
    backgroundColor: '#f9f9fc',
    border: '0px',
    padding: '20px',
  },
  heading: {
    float: 'right',
  },
  workflowButton: {
    borderRadius: '50px',
    float: 'right',
    marginRight: '20px',
  },
  notificationsRed: {
    color: '#ff0000',

  },
});

interface Props {
    content: JSX.Element;
    messageCount: number;
  }

export default function NotificationDrawer(props: Props): JSX.Element {
  const classes = useStyles();
  const [state, setState] = React.useState({
    open: false,
  });

  const toggleDrawer = () => (
    event: React.KeyboardEvent | React.MouseEvent,
  ) => {
    if (
      event.type === 'keydown'
            && ((event as React.KeyboardEvent).key === 'Tab'
                || (event as React.KeyboardEvent).key === 'Shift')
    ) {
      return;
    }
    const isOpen = !state.open;

    setState({ open: isOpen });
  };

  return (
    <>
      <Button
        className={classes.workflowButton}
        onClick={toggleDrawer()}
        color="primary"
        variant="text"
        size="small"
      >
        <Badge badgeContent={props.messageCount} color="secondary">
          {props.messageCount > 0 ? <NotificationsActiveIcon className={classes.notificationsRed} /> : <NotificationsIcon />}
        </Badge>
        {}
      </Button>
      <Drawer anchor="right" open={state.open} onClose={toggleDrawer()}>
        <div className={classes.root}>
          {props.content}
        </div>
      </Drawer>
    </>
  );
}
