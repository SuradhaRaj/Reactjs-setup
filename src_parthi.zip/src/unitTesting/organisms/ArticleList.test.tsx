import React from 'react';
import { mount } from 'enzyme';
import { Step } from '@material-ui/core';
import ArticleList from '../../components/organisms/ArticleList';
import ArticleStatus from '../../interfaces/enums/ArticleStatus';

const wrapper = mount(<ArticleList
  articles={[
    { title: 'Step 1', id: '1', status: ArticleStatus.Available },
    { title: 'Step 2', id: '2', status: ArticleStatus.Error },
    {
      title: 'Step 3', id: '3', status: ArticleStatus.Locked, indexer: 'Will Middlemiss',
    },
    { title: 'Step 4', id: '4', status: ArticleStatus.Complete },
  ]}
  activeArticleId="1"
  handleChange={() => undefined}
/>);

describe('Article List', () => {
  it('should render the correct number of items', () => {
    expect(wrapper.find(Step)).toHaveLength(4);
  });

  it('should render each the title of each step', () => {
    expect(wrapper.contains('Step 1')).toBe(true);
    expect(wrapper.contains('Step 2')).toBe(true);
    expect(wrapper.contains('Step 3')).toBe(true);
    expect(wrapper.contains('Step 4')).toBe(true);
  });

  it('should display the active step', () => {
    expect(wrapper.find('.MuiStepLabel-active').exists()).toBe(true);
  });
});
