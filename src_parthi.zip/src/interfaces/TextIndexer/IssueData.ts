import {
  Record, Static, Boolean,
} from 'runtypes';
import Artifact from '../Artifact';
import { IssueArtifactValidator } from './IssueArtifact';

export const IssueDataValidator = Record({
  info: IssueArtifactValidator,
  isReadOnly: Boolean,
});

type IssueData = Static<typeof IssueDataValidator> & Artifact;
export default IssueData;
