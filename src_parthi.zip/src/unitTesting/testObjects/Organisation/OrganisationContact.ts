import faker from 'faker';
import OrganisationContact from '../../../interfaces/Organisation/OrganisationContact';

const obj = (): OrganisationContact => ({
  contactId: faker.random.number(),
  title: faker.name.prefix(),
  firstName: faker.name.firstName(),
  surname: faker.name.lastName(),
  email: faker.internet.email(),
  address: faker.address.streetAddress(),
  suburb: faker.address.city(),
  country: faker.address.countryCode(),
  state: faker.address.state(),
  postcode: faker.address.zipCode(),
  homePhone: faker.phone.phoneNumber(),
  workPhone: faker.phone.phoneNumber(),
  hubSpotId: faker.random.number(),
  roles: [{ name: 'Role1', contactRoleId: faker.random.number({ min: 1, max: 3 }), isCRM: true }],
});

export default obj;
