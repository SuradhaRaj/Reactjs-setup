import React from 'react';
import { createStyles, makeStyles } from '@material-ui/core/styles';
import { Theme } from '@material-ui/core';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    backgroundColor: '#EFF2F8',
    position: 'sticky',
    top: (offset: number) => offset * 48,
    marginBottom: 0,
    height: 60,
    paddingTop: 10,
    zIndex: 999,
    marginLeft: -3,
    marginRight: -3,
  },
  typography: {
    display: 'inline',
    marginLeft: theme.spacing(2),
  },
}));

interface Props {
  offset: number;
}

const StickyActionBar: React.FC<React.PropsWithChildren<Props>> = ({ children, ...props }) => {
  const classes = useStyles(props.offset);

  return (
    <div className={classes.root}>
      {children}
    </div>
  );
};

export default StickyActionBar;
