import React, { useState } from 'react';
import {
  Grid, Badge, IconButton, createStyles, makeStyles, Tooltip,
} from '@material-ui/core';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import NotesIcon from '@material-ui/icons/Notes';
import { DateTime } from 'luxon';
import ClearIcon from '@material-ui/icons/Clear';
import LuxonExtensions from '../../../utils/LuxonExtensions';
import DoucmentNote from '../../../interfaces/MediaIndexer/DocumentNote';
import NoteCreatorType from '../../../interfaces/enums/NoteCreatorType';
import SmallChip from '../SmallChip';

const useStyles = makeStyles(createStyles({
  dialogText: {
    marginBottom: '20px',
  },
  notesButton: {
    borderRadius: '50px',
    margin: 5,
  },
  userNote: {
    marginBottom: '15px',
  },
  notesContainer: {
    height: '700px',
    minWidth: '700px',
  },
  createdBy: {
    fontWeight: 600,
  },
  addButton: {
    top: '15px',
    float: 'right',
  },
  '@global': {
    '.MuiBadge-anchorOriginTopRightRectangle': {
      top: 7,
      right: 7,
    },
  },
}));

interface State {
  open: boolean;
  note: string;
}

interface Props {
  notes: DoucmentNote[];
  addNoteFunction(newNote: string): void;
  removeNoteFunction(noteToDelete: DoucmentNote): void;
  isReadOnly?: boolean;
  currentUser: string;
}

export default function NotesButton(props: Props): JSX.Element {
  const classes = useStyles();
  const [state, setState] = useState<State>({
    open: false,
    note: '',
  });

  const handleOpenDialog = (): void => {
    setState({
      ...state,
      open: true,
    });
  };

  const handleCloseDialog = (): void => {
    setState({
      ...state,
      open: false,
    });
  };

  const handleAddNote = (): void => {
    if (state.note.trim().length > 0) {
      props.addNoteFunction(state.note.trim());
      setState({
        ...state,
        note: '',
      });
    }
  };

  const handleKeyPress = (event: React.KeyboardEvent): void => {
    if (event.key === 'Enter') {
      handleAddNote();
    }
  };

  const handleNoteChange = (event: React.ChangeEvent<HTMLInputElement>): void => {
    setState({
      ...state,
      note: event.target.value,
    });
  };

  const getType = (type: NoteCreatorType) => {
    switch (type) {
      case NoteCreatorType.Publisher:
        return 'Publisher';
      case NoteCreatorType.ResourceManager:
        return 'Resource Manger';
      default:
        return 'Indexer';
    };
  };

  const renderNotes = (): JSX.Element => {
    if (props.notes !== undefined && props.notes.length > 0) {
      return (
        <div className={classes.userNote}>
          {props.notes.map((note) => (
            <div key={note.createdDate} style={{ marginBottom: '30px' }}>
              {note.createdBy !== props.currentUser
                ? (
                  <DialogContentText className={classes.createdBy}>
                    <>
                      {!note.noteType
                        ? (
                          note.createdBy
                        ) : (
                          <Tooltip
                            title={note.createdBy}
                            placement="top"
                            arrow
                          >
                            <span><SmallChip label={getType(note.noteType)} /></span>
                          </Tooltip>
                        )}
                    </>
                    {' '}
                    -
                    {' '}
                    {LuxonExtensions.ToFriendlyDateString(DateTime.fromISO(note.createdDate))}
                  </DialogContentText>
                )
                : (
                  <DialogContentText className={classes.createdBy}>
                    {note.noteType === undefined ? ('You ') : (
                      <SmallChip label="You" />
                    )}
                    {' '}
                    -
                    {' '}
                    {LuxonExtensions.ToFriendlyDateString(DateTime.fromISO(note.createdDate))}
                    <IconButton onClick={() => props.removeNoteFunction(note)}><ClearIcon /></IconButton>
                  </DialogContentText>
                )}
              <DialogContentText>
                {note.note}
              </DialogContentText>
            </div>
          ))}
        </div>
      );
    }
    return (
      <>
      </>
    );
  };

  const renderNoteInput = (): JSX.Element => (
    <Grid container item xs={12}>
      <Grid item xs={11}>
        <TextField
          autoFocus
          margin="dense"
          id="name"
          label="Note"
          type="text"
          fullWidth
          value={state.note}
          onChange={handleNoteChange}
          onKeyPress={handleKeyPress}
        />
      </Grid>
      <Grid item xs={1}>
        <Button
          className={classes.addButton}
          onClick={handleAddNote}
          variant="contained"
          color="primary"
        >
          Add
        </Button>
      </Grid>
    </Grid>
  );

  return (
    <>

      <Badge badgeContent={props.notes.length} color="primary">
        <Button
          variant="outlined"
          size="small"
          color="primary"
          className={classes.notesButton}
          onClick={handleOpenDialog}
          startIcon={<NotesIcon />}
        >
          Notes
        </Button>
      </Badge>
      <Dialog
        fullWidth
        maxWidth="md"
        open={state.open}
        onClose={handleCloseDialog}
        aria-labelledby="form-dialog-title"
      >
        <DialogTitle id="form-dialog-title">Notes</DialogTitle>
        <DialogContent>
          {renderNotes()}
          {!props.isReadOnly
            && renderNoteInput()}
        </DialogContent>
        <DialogActions>
          <Button color="primary" onClick={handleCloseDialog}>
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
