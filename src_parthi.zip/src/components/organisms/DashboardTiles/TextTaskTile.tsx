import React, { useState, useEffect, useContext } from 'react';
import Axios from 'axios';
import DashboardTaskStatusTile from '../../molecules/DashboardTaskStatusTile';
import TileListItem from '../../../interfaces/Dashboard/TileListItem';
import { AppContext } from '../../Context';

interface State {
  IsLoading: boolean;
    TileListData: TileListItem[];
    Url: string;
}

export default function TextTaskTile(): JSX.Element {
  const [state, setState] = useState<State>({
    IsLoading: true,
    TileListData: [],
    Url: '',
  });

  const context = useContext(AppContext);
  const isAdmin = context.userInfo.isInAnyRole(['InformitAdmin', 'IndexersAdmin']);

  useEffect(() => {
    const tileData: TileListItem[] = [];

    Axios.get(`${process.env.REACT_APP_API_URL}/api/dashboard/TextTask`, { headers: { 'Content-Type': 'application/json' } })
      .then((response) => {
        if (response.status === 200) {
          for (let i = 0; i < response.data.length; i++) {
            tileData.push({ name: response.data[i].Description, value: response.data[i].Value });
          }
        }
      })
      .finally(() => {
        let urlValue = '';
        if (isAdmin) {
          urlValue = '/resource-management';
        } else {
          urlValue = '/tasks/text';
        }
        setState({
          ...state,
          IsLoading: false,
          TileListData: tileData,
          Url: urlValue,
        });
      });
  }, []);

  return (
    <>
      <DashboardTaskStatusTile
        title="Text Tasks"
        url={state.Url}
        tileList={state.TileListData}
        isLoading={state.IsLoading}
      />
    </>
  );
}
