import TextValidationSchemaComposer from '../../utils/TextValidationSchemaComposer';
import WorkflowStatus from '../../interfaces/enums/WorkflowStatus';

describe('Text Validation Schema Composer - Get Schema', () => {
  it('should return the correct schema based on parameters', () => {
    const result1 = TextValidationSchemaComposer.GetSchema(WorkflowStatus.IndexingInProgress);
    expect(result1.schemaNames).toEqual(['Standard']);

    // const result2 = TextValidationSchemaComposer.GetSchema(WorkflowStatus.AdvancedIndexingInProgress);
    // expect(result2.schemaNames).toEqual(['Standard', 'Advanced']);

    const result3 = TextValidationSchemaComposer.GetSchema(WorkflowStatus.LegalIndexingInProgress);
    expect(result3.schemaNames).toEqual(['Standard', 'Advanced', 'Legal']);
  });

  it('should return the default schema if provided with an unknown parameter', () => {
    const result1 = TextValidationSchemaComposer.GetSchema(0);
    expect(result1.schemaNames).toHaveLength(1);
    expect(result1.schemaNames).toEqual(['Standard']);
  });
});
