export default {
  primary: '#000054',
  secondary: '#E60028',
  background: '#EFF2F8',
};
