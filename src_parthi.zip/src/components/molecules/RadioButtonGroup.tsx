import * as React from 'react';
import {
  FormControl, FormLabel, RadioGroup, FormControlLabel, Radio, Typography,
} from '@material-ui/core';

interface RadioButton {
  value: string;
  label: string;
}

interface RadioButtonGroupProps {
  name: string;
  value: string;
  label: string;
  onChange(e: React.ChangeEvent<HTMLInputElement>, value: string): void;
  buttons: RadioButton[];
  readonly?: boolean;
  onBlur?(e: React.FocusEvent<HTMLDivElement>): void;
};

const RadioButtonGroup = (props: RadioButtonGroupProps) => (
  <FormControl component="fieldset" size="small">
    <FormLabel component="legend">
      {props.label}
    </FormLabel>
    <RadioGroup
      name={props.name}
      value={props.value}
      onChange={props.onChange}
      onBlur={props.onBlur}
    >
      {props.buttons.map((button) => (
        <FormControlLabel
          value={button.value}
          control={<Radio color="primary" />}
          label={<Typography variant="body2">{button.label}</Typography>}
          disabled={props.readonly}
        />
      ))}
    </RadioGroup>
  </FormControl>
);

export default RadioButtonGroup;
