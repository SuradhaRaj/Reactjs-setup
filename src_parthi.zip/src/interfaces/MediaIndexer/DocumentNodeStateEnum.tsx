enum DocumentNodeStateEnum {
  SystemSuggested = 'SystemSuggested',
  UserVerified = 'UserVerified',
  UserAdded = 'UserAdded',
  UserRemoved = 'UserRemoved'
}

export default DocumentNodeStateEnum;
