import React from 'react';
import { shallow } from 'enzyme';
import TaskManagementTable, { Row, EmptyTableRow } from '../../components/organisms/TaskManagementTable';
import SampleData from '../../sampledata/TaskManagement';

describe('Task management table', () => {
  it('should render the correct number of items', () => {
    const wrapper = shallow(<TaskManagementTable data={SampleData.slice(0, 3)} />);
    expect(wrapper.find(Row)).toHaveLength(3);
  });

  it('should render the no data row when there are no rows', () => {
    const wrapper = shallow(<TaskManagementTable data={[]} />);
    expect(wrapper.find(EmptyTableRow)).toHaveLength(0);
  });
});
