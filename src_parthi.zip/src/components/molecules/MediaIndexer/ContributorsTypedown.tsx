/* eslint @typescript-eslint/no-explicit-any: 0 */
import React from 'react';
import axios from 'axios';
import _ from 'lodash';
import {
  Grid, Button, InputLabel, Select, MenuItem, FormControl, Chip, Zoom, withStyles, WithStyles, createStyles, TextField, CircularProgress,
} from '@material-ui/core';
import Autocomplete from '@material-ui/lab/Autocomplete';

import AddCircleIcon from '@material-ui/icons/AddCircle';
import DocumentContributor from '../../../interfaces/MediaIndexer/DocumentContributor';
import DocumentNodeStateEnum from '../../../interfaces/MediaIndexer/DocumentNodeStateEnum';
import LoadingButton from '../LoadingButton';
import { TypedownDebounceTime } from '../../../constants/MediaIndexerConstants';

const useStyles = createStyles({
  contributorsInput: {
    width: '100%',
  },
  newContributorsInput: {
    width: '100%',
  },
  contributorsTextField: {
    marginTop: '0px',
  },
  typedownContainer: {
    minWidth: '528px',
    width: '100%',
  },
  dropdownControl: {
    width: '100%',
  },
  newButton: {
    top: '10px',
    marginLeft: '10px',
  },
  addButton: {
    top: '20px',
    marginLeft: '10px',
  },
  cancelButton: {
    top: '20px',
    marginLeft: '10px',
    width: '64px',
    fontSize: '0.775rem',
  },
  contributorsContainer: {
    textAlign: 'left',
    marginTop: '5px',
  },
  chip: {
    marginRight: '5px',
    marginBottom: '5px',
  },
});

interface State {
  roleValue: string;
  contributorOptions: ContributorOption[];
  typedownState: boolean;
  firstName: string;
  middleName: string;
  lastName: string;
  callingApi: boolean;
  labelWidth: number;
  loading: boolean;
}

interface ContributorOption {
  contributorID: number;
  contributorName: string;
  firstName: string;
  middleName: string;
  lastName: string;
}

interface AddContributorRequest {
  FirstName: string;
  MiddleName: string;
  LastName: string;
}

interface ContributorsTypedownProps {
  selectedContributors: DocumentContributor[];
  onChangeFunction: Function;
  errorSnackbarFunction: Function;
  classes: any;
  readOnly?: boolean;
}

function getName(firstName: string, middleName: string, lastName: string): string {
  let returnName = '';

  if (middleName !== null && middleName !== undefined && middleName !== '') {
    returnName = `${firstName} ${middleName} ${lastName}`;
  } else {
    returnName = `${firstName} ${lastName}`;
  }

  return returnName;
}

function getRoleTypeID(roleName: string): number {
  switch (roleName) {
    case 'Host':
      return 1;
    case 'Reporter':
      return 2;
    case 'Contributor':
      return 3;
    case 'Actor':
      return 4;
    case 'Director':
      return 5;
    default:
      return 0;
  }
}

function getOptionRender(option: ContributorOption): JSX.Element {
  if (option.middleName !== undefined && option.middleName !== '') {
    return (
      <>
        <Grid item xs={12}>
          <span>{option.contributorName}</span>
        </Grid>
      </>
    );
  }
  return (
    <>
      <Grid item xs={12}>
        <span>{option.contributorName}</span>
      </Grid>
    </>
  );
}

export class ContributorsTypedown extends React.Component<ContributorsTypedownProps & WithStyles<typeof useStyles>, State, {}> {
  private inputLabel = React.createRef<HTMLLabelElement>();

  constructor(props: ContributorsTypedownProps) {
    super(props);
    this.handleRoleChange = this.handleRoleChange.bind(this);
    this.handleContributorChange = _.debounce(this.handleContributorChange, TypedownDebounceTime);
    this.handleContributorChange = this.handleContributorChange.bind(this);
    this.handleFirstNameChange = this.handleFirstNameChange.bind(this);
    this.handleMiddleNameChange = this.handleMiddleNameChange.bind(this);
    this.handleLastNameChange = this.handleLastNameChange.bind(this);
    this.addExistingContributorToList = this.addExistingContributorToList.bind(this);
    this.addNewContributorToList = this.addNewContributorToList.bind(this);
    this.changeTypedownState = this.changeTypedownState.bind(this);
    this.clearTypedownOptions = this.clearTypedownOptions.bind(this);
    this.renderContributorEntry = this.renderContributorEntry.bind(this);
    this.renderChip = this.renderChip.bind(this);

    this.state = {
      roleValue: 'Host',
      contributorOptions: [],
      typedownState: true,
      firstName: '',
      middleName: '',
      lastName: '',
      callingApi: false,
      labelWidth: 0,
      loading: false,
    };
  }

  componentDidMount() {
    if (this.inputLabel.current != null) {
      this.setState({
        labelWidth: this.inputLabel.current.offsetWidth,
      });
    }
  }

  getContributors(searchTerm: string): Promise<ContributorOption[]> {
    const returnList: ContributorOption[] = [];

    const suggestionsPromise = new Promise<ContributorOption[]>((resolve, reject) => {
      this.setState((prevState) => ({
        ...prevState,
        loading: true,
        contributorOptions: [],
      }));

      fetch(`${process.env.REACT_APP_API_URL}/api/Indexing/searchcontributors?searchTerm=${searchTerm}`)
        .then((res) => res.json())
        .then(
          (result) => {
            if (result.status === 200) {
              for (let i = 0; i < result.results.length; i += 1) {
                returnList.push({
                  contributorID: result.results[i].contributorID,
                  contributorName: getName(result.results[i].firstName, result.results[i].middleName, result.results[i].lastName),
                  firstName: result.results[i].firstName,
                  middleName: result.results[i].middleName,
                  lastName: result.results[i].lastName,
                });
              }
            }
            resolve(returnList);
          },
          (error: Error) => {
            reject(error);
          },
        ).then(() => {
          this.setState((prevState) => ({
            ...prevState,
            loading: false,
          }));
        });
    });

    return suggestionsPromise;
  }

  handleDeleteContributor = (contributorToDelete: DocumentContributor) => () => {
    // If this was a historic contributor then we want to change it's state to user removed, otherwise delete the contributor outright
    if (!contributorToDelete.isNew) {
      const newList = this.props.selectedContributors.filter((contributor) => (contributor !== contributorToDelete
        || contributor.type !== contributorToDelete.type));

      newList.push(contributorToDelete);
      newList[newList.length - 1] = {
        ...newList[newList.length - 1],
        state: DocumentNodeStateEnum.UserRemoved,
      };
      this.props.onChangeFunction(newList);
    } else {
      const newList = this.props.selectedContributors.filter((contributor) => (contributor !== contributorToDelete
        || contributor.type !== contributorToDelete.type));
      this.props.onChangeFunction(newList);
    }
  }

  handleRoleChange(event: any): void {
    this.setState({ roleValue: event.target.value });
  }

  handleContributorChange(event: any): void {
    const value: string = event.target.value;

    if (value.length > 2 && value.length < 100) {
      this.getContributors(value)
        .then((result: ContributorOption[]) => {
          this.setState({ contributorOptions: result });
        });
    }
  }

  handleFirstNameChange(event: any): void {
    this.setState({ firstName: event.target.value });
  }

  handleMiddleNameChange(event: any): void {
    this.setState({ middleName: event.target.value });
  }

  handleLastNameChange(event: any): void {
    this.setState({ lastName: event.target.value });
  }

  getContributorExistedInList(contributorToCheck: Partial<{ contributorID: number}>) {
    const prevState = this.state;
    const existingContributor = this.props.selectedContributors.find((contributor) => contributor.contributorID === contributorToCheck.contributorID
            && contributor.typeID === getRoleTypeID(prevState.roleValue));
    return existingContributor;
  }

  addExistingContributorToList(event: any, newValues: Array<ContributorOption>): void {
    const prevState = this.state;

    if (newValues !== undefined && newValues !== null && newValues[newValues.length - 1]) {
      const value = newValues[newValues.length - 1];
      if (this.props.selectedContributors !== undefined) {
        const existingContributor = this.getContributorExistedInList(value);
        if (existingContributor !== undefined && existingContributor.state === DocumentNodeStateEnum.UserRemoved) {
          const newContributorList = this.props.selectedContributors.filter((contributor) => contributor.contributorID !== value.contributorID
            || contributor.typeID !== getRoleTypeID(prevState.roleValue));
          const newContributor = {
            ...existingContributor,
            state: DocumentNodeStateEnum.UserAdded,
            createdBy: '',
            createdDate: '',
          };

          if (newContributor.typeID !== 0 && this.props.selectedContributors === undefined) {
            this.props.onChangeFunction([newContributor]);
          } else if (newContributor.typeID !== 0) {
            this.props.onChangeFunction([...newContributorList, newContributor]);
          }
        } else if (existingContributor === undefined) {
          const newContributor: DocumentContributor = {
            contributorID: value.contributorID,
            contributorConfidence: 1,
            firstName: value.firstName,
            middleName: value.middleName,
            lastName: value.lastName,
            type: prevState.roleValue,
            typeID: getRoleTypeID(prevState.roleValue),
            createdBy: '',
            createdDate: '',
            state: DocumentNodeStateEnum.UserAdded,
            isNew: true,
          };

          if (newContributor.typeID !== 0 && this.props.selectedContributors === undefined) {
            this.props.onChangeFunction([newContributor]);
          } else if (newContributor.typeID !== 0) {
            this.props.onChangeFunction([...this.props.selectedContributors, newContributor]);
          }
        }
      }
    }
  }

  addNewContributorToList(): void {
    // Create a request to add new contributor
    const state = this.state;

    if (this.state.firstName !== undefined && this.state.firstName.length > 0
      && this.state.lastName !== undefined && this.state.lastName.length > 0) {
      const newContributor: AddContributorRequest = {
        FirstName: this.state.firstName.trim(),
        MiddleName: this.state.middleName.trim(),
        LastName: this.state.lastName.trim(),
      };

      this.setState((prevState) => ({
        ...prevState,
        callingApi: true,
      }));

      // Now send off the request and add response to the list
      axios.post(`${process.env.REACT_APP_API_URL}/api/Indexing/AddNewContributor`, newContributor)
        .then((response: any) => {
          if (response !== null
              && response.data.contributorID !== 0
              && response.data.firstName !== undefined
              && response.data.lastName !== undefined) {
            const contributorToAdd: DocumentContributor = {
              contributorID: response.data.contributorID,
              contributorConfidence: 1,
              firstName: response.data.firstName,
              middleName: response.data.middleName,
              lastName: response.data.lastName,
              type: state.roleValue,
              typeID: getRoleTypeID(state.roleValue),
              createdBy: '',
              createdDate: '',
              state: DocumentNodeStateEnum.UserAdded,
              isNew: true,
            };

            const existingContributor = this.getContributorExistedInList(contributorToAdd);

            if (existingContributor !== undefined) { return; }
            if (contributorToAdd.typeID !== 0 && this.props.selectedContributors !== undefined) {
              this.props.onChangeFunction([...this.props.selectedContributors, contributorToAdd])
                .finally(() => {
                  this.setState((prevState) => ({
                    ...prevState,
                    firstName: '',
                    middleName: '',
                    lastName: '',
                  }));
                });
            } else if (contributorToAdd.typeID !== 0 && this.props.selectedContributors === undefined) {
              this.props.onChangeFunction([contributorToAdd])
                .finally(() => {
                  this.setState((prevState) => ({
                    ...prevState,
                    firstName: '',
                    middleName: '',
                    lastName: '',
                  }));
                });
            }
          } else {
            this.props.errorSnackbarFunction('An error occured when trying to add a new contributor');
          }
        })
        .catch(() => {
          // this.props.errorSnackbarFunction('An error occured when trying to add a new contributor');
          this.setState((prevState) => ({
            ...prevState,
            callingApi: false,
          }));
        })
        .finally(() => {
          this.setState((prevState) => ({
            ...prevState,
            callingApi: false,
          }));
        });
    }
  }

  addSuggestedContributorToList(verifiedValueId: number): void {
    if (verifiedValueId !== undefined && verifiedValueId !== 0) {
      const contributorsList: DocumentContributor[] = [...this.props.selectedContributors];

      // contributorsList.forEach((contributor) => {
      //   if (contributor.contributorID === verifiedValueId) {
      //     contributor.state = DocumentNodeStateEnum.UserVerified;
      //     contributor.isNew = false;
      //   }
      // });
      for (let i = 0; i < contributorsList.length; i++) {
        if (contributorsList[i].contributorID === verifiedValueId) {
          contributorsList[i] = {
            ...contributorsList[i],
            state: DocumentNodeStateEnum.UserVerified,
            isNew: false,
          };
        }
      }

      this.props.onChangeFunction(contributorsList);
    }
  }

  changeTypedownState(): void {
    this.setState((prevState) => ({ typedownState: !prevState.typedownState }));
  }

  clearTypedownOptions(): void {
    this.setState({ contributorOptions: [] });
  }

  renderChip(contributor: DocumentContributor): JSX.Element {
    const { classes } = this.props;

    if (contributor.state !== DocumentNodeStateEnum.SystemSuggested && contributor.state !== DocumentNodeStateEnum.UserRemoved) {
      if (contributor.middleName !== null && contributor.middleName !== undefined && contributor.middleName !== '') {
        return (
          <Zoom in={this.props.selectedContributors.includes(contributor)} key={contributor.contributorID}><Chip tabIndex={-1} className={classes.chip} variant="outlined" label={`${contributor.firstName} ${contributor.middleName} ${contributor.lastName} | ${contributor.type}`} disabled={this.props.readOnly} onDelete={this.handleDeleteContributor(contributor)} color="primary" /></Zoom>
        );
      }

      return (
        <Zoom in={this.props.selectedContributors.includes(contributor)} key={contributor.contributorID}><Chip tabIndex={-1} className={classes.chip} variant="outlined" label={`${contributor.firstName} ${contributor.lastName} | ${contributor.type}`} disabled={this.props.readOnly} onDelete={this.handleDeleteContributor(contributor)} color="primary" /></Zoom>
      );
    }

    return (
      <></>
    );
  }

  renderSuggestedChip(contributor: DocumentContributor): JSX.Element {
    const { classes } = this.props;

    if (contributor.state === DocumentNodeStateEnum.SystemSuggested) {
      if (contributor.middleName !== null && contributor.middleName !== undefined && contributor.middleName !== '') {
        return (
          <Zoom in={this.props.selectedContributors.includes(contributor)} key={contributor.contributorID}>
            <Chip
              tabIndex={-1}
              className={classes.chip}
              label={`${contributor.firstName} ${contributor.middleName} ${contributor.lastName} | ${contributor.type}`}
              disabled={this.props.readOnly}
              onDelete={() => this.addSuggestedContributorToList(contributor.contributorID)}
              deleteIcon={<AddCircleIcon />}
            />
          </Zoom>
        );
      }

      return (
        <Zoom in={this.props.selectedContributors.includes(contributor)} key={contributor.contributorID}>
          <Chip
            tabIndex={-1}
            className={classes.chip}
            label={`${contributor.firstName} ${contributor.lastName} | ${contributor.type}`}
            disabled={this.props.readOnly}
            onDelete={() => this.addSuggestedContributorToList(contributor.contributorID)}
            deleteIcon={<AddCircleIcon />}
          />
        </Zoom>
      );
    }

    return (
      <></>
    );
  }

  renderContributorEntry(): JSX.Element {
    const { classes } = this.props;

    // If typedown state is true then render contributor typedown for existing contributors, otherwise render free text entry
    if (this.state.typedownState) {
      return (
        <>
          <Grid item xs={6}>
            <Autocomplete
              multiple
              className={classes.contributorsInput}
              id="contributor"
              disabled={
                this.props.readOnly
              }
              options={this.state.contributorOptions}
              onChange={this.addExistingContributorToList}
              onOpen={this.clearTypedownOptions}
              renderInput={(params: any) => (
                <TextField
                  {...params}
                  className={classes.contributorsTextField}
                  variant="outlined"
                  label="Contributor"
                  margin="normal"
                  fullWidth
                  onChange={(e) => {
                    e.persist();
                    this.handleContributorChange(e);
                  }}
                  InputProps={{
                    ...params.InputProps,
                    endAdornment: (
                      <>
                        {this.state.loading ? <CircularProgress color="inherit" size={20} /> : null}
                        {params.InputProps.endAdornment}
                      </>
                    ),
                  }}
                />
              )}
              renderOption={(option: ContributorOption) => getOptionRender(option)}
              getOptionLabel={(option) => option.contributorName}
              renderTags={() => <></>}
            />
          </Grid>
          <Grid item xs={1}>
            <Button className={classes.newButton} disabled={this.props.readOnly} size="small" color="primary" onClick={this.changeTypedownState}>New</Button>
          </Grid>
        </>
      );
    }

    return (
      <>
        <Grid container item xs={12}>
          <Grid item xs={6}>
            <TextField
              className={classes.newContributorsInput}
              variant="outlined"
              label="First Name"
              margin="normal"
              fullWidth
              value={this.state.firstName}
              onChange={this.handleFirstNameChange}
            />
          </Grid>
        </Grid>
        <Grid container item xs={12}>
          <Grid item xs={6}>
            <TextField
              className={classes.newContributorsInput}
              label="Middle Name"
              variant="outlined"
              margin="normal"
              fullWidth
              value={this.state.middleName}
              onChange={this.handleMiddleNameChange}
            />
          </Grid>
          <Grid item xs={1}>
            <Button className={classes.cancelButton} size="small" color="primary" onClick={this.changeTypedownState}>Cancel</Button>
          </Grid>
        </Grid>
        <Grid container item xs={12}>
          <Grid item xs={6}>
            <TextField
              className={classes.newContributorsInput}
              label="Last Name"
              margin="normal"
              variant="outlined"
              fullWidth
              value={this.state.lastName}
              onChange={this.handleLastNameChange}
            />
          </Grid>
          <Grid item xs={1}>
            <LoadingButton isLoading={this.state.callingApi} className={classes.addButton} size="small" color="primary" onClick={this.addNewContributorToList}>Add</LoadingButton>
          </Grid>
        </Grid>
      </>
    );
  }

  render(): JSX.Element {
    const { classes } = this.props;
    return (
      <>
        <div className={classes.typedownContainer}>
          <Grid item xs={12}>
            <Grid item xs={6}>
              <FormControl variant="outlined" className={classes.dropdownControl}>
                <InputLabel ref={this.inputLabel} id="ContributorRoleLabel">Role</InputLabel>
                <Select
                  labelId="ContributorRoleLabel"
                  id="ContributorRole"
                  defaultValue="Host"
                  variant="outlined"
                  onChange={this.handleRoleChange}
                  labelWidth={this.state.labelWidth}
                  disabled={this.props.readOnly}
                >
                  <MenuItem key="Host" value="Host">Host</MenuItem>
                  <MenuItem key="Reporter" value="Reporter">Reporter</MenuItem>
                  <MenuItem key="Contributor" value="Contributor">Contributor</MenuItem>
                  <MenuItem key="Actor" value="Actor">Actor</MenuItem>
                  <MenuItem key="Director" value="Director">Director</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
          <Grid container item xs={12}>
            {this.renderContributorEntry()}
          </Grid>
          <Grid container item xs={10} className={classes.contributorsContainer}>
            {this.props.selectedContributors.map((contributor: DocumentContributor) => this.renderChip(contributor))}
          </Grid>
          <Grid container item xs={10} className={classes.contributorsContainer}>
            {this.props.selectedContributors.map((contributor: DocumentContributor) => this.renderSuggestedChip(contributor))}
          </Grid>
        </div>
      </>
    );
  }
}

export default withStyles(useStyles)(ContributorsTypedown);
