import TitleSearchResult from '../../../interfaces/Search/TitleSearchResult';
import ArtifactSearchIndex from '../../../interfaces/enums/ArtifactSearchIndex';

const obj: TitleSearchResult = {
  dateOfPublication: '1 Jan',
  documentNumber: 'DocNum',
  id: 1,
  resourceTitle: 'Title',
  resourceType: 'Book',
  resourceID: '',
  issn: '',
  isbn: '',
  resourceManager: '',
  lastModified: '',
  liveDate: '',
  publisherName: '',
  clearanceStatus: '',
  clearedBy: '',
  searchIndex: ArtifactSearchIndex.Title,
};

export default obj;
