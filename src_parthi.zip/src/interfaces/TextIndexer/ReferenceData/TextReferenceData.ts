import {
  Record, Static, Array, String,
} from 'runtypes';
import { TextResourceTypeValidator } from './TextResourceType';
import { AuthorRoleTypeValidator } from './AuthorRoleType';
import { LookupOptionValidator } from '../../LookupOption';
import { ArrayWithElements } from '../../../runtypeTypes';

export const TextReferenceDataValidator = Record({
  accessRight: ArrayWithElements(LookupOptionValidator),
  authorRoleTypeLookup: Array(AuthorRoleTypeValidator).withConstraint((a) => a.length > 0),
  genres: Array(LookupOptionValidator).withConstraint((a) => a.length > 0),
  resourceTypes: Array(TextResourceTypeValidator).withConstraint((a) => a.length > 0),
  languageLookup: Array(LookupOptionValidator).withConstraint((a) => a.length > 0),
  sectionNameOptions: Array(String),
  descriptionTypes: Array(LookupOptionValidator),
  mediaTypes: Array(LookupOptionValidator),
});

type TextReferenceData = Static<typeof TextReferenceDataValidator>;
export default TextReferenceData;
