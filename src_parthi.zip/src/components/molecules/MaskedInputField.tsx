import React from 'react';
import MaskedInput from 'react-text-mask';
import OutlinedInput, { OutlinedInputProps } from '@material-ui/core/OutlinedInput';
import FormControl from '@material-ui/core/FormControl';
import {
  FormHelperText, InputLabel,
} from '@material-ui/core';

interface TextMaskCustomProps {
  inputRef: (ref: HTMLInputElement | null) => void;
  mask: (string | RegExp)[];
}

function TextMaskCustom(props: TextMaskCustomProps) {
  const { inputRef, ...other } = props;

  return (
    <MaskedInput
      {...other}
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      ref={(ref: any) => {
        inputRef(ref ? ref.inputElement : null);
      }}
      mask={props.mask}
      placeholderChar={'\u2000'}
      showMask
    />
  );
}

interface MaskedInputFieldProps extends Omit<OutlinedInputProps, 'inputComponent' | 'fullWidth' | 'label'>{
  helperText?: string;
  labelText?: string;
  mask: (string | RegExp)[];
}

const MaskedInputField: React.FunctionComponent<MaskedInputFieldProps> = (props) => (
  <FormControl margin="normal">
    <InputLabel variant="outlined">
      {props.labelText}
    </InputLabel>
    <OutlinedInput
      {...props}
      fullWidth
      label={props.labelText}
      inputComponent={TextMaskCustom as never}
      inputProps={{
        ...props.inputProps,
        mask: props.mask,
      }}
    />
    <FormHelperText>
      {props.helperText}
    </FormHelperText>
  </FormControl>
);

export default MaskedInputField;
