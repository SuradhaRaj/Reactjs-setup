import React from 'react';
import {
  Paper, makeStyles, createStyles, Theme, Grid, Typography, Divider, IconButton,
} from '@material-ui/core';
import { useHistory } from 'react-router-dom';

import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import { DateTime } from 'luxon';
import SmallChip from '../../molecules/SmallChip';
import MediaSearchResult from '../../../interfaces/Search/MediaSearchResult';
import RuntypeErrorPaper from '../RuntypeError';
import ArtifactLock from '../ArtifactLock';
import SecondaryData from '../../molecules/SecondaryData';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    padding: theme.spacing(2),
    transition: 'all 0.2s',
    '&:hover': {
      paddingRight: theme.spacing(6),
      '& $navigateChevron': {
        visibility: 'visible',
        opacity: 1,
      },
    },
    position: 'relative',
  },
  rmitNumber: {
    fontSize: '0.85rem',
    marginLeft: theme.spacing(2),
    fontWeight: 600,
  },
  title: {
    fontSize: '0.85rem',
    marginLeft: theme.spacing(2),
  },
  row: {
    display: 'flex',
  },
  divider: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(1),
  },
  workflowState: {
    alignSelf: 'center',
    marginLeft: 'auto',
  },
  unlock: {
    marginLeft: 'auto',
  },
  navigateChevron: {
    visibility: 'hidden',
    position: 'absolute',
    right: 0,
    top: '50%',
    opacity: 0,
    transition: 'all 0.2s',
    transform: 'translateY(-50%)',
  },
}));

interface Props {
  result: MediaSearchResult;
  canUnlock: boolean;
  updateItem(item: MediaSearchResult): void;
}

export default function MediaResult(props: Props) {
  const classes = useStyles();
  const history = useHistory();
  try {
    // MediaSearchResultValidator.check(props.result);
  } catch (error) {
    return (<RuntypeErrorPaper data={props.result} error={error} />);
  }

  const onUnlocked = () => {
    props.updateItem({ ...props.result, indexer: '' });
  };

  const navigateToIndexerUi = (): void => {
    history.push(`/artifact/${props.result.id.toString()}`);
  };

  return (
    <Grid container>
      <Grid item xs={12}>
        <Paper className={classes.root}>
          <Grid container>
            <Grid item xs={12}>
              <Grid container>
                <Grid item xs={12} className={classes.row}>
                  <SmallChip label="MEDIA" />
                  <Typography className={classes.rmitNumber}>{props.result.masId}</Typography>
                  <Typography className={classes.title}>{props.result.itemTitle}</Typography>
                  {props.result.indexer && (
                  <ArtifactLock
                    className={classes.unlock}
                    artifactId={props.result.id}
                    canUnlock={props.canUnlock}
                    indexer={props.result.indexer}
                    title={props.result.itemTitle}
                    onUnlocked={onUnlocked}
                  />
                  )}
                </Grid>
              </Grid>
              <Divider className={classes.divider} />
              <Grid container>
                <Grid item xs={9} className={classes.row}>
                  <SecondaryData title="Channel" content={props.result.channel} />
                  <SecondaryData title="Program" content={props.result.programTitle} />
                  <SecondaryData title="Broadcast" content={DateTime.fromISO(props.result.broadcastDate).toFormat('d LLL yyyy')} />
                </Grid>
                <Grid item xs={3} className={classes.row}>
                  <SmallChip className={classes.workflowState} label={props.result.workflowState} />
                </Grid>
              </Grid>
            </Grid>

          </Grid>
          <IconButton className={classes.navigateChevron} onClick={navigateToIndexerUi}>
            <ChevronRightIcon />
          </IconButton>

        </Paper>
      </Grid>
    </Grid>
  );
}
