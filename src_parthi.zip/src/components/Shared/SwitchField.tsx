import React from 'react';
import Grid from '@material-ui/core/Grid';
import {
  FormLabel, makeStyles, createStyles, Theme, Switch,
} from '@material-ui/core';

const useStyles = makeStyles((theme: Theme) => createStyles({
  formLabel: {
    fontSize: '14px',
    fontWeight: 600,
    color: '#000054',
  },
  displayText: {
    fontSize: '12px',
    color: '#000054',
  },
  oneLineMargin: {
    marginLeft: theme.spacing(1),
  },
}));

interface SwitchFieldProps {
  labelText: string;

    oneLine: boolean;
    checked: boolean;
    onChange: (event: React.ChangeEvent<HTMLInputElement>, checked: boolean) => void;
    name: string;

}

export default function SwitchField(props: SwitchFieldProps): JSX.Element {
  const classes = useStyles();

  return (
    <Grid container alignItems="baseline">
      <Grid item xs={props.oneLine ? 4 : 12}>
        <FormLabel className={classes.formLabel}>{props.labelText}</FormLabel>
      </Grid>
      <Grid item xs={props.oneLine ? 8 : 12}>
        <Switch
          checked={props.checked}
          onChange={props.onChange}
          color="primary"
          name={props.name}
        />
      </Grid>
    </Grid>
  );
}
