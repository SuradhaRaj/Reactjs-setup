import notistack from './mocks/notistack';
import reactRouterDom from './mocks/react-router-dom';

export default () => {
  notistack();
  reactRouterDom();
};
