import {
  Static, Record, String, Null,
} from 'runtypes';
import { SearchResultValidator } from './SearchResult';

export const TitleSearchResultValidator = Record({
  documentNumber: String.Or(Null),
  resourceTitle: String.withConstraint((s) => !!s || 'Non empty string is required'),
  dateOfPublication: String.Or(Null),
  resourceType: String,
  resourceID: String,
  issn: String,
  isbn: String,
  resourceManager: String,
  lastModified: String,
  liveDate: String,
  publisherName: String.Or(Null),
  clearanceStatus: String,
  clearedBy: String,
}).And(SearchResultValidator);

type TitleSearchResult = Static<typeof TitleSearchResultValidator>;

export default TitleSearchResult;
