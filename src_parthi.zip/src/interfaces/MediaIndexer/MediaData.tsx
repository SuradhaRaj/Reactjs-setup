/*eslint-disable*/
import MediaArtifact from './MediaArtifact';
import ArtifactStatus from '../enums/ArtifactStatus';
import Artifact from '../Artifact';

export default interface MediaData extends Artifact {
    groupIndexer: string;
    isReadOnly: boolean;
    isPublishedViaWorkflow: boolean;
    lockedBy: string;
    lockOwned: boolean;
   
    switchJWTToken: string;
    videoContentID: string;
    
    workflowStatusId?: number;
    workflowStatus?: string;
    
    mediaArtifactDocument: MediaArtifact;
    locationSuggestions: string[];
    topicSuggestions: string[];
    submitTasks: string[];
    electronicTypeFormat: string | undefined;
    artifactStatusId: ArtifactStatus;
    artifactTypeId: number;
}