import React, { useEffect } from 'react';
import { ApplicationInsights } from '@microsoft/applicationinsights-web';
import { ReactPlugin } from '@microsoft/applicationinsights-react-js';
import { useHistory } from 'react-router-dom';
import { useTypedSelector } from '../../store/store';

export default () => {
  const instrumentationKey = useTypedSelector((store) => store.ClientConfiguration.ClientConfiguration.data.appInsightsInstrumentationKey);
  const history = useHistory();

  useEffect(() => {
    const reactPlugin = new ReactPlugin();

    const appInsights = new ApplicationInsights({
      config: {
        instrumentationKey,
        extensions: [reactPlugin],
        extensionConfig: {
          [reactPlugin.identifier]: { history },
        },
      },
    });
    appInsights.loadAppInsights();
  }, [instrumentationKey]);
  return (<></>);
};
