import React from 'react';
import { mount } from 'enzyme';
import { LicenceTemplatesListItem } from '../../../components/organisms/Organisation/LicenceTemplatesList';
import RuntypeErrorPaper from '../../../components/organisms/RuntypeError';

const wrapper = mount(<LicenceTemplatesListItem
  onEditLicenceClick={() => undefined}
  licenceTemplate={{
    licenceTemplateId: 7,
    ielcopyright: null,
    clearanceStatusId: 1,
    contractStartDate: '2015-01-01T00:00:00+11:00',
    contractEndDate: '2020-12-10T00:00:00+11:00',
    ppvavailable: false,
    agreementNumber: 'JM TEST AGREEMENT NUMBER',
    embargoPeriod: null,
    price: 0.0,
    royaltiesDue: null,
    clearedById: null,
    royaltyRate: null,
    archiveRoyaltyRate: null,
    noticePeriod: null,
    archivalPeriod: null,
    terminationNote: 'JM Test Management Note',
    individualSubscriptions: false,
    cclicenceTypeId: 1,
    accessRightId: 4,
    accessTypeId: null,
    perpetualAccess: false,
  }}
  referenceData={{
    ccLicenceType: [],
    clearedBy: [],
    clearanceStatus: [{ key: 1, value: 'test status' }],
    accessRight: [],
    accessType: [],
    contactRoleType: [],
  }}
  dialogOpen={false}
  handleCloseDialog={() => undefined}
  onLicenceTemplateChangeHandler={() => undefined}
/>);

describe('Licence Template List Item', () => {
  it('should show the agreement number', () => {
    expect(wrapper.text().includes('JM TEST AGREEMENT NUMBER')).toBeTruthy();
  });

  it('should show an error if the licence template is invalid', () => {
    const testWrapper = mount(<LicenceTemplatesListItem
      onEditLicenceClick={() => undefined}
      licenceTemplate={{
        licenceTemplateId: 7,
        ielcopyright: null,
        clearanceStatusId: 1,
        contractStartDate: 'invalid date string',
        contractEndDate: 'invalid date string',
        ppvavailable: false,
        agreementNumber: 'Agreement number',
        embargoPeriod: null,
        price: 0.0,
        royaltiesDue: null,
        clearedById: null,
        royaltyRate: null,
        archiveRoyaltyRate: null,
        noticePeriod: null,
        archivalPeriod: null,
        terminationNote: 'JM Test Management Note',
        individualSubscriptions: false,
        cclicenceTypeId: 1,
        accessRightId: 4,
        accessTypeId: null,
        perpetualAccess: false,
      }}
      referenceData={{
        ccLicenceType: [],
        clearedBy: [],
        clearanceStatus: [{ key: 1, value: 'test status' }],
        accessRight: [],
        accessType: [],
        contactRoleType: [],
      }}
      dialogOpen={false}
      handleCloseDialog={() => undefined}
      onLicenceTemplateChangeHandler={() => undefined}
    />);

    expect(testWrapper.find(RuntypeErrorPaper).length).toBeTruthy();
  });
});
