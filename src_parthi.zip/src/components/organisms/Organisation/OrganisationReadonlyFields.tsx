import React from 'react';
import {
  Paper, Grid, makeStyles, Theme, createStyles, Typography, Button,
} from '@material-ui/core';
import WebIcon from '@material-ui/icons/Language';
import PhoneIcon from '@material-ui/icons/Phone';
import EmailIcon from '@material-ui/icons/Email';
import FaxIcon from '@material-ui/icons/Print';
import HomeIcon from '@material-ui/icons/HomeWork';
import NoIcon from '@material-ui/icons/Block';
import YesIcon from '@material-ui/icons/Check';
import OrganisationData, { OrganisationDataValidator } from '../../../interfaces/Organisation/OrganisationData';
import CopyableTooltipIconWithContentText from '../CopyableTooltipIconWithContentText';
import RuntypeErrorPaper from '../RuntypeError';
import SmallChip from '../../molecules/SmallChip';
import { hubSpotOrganisationLink } from '../../../constants/HubSpotConstants';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    paddingTop: theme.spacing(2),
    paddingBottom: theme.spacing(2),
    paddingLeft: theme.spacing(1),
    paddingRight: theme.spacing(1),
    position: 'relative',
    minHeight: 150,
  },
  chips: {
    position: 'absolute',
    top: 5,
    right: 8,
  },
  chip: {
    marginLeft: theme.spacing(1),
  },
  button: {
    position: 'absolute',
    bottom: theme.spacing(2),
    right: theme.spacing(2),
  },
  columnWrapper: {
    paddingLeft: theme.spacing(3),
    paddingRight: theme.spacing(3),
    paddingBottom: theme.spacing(1),
  },
  field: {
    paddingTop: theme.spacing(1),
  },
  heading: {
    fontSize: '1rem',
    fontWeight: 500,
    textTransform: 'uppercase',
    color: theme.palette.primary.main,
  },
  label: {
    fontWeight: 460,
  },
  headerWrapper: {
    paddingLeft: theme.spacing(3),
    paddingRight: theme.spacing(3),
    paddingBottom: theme.spacing(1),
  },
  contactDetailRow: {
    paddingTop: theme.spacing(1.5),
  },
  title: {
    fontSize: '1.6rem',
  },
  codeLabel: {
    fontStyle: 'italic',
    fontSize: '1.3rem',
    color: theme.palette.text.secondary,
  },
  chipIcon: {
    fontSize: 'inherit',
    marginRight: theme.spacing(1),
  },
}));

interface OrganisationReadonlyFieldsProps {
  data: OrganisationData;
};

const OrganisationReadonlyFields: React.SFC<OrganisationReadonlyFieldsProps> = (props) => {
  const classes = useStyles();

  const getAddress = () => (
    [
      props.data.organisationStreetAddress,
      props.data.organisationSuburb,
      props.data.organisationState,
      props.data.organisationPostcode,
      props.data.organisationCountry,
    ].filter((s) => s?.trim()).join(', ')
  );

  const hasContactDetails = () => (
    props.data.organisationPhone
    || props.data.organisationFax
    || props.data.organisationEmail
    || props.data.organisationWebAddress
    || getAddress()
  );

  try {
    OrganisationDataValidator.check(props.data);
  } catch (e) {
    return <RuntypeErrorPaper data={props.data} error={e} />;
  }

  return (
    <>
      <Paper className={classes.root}>
        <div className={classes.chips}>
          <SmallChip
            className={classes.chip}
            label="Publisher"
            icon={props.data.isPublisher
              ? <YesIcon color="primary" className={classes.chipIcon} />
              : <NoIcon color="error" className={classes.chipIcon} />}
          />
          <SmallChip
            className={classes.chip}
            label="Subscriber"
            icon={props.data.isSubscriber
              ? <YesIcon color="primary" className={classes.chipIcon} />
              : <NoIcon color="error" className={classes.chipIcon} />}
          />
        </div>
        <Grid container>
          <Grid item xs={12} className={classes.headerWrapper}>
            <Typography
              className={classes.title}
            >
              {props.data.organisationName}
            </Typography>
            <Typography className={classes.codeLabel}>
              {props.data.organisationCode}
            </Typography>
          </Grid>
          {hasContactDetails() && (
            <Grid
              item
              xs={10}
              className={classes.columnWrapper}
              style={{ marginBottom: 8 }}
            >
              <Typography className={classes.heading}>
                CONTACT DETAILS
              </Typography>
              <Grid container>
                {props.data.organisationPhone && (
                  <Grid item xs={6}>
                    <CopyableTooltipIconWithContentText
                      className={classes.contactDetailRow}
                      content={props.data.organisationPhone}
                      icon={<PhoneIcon />}
                      contentTextProps={{ color: 'textSecondary', display: 'inline', style: { marginLeft: 10 } }}
                    />
                  </Grid>
                )}
                {props.data.organisationFax && (
                  <Grid item xs={6}>
                    <CopyableTooltipIconWithContentText
                      className={classes.contactDetailRow}
                      content={props.data.organisationFax}
                      icon={<FaxIcon />}
                      contentTextProps={{ color: 'textSecondary', display: 'inline', style: { marginLeft: 10 } }}
                    />
                  </Grid>
                )}
                {props.data.organisationEmail && (
                  <Grid item xs={6}>
                    <CopyableTooltipIconWithContentText
                      className={classes.contactDetailRow}
                      content={props.data.organisationEmail}
                      icon={<EmailIcon />}
                      contentTextProps={{ color: 'textSecondary', display: 'inline', style: { marginLeft: 10 } }}
                    />
                  </Grid>
                )}
                {props.data.organisationWebAddress && (
                  <Grid item xs={6}>
                    <CopyableTooltipIconWithContentText
                      className={classes.contactDetailRow}
                      content={props.data.organisationWebAddress}
                      isLink
                      linkProps={{
                        href: props.data.organisationWebAddress,
                        target: '_blank',
                        color: 'textSecondary',
                      }}
                      icon={<WebIcon />}
                      contentTextProps={{ color: 'textSecondary', display: 'inline', style: { marginLeft: 10 } }}
                    />
                  </Grid>
                )}
                {getAddress() && (
                  <Grid item xs={12}>
                    <CopyableTooltipIconWithContentText
                      className={classes.contactDetailRow}
                      content={getAddress()}
                      icon={<HomeIcon />}
                      contentTextProps={{ color: 'textSecondary', display: 'inline', style: { marginLeft: 10 } }}
                    />
                  </Grid>
                )}
              </Grid>
            </Grid>
          )}
        </Grid>
        <Button
          color="primary"
          href={hubSpotOrganisationLink(props.data.hubSpotId)}
          variant="outlined"
          target="_blank"
          className={classes.button}
        >
          View in Hubspot
        </Button>
      </Paper>
    </>
  );
};

export default OrganisationReadonlyFields;
