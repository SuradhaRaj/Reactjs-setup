import React, { Children, useEffect, useState } from 'react';
import {
  Typography, Grid, Card, Button, makeStyles, Chip,
} from '@material-ui/core';
import { useDispatch } from 'react-redux';
// import Dropdown from '../../Shared/Dropdown';

import TreeView from '@material-ui/lab/TreeView';
import TreeItem from '@material-ui/lab/TreeItem';

import RemoveCircleIcon from '@material-ui/icons/RemoveCircle';
import { red } from '@material-ui/core/colors';
import { mapper } from 'recompose';
import Typedown from '../Typedown';
// import subjectData, { SubjectDataValidatior } from '../../../interfaces/ResourceManagement/subject';

import { TypedownOption } from '../../../interfaces/TypedownOption';

import { useTypedSelector } from '../../../store/store';

interface SubjectProp {
  fastTerm: Array<TypedownOption>;
  fastGeo: Array<TypedownOption>;
  subjectLC: Array<TypedownOption>;
  identifier: Array<TypedownOption>;
  broadSubject: Array<TypedownOption>;
  narrowSubject: Array<TypedownOption>;

  fastTermSV: TypedownOption;
  fastGeoSV: TypedownOption;
  subjectLCSV: TypedownOption;
  identifierSV: TypedownOption;
  broadSubjectSV: TypedownOption;
  narrowSubjectSV: TypedownOption;

  resourceNarrowSubject: Array<number>;
  resourceBroadSubject: Array<number>;
}

interface ParentTree {
  id: string;
  name: string;
  children: Array<SubChild>;
}

interface SubChild {
  id: string;
  name: string;
}

interface Chipval {
  chpfast: Array<TypedownOption>;
  chpfastgeo: Array<TypedownOption>;
  chpsubj: Array<TypedownOption>;
  chpident: Array<TypedownOption>;
  chpnarrow: Array<TypedownOption>;
  chptree: Array<ParentTree>;
  treeexpand: Array<string>;
  listchpfastid: Array<number| null>;
  listchpfastgeoid: Array<number| null>;
  listchpsubjid: Array<number| null>;
  listchpidentid: Array<number| null>;
  listchpnarrowid: Array<number| null>;
  listchpbroadid: Array<number| null>;
}

type NewType = boolean;

interface Props {
  isLoading: NewType;
}

const useStyles = makeStyles({
  labelRoot: {
    display: 'flex',
    alignItems: 'center',

  },
  labelIcon: {

  },
  labelText: {
    fontWeight: 'inherit',
    flexGrow: 1,
  },

  resourceIdeContainer: {
    paddingBottom: '20',
  },

  heading: {
    'font-size': '13px',
    'font-weight': '500',
    'text-transform': 'none',
    color: '#000000',
  },
  addbutton: {
    height: '32px',
    'font-size': '13px',
    'line-height': '30px',
  },
  subheading: {
    'font-size': '12px',
    'font-weight': '500',
    'text-transform': 'none',
    color: '#000000',
  },
  borderleft: {
    borderleft: '1px solid #cccccc',
  },
  root: {
    height: 110,
    flexGrow: 1,
    maxWidth: 400,
  },
});

function AddSubject(props: any): JSX.Element {
  const classes = useStyles();
  const getResourceData = useTypedSelector((store) => store.ResourceDataOnId);
  const getReferenceData = useTypedSelector((store) => store.TitleResourceReferenceData);

  const dispatch = useDispatch();

  const [statesubject, setStatesubject] = useState<SubjectProp>({
    fastTerm: [],
    fastGeo: [],
    subjectLC: [],
    identifier: [],
    broadSubject: [],
    narrowSubject: [],
    fastTermSV: { id: 1, value: '' },
    fastGeoSV: { id: 1, value: '' },
    subjectLCSV: { id: 1, value: '' },
    identifierSV: { id: 1, value: '' },
    broadSubjectSV: { id: 1, value: '' },
    narrowSubjectSV: { id: 1, value: '' },
    resourceNarrowSubject: [],
    resourceBroadSubject: [],
  });
  // const [chips, setChips] = useState(['chip1','chip2','chip3']);

  const [chiplist, setChiplist] = useState<Chipval>({
    chpfast: [],
    chpfastgeo: [],
    chpsubj: [],
    chpident: [],
    chpnarrow: [],
    chptree: [],
    treeexpand: [],
    listchpfastid: [],
    listchpfastgeoid: [],
    listchpsubjid: [],
    listchpidentid: [],
    listchpnarrowid: [],
    listchpbroadid: [],
  });

  // const renderchip = (nodes: any) => (
  //   <div className='custom_treeview'>
  //     <TreeItem key={nodes.id} nodeId={nodes.id} label=""  >
  //       <Chip key={nodes.id} label={nodes.name} onClick={handleClick} onDelete={() => handleDelete(nodes.id, nodes.name, "Narrow Subject")} />
  //       {Array.isArray(nodes.children) ? nodes.children.map((node: any) => renderchip(node)) : null}
  //     </TreeItem>
  //   </div>
  // );

  // const renderTree = (nodes : any) => (
  //   <TreeItem key={nodes.id} nodeId={nodes.id} label={nodes.name}>
  //     {Array.isArray(nodes.children) ? nodes.children.map((node : any) => renderTree(node)) : null}
  //   </TreeItem>
  // );

  useEffect(() => {
    // Axios.get<subjectData>(`${process.env.REACT_APP_API_URL}/api/resource/subjectdata`)
    // .then((subjectdata) => {
    //   console.log("subjectdata");
    //    console.log(subjectdata);
    //   });

    const resFast: Array<TypedownOption> = getResourceData.ResourceData.resourceFast
      .map((x) => ({ id: x.Key, value: x.Value }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);

    const resfastid: Array<number|null> = getResourceData.ResourceData.resourceFast
      .map((x) => x.Key).filter((x) => x !== null && x !== undefined);

    // const addsichip : Array<TypedownOption> = chiplist.chpfast.map((x) => ({ id: x.id, value: x.value }));
    //  addsichip.push(addval);

    const resFastgeo: Array<TypedownOption> = getResourceData.ResourceData.resourceFastGeo
      .map((x) => ({ id: x.Key, value: x.Value }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);

    const resfastgeoid: Array<number|null> = getResourceData.ResourceData.resourceFastGeo
      .map((x) => x.Key).filter((x) => x !== null && x !== undefined);

    const ressubj: Array<TypedownOption> = getResourceData.ResourceData.resourceSubjectLc
      .map((x) => ({ id: x.Key, value: x.Value }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);

    const ressubjlcid: Array<number|null> = getResourceData.ResourceData.resourceSubjectLc
      .map((x) => x.Key).filter((x) => x !== null && x !== undefined);

    const resident: Array<TypedownOption> = getResourceData.ResourceData.resourceIdentifier
      .map((x) => ({ id: x.Key, value: x.Value }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);

    const resIdentifierid: Array<number|null> = getResourceData.ResourceData.resourceIdentifier
      .map((x) => x.Key).filter((x) => x !== null && x !== undefined);

    // const defexpand: Array<number> = getResourceData.ResourceData.broadSubjectLookup.findIndex(x => x.broadSubjectID > 0);
    const tmptree: Array<ParentTree> = getResourceData.ResourceData.broadSubjectLookup.map((bro) => ({
      id: bro.broadSubjectID.toString(),
      name: bro.name,
      children: bro.narrowSubjects.map((nar) => ({
        id: nar.Key.toString(),
        name: nar.Value,
      })),
    }));

    const tmpbroadcolection: Array<number> = tmptree.map((x) => +x.id);
    const tmpnarrowcolection: Array<number> = [];

    tmptree.forEach((item, index) => {
      if (Array.isArray(item.children)) {
        item.children.forEach((sub, subindex) => {
          tmpnarrowcolection.push(+sub.id);
        });
      }
    });

    // formnarrow(resnarrowsub);

    setChiplist((prev) => (
      {
        ...prev,
        chpfast: resFast,
        chpfastgeo: resFastgeo,
        chpsubj: ressubj,
        chpident: resident,
        chptree: tmptree,
        treeexpand: ['1'],
        listchpfastid: resfastid,
        listchpfastgeoid: resfastgeoid,
        listchpidentid: resIdentifierid,
        listchpsubjid: ressubjlcid,
        listchpbroadid: tmpbroadcolection,
        listchpnarrowid: tmpnarrowcolection,
      }));
  }, [getResourceData.ResourceData]);

  useEffect(() => {
    props.callback(chiplist);
  }, [chiplist]);

  useEffect(() => {
    const tmpFast: Array<TypedownOption> = getReferenceData.TitleResourceReferenceData.fasttermLookup
      .map((x) => ({ id: x.fastid, value: x.term }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);

    const tmpFastGeo: Array<TypedownOption> = getReferenceData.TitleResourceReferenceData.fastGeoLookup
      .map((x) => ({ id: x.fastid, value: x.term }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);

    const tmpIdentifier: Array<TypedownOption> = getReferenceData.TitleResourceReferenceData.identifierlookup
      .map((x) => ({ id: x.Key, value: x.Value }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);

    const tmpSubjectLc: Array<TypedownOption> = getReferenceData.TitleResourceReferenceData.subjectLC
      .map((x) => ({ id: x.Key, value: x.Value }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);

    const tmpBroadsubject: Array<TypedownOption> = getReferenceData.TitleResourceReferenceData.broadSubjectLookup
      .map((x) => ({ id: x.broadSubjectID, value: x.name })).filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);

    setStatesubject((prevstate) => ({
      ...prevstate,
      fastTerm: tmpFast,
      fastGeo: tmpFastGeo,
      subjectLC: tmpSubjectLc,
      broadSubject: tmpBroadsubject,
      identifier: tmpIdentifier,

    }));
  }, [getReferenceData.TitleResourceReferenceData]);

  function formnarrow(resnarrowsub: Array<number>) {
    const ressubj: Array<TypedownOption> = [];
    const blen = getReferenceData.TitleResourceReferenceData.broadSubjectLookup.length;
    for (let i = 0; i < blen; i++) {
      const nlen = getReferenceData.TitleResourceReferenceData.broadSubjectLookup[i].narrowSubjects.length;

      const uniqueResultTwo = getReferenceData.TitleResourceReferenceData.broadSubjectLookup[i].narrowSubjects.filter((obj) => resnarrowsub.some((obj2) => obj.Key === obj2));

      //  ressubj =  uniqueResultTwo
      // .map((x) => ({ id: x.Key, value: x.Value }))
      // .filter((x) => x !== null && x !== undefined)
      // .filter((x) => x.value !== null);

      // console.log(uniqueResultTwo)
    }
  }

  function changeTextFilter(e: any) {
    const fieldvalue = e.target.value;

    const filterVaule = fieldvalue === '' ? [] : [fieldvalue];
    // update state

    // console.log(state);
    //    setFilterList(filterList.updateFilter<keyof SelectedOptionState>(filterName, filterVaule));
  }

  //  const [filterList, setFilterList] = useState<SelectedOptionFilters>(SelectedOptionFilters.empty());

  const handleClick = () => {
    console.info('You clicked the Chip.');
  };

  const handleDelete = (chipid: number, Chipval: string, control: string) => {
    // setChips(
    //   (chipss) => chipss.filter((chip)=> chip !== chipval)
    // );

    if (control === 'FAST Terms') {
      setChiplist((prev) => (
        {
          ...prev,
          chpfast: chiplist.chpfast.filter((x) => x.id !== chipid),
          listchpfastid: chiplist.listchpfastid.filter((x) => x !== chipid),
        }));
    }
    if (control === 'FastGeo') {
      setChiplist((prev) => (
        {
          ...prev,
          chpfastgeo: chiplist.chpfastgeo.filter((x) => x.id !== chipid),
          listchpfastgeoid: chiplist.listchpfastgeoid.filter((x) => x !== chipid),
        }));
    }

    if (control === 'SubjectLC') {
      setChiplist((prev) => (
        {
          ...prev,
          chpsubj: chiplist.chpsubj.filter((x) => x.id !== chipid),
          listchpsubjid: chiplist.listchpsubjid.filter((x) => x !== chipid),
        }));
    }

    if (control === 'Identifiers') {
      setChiplist((prev) => (
        {
          ...prev,
          chpident: chiplist.chpident.filter((x) => x.id !== chipid),
          listchpidentid: chiplist.listchpidentid.filter((x) => x !== chipid),
        }));
    }

    if (control === 'Narrow Subject') {
      setChiplist((prev) => (
        {
          ...prev,
          chpnarrow: chiplist.chpnarrow.filter((x) => x.id !== chipid),
        }));

      const mainindex = chiplist.chptree.findIndex((x) => x.id === chipid.toString() && x.name === Chipval.toString());
      if (mainindex >= 0) {
        chiplist.chptree.splice(mainindex, 1);

        setChiplist((prev) => (
          {
            ...prev,
            listchpbroadid: chiplist.listchpbroadid.filter((x) => x !== +chipid),
          }));
      } else {
        chiplist.chptree.forEach((item, index) => {
          item.children.forEach((subitem, subindex) => {
            if (subitem.id === chipid.toString() && subitem.name === Chipval.toString()) {
              item.children.splice(subindex, 1);
              setChiplist((prev) => (
                {
                  ...prev,
                  listchpnarrowid: chiplist.listchpnarrowid.filter((x) => x !== +chipid),
                }));
            }
          });
        });
      }
    }
    console.info('You clicked the delete icon.');
    console.log('checkremove', chiplist);
  };

  function onchangeTypedown(value: string, key: number, control: string) {
    if (control === 'FAST Terms') {
      setStatesubject((prevstate) => ({
        ...prevstate,
        fastTermSV: { id: key, value },
      }));
    }

    if (control === 'FastGeo') {
      setStatesubject((prevstate) => ({
        ...prevstate,
        fastGeoSV: { id: key, value },
      }));
    }

    if (control === 'SubjectLC') {
      setStatesubject((prevstate) => ({
        ...prevstate,
        subjectLCSV: { id: key, value },
      }));
    }

    if (control === 'Identifiers') {
      setStatesubject((prevstate) => ({
        ...prevstate,
        identifierSV: { id: key, value },
      }));
    }
    if (control === 'FAST Geolocation') {
      setStatesubject((prevstate) => ({
        ...prevstate,
        fastGeoSV: { id: key, value },
      }));
    }

    if (control === 'Narrow Subject') {
      setStatesubject((prevstate) => ({
        ...prevstate,
        narrowSubjectSV: { id: key, value },
      }));
    }
  }

  function Addclick(control: string) {
    console.log('addcheck', chiplist);
    if (control === 'FAST Terms') {
      const findex = chiplist.chpfast.findIndex((x) => x.id === statesubject.fastTermSV.id);
      if (findex === -1) {
        const addval: TypedownOption = {
          id: statesubject.fastTermSV.id,
          value: statesubject.fastTermSV.value,
        };

        const addsichip: Array<TypedownOption> = chiplist.chpfast.map((x) => ({ id: x.id, value: x.value }));
        const addsichipli: Array<number|null> = chiplist.chpfast.map((x) => x.id);

        addsichip.push(addval);
        addsichipli.push(addval.id);

        setChiplist((prev) => (
          {
            ...prev,
            chpfast: addsichip,
            listchpfastid: addsichipli,
          }));
      }
    }

    if (control === 'FastGeo') {
      const fgindex = chiplist.chpfastgeo.findIndex((x) => x.id === statesubject.fastGeoSV.id);
      if (fgindex === -1) {
        const addfgval: TypedownOption = {
          id: statesubject.fastGeoSV.id,
          value: statesubject.fastGeoSV.value,
        };

        const addfgchip: Array<TypedownOption> = chiplist.chpfastgeo.map((x) => ({ id: x.id, value: x.value }));
        const addfgchipli: Array<number> = chiplist.chpfastgeo.map((x) => x.id);

        addfgchip.push(addfgval);
        addfgchipli.push(addfgval.id);

        setChiplist((prev) => (
          {
            ...prev,
            chpfastgeo: addfgchip,
            listchpfastgeoid: addfgchipli,
          }));
      }
    }

    if (control === 'SubjectLC') {
      const subindex = chiplist.chpsubj.findIndex((x) => x.id === statesubject.subjectLCSV.id);
      if (subindex === -1) {
        const addvalsub: TypedownOption = {
          id: statesubject.subjectLCSV.id,
          value: statesubject.subjectLCSV.value,
        };

        const addsubchip: Array<TypedownOption> = chiplist.chpsubj.map((x) => ({ id: x.id, value: x.value }));
        const addsubchipli: Array<number> = chiplist.chpsubj.map((x) => x.id);

        addsubchip.push(addvalsub);
        addsubchipli.push(addvalsub.id);

        setChiplist((prev) => (
          {
            ...prev,
            chpsubj: addsubchip,
            listchpsubjid: addsubchipli,
          }));
      }
    }
    if (control === 'Identifiers') {
      const idenindex = chiplist.chpident.findIndex((x) => x.id === statesubject.identifierSV.id);
      if (idenindex === -1) {
        const addvaliden: TypedownOption = {
          id: statesubject.identifierSV.id,
          value: statesubject.identifierSV.value,
        };

        const addidenchip: Array<TypedownOption> = chiplist.chpident.map((x) => ({ id: x.id, value: x.value }));
        const addidenchipli: Array<number> = chiplist.chpident.map((x) => x.id);

        addidenchip.push(addvaliden);
        addidenchipli.push(addvaliden.id);

        setChiplist((prev) => (
          {
            ...prev,
            chpident: addidenchip,
            listchpidentid: addidenchipli,
          }));
      }
    }

    if (control === 'Narrow Subject') {
      const broadexist = chiplist.chptree.findIndex((obj) => obj.id === statesubject.broadSubjectSV.id.toString());
      let nindex = -1;

      chiplist.chptree.forEach((obj) => {
        if (obj.id === statesubject.broadSubjectSV.id.toString()) {
          obj.children.forEach((sub, sindex) => {
            if (sub.id === statesubject.narrowSubjectSV.id.toString()) {
              nindex = sindex;
              // return sindex;
            }
          });
        }
      });

      if (nindex === -1) {
        const tmptree: ParentTree = { id: '', name: '', children: [] };

        const addvalnsub: SubChild = {
          id: statesubject.narrowSubjectSV.id.toString(),
          name: statesubject.narrowSubjectSV.value,
        };

        tmptree.id = statesubject.broadSubjectSV.id.toString();
        tmptree.name = statesubject.broadSubjectSV.value;
        tmptree.children.push(addvalnsub);

        const tmpbroadlist: Array<number> = chiplist.chptree.map((x) => +x.id);
        // const old_tmpnarrowlist: Array<number> = chiplist.chptree.map((x) => x.children.map((c) => +c.id)).map((x) => x[0]);

        const tmpnarrowlist: Array<number> = [];
        chiplist.chptree.forEach((item, index) => {
          if (Array.isArray(item.children)) {
            item.children.forEach((sub, subindex) => {
              tmpnarrowlist.push(+sub.id);
            });
          }
        });
        // Array.isArray(nodes.children)

        const tmparraytree: Array<ParentTree> = chiplist.chptree.map((x) => ({
          id: x.id,
          name: x.name,
          children: x.children.map((y) => ({
            id: y.id, name: y.name,
          })),
        }));

        if (broadexist >= 0) {
          tmparraytree.forEach((obj, index) => {
            if (index === broadexist) {
              obj.children.push(addvalnsub);
              tmpnarrowlist.push(+addvalnsub.id);
            }
          });
        } else {
          tmparraytree.push(tmptree);
          tmpbroadlist.push(+tmptree.id);
          tmpnarrowlist.push(+addvalnsub.id);
        }

        setChiplist((prev) => (
          {
            ...prev,
            chptree: tmparraytree,
            listchpnarrowid: tmpnarrowlist,
            listchpbroadid: tmpbroadlist,
          }));
      }
    }
  }

  function changeBroadSubject(value: string, key: number) {
    const dropdownList: Array<TypedownOption> = [];
    // const narowfilter1: narrowsubjectprop = getReferenceData.ResourceReferenceData.broadSubjectLookup.filter((x) => {(x.broadSubjectID == key)});
    // const narowfilter : narrowsubjectprop[]  = getReferenceData.ResourceReferenceData.broadSubjectLookup.filter((x) => {(x.broadSubjectID == key)});
    // map((x) =>({ broadSubjectID : x.broadSubjectID,name:x.name ,narrowSubjects: x.narrowSubjects }) )
    // .filter((x) => {(x.broadSubjectID == key)});
    // "no-unused-expressions": "off"

    for (let i = 0; i < getReferenceData.TitleResourceReferenceData.broadSubjectLookup.length; i++) {
      if (getReferenceData.TitleResourceReferenceData.broadSubjectLookup[i].broadSubjectID === key) {
        for (let n = 0; n < getReferenceData.TitleResourceReferenceData.broadSubjectLookup[i].narrowSubjects.length; n++) {
          if (getReferenceData.TitleResourceReferenceData.broadSubjectLookup[i].narrowSubjects[n].Key != null
            && getReferenceData.TitleResourceReferenceData.broadSubjectLookup[i].narrowSubjects[n].Value != null) {
            dropdownList.push({
              id: getReferenceData.TitleResourceReferenceData.broadSubjectLookup[i].narrowSubjects[n].Key,
              value: getReferenceData.TitleResourceReferenceData.broadSubjectLookup[i].narrowSubjects[n].Value,
            });
          }
        }
      }
    }

    setStatesubject((prevstate) => ({
      ...prevstate,
      broadSubjectSV: { id: key, value },
      narrowSubject: dropdownList,
    }));
  }

  const renderchip = (nodes: any) => (

    <TreeItem
      key={nodes.id}
      nodeId={nodes.id}
      label={(
        <div className={classes.labelRoot}>
          <RemoveCircleIcon
            style={{ color: red[500] }}
            className={classes.labelIcon}
            onClick={() => handleDelete(nodes.id, nodes.name, 'Narrow Subject')}
          />
          <Typography variant="body2" className={classes.labelText}>
            {nodes.name}
          </Typography>

        </div>
    )}
    >
      {/* <Chip className='treeviewchip' key={nodes.id} label={nodes.name} onClick={handleClick} onDelete={() => handleDelete(nodes.id, nodes.name, "Narrow Subject")} /> */}
      {Array.isArray(nodes.children) ? nodes.children.map((node: any) => renderchip(node)) : null}
    </TreeItem>

  );

  return (
    <Card
      variant="outlined"
      className="SubjectContainer"
      style={{
        marginLeft: 20,
        marginRight: 20,
        paddingBottom: 20,
        marginTop: 20,
      }}
    >
      <Grid item xs={12} style={{ textAlign: 'left' }}>
        <Typography
          className={classes.heading}
          variant="overline"
          style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
        >
          Subject
        </Typography>
      </Grid>
      <Grid xs={12} container>
        <Grid
          item
          xs={6}
          container
          className="custom_chip"
          spacing={2}
          style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
        >
          <Grid item xs={4}>
            <div className="custommultislect">
              <Typedown
                isLoading={props.isLoading}
                label="FAST Terms"
                options={statesubject.fastTerm}
                selectedValue={statesubject.fastTermSV}
                onChange={(Options) => { onchangeTypedown(Options.value, +Options.id, 'FAST Terms'); }}
                allowMultiple={false}
              />

            </div>
          </Grid>
          <Grid item xs={2}>
            <Button
              onClick={() => { Addclick('FAST Terms'); }}
              color="primary"
              variant="outlined"
              className="addbutton"
            >
              Add
            </Button>
          </Grid>
          <Grid item xs={4}>
            <div className="custommultislect">
              <Typedown
                isLoading={props.isLoading}
                label="SubjectLC"
                options={statesubject.subjectLC}
                selectedValue={statesubject.subjectLCSV}
                onChange={(Options) => { onchangeTypedown(Options.value, +Options.id, 'SubjectLC'); }}
                allowMultiple={false}
              />

            </div>
          </Grid>
          <Grid item xs={2}>
            <Button
              onClick={() => { Addclick('SubjectLC'); }}
              color="primary"
              variant="outlined"
              className="addbutton"
            >
              Add
            </Button>
          </Grid>

          <Grid item xs={4}>
            <div className="custommultislect">
              <Typedown
                isLoading={props.isLoading}
                label="FAST Geolocation"
                options={statesubject.fastGeo}
                selectedValue={statesubject.fastGeoSV}
                // onChange={(options) => { changeFilter("uniformtitle", options as unknown as TypedownOption[]); }}
                onChange={(Options) => { onchangeTypedown(Options.value, +Options.id, 'FastGeo'); }}
                allowMultiple={false}
              />

            </div>
          </Grid>
          <Grid item xs={2}>
            <Button
              onClick={() => { Addclick('FastGeo'); }}
              color="primary"
              variant="outlined"
              className="addbutton"
            >
              Add
            </Button>
          </Grid>
          <Grid item xs={4}>
            <div className="custommultislect">
              <Typedown
                isLoading={props.isLoading}
                label="Identifiers"
                options={statesubject.identifier}
                selectedValue={statesubject.identifierSV}
                onChange={(Options) => { onchangeTypedown(Options.value, +Options.id, 'Identifiers'); }}
                allowMultiple={false}
              />

            </div>
          </Grid>
          <Grid item xs={2}>
            <Button
              onClick={() => { Addclick('Identifiers'); }}
              color="primary"
              variant="outlined"
              className="addbutton"
            >
              Add
            </Button>
          </Grid>

          <Grid
            item
            xs={12}
            container
            spacing={2}
            style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
          >
            <Typography className={classes.subheading} variant="overline">
              Selected FAST Terms
            </Typography>
            <Grid direction="row" xs={12} spacing={2}>
              {
                chiplist.chpfast.map((ds) => (
                  <Chip icon={<RemoveCircleIcon  onClick={() => handleDelete(ds.id, ds.value, 'FAST Terms')} />}
                  key={ds.id} label={ds.value} onClick={handleClick} />
                ))
              }
              {/* <Chip
                key = 'key'
                color='primary'
                label="Clickable Deletable"
                onClick={handleClick}
                onDelete={handleDelete}
              />
            */}
            </Grid>
          </Grid>

          <Grid
            item
            xs={12}
            container
            spacing={2}
            style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
          >
            <Typography className={classes.subheading} variant="overline">
              Selected Fast Geo
            </Typography>
            <Grid direction="row" xs={12} spacing={2}>
              {
                chiplist.chpfastgeo.map((su) => (
                  <Chip icon={<RemoveCircleIcon  onClick={() => handleDelete(su.id, su.value, 'FastGeo')} />}
                  key={su.id} label={su.value} onClick={handleClick}/>
                ))
              }

            </Grid>
          </Grid>

          <Grid
            item
            xs={12}
            container
            spacing={2}
            style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
          >
            <Typography className={classes.subheading} variant="overline">
              Selected SubjectLC
            </Typography>
            <Grid direction="row" xs={12} spacing={2}>
              {
                chiplist.chpsubj.map((su) => (
                  <Chip icon={<RemoveCircleIcon  onClick={() => handleDelete(su.id, su.value, 'SubjectLC')} />}
                   key={su.id} label={su.value} onClick={handleClick}  />
                ))
              }

            </Grid>
          </Grid>
          <Grid
            item
            xs={12}
            container
            spacing={2}
            style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
          >
            <Typography className={classes.subheading} variant="overline">
              Selected Identifiers
            </Typography>
            <Grid direction="row" xs={12} spacing={2}>
              {
                chiplist.chpident.map((su) => (
                  <Chip  icon={<RemoveCircleIcon  onClick={() =>  handleDelete(su.id, su.value, 'Identifiers')} />}
                  key={su.id} label={su.value} onClick={handleClick}  />
                ))
              }
            </Grid>
          </Grid>
        </Grid>
        <Grid
          item
          xs={6}
          container
          className="borderleft"
          spacing={2}
          style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
        >
          <Grid item xs={4}>
            <div className="custommultislect">
              <Typedown
                isLoading={props.isLoading}
                label="Broad Subject Area"
                options={statesubject.broadSubject}
                selectedValue={statesubject.broadSubjectSV}
                // onChange={(options) => { changeFilter("uniformtitle", options as unknown as TypedownOption[]); }}
                onChange={(Options) => { changeBroadSubject(Options.value, +Options.id); }}
              />

            </div>

          </Grid>
          <Grid item xs={4}>
            <div className="custommultislect">

              <Typedown
                isLoading={props.isLoading}
                label="Narrow Subject Area"
                options={statesubject.narrowSubject}
                selectedValue={statesubject.narrowSubjectSV}
                onChange={(Options) => { onchangeTypedown(Options.value, +Options.id, 'Narrow Subject'); }}
              />
            </div>

          </Grid>
          <Grid item xs={2}>
            <Button
              onClick={() => { Addclick('Narrow Subject'); }}
              color="primary"
              variant="outlined"
              className="addbutton"
            >
              Add
            </Button>
          </Grid>

          <Grid direction="row" xs={12} spacing={2}>
            <Grid
              item
              xs={12}
              container
              spacing={2}
              style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
            >
              <Typography className={classes.subheading} variant="overline">
                Selected Narrow Subject Area
              </Typography>
              <Grid xs={12} spacing={2} className="custom_treeview">

                {/* { className='custom_treeview'
                chiplist.chpnarrow.map(su => (
                <Chip key ={su.id} label = {su.value} onClick={handleClick} onDelete={() => handleDelete(su.id, su.value,"Narrow Subject")}/>
              ))
              } */}

                {/* {renderTree(chiplist.chpnarrow)} */}

                <TreeView
                  className={classes.root}
            //  defaultCollapseIcon={<ExpandMoreIcon />}
                  defaultExpanded={['0,1']}
                >
                  {
                chiplist.chptree.map((su) => (
                  renderchip(su)
                ))
              }
                  {/* {
                  hierarchy.map(su => (renderchip(su)))
               }
                 */}
                </TreeView>

                {/* <TreeViewComponent fields={datasourceFields}> </TreeViewComponent>  */}
              </Grid>
            </Grid>

          </Grid>
        </Grid>
      </Grid>

    </Card>
  );
}

export default AddSubject;
