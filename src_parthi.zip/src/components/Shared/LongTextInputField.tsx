/* eslint @typescript-eslint/no-explicit-any: 0 */
import React from 'react';
import {
  FormControl, createStyles, TextField, WithStyles, withStyles,
} from '@material-ui/core';

const useStyles = createStyles({
  longTextInputField: {
    width: '100%',
    color: '#000054',
  },
});

interface LongTextInputFieldProps {
    labelText: string;
    inputText: string | number | null | undefined;
    keyName: string;
    onChangeFunction: any;
    onBlur: any;
    error: boolean;
    classes: any;
    rows?: string;
    readOnly?: boolean;
    errorMessage?: string;
    placeholder?: string;
}

class LongTextInputField extends React.Component<LongTextInputFieldProps & WithStyles<typeof useStyles>> {
  constructor(props: LongTextInputFieldProps) {
    super(props);
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(event: any) {
    this.props.onChangeFunction(this.props.keyName, event.target.value);
  }

  render() {
    const { classes } = this.props;
    return (
      <FormControl className={classes.longTextInputField}>
        <TextField
          name={this.props.keyName}
          required
          multiline
          rows={this.props.rows}
          variant="outlined"
          label={this.props.labelText}
          defaultValue={this.props.inputText}
          margin="normal"
          onChange={this.props.onChangeFunction}
          onBlur={this.props.onBlur}
          error={this.props.error}
          disabled={this.props.readOnly}
          helperText={this.props.error ? this.props.errorMessage : ''}
          placeholder={this.props.placeholder}
        />
      </FormControl>
    );
  }
}

export default withStyles(useStyles)(LongTextInputField);
