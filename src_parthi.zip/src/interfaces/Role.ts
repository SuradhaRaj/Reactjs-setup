type Role = 'Indexer'|'MediaIndexer'|'TextIndexer'|'IndexersAdmin' | 'InformitAdmin' | 'TextEduIndexer' | 'TextLgealIndexer' | 'IssueSplitter';
export default Role;
