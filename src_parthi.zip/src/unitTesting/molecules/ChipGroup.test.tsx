import React from 'react';
import { shallow, mount } from 'enzyme';
import ChipGroup from '../../components/molecules/ChipGroup';

describe('Chip group', () => {
  it('should render the correct number of chips up to the max', () => {
    const wrapper = shallow(<ChipGroup
      onDelete={() => undefined}
      content={['Item1', 'Item2', 'Item3', 'Item4']}
      maxLength={10}
    />);

    expect(wrapper.find('[data-visible-chips]')).toHaveLength(4);
  });

  it('should show "+1 more" when one more than the max is specified', () => {
    const wrapper = shallow(<ChipGroup
      onDelete={() => undefined}
      content={['Item1', 'Item2', 'Item3', 'Item4']}
      maxLength={3}
    />);

    expect(wrapper.find('[data-visible-chips]')).toHaveLength(3);
    expect(wrapper.find('[data-more-items]').prop('label')).toBe('+1 more');
  });

  it('should not show "+x more" when the max is specified', () => {
    const wrapper = shallow(<ChipGroup
      onDelete={() => undefined}
      content={['Item1', 'Item2', 'Item3', 'Item4']}
      maxLength={4}
    />);

    expect(wrapper.find('[data-more-items]').length).toBe(0);
    expect(wrapper.find('[data-visible-chips]')).toHaveLength(4);
    expect(wrapper.find('[data-hidden-chips]')).toHaveLength(0);
  });

  it('should render the correct number of hidden chips', () => {
    const wrapper = shallow(<ChipGroup
      onDelete={() => undefined}
      content={['Item1', 'Item2', 'Item3', 'Item4']}
      maxLength={3}
    />);

    expect(wrapper.find('[data-visible-chips]')).toHaveLength(3);
    expect(wrapper.find('[data-hidden-chips]')).toHaveLength(1);
  });

  it('should call the onDelete function when a chip is deleted', () => {
    const onDeleteCallback = jest.fn();
    const wrapper = mount(<ChipGroup
      onDelete={onDeleteCallback}
      content={['Item1', 'Item2', 'Item3', 'Item4']}
      maxLength={3}
    />);

    wrapper.find('.MuiChip-deleteIcon').first().simulate('click');

    expect(onDeleteCallback.mock.calls).toHaveLength(1);
  });
});
