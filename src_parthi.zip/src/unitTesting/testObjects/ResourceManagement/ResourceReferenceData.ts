import ResourceReferenceData from '../../../interfaces/ResourceManagement/ResourceReferenceData';

const refData: ResourceReferenceData = {
  broadSubjectLookup: [],
  contentType: [{ key: 1, value: 'value1' }],
  descriptionType: [{ Key: 1, Value: 'value1' }],
  fileType: [{ key: 1, value: 'value1' }],
  frequency: [{ Key: 1, Value: 'value1' }],
  indexingCompany: [{ Key: 1, Value: 'value1' }],
  languages: [{ Key: 1, Value: 'value1' }],
  mediaType: [{ Key: 1, Value: 'value1' }],
  resourceManager: [{ Key: 1, Value: 'Michael' }, { Key: 2, Value: 'Jeremy' }],
  resourceTypes: [{
    resourceTypeID: 1,
    name: 'value1',
    children: [{
      children: [],
      displayOrder: 1,
      name: 'Value 2',
      resourceTypeID: 2,
    }],
    displayOrder: 1,
  }],
  titleType: [{ key: 1, value: 'value1' }],
  resourceIndexes: [{ key: 1, value: 'value1' }],
  seriesTitles: [{ key: 1, value: 'value1' }],
  uniformTitles: [{ Key: 1, Value: 'value1' }],
  resourceWorkflowStates: [{ Key: 1, Value: 'value1' }],
  contactRoleType: [{ key: 1, value: 'value1' }],
  accessRight: [{ Key: 1, Value: 'value1' }],
  indexType: [{ key: 'CR', value: 'value1' }],
  productLibrary: [{ key: 'APAFT', value: 'value1' }],
  clearedBy: [{ key: 1, value: 'value1' }],
  countryOfPublicationMarc: [{ key: 'at', value: 'Australia' }],
  cclicenceType: [{ key: 1, value: 'value1' }],
  accessType: [{ key: 1, value: 'value1' }],
  clearanceStatus: [{ key: 1, value: 'value1' }],
  royaltyOrganisation: [{ key: 1, value: 'value1' }],
  resourceslookup: [{
    resourceID: 1, resourceTitle: 'value1', resourceTypeID: 1, resourceName: 'value1',
  }],
  fasttermLookup: [{
    fastid: 1, termid: 'value1', term: 'value1', termdisplayname: 'value1',
  }],
  fastGeoLookup: [{
    fastid: 1, termid: 'value1', term: 'value1', termdisplayname: 'value1',
  }],
  subjectLC: [{ Key: 1, Value: 'value1' }],
  identifierlookup: [{ Key: 1, Value: 'value1' }],
};
export default refData;
