import React, { useState, useEffect } from 'react';
import {
  Typography,
  Grid,
  Card,
  Button,
  makeStyles,
  Chip,
} from '@material-ui/core';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { useTypedSelector } from '../../../store/store';
import { StrStrTypedownOption, TypedownOption } from '../../../interfaces/TypedownOption';
import Typedown from '../Typedown';
import ProductsInfo from './ProductInformation';
import LicenseInfo from './LicensecInformation';
import RemoveCircleIcon from '@material-ui/icons/RemoveCircle';

interface ProdCollection {
  product: Array<StrStrTypedownOption>;
  collection: Array<StrStrTypedownOption>;
}
interface ProdCollectionVal {
  prodList: Array<StrStrTypedownOption>;
  collectionList: Array<StrStrTypedownOption |TypedownOption>;
}
interface GetSelValue {
  selectedProd: StrStrTypedownOption;
  selectedCol: Array<StrStrTypedownOption|TypedownOption>;
}
type NewType = boolean;
interface Props {
  isLoading: NewType;
}
const useStyles = makeStyles({
  resourceIdeContainer: {
    paddingBottom: '20',
  },

  heading: {
    'font-size': '13px',
    'font-weight': '500',
    'text-transform': 'none',
    color: '#000000',
  },
  addbutton: {
    height: '32px',
    'font-size': '13px',
    'line-height': '30px',
  },
  subheading: {
    'font-size': '12px',
    'font-weight': '500',
    'text-transform': 'none',
    color: '#000000',
  },
  borderleft: {
    borderleft: '1px solid #cccccc',
  },
  SubjectContainer: {
    width: '100%',
  },
  notification: {},
  typo: {
    fontSize: '17px',
    'font-weight': '600',
    marginBottom: '0px',
    paddingLeft: '20px !important',
    'text-transform': 'none',
  },
});

function ProductsCollection(props: any): JSX.Element {
  const classes = useStyles();
  const getReferenceData = useTypedSelector((store) => store.TitleResourceReferenceData.TitleResourceReferenceData);
  const getResourceData = useTypedSelector((store) => store.ResourceDataOnId.ResourceData);
  const [prodCollDrop, setProdCollDrop] = useState<ProdCollection>({
    product: [],
    collection: [],
  });
  const [prodCollList, setProdCollList] = useState<ProdCollectionVal>({
    prodList: [],
    collectionList: [],
  });
  const [selectedData, setSelectedData] = useState<GetSelValue>({
    selectedProd: { id: '', value: '' },
    selectedCol: [],
  });
  const [collectionState, setCollectionState] = useState<boolean>(false);
  const [licenceTab, setLicenceTab] = useState<StrStrTypedownOption | null>(null);
  useEffect(() => {
    if (getReferenceData !== null) {
      const productDropDown: Array<StrStrTypedownOption> = [];
      getReferenceData.productLibrary.forEach((element) => {
        productDropDown.push({ id: element.Key, value: element.Value });
      });
      setProdCollDrop((prev) => ({
        ...prev,
        product: productDropDown,
      }));
      const CollectionDropDown: Array<StrStrTypedownOption> = [];
      getReferenceData.collection.forEach((element) => {
        CollectionDropDown.push({ id: element.Key, value: element.Value });
      });
      setProdCollDrop((prev) => ({
        ...prev,
        collection: CollectionDropDown,
      }));
      const mappedValueProd: Array<StrStrTypedownOption> = [];
      prodCollDrop.product.forEach((e) => {
        if (getResourceData.resourceProductCode.includes(e.id)) {
          mappedValueProd.push(e);
        }
      });
      const mappedValuecol: Array<StrStrTypedownOption> = [];
      prodCollDrop.collection.forEach((e) => {
        if (getResourceData.resourceCollectionCode.includes(e.id)) {
          mappedValuecol.push(e);
        }
      });
      setProdCollList({
        prodList: mappedValueProd,
        collectionList: mappedValuecol,
      });
    }
  }, [getReferenceData, getResourceData]);
  useEffect(() => {
    if (prodCollList.prodList.length !== 0) { props.callback(prodCollList); }
  }, [prodCollList]);
  const deleteRecord = (deleteDataPos: number, type: string) => {
    if (type.match('product')) {
      if (prodCollList.prodList[deleteDataPos].id.match('APAFT')) {
        setLicenceTab(null);
      }
      const data = prodCollList.prodList.filter((_, index) => index !== deleteDataPos);
      if (prodCollList.prodList[deleteDataPos].id.match('COLLECTIONS')) {
        setProdCollList({
          prodList: data,
          collectionList: [],
        });
        setCollectionState(false);
      } else {
        setProdCollList((prev) => ({
          ...prev,
          prodList: data,
        }));
      }
    }
    if (type.match('collection')) {
      const data = prodCollList.collectionList.filter((_, index) => index !== deleteDataPos);
      setProdCollList((prev) => ({
        ...prev,
        collectionList: data,
      }));
    }
  };
  function addProduct() {
    if (selectedData.selectedProd.id.length !== 0 && selectedData.selectedProd.id !== null && selectedData.selectedProd.id !== undefined) {
      setProdCollList((prev) => ({
        ...prev,
        prodList: [...prev.prodList, selectedData.selectedProd],
      }));
      if (selectedData.selectedProd.id.match('COLLECTIONS')) {
        setCollectionState(true);
      } else {
        setCollectionState(false);
      }
      if (selectedData.selectedProd.id.match('APAFT')) {
        setLicenceTab(selectedData.selectedProd);
      }
    }
    if (selectedData.selectedCol.length !== 0) {
      selectedData.selectedCol.forEach((e) => {
        prodCollList.collectionList.push(e);
      });
      setProdCollList((prev) => ({
        ...prev,
      }));
    }
    setSelectedData({
      selectedProd: { id: '', value: '' },
      selectedCol: [],
    });
  }
  return (
    <Grid>
      <Grid xs={12} container>
        <Grid item xs={12} style={{ textAlign: 'left' }}>
          <div className={classes.notification}>
            <h6 className={classes.typo}>
              The resource is available on the following fulltext products
            </h6>
          </div>
        </Grid>
        <Card
          variant="outlined"
          className="SubjectContainer"
          style={{
            marginLeft: 20,
            marginRight: 20,
            paddingBottom: 20,
            marginTop: 20,
            marginBottom: 20,
            width: '100%',
          }}
        >
          <Grid item xs={12} style={{ textAlign: 'left' }}>
            <Typography
              className={classes.heading}
              variant="overline"
              style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
            >
              Products and Collections
            </Typography>
          </Grid>
          <Grid xs={12} container>
            <Grid
              item
              xs={6}
              container
              spacing={2}
              style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
            >
              <Grid xs={12} container spacing={2}>
                <Grid item xs={8}>
                  <div className="custom_autocomplete">
                    <Typedown
                      isLoading={props.isLoading}
                      label="Products"
                      options={prodCollDrop.product}
                      selectedValue={selectedData.selectedProd}
                      onChange={(Options) => {
                        setSelectedData((prev) => (
                          {
                            ...prev,
                            selectedProd: { id: Options.id.toString(), value: Options.value },
                          }));
                      }}
                    />
                  </div>
                </Grid>
                <Grid item xs={4}>
                  <Button
                    onClick={(e) => { addProduct(); }}
                    color="primary"
                    variant="outlined"
                    className="addbutton"
                  >
                    Add Product
                  </Button>
                </Grid>
              </Grid>
              {collectionState ? (
                <Grid xs={12} container spacing={2}>
                  <Grid item xs={8}>
                    <div className="custom_autocomplete">
                      <Typedown
                        key="collection"
                        isLoading={props.isLoading}
                        label="Collections"
                        options={prodCollDrop.collection}
                        selectedOptions={selectedData.selectedCol.map((e) => e)}
                      // selectedValue={prodCollDrop.collection[0]}
                        allowMultiple
                      // onChange={(Options) => {console.log(Options.value, +Options.id); }}
                      // onChangeMultiple={(Options) => {setSelectedData1(Options);}}
                        onChangeMultiple={(Options) => {
                          setSelectedData((prev) => ({
                            ...prev,
                            selectedCol: Options,
                          }));
                        }}
                      />
                    </div>
                  </Grid>
                  <Grid item xs={4}>
                    <Button
                      onClick={(e) => { addProduct(); }}
                      color="primary"
                      variant="outlined"
                      className="addbutton"
                    >
                      Add Collection
                    </Button>
                  </Grid>
                </Grid>
              ) : ''}

            </Grid>
            <Grid
              item
              xs={6}
              container
              className="borderleft"
              spacing={2}
              style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
            >
              <Grid
                item
                xs={12}
                container
                spacing={2}
                style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
              >
                <Grid item xs={6} container>
                  <Typography className={classes.subheading} variant="overline">
                    Products
                  </Typography>
                  {prodCollList.prodList.map((list, pos) => (
                    <Grid
                      direction="row"
                      xs={12}
                      spacing={2}
                      className="custom_chipelements"
                    >
                      <Chip icon={<RemoveCircleIcon  onClick={() => deleteRecord(pos, 'product')}  />}
                        label={list.value}                       
                      />
                    </Grid>
                  ))}
                </Grid>
                <Grid item xs={6} container>
                  <Typography className={classes.subheading} variant="overline">
                    Collections
                  </Typography>
                  {prodCollList.collectionList.map((list, pos) => (
                    <Grid
                      direction="row"
                      xs={12}
                      spacing={2}
                      className="custom_chipelements"
                    >
                      <Chip icon={<RemoveCircleIcon  onClick={() => deleteRecord(pos, 'collection')}  />}
                        label={list.value} 
                      />
                    </Grid>
                  ))}
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Card>
      </Grid>
      <Grid
        item
        xs={12}
        container
        style={{
          marginLeft: 0,
          marginRight: 0,
          paddingBottom: 20,
          marginTop: 0,
          marginBottom: 0,
        }}
      >
        <div className="customaccordion">
          <Accordion>
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel2a-content"
              id="panel2a-header"
            >
              <Typography className={classes.heading}>Licence Information</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <LicenseInfo productInfo={prodCollList.prodList} isLoading />
            </AccordionDetails>
          </Accordion>
          { licenceTab?.id === 'APAFT'
            && (
            <Accordion>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel1a-content"
                id="panel1a-header"
              >
                <Typography className={classes.heading}>AGIS Plus Text</Typography>
              </AccordionSummary>
              <AccordionDetails>
                <ProductsInfo productInfo={licenceTab} isLoading />
              </AccordionDetails>
            </Accordion>
)}
        </div>
      </Grid>
    </Grid>
  );
}

export default ProductsCollection;
