import React, { useEffect, useState } from 'react';
import {
  Typography,
  Grid,
  Card,
  makeStyles,
} from '@material-ui/core';
import { useDispatch } from 'react-redux';
import Axios from 'axios';
import TypedownFilter from '../TypedownFilter';

import { useTypedSelector } from '../../../store/store';
import TextInputField from '../../Shared/TextInputField';
import InlineDatePicker from '../../Shared/Datepicker';
import Dropdown from '../../Shared/Dropdown';
import DropdownOption from '../../../interfaces/MediaIndexer/DropdownOption';
import LookupOption from '../../../interfaces/LookupOption';
import {
  clearFilters,
  ActionTypes,
} from '../../../store/actions/ActnTextTaskManagement';
import ResourceResponse from '../../../interfaces/ResourceManagement/ResourceResponse';
import { setResourceData } from '../../../store/actions/ActnResourceData';

import { TypedownOption, StrStrTypedownOption } from '../../../interfaces/TypedownOption';
import Typedown from '../Typedown';
import WorkflowInformationFilters from '../../../classes/WorkflowInformationFilters';

interface State {
  status: Array<string>;
  publisher: Array<string>;
  title: Array<string>;
  grouping: Array<string>;
  manager: Array<TypedownOption | StrStrTypedownOption>;
  broadcastdate: Array<string>;

}
interface StateResource {
  resourcetype: Array<TypedownOption | StrStrTypedownOption>;
  resource: Array<TypedownOption | StrStrTypedownOption>;
  search: string;
  workflowStatus: Array<TypedownOption | StrStrTypedownOption>;
  accessRights: Array<TypedownOption | StrStrTypedownOption>;
  indexingCompany: Array<TypedownOption | StrStrTypedownOption>;
  resourceManager: Array<TypedownOption | StrStrTypedownOption>;
  resourceSV: string;
  resourcetypeSV: string;
}

type NewType = boolean;

interface Props {
  isLoading: NewType;
}

const useStyles = makeStyles({
  resourceIdeContainer: {
    paddingBottom: '20',
  },

  heading: {
    'font-size': '13px',
    'font-weight': '500',
    'text-transform': 'none',
    color: '#000000',
    float: 'left',
  },
  cardheader: {},
  Lgroup: {
    fontSize: '12px',
    marginRight: '20px',
    color: '#000000',
    paddingTop: '15',
    paddingBottom: '15',
  },
  Lname: {
    fontSize: '12px',
    'font-weight': '600',
    color: '#000000',
    marginRight: '8px',
    marginBottom: '0px',
  },
});

function Workflow(props: Props): JSX.Element {
  const classes = useStyles();

  const getReferenceData = useTypedSelector((store) => store.TitleResourceReferenceData.TitleResourceReferenceData);
  const getResourceData = useTypedSelector((store) => store.ResourceDataOnId);

  const refData = getReferenceData;
  const resData = getResourceData.ResourceData;
  // commented as part elint fix
  // const dispatch = useDispatch();

  const [workflowinfo, setWorkflowInformation] = useState<StateResource>({
    resourcetype: [],
    resource: [],
    search: '',
    workflowStatus: [],
    accessRights: [],
    indexingCompany: [],
    resourceManager: [],
    resourceSV: '',
    resourcetypeSV: '',
  });

  const [workflowoptions, setWorkflowOptions] = useState<WorkflowInformationFilters>(WorkflowInformationFilters.empty());

  function changeFilter<T extends keyof StateResource>(
    filterName: T,
    value: StateResource[T],
  ) {
    setWorkflowOptions(workflowoptions.updateFilter<keyof StateResource>(filterName, value));
    console.log(workflowoptions);
  }

  useEffect(() => {
    const resourceManagerLookup: Array<TypedownOption | StrStrTypedownOption> = refData.resourceManager
      .map((x) => ({ id: x.Key, value: x.Value }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);
    const workflowStatusLookup: Array<TypedownOption | StrStrTypedownOption> = refData.resourceWorkflowStates
      .map((x) => ({ id: x.Key, value: x.Value }))
      .filter((x) => x !== null && x !== undefined)
      .filter((x) => x.value !== null);

    setWorkflowInformation((prevState) => ({
      ...prevState,

      resourceManager: resourceManagerLookup,
      workflowStatus: workflowStatusLookup,

    }));

    if (resData.resourceManagerId != null) {
      setWorkflowOptions(workflowoptions.updateFilter<keyof StateResource>('resourceManager', {
        id: resData.resourceManagerId ?? undefined,
        value: refData.resourceManager.find((x) => x.Key === resData.resourceManagerId)?.Value ?? '',
      } as unknown as TypedownOption[]));
    }
    if (resData.workflowStatusId != null) {
      setWorkflowOptions(workflowoptions.updateFilter<keyof StateResource>('workflowStatus', {
        id: resData.workflowStatusId ?? undefined,
        value: refData.resourceWorkflowStates.find((x) => x.Key === resData.workflowStatusId)?.Value ?? '',
      } as unknown as TypedownOption[]));
    }
  }, [resData, refData]);

  return (
    <Card
      variant="outlined"
      className="resourceIdeContainer"
      style={{
        marginLeft: 20,
        marginRight: 20,
        paddingBottom: 20,
        marginTop: 20,
        paddingTop: 10,
      }}
    >
      <Grid container spacing={2}>
        <Grid item xs={4}>
          <Typography
            className={classes.heading}
            variant="overline"
            style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
          >
            Workflow
          </Typography>
        </Grid>
        <Grid item xs={8}>
          <div className={classes.cardheader} style={{ textAlign: 'right' }}>
            <span className={classes.Lgroup}>
              <span className={classes.Lname}>Content Source:</span>
              <span>{resData.source}</span>
            </span>
            <span className={classes.Lgroup}>
              <span className={classes.Lname}>Content DN:</span>
              <span>
                {resData.titleDocumentNumber}
                {' '}
              </span>
            </span>
            <span className={classes.Lgroup}>
              <span className={classes.Lname}>Content Import Date:</span>
              <span>
                {resData.liveDate}
                {' '}
              </span>
            </span>
          </div>
        </Grid>
      </Grid>
      <Grid
        container
        spacing={2}
        style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}
      >
        <Grid item xs={2}>
          <Typedown
            isLoading={props.isLoading}
            label="Title Workflow Status"
            options={workflowinfo.workflowStatus}
            selectedValue={resData.workflowStatusId != null
              ? workflowinfo.workflowStatus[resData.workflowStatusId - 1]
              : workflowinfo.workflowStatus[0]}

            onChange={(options) => { changeFilter('workflowStatus', options as unknown as TypedownOption[]); }}
          />
        </Grid>
        <Grid item xs={2}>
          <div className="customdatepicker">
            <InlineDatePicker
              labelText="Live Date"
              value={resData.liveDate}
            />
          </div>
        </Grid>

        <Grid item xs={2}>
          <div className="custom_autocomplete">

            <Typedown
              isLoading={props.isLoading}
              label="Resource Manager"
              options={workflowinfo.resourceManager}
              selectedValue={resData.resourceManagerId != null
                ? workflowinfo.resourceManager[resData.resourceManagerId - 1]
                : workflowinfo.resourceManager[0]}

              onChange={(options) => { changeFilter('resourceManager', options as unknown as TypedownOption[]); }}
            />
          </div>

        </Grid>
        <Grid item xs={6}>
          <div className="custominput mt0">
            <TextInputField
              keyName="eissn"
              labelText="Title Website"

              value={resData.website}
              onChangeFunction={(e: any) => e}
              // onBlur={(e: any) => {}}
              error={false}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custominput mt0">
            <TextInputField
              keyName="eissn"
              labelText="Title Ready For Metadata"

              value={resData.readyForMetadataDate}
              onChangeFunction={(e: any) => e}
              // onBlur={(e: any) => {}}
              error={false}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custominput mt0">
            <TextInputField
              keyName="eissn"
              labelText="Title Ready For Files"
              value={resData.readyForFilesDate}
              onChangeFunction={(e: any) => e}
              // onBlur={(e: any) => {}}
              error={false}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custominput mt0">
            <TextInputField
              keyName="eissn"
              labelText="Tiltle Ready For Cateloguing"
              value={resData.readyForCataloguingDate}
              onChangeFunction={(e: any) => e}
              // onBlur={(e: any) => {}}
              error={false}
            />
          </div>
        </Grid>
        <Grid item xs={3}>
          <div className="custominput mt0">
            <TextInputField
              keyName="eissn"
              labelText="Tiltle Ready For QA"
              value={resData.readyForQaDate}
              onChangeFunction={(e: any) => e}
              // onBlur={(e: any) => {}}
              error={false}
            />
          </div>
        </Grid>
      </Grid>
    </Card>
  );
}

export default Workflow;

function dispatch(arg0: ActionTypes) {
  throw new Error('Function not implemented.');
}
