import React from 'react';
import { mount } from 'enzyme';
import Axios from 'axios';
import { act } from 'react-dom/test-utils';
import MockAdaptor from 'axios-mock-adapter';
import { Provider } from 'react-redux';
import { MuiThemeProvider } from '@material-ui/core';
import Resource from '../../../components/pages/Resource';
import ResourceResponse from '../../testObjects/ResourceManagement/ResourceResponse';
import ResourceReferenceData from '../../testObjects/ResourceManagement/ResourceReferenceData';
import store from '../../../store/store';
import RuntypeErrorPaper from '../../../components/organisms/RuntypeError';
import RootResource from '../../../components/organisms/ResourceManagement/RootResource';
import theme from '../../../config/theme';

jest.mock('react-router-dom', () => ({
  useParams: () => ({ resId: 1640 }),
}));

const mockAxios = new MockAdaptor(Axios);

const mountResource = () => mount(
  <Provider store={store}>

    <MuiThemeProvider theme={theme}><Resource /></MuiThemeProvider>
  </Provider>,
);

describe('Root Resource', () => {
  it('should show runtype error when data is invalid', async () => {
    mockAxios.onGet('/api/resource/referencedata').reply(200, {});
    mockAxios.onGet(`/api/resource/${ResourceResponse.resource.resourceId}`).reply(200, {});

    const wrapper = mountResource();
    await act(async () => {
      await Promise.resolve(wrapper);
    });

    wrapper.update();
    expect(wrapper.find(RuntypeErrorPaper)).toHaveLength(1);
  });
  it('should show correct error when 404 is received for resource', async () => {
    mockAxios.onGet('/api/resource/referencedata').reply(200, {});
    mockAxios.onGet(`/api/resource/${ResourceResponse.resource.resourceId}`).reply(404, {});

    const wrapper = mountResource();
    await act(async () => {
      await Promise.resolve(wrapper);
    });

    wrapper.update();
    expect(wrapper.find('[data-testid="404Error"]')).toHaveLength(1);
  });
  it('should show generic error when non 404 error is received for resource', async () => {
    mockAxios.onGet('/api/resource/referencedata').reply(200, {});
    mockAxios.onGet(`/api/resource/${ResourceResponse.resource.resourceId}`).reply(500, {});

    const wrapper = mountResource();
    await act(async () => {
      await Promise.resolve(wrapper);
    });
    wrapper.update();
    expect(wrapper.find('[data-testid="genericError"]')).toHaveLength(1);
  });
  it('should show generic error when non 404 error is received for reference data', async () => {
    mockAxios.onGet('/api/resource/referencedata').reply(500, {});
    mockAxios.onGet(`/api/resource/${ResourceResponse.resource.resourceId}`).reply(200, {});

    const wrapper = mountResource();
    await act(async () => {
      await Promise.resolve(wrapper);
    });

    wrapper.update();
    expect(wrapper.find('[data-testid="genericError"]')).toHaveLength(1);
  });
  it('should render the RootResource node when data is retrieved successfully', async () => {
    mockAxios.onGet('/api/resource/referencedata').reply(200, ResourceReferenceData);
    mockAxios.onGet(`/api/resource/${ResourceResponse.resource.resourceId}`).reply(200, ResourceResponse);

    const wrapper = mountResource();
    await act(async () => {
      await Promise.resolve(wrapper);
    });

    wrapper.update();
    expect(wrapper.find(RootResource)).toHaveLength(1);
  });
});
