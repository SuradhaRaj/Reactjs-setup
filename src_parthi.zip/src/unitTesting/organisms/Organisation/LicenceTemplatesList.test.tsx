import React from 'react';
import { mount } from 'enzyme';
import LicenceTemplatesList, { LicenceTemplatesListItem } from '../../../components/organisms/Organisation/LicenceTemplatesList';

const wrapper = mount(<LicenceTemplatesList
  onEditClick={() => undefined}
  licenceTemplates={[]}
  referenceData={{
    ccLicenceType: [],
    clearedBy: [],
    clearanceStatus: [],
    accessRight: [],
    accessType: [],
    contactRoleType: [],
  }}
  templateIdToEdit={0}
  handleCloseDialog={() => undefined}
  onLicenceTemplateChangeHandler={() => undefined}
/>);

describe('Licences List', () => {
  it('should not show any licences if none are provided', () => {
    expect(wrapper.find(LicenceTemplatesListItem).length).toBeFalsy();
  });

  const testWrapper = mount(<LicenceTemplatesList
    onEditClick={() => undefined}
    licenceTemplates={[{
      licenceTemplateId: 7,
      ielcopyright: null,
      clearanceStatusId: null,
      contractStartDate: '2015-01-01T00:00:00+11:00',
      contractEndDate: '2020-12-10T00:00:00+11:00',
      ppvavailable: false,
      agreementNumber: 'JM TEST AGREEMENT NUMBER',
      embargoPeriod: null,
      price: 0.0,
      royaltiesDue: null,
      clearedById: null,
      royaltyRate: null,
      archiveRoyaltyRate: null,
      noticePeriod: null,
      archivalPeriod: null,
      terminationNote: 'JM Test Management Note',
      individualSubscriptions: false,
      cclicenceTypeId: 1,
      accessRightId: 4,
      accessTypeId: null,
      perpetualAccess: false,
    }, {
      licenceTemplateId: 4,
      ielcopyright: null,
      clearanceStatusId: null,
      contractStartDate: '2015-01-01T00:00:00+11:00',
      contractEndDate: '2020-12-10T00:00:00+11:00',
      ppvavailable: false,
      agreementNumber: 'JM TEST AGREEMENT NUMBER',
      embargoPeriod: null,
      price: 0.0,
      royaltiesDue: null,
      clearedById: null,
      royaltyRate: null,
      archiveRoyaltyRate: null,
      noticePeriod: null,
      archivalPeriod: null,
      terminationNote: 'JM Test Management Note',
      individualSubscriptions: false,
      cclicenceTypeId: 1,
      accessRightId: 4,
      accessTypeId: null,
      perpetualAccess: false,
    }]}
    referenceData={{
      ccLicenceType: [],
      clearedBy: [],
      clearanceStatus: [],
      accessRight: [],
      accessType: [],
      contactRoleType: [],
    }}
    templateIdToEdit={0}
    handleCloseDialog={() => undefined}
    onLicenceTemplateChangeHandler={() => undefined}
  />);

  it('should show the correct number of licences', () => {
    expect(testWrapper.find(LicenceTemplatesListItem).length).toBe(2);
  });
});
