import {
  Record, Static, String, Null,
} from 'runtypes';
import { SearchResultValidator } from './SearchResult';
import { NonEmptyString } from '../../runtypeTypes';

export const OrganisationSearchResultValidator = Record({
  name: NonEmptyString,
  code: String.Or(Null),
  numberOfTitles: String.Or(Null),
  address: String.Or(Null),
  primaryContact: NonEmptyString.Or(Null),
}).And(SearchResultValidator);

type OrganisationSearchResult = Static<typeof OrganisationSearchResultValidator>;

export default OrganisationSearchResult;
