import React from 'react';
import { makeStyles, createStyles } from '@material-ui/core';
import classnames from 'classnames';

interface Props {
  front: JSX.Element;
  back: JSX.Element;
}

const useStyles = makeStyles(() => createStyles({
  root: {
    '&:hover': {
      '& $front': {
        visibility: 'hidden',
        transform: 'scaleX(-1)',
        opacity: 0,
      },
      '& $back': {
        visibility: 'visible',
        transform: 'scaleX(-1)',
        opacity: 1,
      },
    },
    position: 'relative',
  },
  front: {
    visibility: 'visible',
    opacity: 1,
  },
  back: {
    visibility: 'hidden',
    opacity: 0,
  },
  item: {
    position: 'absolute',
    top: -8,
    left: -8,
    transition: 'all 0.3s',
    background: 'white',
  },
}));

const Flipper = (props: Props) => {
  const classes = useStyles();
  return (
    <span className={classes.root}>
      <span className={classnames(classes.item, classes.front)}>
        {props.front}
      </span>
      <span className={classnames(classes.item, classes.back)}>
        {props.back}
      </span>
    </span>

  );
};

export default Flipper;
