import React from 'react';
import {
  Typography, makeStyles, Theme, createStyles, Paper,
} from '@material-ui/core';
import { useSnackbar } from 'notistack';
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';
import SmallChip from '../molecules/SmallChip';

const useStyles = makeStyles((theme: Theme) => createStyles({
  paperRoot: {
    padding: theme.spacing(4),
  },
  errorChip: {
    color: theme.palette.secondary.main,
    background: '#ffcccc',
  },
  errorMessage: {
    display: 'inline-block',
    paddingLeft: theme.spacing(2),
  },
  errorIcon: {
    verticalAlign: 'top',
    display: 'inline-block',
  },
}));

interface RuntypeErrorProps {
  error?: Error;
  data?: Record<string, unknown>;
};

const RuntypeError = (props: RuntypeErrorProps) => {
  const classes = useStyles();

  const { enqueueSnackbar } = useSnackbar();

  const onClickHandler = (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    e.preventDefault();
    e.stopPropagation();
    const payload = {
      url: window.location.href,
      error: props?.error?.message,
      data: props.data,
    };
    const text = JSON.stringify(payload);
    const textField = document.createElement('textarea');
    if (text !== undefined) {
      textField.innerText = text;
    }
    document.body.appendChild(textField);
    textField.select();
    document.execCommand('copy');
    textField.remove();

    enqueueSnackbar('Copied error data to clipboard.', { variant: 'info' });
  };

  return (
    <div className={classes.errorMessage}>
      <Typography>
        There was an error reading the response. Please contact a system administrator.
      </Typography>
      {props.data !== undefined && (

      <SmallChip
        variant="outlined"
        size="medium"
        className={classes.errorChip}
        label="Click here to copy error information"
        onClick={onClickHandler}
      />
      )}
    </div>
  );
};

const RuntypeErrorPaper: React.FC<RuntypeErrorProps> = (props: RuntypeErrorProps) => {
  const classes = useStyles();
  return (
    <Paper className={classes.paperRoot}>
      <ErrorOutlineIcon color="error" className={classes.errorIcon} />
      <RuntypeError
        error={props.error}
        data={props.data}
      />
    </Paper>
  );
};

export default RuntypeErrorPaper;
