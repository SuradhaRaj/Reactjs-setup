import {
  Record, Static, Boolean, Number, String,
} from 'runtypes';

export const ArtifactErrorCodeValidator = Record({
  errorID: Number,
  name: String,
  isRecoverable: Boolean,
});

type ArtifactErrorCode = Static<typeof ArtifactErrorCodeValidator>;
export default ArtifactErrorCode;
