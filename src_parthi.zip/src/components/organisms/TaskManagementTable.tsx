import React from 'react';
import {
  makeStyles, createStyles, useTheme, Theme,
} from '@material-ui/core/styles';
import { IconButton, Tooltip } from '@material-ui/core';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import TablePagination from '@material-ui/core/TablePagination';
import { useHistory } from 'react-router-dom';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import LockIcon from '@material-ui/icons/Lock';

import { DateTime } from 'luxon';
import LocalOfferOutlinedIcon from '@material-ui/icons/LocalOfferOutlined';
import { KeyboardArrowLeft, KeyboardArrowRight } from '@material-ui/icons';
import LastPageIcon from '@material-ui/icons/LastPage';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import { TablePaginationActionsProps } from '@material-ui/core/TablePagination/TablePaginationActions';
import TaskManagementTask from '../../interfaces/TaskManagementTask';
import { useSort } from '../../utils/TableSortHelper';
import EnhanceTaskTableHead, { HeadCell } from '../molecules/EnhancedTableHead';
import CopyableTooltip from '../molecules/CopyableTooltipIconButton';
import DenseFixedLayoutTable from './DenseFixedLayoutTable';
import SmallChip from '../molecules/SmallChip';

const useStyles = makeStyles(createStyles({
  row: {
    '&:hover': {
      '& $recordNumberIcon': {
        visibility: 'visible',
      },
    },
  },
  selectableCell: {
    cursor: 'pointer',
    padding: 5,
    textAlign: 'center',
    transition: 'all 0.2s',
  },
  emptyRowTd: {
    textAlign: 'center',
  },
  indexerColumn: { width: 40 },
  recordNumberColumn: { width: 40 },
  broadcastColumn: { width: 130 },
  channelColumn: { width: 150 },
  navigationColumn: { width: 100 },
  statusColumn: {
    width: 200,
    cursor: 'pointer',
  },
  recordNumberIcon: {
    visibility: 'hidden',
  },
  pagination: {
    float: 'left',
    width: 'max-content',
  },
}));
const useStyles1 = makeStyles((theme: Theme) => createStyles({
  root: {
    flexShrink: 0,
    marginLeft: theme.spacing(2.5),
  },
}));

function TablePaginationActions(props: TablePaginationActionsProps) {
  const classes = useStyles1();
  const theme = useTheme();
  const {
    count, page, rowsPerPage, onChangePage,
  } = props;

  const handleFirstPageButtonClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    onChangePage(event, 0);
  };

  const handleBackButtonClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    onChangePage(event, page - 1);
  };

  const handleNextButtonClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    onChangePage(event, page + 1);
  };

  const handleLastPageButtonClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    onChangePage(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
  };

  return (
    <div className={classes.root}>
      <IconButton
        onClick={handleFirstPageButtonClick}
        disabled={page === 0}
        aria-label="first page"
      >
        {theme.direction === 'rtl' ? <LastPageIcon /> : <FirstPageIcon />}
      </IconButton>
      <IconButton onClick={handleBackButtonClick} disabled={page === 0} aria-label="previous page">
        {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
      </IconButton>
      <IconButton
        onClick={handleNextButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="next page"
      >
        {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
      </IconButton>
      <IconButton
        onClick={handleLastPageButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="last page"
      >
        {theme.direction === 'rtl' ? <FirstPageIcon /> : <LastPageIcon />}
      </IconButton>
    </div>
  );
}
const NavCell: React.FC<{ row: TaskManagementTask }> = ({ row }) => {
  const classes = useStyles();
  const history = useHistory();
  const navigateToIndexerUi = (artifactId: number): void => {
    history.push(`/artifact/${artifactId}`);
  };

  return (
    <>
      {row.workflowState && (
        <TableCell align="right" onClick={() => navigateToIndexerUi(row.artifactId)} className={classes.statusColumn}><SmallChip variant="outlined" size="medium" label={row.workflowState.toUpperCase()} /></TableCell>
      )}
      {!row.workflowState && (
        <TableCell align="right" />
      )}
      <TableCell className={classes.selectableCell} onClick={() => navigateToIndexerUi(row.artifactId)}>
        <ChevronRightIcon />
      </TableCell>
    </>
  );
};

export const Row: React.FC<{ row: TaskManagementTask }> = ({ row }) => {
  const classes = useStyles();

  return (
    <TableRow key={row.rmitNumber} hover className={classes.row}>
      <TableCell align="center" className={classes.indexerColumn}>
        {row.indexer && (
          <Tooltip title={row.indexer}><LockIcon fontSize="small" /></Tooltip>
        )}
      </TableCell>
      <TableCell className={classes.recordNumberColumn}>
        <div className={classes.recordNumberIcon}>
          <CopyableTooltip title={row.rmitNumber}><LocalOfferOutlinedIcon fontSize="small" /></CopyableTooltip>
        </div>
      </TableCell>
      <TableCell className={classes.channelColumn}>{row.channel}</TableCell>
      <TableCell>{row.programTitle}</TableCell>
      <TableCell>
        {row.itemTitle}
      </TableCell>
      <TableCell align="right" className={classes.broadcastColumn}>{DateTime.fromISO(row.broadcastDate).toFormat('d LLL yyyy')}</TableCell>
      <NavCell row={row} />
    </TableRow>
  );
};

export const EmptyTableRow: React.FC = () => {
  const classes = useStyles();

  return (
    <TableRow className={classes.row}>
      <TableCell className={classes.emptyRowTd} colSpan={10}>There are no tasks available to complete.</TableCell>
    </TableRow>
  );
};

const TaskManagementTable: React.FC<{ data: Array<TaskManagementTask> }> = ({ data }) => {
  const classes = useStyles();

  const {
    handleRequestSort, order, orderBy, orderedData,
  } = useSort<TaskManagementTask>(data);
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(100);
  const handleChangePage = (event: React.MouseEvent<HTMLButtonElement> | null, newPage: number) => {
    setPage(newPage);
  };
  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  const headCells: HeadCell[] = [
    {
      id: 'isLocked', rightAlign: false, label: '', className: classes.indexerColumn,
    },
    {
      id: 'rmitNumber', rightAlign: false, label: '', className: classes.recordNumberColumn,
    },
    {
      id: 'channel', rightAlign: false, label: 'Channel', className: classes.channelColumn,
    },
    { id: 'programTitle', rightAlign: false, label: 'Program' },
    { id: 'itemTitle', rightAlign: false, label: 'Title' },
    {
      id: 'broadcastDate', rightAlign: true, label: 'Broadcast', className: classes.broadcastColumn,
    },
    {
      id: 'workflowState', rightAlign: true, label: 'Status', className: classes.statusColumn,
    },
    {
      id: 'navigationColumn', label: '', className: classes.navigationColumn, canSort: false,
    },
  ];

  return (

    <DenseFixedLayoutTable>
      <EnhanceTaskTableHead
        order={order}
        orderBy={orderBy}
        onRequestSort={handleRequestSort}
        headCells={headCells}
      />
      <TableBody>
        {

                  ((orderedData.length < (page * rowsPerPage))
                    ? orderedData.slice(0 * rowsPerPage, 0 * rowsPerPage + rowsPerPage).map((row) => (<Row key={row.rmitNumber} row={row} />))
                    : orderedData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => (<Row key={row.rmitNumber} row={row} />)))
              }
      </TableBody>
      <div className={classes.pagination}>
        <TablePagination
          ActionsComponent={TablePaginationActions}
          rowsPerPageOptions={[25, 50, 100, 500, 1000]}
          count={orderedData.length}
          page={orderedData.length < (page * rowsPerPage) ? 0 : page}
          onChangePage={handleChangePage}
          onChangeRowsPerPage={handleChangeRowsPerPage}
          rowsPerPage={rowsPerPage}
        />
      </div>
    </DenseFixedLayoutTable>
  );
};

export default TaskManagementTable;
