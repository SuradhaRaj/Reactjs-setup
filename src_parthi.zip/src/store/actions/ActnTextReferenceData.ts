import TextReferenceData from '../../interfaces/TextIndexer/ReferenceData/TextReferenceData';

export const UPDATE_TEXT_REFERENCE_DATA = 'UPDATE_TEXT_REFERENCE_DATA';

interface UpdateTextReferenceDataAction {
  type: typeof UPDATE_TEXT_REFERENCE_DATA;
  payload: TextReferenceData;
}

export type ActionTypes = UpdateTextReferenceDataAction;

export function updateTextReferenceData(data: TextReferenceData): ActionTypes {
  return {
    type: UPDATE_TEXT_REFERENCE_DATA,
    payload: data,
  };
}
