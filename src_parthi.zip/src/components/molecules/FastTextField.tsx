import React from 'react';
import { BaseTextFieldProps, TextField } from '@material-ui/core';

type Props = Omit<BaseTextFieldProps, 'onChange'|'onBlur'> & {
  onUpdate(key: string, value: string): void;
  name: string;
  maxLength?: number;
}

const FastTextField = (props: Props) => {
  const [value, setValue] = React.useState<string>(props.defaultValue as string);

  const { onUpdate, ...rest } = props;

  const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const eventValue = e.target.value;
    setValue(eventValue);
  };
  const onBlur = () => {
    onUpdate(props.name, value);
  };
  const onInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (props.maxLength !== undefined) {
      e.target.value = Math.max(0, parseInt(e.target.value)).toString().slice(0, props.maxLength);
    }
  };

  return (
    <TextField
      {...rest}
      InputLabelProps={{
        shrink: true,
      }}
      variant="outlined"
      defaultValue={value}
      onChange={onChange}
      onBlur={onBlur}
      onInput={onInput}
    />
  );
};
export default FastTextField;
