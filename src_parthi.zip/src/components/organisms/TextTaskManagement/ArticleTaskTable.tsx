import React from 'react';

import {
  TableRow, TableCell, TableBody, Avatar, Tooltip, Button,
} from '@material-ui/core';
import { makeStyles, createStyles, Theme } from '@material-ui/core/styles';
import CheckIcon from '@material-ui/icons/Check';
import LocalOfferOutlinedIcon from '@material-ui/icons/LocalOfferOutlined';
import classnames from 'classnames';
import { useHistory } from 'react-router-dom';
import { DateTime } from 'luxon';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import EnhanceTaskTableHead, { HeadCell } from '../../molecules/EnhancedTableHead';

import SmallChipDialog from '../SmallChipDialog';
import { useSort } from '../../../utils/TableSortHelper';
import CopyableTooltip from '../../molecules/CopyableTooltipIconButton';
import TextTaskManagementArticleTask from '../../../interfaces/TaskManagementText/TextTaskManagementArticleTask';
import ArtifactLock from '../ArtifactLock';

const useStyles = makeStyles((theme: Theme) => createStyles({
  row: {
    '&:hover': {
      '& $recordNumberIcon': {
        visibility: 'visible',
      },
      '& $navigationIcon': {
        visibility: 'visible',
      },
    },
    // transition: 'all 0s !important',
  },
  selectableCell: {
    cursor: 'pointer',
    padding: 5,
    textAlign: 'center',
    transition: 'all 0.2s',
  },
  emptyRowTd: {
    textAlign: 'center',
  },
  initials: {
    backgroundColor: theme.palette.primary.light,
    width: 'fit-content',
    height: 22,
    fontSize: 14,
    padding: 3,
    minWidth: 30,
  },
  check: {
    color: theme.palette.success.main,
  },
  initialsColumn: {
    width: 90,
  },
  filesColumn: {
    width: 60,
  },
  actionColumn: {
    width: 50,
  },
  deliveredColumn: {
    width: 100,
  },
  recordNumberColumn: {
    width: 35,
  },
  indexerColumn: {
    width: 35,
  },
  indexingCompanyColumn: {
    width: 160,
  },
  navigationColumn: {
    width: 110,
  },
  notesColumn: {
    width: 100,
  },
  publishDateColumn: {
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
  },
  notesChip: {
    marginRight: theme.spacing(1),
  },
  recordNumberIcon: {
    visibility: 'hidden',
  },
  navigationIcon: {
    visibility: 'hidden',
  },
  unlockIcon: {
    cursor: 'pointer',
  },
  button: {
    borderRadius: 50,
    '& .MuiButton-label': {
      maxHeight: '15px',
    },
  },
}));

interface Props {
  canUnlock: boolean;
  onUpdate(row: TextTaskManagementArticleTask): void;
  row: TextTaskManagementArticleTask;
}

const getManagerInitials = (managerName: string): string => managerName.split(' ').map((s) => s[0]).toString().replace(',', '');

export const ArticleTaskRow: React.FC<Props> = ({ row, canUnlock, onUpdate }) => {
  const classes = useStyles();
  const history = useHistory();
  const onUnlocked = () => {
    onUpdate({
      ...row,
      indexer: '',
    });
  };

  return (
    <TableRow className={classes.row} hover key={row.rmitNumber}>
      <TableCell align="center" className={classes.indexerColumn}>
        {row.indexer && (
        <ArtifactLock
          artifactId={row.artifactId}
          canUnlock={canUnlock}
          indexer={row.indexer}
          title={row.title}
          onUnlocked={onUnlocked}
        />
        )}
      </TableCell>
      <TableCell className={classes.recordNumberColumn}>
        <div className={classes.recordNumberIcon}>
          <CopyableTooltip title={row.rmitNumber}><LocalOfferOutlinedIcon fontSize="small" /></CopyableTooltip>
        </div>
      </TableCell>
      <TableCell><Tooltip title={row.resourceId}><span>{row.resourceId}</span></Tooltip></TableCell>
      <TableCell><Tooltip title={row.articleTitle}><span>{row.articleTitle}</span></Tooltip></TableCell>
      <TableCell><Tooltip title={row.title}><span>{row.title}</span></Tooltip></TableCell>
      <TableCell><Tooltip title={row.grouping}><span>{row.grouping}</span></Tooltip></TableCell>
      <TableCell><Tooltip title={row.indexingCompany}><span>{row.indexingCompany}</span></Tooltip></TableCell>
      <TableCell><Tooltip title={row.publisher ?? ''}><span>{row.publisher}</span></Tooltip></TableCell>
      <TableCell><Tooltip title={row.dateOfPublication}><span>{row.dateOfPublication}</span></Tooltip></TableCell>
      <TableCell className={classes.deliveredColumn} align="center">{row.delivered ? (<Tooltip title={DateTime.fromISO(row.delivered).toFormat('d LLL yyyy')}><CheckIcon className={classes.check} /></Tooltip>) : (<></>)}</TableCell>
      <TableCell className={classes.initialsColumn}>
        <div style={{ display: 'flex', justifyContent: 'center' }}>
          <Tooltip title={row.manager}>
            <Avatar variant="rounded" className={classes.initials}>{getManagerInitials(row.manager)}</Avatar>
          </Tooltip>
        </div>
      </TableCell>
      <TableCell className={classes.notesColumn}>
        {row.indexerNotes !== null && row.indexerNotes.length > 0 && (
        <SmallChipDialog style={{ marginRight: 8 }} label="Indexer" dialogTitle="Indexer notes" dialogContent={row.indexerNotes} />
        )}
        {row.publisherNotes !== null && row.publisherNotes.length > 0 && (
        <SmallChipDialog label="Publisher" dialogTitle="Publisher notes" dialogContent={row.publisherNotes} />
        )}
      </TableCell>
      <TableCell
        className={classnames(classes.navigationColumn, classes.selectableCell)}
        onClick={() => history.push(`/artifact/${row.artifactId}`)}
      >
        {/* <ChevronRightIcon className={classes.navigationIcon} /> */}
        <Button
          size="small"
          color="primary"
          variant="outlined"
          onClick={() => undefined}
          endIcon={<ArrowForwardIcon />}
          className={classes.button}
        >
          Open
        </Button>
      </TableCell>
    </TableRow>
  );
};

interface TableProps {
  canUnlock: boolean;
  onUpdate(row: TextTaskManagementArticleTask): void;
  rows: TextTaskManagementArticleTask[];
}

const ArticleTaskTable: React.FC<TableProps> = ({ rows, canUnlock, onUpdate }) => {
  const classes = useStyles();

  const {
    handleRequestSort, order, orderBy, orderedData,
  } = useSort<TextTaskManagementArticleTask>(rows);

  const headCells: HeadCell[] = [
    {
      id: 'indexer', label: '', canSort: false, className: classes.indexerColumn,
    },
    {
      id: 'recordNumber', label: '', canSort: false, className: classes.recordNumberColumn,
    },
    { id: 'resourceId', label: 'Resource ID' },
    { id: 'articleName', label: 'Name' },
    { id: 'title', label: 'Title' },
    { id: 'grouping', label: 'Grouping' },
    { id: 'indexingCompany', label: 'Company' },
    { id: 'publisher', label: 'Publisher' },
    {
      id: 'publishDate', label: 'Publish Date', canSort: false, className: classes.publishDateColumn,
    },
    { id: 'delivered', label: 'Delivered', className: classes.deliveredColumn },
    {
      id: 'manager', label: 'Manager', className: classes.initialsColumn,
    },
    {
      id: 'notes', label: 'Notes', canSort: false, className: classes.notesColumn,
    },
    {
      id: 'navCell', label: 'View/Edit', canSort: false, className: classes.navigationColumn,
    },

  ];

  return (
    <>
      <EnhanceTaskTableHead
        order={order}
        orderBy={orderBy}
        onRequestSort={handleRequestSort}
        headCells={headCells}
      />
      <TableBody>
        {orderedData.length > 0 ? orderedData.map((row) => (
          <ArticleTaskRow row={row} key={row.rmitNumber} canUnlock={canUnlock} onUpdate={onUpdate} />
        ))
          : (<EmptyTableRow />)}

      </TableBody>
    </>
  );
};

export const EmptyTableRow: React.FC = () => {
  const classes = useStyles();

  return (
    <TableRow className={classes.row}>
      <TableCell className={classes.emptyRowTd} colSpan={10}>There are no tasks available to complete.</TableCell>
    </TableRow>
  );
};

export default ArticleTaskTable;
