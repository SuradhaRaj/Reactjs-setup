import React from 'react';
import {
  Paper, makeStyles, createStyles, Theme, Grid, Typography,
} from '@material-ui/core';
import { Link } from 'react-router-dom';
import Skeleton from '@material-ui/lab/Skeleton';
import { random } from 'lodash';
import TileListItem from '../../interfaces/Dashboard/TileListItem';
import SmallChip from './SmallChip';

interface DashboardTaskStatusTileProps {
  title: string;
  url: string;
  tileList: TileListItem[];
  isLoading: boolean;
}

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    minHeight: '100px',
    width: '100%',
    '&:hover': {
      transform: 'scale(1.10)',
    },
    transition: 'all 0.2s',
  },
  tileTitle: {
    textAlign: 'left',
    color: 'grey',
    padding: theme.spacing(2),
    textTransform: 'uppercase',
    letterSpacing: '1px',
  },
  titleSizing: {
    fontSize: '0.85rem',
  },
  tileData: {
    float: 'right',
    backgroundColor: '#EEEEFF',
    color: theme.palette.primary.dark,
  },
  dataColumn: {
    paddingRight: theme.spacing(2),
    paddingBottom: theme.spacing(2),
  },
  dataNameColumn: {
    paddingRight: theme.spacing(2),
    paddingBottom: theme.spacing(2),
  },
  dataColumnLoading: {
    paddingRight: theme.spacing(2),
    paddingBottom: theme.spacing(2),
    paddingLeft: theme.spacing(2),
  },
}));

const DashboardTile: React.FC<DashboardTaskStatusTileProps> = (props) => {
  const classes = useStyles();

  if (props.isLoading) {
    return (
      <>
        <Link to={props.url} style={{ textDecoration: 'none' }}>
          <Paper className={classes.root}>
            <Grid container>
              <Grid item xs={12} className={classes.tileTitle}>
                <Typography className={classes.titleSizing}>{props.title}</Typography>
              </Grid>
              {
                [...Array(2)].map(() => (
                  <>
                    <Grid item xs={3} className={classes.dataColumnLoading}>
                      <Skeleton animation="wave" />
                    </Grid>
                    <Grid item xs={9}>
                      <Skeleton animation="wave" width={random(100, 200)} />
                    </Grid>
                  </>
                ))
              }
            </Grid>
          </Paper>
        </Link>
      </>
    );
  }

  return (
    <>
      <Link to={props.url} style={{ textDecoration: 'none' }}>
        <Paper className={classes.root}>
          <Grid container xs={12}>
            <Grid item xs={12} className={classes.tileTitle}>
              <Typography className={classes.titleSizing}>{props.title}</Typography>
            </Grid>
          </Grid>
          {props.tileList.map((item) => (
            <Grid key={item.name} container xs={12}>
              <Grid item xs={3} className={classes.dataColumn}>
                <SmallChip
                  size="small"
                  label={item.value}
                  className={classes.tileData}
                />
              </Grid>
              <Grid item xs={9} className={classes.dataNameColumn}>
                <Typography variant="subtitle2">{item.name}</Typography>
              </Grid>
            </Grid>
          ))}
        </Paper>
      </Link>
    </>
  );
};

export default DashboardTile;
