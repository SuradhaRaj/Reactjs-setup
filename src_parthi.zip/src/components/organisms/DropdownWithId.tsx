import React from 'react';
import LookupOption from '../../interfaces/LookupOption';
import Dropdown, { DropdownProps } from '../Shared/Dropdown';

export interface DropdownWithIdProps extends Omit<DropdownProps, 'onChangeFunction'|'keyName'|'classes'> {
  valueKey: string;
  idKey: string;
  lookup: LookupOption[];
  onChangeHandler(key: string, value: string | number | null): void;
};

const DropdownWithId: React.SFC<DropdownWithIdProps> = (props) => {
  const onChangeHandler = (key: string, value: string) => {
    // first update the field holding the string value
    props.onChangeHandler(props.valueKey, value);
    // then update the field holding the id
    const lookupOption = props.lookup.find((option) => option.value === value);
    props.onChangeHandler(props.idKey, lookupOption?.key || null);
  };

  return (
    <Dropdown
      {...props}
      keyName={props.valueKey}
      onChangeFunction={onChangeHandler}
    />
  );
};

export default DropdownWithId;
