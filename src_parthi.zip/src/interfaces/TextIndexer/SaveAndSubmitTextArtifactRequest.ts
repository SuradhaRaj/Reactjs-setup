import TextArtifact from './TextArtifact';

export default interface SaveAndSubmitTextArtifactRequest {
  action: string;
  documentData: TextArtifact;
  validateArtifact: boolean;

// eslint-disable-next-line semi
}
