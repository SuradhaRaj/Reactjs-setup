import TaskManagementFilterHelper from '../../utils/TaskManagementFilterHelper';

describe('Task management filter helper - Get Values', () => {
  it('should return the list in order', () => {
    const values = ['Carrot', 'Banana', 'Apple'];
    const result = TaskManagementFilterHelper.GetValues(values);
    expect(result[0]).toBe('Apple');
    expect(result[1]).toBe('Banana');
    expect(result[2]).toBe('Carrot');
  });

  it('should return the list without duplicates', () => {
    const values = ['Carrot', 'Banana', 'Apple', 'Carrot'];
    const result = TaskManagementFilterHelper.GetValues(values);
    expect(result).toHaveLength(3);
  });

  it('should return the list without duplicates (with white space)', () => {
    const values = ['Carrot', 'Banana', 'Apple', ' Carrot', ' Carrot ', 'Carrot '];
    const result = TaskManagementFilterHelper.GetValues(values);
    expect(result).toHaveLength(3);
  });

  it('should return the list without duplicates (with mismatching case)', () => {
    const values = ['Carrot', 'Banana', 'Apple', ' CArrOt', ' carrOT ', 'CArRoT '];
    const result = TaskManagementFilterHelper.GetValues(values);
    expect(result).toHaveLength(3);
  });
});
