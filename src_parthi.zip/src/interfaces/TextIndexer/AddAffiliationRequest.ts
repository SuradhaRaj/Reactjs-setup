interface AddAffiliationRequest {
    affiliation: string;
    artifactArticleId: number;
    authorId: number;
};

export default AddAffiliationRequest;
