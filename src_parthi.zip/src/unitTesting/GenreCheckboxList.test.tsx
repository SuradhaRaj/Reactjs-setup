/* eslint-disable @typescript-eslint/no-empty-function */
import React from 'react';
import { mount } from 'enzyme';
import GenreCheckboxList from '../components/molecules/MediaIndexer/GenreCheckboxList';

const wrapper = mount(
  <GenreCheckboxList
    labelText="This is a test label"
    preSelectedOptions={[{
      id: 1, createdBy: 'Will', createdDate: '2019-01-01', name: 'Option1',
    }]}
    keyName=""
    onChangeFunction={() => {}}
    checkboxLimit={2}
    checkboxOptions={[
      { key: 1, value: 'Option1' },
      { key: 2, value: 'Option2' },
      { key: 3, value: 'Option3' },
    ]}
  />,
);

describe('GenreCheckboxList Tests', () => {
  it('should display label that is passed into props', () => {
    expect(
      wrapper.contains('This is a test label'),
    ).toBe(true);
  });

  it('should display all genre options', () => {
    expect(
      wrapper.containsAllMatchingElements([
        <span>Option1</span>,
        <span>Option2</span>,
        <span>Option3</span>,
      ]),
    ).toBe(true);
  });

  it('should display the given selected option as selected', () => {
    expect(
      wrapper.find('.Mui-checked').length > 0,
    ).toBe(true);
  });

  it('should display the remaining number of selections allowed', () => {
    expect(wrapper.find('[data-remaining]').text()).toBe('1');
  });
});
