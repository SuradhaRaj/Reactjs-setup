/*eslint-disable*/
import MediaArtifact from './MediaArtifact';

export default interface SaveAndSubmitMediaArtifactRequest {
    action: string;
    
    documentData: MediaArtifact;
    validateArtifact: boolean;
}