/* eslint-disable max-len */
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable no-unused-expressions */
/* eslint-disable @typescript-eslint/no-explicit-any */
import Axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Delete } from '@material-ui/icons';
import {
  Button,
} from '@material-ui/core';
import { useDispatch } from 'react-redux';
import { initializeApp } from 'firebase/app';

import {
  getMessaging, getToken, onMessage, MessagePayload,
} from 'firebase/messaging';
import { useTypedSelector } from '../../store/store';
import XNotify from '../../x-notify';
import { addNotification, removeNotification } from '../../store/actions/ActnNotification';
import NotificationDrawer from '../organisms/NotficationDrawer';
import EventHelper from '../../utils/EventHelper';

// eslint-disable-next-line @typescript-eslint/no-explicit-any

// eslint-disable-next-line @typescript-eslint/no-explicit-any
// declare let Notif: any;
export default () => {
  const FirebaseConfigApiKey = useTypedSelector((store) => store.ClientConfiguration.ClientConfiguration.data.firebaseConfigApiKey);
  const FirebaseConfigAppId = useTypedSelector((store) => store.ClientConfiguration.ClientConfiguration.data.firebaseConfigAppId);
  const FirebaseConfigAuthDomain = useTypedSelector((store) => store.ClientConfiguration.ClientConfiguration.data.firebaseConfigAuthDomain);
  const FirebaseConfigMeasurementId = useTypedSelector((store) => store.ClientConfiguration.ClientConfiguration.data.firebaseConfigMeasurementId);
  // eslint-disable-next-line max-len
  const FirebaseConfigMessagingSenderId = useTypedSelector((store) => store.ClientConfiguration.ClientConfiguration.data.firebaseConfigMessagingSenderId);
  const FirebaseConfigProjectId = useTypedSelector((store) => store.ClientConfiguration.ClientConfiguration.data.firebaseConfigProjectId);
  const FirebaseConfigStorageBucket = useTypedSelector((store) => store.ClientConfiguration.ClientConfiguration.data.firebaseConfigStorageBucket);
  const Notif = new XNotify();
  const dispatch = useDispatch();
  const [refresh, SetRefresh] = useState<boolean>(false);
  const notifObj = useTypedSelector((store) => store.Notification.Notification.data);

  useEffect(() => {
    const firebaseConfig = {
      apiKey: FirebaseConfigApiKey,
      authDomain: FirebaseConfigAuthDomain,
      projectId: FirebaseConfigProjectId,
      storageBucket: FirebaseConfigStorageBucket,
      messagingSenderId: FirebaseConfigMessagingSenderId,
      appId: FirebaseConfigAppId,
      measurementId: FirebaseConfigMeasurementId,
    };

    const enableForegroundNotification = true;

    const app = initializeApp(firebaseConfig);
    const messaging = getMessaging(app);

    const entityTypeEventList: { [key: string]: {eventName: string}} = {
      'Artifact Updated': { eventName: 'update-media-artifact' },
      'Issue Updated': { eventName: 'update-issue' },
    };
    if (enableForegroundNotification) {
      // console.log(enableForegroundNotification);
      // const notification = payload.notification;
      navigator.serviceWorker.register(`/js/firebase-messaging-sw.js?${new URLSearchParams(firebaseConfig).toString()}`, { scope: '/js/', updateViaCache: 'all' })
        .then((registration) => {
          // console.log('Registration successful, scope is:', registration.scope);
          // getToken(messaging, { vapidKey: 'BAXru1DI4nZviolAAqBtlve7sKAdcRrp7l5c_IqKF-GgYaYQusDx_i_PGtWlXhw92_AdXQF6lQG0rki6t8kDrqM', serviceWorkerRegistration: registration} )
          getToken(messaging, { serviceWorkerRegistration: registration })
            .then((currentToken) => {
              // MsgElem.innerHTML = 'Notification permission granted.';
              if (currentToken) {
                // Notif.info({
                //  title: 'Info',
                //  description: 'Notification permission granted.',
                //  duration: 4000,
                // });

                console.info('currentToken:', currentToken);
              } else {
                console.error('No registration token available. Request permission to generate one.');
              }

              onMessage(messaging, (payload?: MessagePayload) => {
                const notifBodyString = payload !== undefined && payload.notification !== undefined && payload.notification.body !== undefined ? payload.notification.body : '';
                const notifBody = JSON.parse(notifBodyString);

                //  console.log('payload', payload);
                // console.log('EntityType:', notifBody.EntityType);
                // console.log('entityTypeEventList[notifBody.EntityType]:', entityTypeEventList[notifBody.EntityType]);
                if (entityTypeEventList[notifBody.EntityType] !== undefined) {
                  console.info('trigger event:',
                    entityTypeEventList[notifBody.EntityType].eventName);
                  // console.log('event detail:', notifBody);
                  EventHelper.trigger(entityTypeEventList[notifBody.EntityType].eventName, notifBody);
                }

                // if (notifBody.EntityType === "Artifact Updated") {
                //    EventHelper.trigger("update-media-artifact",
                //        notifBody
                //    )
                //    console.log("trigger update-media-artifact");

                // }
                // if (notifBody.EntityType === "Issue Updated") {
                //    EventHelper.trigger("update-issue",
                //        notifBody
                //    )

                // }
                //
                // NotisElem.innerHTML += JSON.stringify(notifBody);

                // Notif.info({
                //  title: notifBody.Message,
                //  description: notifBody.Message,
                //  duration: 4000,
                // });

                const newNotifyList = [notifBody];

                //  console.log(newNotifyList);
                dispatch(addNotification({ data: newNotifyList }));
                let newRefresh = refresh;
                newRefresh = true;
                SetRefresh(newRefresh);
                // setTimeout(() => { window.location.replace(`/issues/${notifBody.EntityId}`); }, 5000);
              });
              // console.log(messaging);
              return currentToken;
              // get the token in the form of promise
              //        return messaging.getToken();
            })
            .then((token: any) => {
              // TokenElem.innerHTML = `Device token is : <br>${token}`;
              // console.log('token:', token);
              Axios.post(`${process.env.REACT_APP_API_URL}/api/user`, { DeviceToken: token }).then(() => undefined).catch(() => undefined);
              // Notif.info({
              //   title: 'Info',
              //   description: `Device token is : <br>${token}`,
              //   duration: 4000,
              // });
            })
            .catch((err: any) => {
              // ErrElem.innerHTML = `${ErrElem.innerHTML}; ${err}`;
              Notif.error({
                title: 'Notification Error',
                description: `'Unable to show notifications. ${err}'`,
                duration: 5000,
              });
              console.info('get Token err:', err);
            });

          // registration.showNotification("register is done");
        }).catch((err) => {
          console.info('Service worker registration failed, error:', err);
        });
    }
    // firebase.initializeApp(firebaseConfig);
    // const messaging = firebase.messaging();
  }, [FirebaseConfigApiKey]);
  return (
    <>
      <div id="token" />
      <div id="msg" />
      <div id="notis" />
      <div id="err" />

      <NotificationDrawer
        messageCount={notifObj.length}
        content={(
          <>
            {/* <Grid item xs={1}> */}

            <ul>
              {(refresh && (notifObj.length > 0)) ? (
                <>
                  {notifObj.map((x) => ((x as any).NotificationType === 2) && (

                  <li>
                    <Button
                      onClick={() => {
                        const remNotifyList = [x];
                        dispatch(removeNotification({ data: remNotifyList }));
                      }}
                      aria-label="delete"
                    >
                      <Delete />
                    </Button>
                    <span>{`${(x as any).Message}`}</span>
                    {' '}
                    <span>
                      {' '}
                      {(x as any).EntityType.startsWith('Issue') && (
                      <a href={`/issues/${(x as any).EntityId}`}>
                        {(x as any).EntityId}
                      </a>

                      )}
                    </span>
                    <span>
                      {' '}
                      {(x as any).EntityType.startsWith('Artifact') && (
                      <a href={`/artifact/${(x as any).EntityId}`}>
                        {(x as any).EntityId}
                      </a>

                      )}
                    </span>
                  </li>

                  ))}
                </>
              ) : (<></>)}

            </ul>
          </>
)}
      />

    </>
  );
};
