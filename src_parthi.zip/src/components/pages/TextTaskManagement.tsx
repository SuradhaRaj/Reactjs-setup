import React, {
  useState, useEffect, useContext, createRef,
} from 'react';
import Grid from '@material-ui/core/Grid';

import { values } from 'lodash';
import {
  makeStyles, createStyles, Theme, Paper, Typography, Hidden, CircularProgress, Drawer, Button, AppBar, Toolbar, IconButton,
} from '@material-ui/core';
import CheckIcon from '@material-ui/icons/Check';
// import { useDispatch } from 'react-redux';
import FilterListIcon from '@material-ui/icons/FilterList';
import Axios, { AxiosResponse } from 'axios';
// import ExpansionPanelForTable from '../organisms/ExpansionPanelForTable';

import { ExportToCsv } from 'export-to-csv';

import RemoveIcon from '@material-ui/icons/Remove';
import SettingsBackupRestoreIcon from '@material-ui/icons/SettingsBackupRestore';
import ArrowLeftIcon from '@material-ui/icons/KeyboardArrowLeft';
import ArrowRightIcon from '@material-ui/icons/KeyboardArrowRight';
import LoadingExpansionPanel from '../molecules/LoadingExpansionPanel';
import Filters, { SelectedOptionState } from '../organisms/TextTaskManagement/SimpleFilters';
// import { updateTaskManagementList } from '../../store/actions/ActnTextTaskManagement';
// import { useTypedSelector } from '../../store/store';
import ErrorPaper from '../organisms/ErrorPaper';
import TextTaskManagementTasks, { TextTaskManagementTasksValidator } from '../../interfaces/TaskManagementText/TextTaskManagementTasks';
import { AppContext } from '../Context';
// import {  TextWorkflowOrder, WorkflowStatusDisplayNames} from '../../interfaces/enums/WorkflowStatus';
import useRuntypeError from '../hooks/useRuntypeError';
import TextTaskManagementArtifactTask from '../../interfaces/TaskManagementText/TextTaskManagementArtifactTask';
import ArtifactTextTaskTable from '../organisms/TextTaskManagement/ArtifactTextTaskTable';
import { isKeyValue } from '../../interfaces/TaskManagementText/TextTaskManagementRequest';
import DenseFixedLayoutTable from '../organisms/DenseFixedLayoutTable';
import { DateFromToField } from '../organisms/TextTaskManagement/DateFromToField';
import { saveStorageZoomPercent, getStorageZoomPercent } from '../../utils/LocalStorage';
import { UserContext } from '../Layout';

const csvoptions = {
  fieldSeparator: ',',
  quoteStrings: '"',
  decimalSeparator: '.',
  showLabels: true,
  showTitle: true,
  filename: 'Exported_CSV',
  useTextFile: false,
  useBom: true,
  useKeysAsHeaders: true,
};

interface QueryTextTask {
    IncludeRelated: boolean;
    Groupings: string[];
    WorkflowStatusIds: number[];
    ResourceManagers: number[];
    Publishers: string[];
    Titles: string[];
    currentPage: number;
    pageSize: number;
    priority: number[];
    exportCSV: boolean;
}
interface Pager {
    totalItems: number;
    currentPage: number;
    pageSize: number;
    totalPages: number;
    startPage: number;
    endPage: number;
    startIndex: number;
    endIndex: number;
    pages: number[];
}

interface State {
    isError: boolean;
    isLoading: boolean;
    filterDrawerOpen: boolean;
    isUpdating: boolean;
    isFiltered: boolean;
    filterSelected?: SelectedOptionState;
    pageSize: number;
    zoom: number;
    // isApplyFilter: boolean;
}

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    paddingLeft: theme.spacing(2),
    paddingRight: theme.spacing(2),
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
  },
  container: {
    marginBottom: theme.spacing(2),
  },
  noTasks: {
    padding: theme.spacing(4),
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkIcon: {
    display: 'inline',
    color: theme.palette.success.main,
    marginRight: theme.spacing(1),
  },
  loadingContainer: {
    flexDirection: 'column',
  },
  updatingSpinner: {
    position: 'absolute',
    top: -36,
    right: 12,
    display: 'flex',
    alignItems: 'center',
  },
  filterButton: {
    position: 'absolute',
    top: -36,
    left: 12,
  },
  paper: {
    position: 'sticky',
    top: theme.spacing(2),
  },
  filterIcon: {
    marginLeft: theme.spacing(1),
  },
  hiddenTasksPaper: {
    padding: theme.spacing(2),
    textAlign: 'center',
  },
  changeFilterText: {
    fontWeight: 600,
    marginTop: theme.spacing(1),
  },
  appBar: {
    top: 'auto',
    bottom: 0,
  },
  grow: {
    flexGrow: 1,
  },
  pagination: {
    backgroundColor: '#fefefe',
    borderRadius: '10px',
  },

}));

export default () => {
  const [state, setState] = useState<State>({
    filterDrawerOpen: false,
    isError: false,
    isLoading: true,
    isUpdating: true,
    isFiltered: false,
    pageSize: 100,
    zoom: getStorageZoomPercent(),
  });
  const [pager, setPager] = useState<Pager>({
    totalItems: 0,
    currentPage: 0,
    pageSize: 0,
    totalPages: 0,
    startPage: 0,
    endPage: 0,
    startIndex: 0,
    endIndex: 0,
    pages: [],
  });

  const context = useContext(AppContext);
  const [tasks, setTasks] = useState<TextTaskManagementTasks>([]);
  const [hasTasks, setHasTasks] = useState<boolean>(false);
  const taskManagementValidator = useRuntypeError(TextTaskManagementTasksValidator);
  const classes = useStyles();

  const isAdmin = context.userInfo.isInAnyRole(['InformitAdmin', 'IndexersAdmin']);
  const canUnlock = isAdmin;

  // const isAdmin = false;
  const ref = createRef<HTMLDivElement>();

  function zoom(zoomPercent: number) {
    if (ref !== null && ref.current !== null) {
      ref.current.style.zoom = `${zoomPercent}%`;

      setState((prestate) => ({
        ...prestate,
        zoom: zoomPercent,
      }));
    }
  }

  function zoomIn() {
    const zoomPercent = state.zoom - 5;
    zoom(zoomPercent);
    saveStorageZoomPercent(zoomPercent);
  }

  function zoomRest() {
    const zoomPercent = 100;
    zoom(zoomPercent);
    saveStorageZoomPercent(zoomPercent);
  }

  function scroll(move: number) {
    if (ref !== null && ref.current !== null) {
      const scrollbar = ref.current?.scrollLeft;
      ref.current.scrollLeft = scrollbar + move;
    }
  }

  // @ts-ignore
  const { navstate, setNavState } = useContext(UserContext);
  useEffect(() => {
    setNavState({ type: 'TEXT_TILE', payload: true });
  }, []);

  useEffect(() => {
    setState((prevState) => ({
      ...prevState,
      isLoading: true,
      isUpdating: true,
    }));
    /* console.log(process.env.REACT_APP_API_URL); */

    Axios.get(`${process.env.REACT_APP_API_URL}/api/taskmanagement/text`)
      .then((response: AxiosResponse<{ data: TextTaskManagementTasks; pager: Pager }>) => {
        setState((prevState) => ({
          ...prevState,
          isLoading: false,
          isError: false,
          isUpdating: false,
        }));

        const records = response.data.data;
        const pager1 = response.data.pager;
        setPager(pager1);
        setTasks(records);
        setHasTasks(true);
      })
      .catch(() => {
        setState((prevState) => ({
          ...prevState,
          isError: true,
        }));
      }).finally(() => {
        setState((prevState) => ({
          ...prevState,
          isLoading: false,
          isUpdating: false,
        }));
      });
  }, []);

  const processRequestQuery = (queryObject: SelectedOptionState | undefined, page?: number, numPerPage?: number) => {
    // page = ;
    // numPerPage = ;
    const queryRequest: SelectedOptionState & { page: number; pageSize: number; exportCSV: boolean } = {
      status: [],
      grouping: [],
      title: [],
      publisher: [],
      manager: [],
      organisation: [],
      contentType: [],
      issn: [],
      isbn: [],
      documentNumber: [],
      resource: [],
      dates: [],
      datesLog: [],
      priority: [],
      indexingCompany: [],

      hasIndexerNotes: undefined,
      hasPublisherNotes: undefined,
      includeRelated: undefined,
      page: page ?? 1,
      pageSize: numPerPage ?? state.pageSize,

      exportCSV: false,
    };
    if (queryObject !== null && queryObject !== undefined) {
      Object.keys(queryObject).forEach((x) => {
        // @ts-ignore
        queryRequest[x] = Array.isArray(queryObject[x])
        // @ts-ignore
          ? queryObject[x].map((item) => (isKeyValue(item) ? { key: item.id, value: item.value } : item))
        // @ts-ignore
          : queryObject[x];
      });
    }
    ['dates', 'datesLog'].forEach((dategroup) => {
      // @ts-ignore
      queryRequest[dategroup] = queryRequest[dategroup].map((x: DateFromToField) => {
        const datefield = { ...x } as DateFromToField;
        datefield.from = datefield.from !== '' ? new Date(datefield.from as string) : null;
        datefield.to = datefield.to !== '' ? new Date(datefield.to as string) : null;

        return datefield;
      })
      // @ts-ignore
        .filter((x) => x.from !== null && x.to !== null);
    });

    return queryRequest;
  };

  function requestFilter(queryObject?: SelectedOptionState, page?: number, numPerPage?: number) {
    // console.log(queryObject);
    setState((prevState) => ({
      ...prevState,
      isLoading: true,
      isUpdating: true,

    }));

    const queryRequest = processRequestQuery(queryObject, page, numPerPage);

    // console.log(queryRequest);

    Axios.post(`${process.env.REACT_APP_API_URL}/api/taskmanagement/text`, queryRequest)
      .then((response: AxiosResponse<{ data: TextTaskManagementTasks; pager: Pager }>) => {
        const records = response.data.data;
        const pager1 = response.data.pager;
        setPager(pager1);
        setTasks(records);
        setHasTasks(true);
      })
      .catch(() => {
        setState((prevState) => ({
          ...prevState,
          isError: true,
        }));
      }).finally(() => {
        setState((prevState) => ({
          ...prevState,
          isLoading: false,
          isUpdating: false,
        }));
      });
  }

  const toggleDrawer = () => {
    setState((prevState) => ({
      ...prevState,
      filterDrawerOpen: !prevState.filterDrawerOpen,
    }));
  };

  const updateArtifactRow = (row: TextTaskManagementArtifactTask) => {
    const index = tasks.findIndex((x) => x.artifactId === row.artifactId);
    const newTasks = [...tasks];
    newTasks.splice(index, 1, row);

    setTasks({ ...newTasks });
  };

  const checkFiltered = (queryObject: SelectedOptionState): boolean => {
    let isFiltered = false;
    if (queryObject !== null && queryObject !== undefined) {
      // @ts-ignore
      isFiltered = Object.keys(queryObject).reduce((sum, x) => (Array.isArray(x) && queryObject[x].length > 0) || sum, false);
    } else {
      isFiltered = true;
    }

    return isFiltered;
  };

  const applyFilter = (queryObject: SelectedOptionState) => {
    const isFileted = checkFiltered(queryObject);
    setState((prestate) => ({ ...prestate, filterSelected: queryObject, isFiltered: isFileted }));

    // console.log(queryObject);
    // console.log(state);
    requestFilter(queryObject, 1, state.pageSize);
  };
  const downloadCSV = (queryObject: SelectedOptionState) => {
    const isFileted = checkFiltered(queryObject);
    // queryObject.exportCSV = true;
    setState((prestate) => ({ ...prestate, filterSelected: queryObject, isFiltered: isFileted }));
    const queryRequest = processRequestQuery(queryObject, 1, state.pageSize);

    queryRequest.exportCSV = true;
    // console.log(queryRequest);

    Axios.post(`${process.env.REACT_APP_API_URL}/api/taskmanagement/text`, queryRequest)
      .then((response: AxiosResponse<{ data: TextTaskManagementTasks; pager: Pager }>) => {
        const records = response.data.data;

        setHasTasks(true);
        const csvExporter = new ExportToCsv(csvoptions);
        csvExporter.generateCsv(records);
      })
      .catch(() => {
        setState((prevState) => ({
          ...prevState,
          isError: true,
        }));
      });

    //  requestFilter(queryObject, 1, state.pageSize);
  };
  // function paginationHandleChange(event: React.ChangeEvent<unknown>, value: number) {
  //  setState({
  //    ...state,
  //    isLoading: true,
  //  });
  //  // console.log(state.filterSelected);
  //  requestFilter(state.filterSelected, value, state.pageSize);
  // }

  const taskList = values(tasks);

  const textTables: JSX.Element[] = [];
  textTables.push(
    <Grid container className={classes.container} data-issue-group>
      <Grid item xs={12}>
        <ArtifactTextTaskTable
          rows={taskList}
          canUnlock={canUnlock}
          onUpdate={updateArtifactRow}
          isAdmin={isAdmin}
        />
      </Grid>
    </Grid>,
  );

  if (state.isError) {
    return (<ErrorPaper text="Unable to load the list of tasks." />);
  }

  if (!taskManagementValidator.isValid) {
    return taskManagementValidator.error();
  }

  if (!hasTasks && !state.isFiltered && !state.isLoading) {
    return (
      <>
        <Grid container justify="center">
          <Grid item xs={3}>
            <Paper className={classes.noTasks}>
              <CheckIcon className={classes.checkIcon} />
              <Typography component="span">There are no tasks to complete!</Typography>
            </Paper>
          </Grid>
        </Grid>
      </>
    );
  }

  return (
    <>
      {(hasTasks || state.isFiltered || state.isLoading) && (
        <Grid container justify="center" spacing={2} className={classes.root}>
          <Hidden mdDown>
            <Grid item xs={12} lg={12} xl={12}>
              <Paper className={classes.paper}>
                <Filters isLoading={state.isLoading} onApplyFilter={applyFilter} onDownloadCSV={downloadCSV} isAdmin={isAdmin} />
              </Paper>
            </Grid>
          </Hidden>

          <Grid item xs={12} md={12} xl={12} style={{ position: 'relative' }}>

            {state.isLoading ? (<LoadingPanels />) : (
              <>
                <DenseFixedLayoutTable forwordRef={ref}>
                  {textTables}
                </DenseFixedLayoutTable>
              </>
            )}

            {state.isUpdating && (
            <div className={classes.updatingSpinner}>
              <CircularProgress size={20} />
              <Typography variant="overline" style={{ display: 'inline', marginLeft: 6 }}>Updating</Typography>
            </div>
            )}

            {state.isFiltered && (
            <Grid container justify="center">

              <Grid xs={8}>
                <Paper className={classes.hiddenTasksPaper}>
                  <Typography>
                    There are available tasks that are hidden by the filters.
                  </Typography>
                  <Typography className={classes.changeFilterText}>
                    Please change your filter selection.
                  </Typography>
                </Paper>
              </Grid>
              <Hidden mdDown>
                <Grid xs={2} />
              </Hidden>
            </Grid>
            )}

            <AppBar position="fixed" className={classes.appBar}>
              <Toolbar variant="dense">
                {state.isLoading ? ('') : (
                  <></>
                // <div className={classes.pagination}>
                //  <Pagination
                //    page={pager.currentPage}
                //    count={pager.totalPages}
                //    onChange={paginationHandleChange}
                //  />
                // </div>
                )}
                <div className={classes.grow} />
                Zoom(
                {getStorageZoomPercent()}
                %):
                <IconButton color="inherit" aria-label="zoom-out" onClick={zoomRest} size="medium">
                  <SettingsBackupRestoreIcon />
                </IconButton>
                <IconButton color="inherit" aria-label="zoom-in" onClick={zoomIn} size="medium">
                  <RemoveIcon />
                </IconButton>
                Scroll:
                <IconButton color="inherit" aria-label="scroll-left" onClick={() => scroll(-500)} size="medium">
                  <ArrowLeftIcon />
                </IconButton>
                <IconButton color="inherit" aria-label="scroll-right" onClick={() => scroll(500)} size="medium">
                  <ArrowRightIcon />
                </IconButton>
              </Toolbar>
            </AppBar>

            <Hidden lgUp>
              <Drawer open={state.filterDrawerOpen} onClose={() => toggleDrawer()}>
                <Filters isLoading={state.isLoading} onApplyFilter={applyFilter} onDownloadCSV={downloadCSV} isAdmin={isAdmin} />
              </Drawer>
              <Button className={classes.filterButton} variant="text" color="primary" onClick={() => toggleDrawer()}>
                Filter
                {' '}
                <FilterListIcon className={classes.filterIcon} />
              </Button>
            </Hidden>
          </Grid>
        </Grid>
      )}
    </>
  );
};

const LoadingPanels = () => {
  const classes = useStyles();
  return (
    <>
      {
                [...Array(3)].map(() => (
                  <Grid container justify="center">
                    <Grid item xs={12}>
                      <LoadingExpansionPanel className={classes.container} />
                    </Grid>
                  </Grid>
                ))
            }
    </>

  );
};
