import React from 'react';
import {
  ExpansionPanel,
  ExpansionPanelSummary,
  Grid,
  Box,
  Typography,
  makeStyles,
  Theme,
  createStyles,
  ExpansionPanelDetails,
  Fade,
  ExpansionPanelActions,
  Button,
  Paper,
} from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import PhoneIcon from '@material-ui/icons/Phone';
import EmailIcon from '@material-ui/icons/Email';
import HomeIcon from '@material-ui/icons/HomeWork';
import CellphoneIcon from '@material-ui/icons/PhoneAndroid';
import Axios from 'axios';
import { useSnackbar } from 'notistack';
import CopyableTooltipIconButton from '../../molecules/CopyableTooltipIconButton';
import SmallChip from '../../molecules/SmallChip';
import RuntypeError from '../RuntypeError';
import OrganisationContact, { OrganisationContactValidator } from '../../../interfaces/Organisation/OrganisationContact';
import CopyableTooltipIconWithContentText from '../CopyableTooltipIconWithContentText';
import ContactRolesDialog from '../ContactRolesDialog';
import UpdateOrganisationContactResponse, { UpdateOrganisationContactResponseValidator } from '../../../interfaces/Organisation/UpdateOrganisationContactResponse';
import UpdateOrganisationContactRequest from '../../../interfaces/Organisation/UpdateOrganisationContactRequest';
import LookupOption from '../../../interfaces/LookupOption';
import { hubSpotContactLink } from '../../../constants/HubSpotConstants';

const useStyles = makeStyles((theme: Theme) => createStyles({
  icon: {
    marginRight: theme.spacing(1),
  },
  readonlyContactDetails: {
    marginBottom: theme.spacing(2),
    marginRight: theme.spacing(4),
  },
  chip: {
    marginRight: theme.spacing(1),
  },
  iconContainer: {
    textAlign: 'right',
  },
  paper: {
    padding: theme.spacing(3),
    textAlign: 'center',
  },
}));

export const noContactsMessage = 'There are currently no contacts to view.';

interface ContactListItemProps {
  contact: OrganisationContact;
  organisationId: number;
  handleContactChange(newContact: OrganisationContact): void;
  contactRoleTypeLookup: LookupOption[];
  elevation?: number;
};

interface ContactListItemState {
  isExpanded: boolean;
  dialogOpen: boolean;
  loading: boolean;
};

export const ContactListItem: React.FC<ContactListItemProps> = (props) => {
  const classes = useStyles();
  const { enqueueSnackbar } = useSnackbar();

  const [state, setState] = React.useState<ContactListItemState>({
    isExpanded: false,
    dialogOpen: false,
    loading: false,
  });

  const getFullName = () => (
    [
      props.contact.title,
      props.contact.firstName,
      props.contact.surname,
    ].filter((s) => s).join(' ')
  );

  const getAddress = () => (
    [
      props.contact.address,
      props.contact.state,
      props.contact.suburb,
      props.contact.postcode,
      props.contact.country,
    ].filter((s) => s).join(', ')
  );

  const handlePanelStateChange = (event: React.ChangeEvent<{}>, isExpanded: boolean) => {
    setState((prevState) => ({
      ...prevState,
      isExpanded,
    }));
  };

  const openDialog = () => (setState((prevState) => ({ ...prevState, dialogOpen: true })));
  const closeDialog = () => (setState((prevState) => ({ ...prevState, dialogOpen: false })));

  const submitUpdateRoles = (roleIds: number[]) => {
    setState((prevState) => ({
      ...prevState,
      loading: true,
    }));

    const requestData: UpdateOrganisationContactRequest = {
      organisationId: props.organisationId,
      contactId: props.contact.contactId,
      contactRoleIds: roleIds,
    };

    Axios.post<UpdateOrganisationContactResponse>(`${process.env.REACT_APP_API_URL}/api/organisation/updatecontactrole`, requestData)
      .then(({ data }) => {
        const { contactRoles } = UpdateOrganisationContactResponseValidator.check(data);

        props.handleContactChange({
          ...props.contact,
          roles: contactRoles,
        });

        setState((prevState) => ({
          ...prevState,
          dialogOpen: false,
        }));

        enqueueSnackbar(('Successfully updated the contact roles'), { variant: 'success' });
      })
      .catch(() => {
        enqueueSnackbar(('An error occurred while updating the roles for this contact'), { variant: 'error' });
      })
      .finally(() => {
        setState((prevState) => ({
          ...prevState,
          loading: false,
        }));
      });
  };

  return (
    <>
      <ExpansionPanel expanded={state.isExpanded} onChange={handlePanelStateChange} elevation={props.elevation}>
        <ExpansionPanelSummary
          expandIcon={<ExpandMoreIcon />}
        >
          <Grid container wrap="nowrap">
            <Grid item xs={4} zeroMinWidth>
              {props.contact.roles.map((role) => (
                <SmallChip
                  className={classes.chip}
                  label={role.name}
                />
              ))}
            </Grid>
            <Grid item xs={4} zeroMinWidth>
              <Typography noWrap>
                {getFullName()}
              </Typography>
            </Grid>
            <Fade in={!state.isExpanded}>
              <Grid item xs={4} zeroMinWidth className={classes.iconContainer}>
                {props.contact.homePhone && (
                <CopyableTooltipIconButton
                  title={props.contact.homePhone}
                  placement="top"
                  arrow
                  className={classes.icon}
                >
                  <CellphoneIcon />
                </CopyableTooltipIconButton>
                )}
                <CopyableTooltipIconButton
                  title={props.contact.workPhone || ''}
                  placement="top"
                  arrow
                  disabled={!props.contact.workPhone}
                  className={classes.icon}
                >
                  <PhoneIcon />
                </CopyableTooltipIconButton>
                <CopyableTooltipIconButton
                  title={props.contact.email ?? ''}
                  placement="top"
                  arrow
                  disabled={!props.contact.email}
                  className={classes.icon}
                >
                  <EmailIcon />
                </CopyableTooltipIconButton>
                <CopyableTooltipIconButton
                  title={getAddress()}
                  placement="top"
                  arrow
                  disabled={!getAddress()}
                  className={classes.icon}
                >
                  <HomeIcon />
                </CopyableTooltipIconButton>
              </Grid>
            </Fade>
          </Grid>
        </ExpansionPanelSummary>
        <ExpansionPanelDetails>
          {props.contact.homePhone && (
          <Box display="inline-block" className={classes.readonlyContactDetails}>
            <CopyableTooltipIconWithContentText
              content={props.contact.homePhone}
              icon={<CellphoneIcon className={classes.icon} />}
              contentTextProps={{ display: 'inline', color: 'textSecondary' }}
            />
          </Box>
          )}
          {props.contact.workPhone && (
          <Box display="inline-block" className={classes.readonlyContactDetails}>
            <CopyableTooltipIconWithContentText
              content={props.contact.workPhone}
              icon={<PhoneIcon className={classes.icon} />}
              contentTextProps={{ display: 'inline', color: 'textSecondary' }}
            />
          </Box>
          )}
          {props.contact.email && (
          <Box display="inline-block" className={classes.readonlyContactDetails}>
            <CopyableTooltipIconWithContentText
              content={props.contact.email}
              icon={<EmailIcon className={classes.icon} />}
              contentTextProps={{ display: 'inline', color: 'textSecondary' }}
            />
          </Box>
          )}
          {getAddress() && (
          <Box display="inline-block" className={classes.readonlyContactDetails}>
            <CopyableTooltipIconWithContentText
              content={getAddress()}
              icon={<HomeIcon className={classes.icon} />}
              contentTextProps={{ display: 'inline', color: 'textSecondary' }}
            />
          </Box>
          )}
        </ExpansionPanelDetails>
        <ExpansionPanelActions>
          <Button
            color="primary"
            href={hubSpotContactLink(props.contact.hubSpotId)}
            variant="outlined"
            target="_blank"
          >
            View in Hubspot
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={openDialog}
            id="edit-roles"
          >
            Edit Roles
          </Button>
        </ExpansionPanelActions>
      </ExpansionPanel>
      <ContactRolesDialog
        initiallySelectedRoles={props.contact.roles}
        open={state.dialogOpen}
        handleClose={closeDialog}
        contactName={getFullName()}
        contactRoleLookup={props.contactRoleTypeLookup}
        loading={state.loading}
        submitUpdatedRoles={submitUpdateRoles}
      />
    </>
  );
};

interface ContactListProps {
  contacts: OrganisationContact[];
  organisationId: number;
  handleContactsChange(newContacts: OrganisationContact[]): void;
  contactRoleTypeLookup: LookupOption[];
  elevation?: number;
};

const ContactList: React.FC<ContactListProps> = (props) => {
  const classes = useStyles();

  const handleContactChange = (newContact: OrganisationContact) => {
    const newContacts = [...props.contacts];
    const indexOfContactToChange = newContacts.findIndex((c) => c.contactId === newContact.contactId);

    if (indexOfContactToChange > -1) {
      newContacts[indexOfContactToChange] = {
        ...newContact,
      };

      props.handleContactsChange(newContacts);
    }
  };

  const renderListItem = (contact: OrganisationContact): JSX.Element => {
    try {
      const validContact = OrganisationContactValidator.check(contact);
      return (
        <ContactListItem
          contact={validContact}
          organisationId={props.organisationId}
          handleContactChange={handleContactChange}
          contactRoleTypeLookup={props.contactRoleTypeLookup}
          key={validContact.contactId}
          elevation={props.elevation}
        />
      );
    } catch (e) {
      return (
        <RuntypeError
          error={e}
          data={contact}
        />
      );
    }
  };

  return (
    <Box width={1}>
      {props.contacts.length ? (
        props.contacts.map((contact) => renderListItem(contact))
      ) : (
        <Paper className={classes.paper}>
          <Typography>
            {noContactsMessage}
          </Typography>
        </Paper>
      )}
    </Box>
  );
};

export default ContactList;
