import React, { useState, useContext } from 'react';
import { useSnackbar } from 'notistack';
import Axios from 'axios';
import {
  CircularProgress, Tooltip, createStyles, Typography, useTheme,
} from '@material-ui/core';
import LockIcon from '@material-ui/icons/Lock';
import LockOpenIcon from '@material-ui/icons/LockOpen';
import { makeStyles } from '@material-ui/styles';
import ConfirmationDialog from '../molecules/ConfirmationDialog';
import Flipper from '../atoms/Flipper';
import { AppContext } from '../Context';

interface LockIconProps {
  canUnlock: boolean;
  indexer: string;
  title: string;
  artifactId: number;
  onUnlocked(): void;
  className?: string;
}

const useStyles = makeStyles(() => createStyles({
  unlockIcon: {
    cursor: 'pointer',
  },
}));

export default function ArtifactLock(props: LockIconProps) {
  const [state, setState] = useState({
    isUnlocking: false,
    openConfirmationDialog: false,
  });

  const snackbar = useSnackbar();
  const classes = useStyles();
  const theme = useTheme();
  const context = useContext(AppContext);

  const isOwned = context.userInfo.data.name === props.indexer;

  const openUnlockDialog = (): void => {
    setState((prevState) => ({
      ...prevState,
      openConfirmationDialog: true,
    }));
  };

  const confirmUnlockArtifact = (artifactId: number): void => {
    Axios.post(`${process.env.REACT_APP_API_URL}/api/artifact/explicitunlockartifact?artifactId=${artifactId}`).then(() => {
      props.onUnlocked();
      snackbar.enqueueSnackbar('Artifact unlocked', { variant: 'success' });
    }).catch(() => {
      snackbar.enqueueSnackbar('Unable to unlock artifact', { variant: 'error' });
    }).finally(() => {
      setState((prevState) => ({
        ...prevState,
        isUnlocking: false,
      }));
    });
  };

  const renderConfirmationDialog = (): JSX.Element => (
    <ConfirmationDialog
      dialogTitle="Unlock Artifact"
      dialogBodyText={(
        <Typography>
          Are you sure you want to unlock artifact
          {' '}
          <strong>{props.title}</strong>
          {' '}
          from
          {' '}
          <strong>{props.indexer}</strong>
          ?
          {' '}
          <br />
          If they are currently working on this artifact, they will lose any unsaved changes.
        </Typography>
)}
      isOpen={state.openConfirmationDialog}
      onReturn={() => {
        setState((prevState) => ({
          ...prevState,
          openConfirmationDialog: false,
        }));
      }}
      onProceed={() => {
        setState((prevState) => ({
          ...prevState,
          openConfirmationDialog: false,
          isUnlocking: true,
        }));
        confirmUnlockArtifact(props.artifactId);
      }}
    />
  );

  return (
    <div className={props.className}>
      {!state.isUnlocking && (
        <>
          {props.canUnlock ? (
            <Flipper
              front={(<LockIcon style={{ color: isOwned ? theme.palette.success.main : 'inherit' }} fontSize="small" />)}
              back={(<Tooltip title={`Unlock artifact from ${props.indexer}`}><LockOpenIcon className={classes.unlockIcon} fontSize="small" onClick={openUnlockDialog} /></Tooltip>)}
            />
          ) : (
            <Tooltip title={props.indexer}><LockIcon fontSize="small" /></Tooltip>
          )}

        </>
      )}
      {state.openConfirmationDialog && props.indexer && (
        <>
          {renderConfirmationDialog()}
        </>
      )}
      {state.isUnlocking && (
        <CircularProgress size={18} style={{ marginRight: 9 }} />
      )}
    </div>
  );
};
