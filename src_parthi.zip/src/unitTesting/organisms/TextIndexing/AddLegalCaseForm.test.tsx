import React from 'react';
import { mount } from 'enzyme';
import { Button } from '@material-ui/core';
import AddLegalCaseForm from '../../../components/organisms/TextIndexer/AddLegalCaseForm';
import SingleCheckbox from '../../../components/molecules/SingleCheckbox';
import TextInputField from '../../../components/Shared/TextInputField';
import LoadingButton from '../../../components/molecules/LoadingButton';

describe('Add legal case form', () => {
  it('should render the correct fields initially', () => {
    const wrapper = mount(
      <AddLegalCaseForm
        loading={false}
        onAdd={() => undefined}
        onCancel={() => undefined}
      />,
    );

    expect(wrapper.find(TextInputField)).toHaveLength(1);
    expect(wrapper.find(SingleCheckbox)).toHaveLength(1);
  });

  it('should initially not allow add', () => {
    const wrapper = mount(
      <AddLegalCaseForm
        loading={false}
        onAdd={() => undefined}
        onCancel={() => undefined}
      />,
    );

    expect(wrapper.find(LoadingButton).prop('disabled')).toBeTruthy();
  });

  it('Should not allow adding or cancelling while loading', () => {
    const wrapper = mount(
      <AddLegalCaseForm
        loading
        onAdd={() => undefined}
        onCancel={() => undefined}
      />,
    );

    expect(wrapper.find(Button).at(0).prop('disabled')).toBeTruthy();
    expect(wrapper.find(Button).at(1).prop('disabled')).toBeTruthy();
  });
});
