/* eslint @typescript-eslint/no-explicit-any: 0 */
import React from 'react';
import { TextField, Grid } from '@material-ui/core';
import Autocomplete from '@material-ui/lab/Autocomplete';
import NarrowSubjectOption from '../../../interfaces/MediaIndexer/NarrowSubjectOption';

interface NarrowSubjectsProps {
  options: NarrowSubjectOption[];
  handleValueChangeFunction: Function;
}

function getOptionRender(option: NarrowSubjectOption): JSX.Element {
  return (
    <>
      <Grid item xs={11}>
        <span>{option.value}</span>
      </Grid>
    </>
  );
}

export default function NarrowSubjects(props: NarrowSubjectsProps): JSX.Element {
  return (
    <>
      {/* <Typedown
        labelText="Narrow Subjects"
        inputValue=""
        placeholderText=""
        getSuggestionsListFunction={getNarrowSubjects}
        onValueChangeFunction={props.handleValueChangeFunction}
      /> */}
      <Autocomplete
        multiple
        id="tags-standard"
        options={props.options}
        onChange={() => props.handleValueChangeFunction()}
        renderInput={(params: any) => (
          <TextField
            {...params}
            variant="standard"
            label="Narrow Subject"
            margin="normal"
            fullWidth
          />
        )}
        renderOption={(option: NarrowSubjectOption) => getOptionRender(option)}
        renderTags={() => <></>}
      />
    </>
  );
}
