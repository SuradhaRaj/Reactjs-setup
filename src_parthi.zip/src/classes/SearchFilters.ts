import {
  Record, String, Array as RtArray, Static, Undefined, Number,
} from 'runtypes';
import Filters from './Filters';
import ArtifactSearchIndex from '../interfaces/enums/ArtifactSearchIndex';

const IndexRequestValidator = Record({
  searchIndex: Number,
  payload: String.Or(Undefined),
});

interface SearchFiltersData {
  text: string;
  index: ArtifactSearchIndex;
}

const SearchRequestValidator = Record({
  text: String,
  indexRequests: RtArray(IndexRequestValidator),
});

type SearchRequest = Static<typeof SearchRequestValidator> ;

class SearchFilters extends Filters<SearchFiltersData> {
  constructor(filterContent: SearchRequest) {
    try {
      SearchRequestValidator.check(filterContent);
      let index = ArtifactSearchIndex.All;
      if (filterContent.indexRequests.length > 0) {
        index = filterContent.indexRequests[0].searchIndex;
      }
      super({
        index,
        text: filterContent.text,
      });
    } catch (error) {
      console.error(error);
      throw error;
    }
  }

  getQueryObject() {
    return {
      text: this.data.text.trim(),
      indexRequests: [{
        searchIndex: this.data.index,
      }],
    };
  }

  getQueryString() {
    const serialised = JSON.stringify(this.getQueryObject());
    return serialised === '{}' ? '' : serialised;
  }

  static empty() {
    return new SearchFilters({
      indexRequests: [{ searchIndex: ArtifactSearchIndex.All, payload: undefined }],
      text: '',
    });
  }
}

export default SearchFilters;
