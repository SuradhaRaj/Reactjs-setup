import ArtifactType from '../enums/ArtifactType';

interface AddNewIdentifierRequest {
  name: string;
  artifactType: ArtifactType;
};

export default AddNewIdentifierRequest;
