import {
  Record, String, Number, InstanceOf, Null, Boolean, Array, Static,
} from 'runtypes';
import { ArticleDocumentAuthorValidator } from './ArticleDocumentAuthor';
import { DocumentItemNodeValidator } from '../MediaIndexer/DocumentItemNode';
import { DocumentFastNodeValidator } from '../MediaIndexer/DocumentFastNode';
import { CorporateAuthorValidator } from './CorporateAuthor';
import { CosmosDocumentNoteValidator } from '../MediaIndexer/DocumentNote';
import { NumberGreaterZero } from '../../runtypeTypes';
import { DocumentLangNodeValidator } from '../MediaIndexer/DocumentLangNode';

export const TextArtifactValidator = Record({
  pk: String,
  artifactId: Number,
  rmitNumber: String,
  createdDate: String,
  versionNumber: Number,
  externalID: String,
  resourceTitle: String,
  resourceManager: String,
  grouping: String,
  artifactArticleId: Number,
  modifiedDate: InstanceOf(Date),
  doi: String.Or(Null),
  isItem: Boolean,
  isMinor: Boolean,
  genreID: Number.Or(Null),
  genre: String.Or(Null),
  title: String.Or(Null),
  subtitle: String.Or(Null),
  articlePublishDate: String.Or(Null),
  pagination: String.Or(Null),
  fPage: String.Or(Null),
  lPage: String.Or(Null),
  eLocation: String.Or(Null),
  sectionName: String.Or(Null),
  description: String.Or(Null),
  descriptionTypeID: Number.Or(Null),
  descriptionType: String.Or(Null),
  authors: Array(ArticleDocumentAuthorValidator),
  corporateAuthors: Array(CorporateAuthorValidator),
  aglibsSubjects: Array(DocumentItemNodeValidator),
  legislation: Array(DocumentItemNodeValidator),
  languages: Array(DocumentLangNodeValidator),
  identifiers: Array(DocumentItemNodeValidator),
  fast: Array(DocumentFastNodeValidator),
  fastGeo: Array(DocumentFastNodeValidator),
  legalCase: Array(DocumentItemNodeValidator),
  treaty: Array(DocumentItemNodeValidator),
  jurisdiction: Array(DocumentItemNodeValidator),
  resourceTypeId: Number.Or(Null),
  resourceType: String.Or(Null),
  mediaTypes: Array(DocumentItemNodeValidator),
  mimeType: String.Or(Null),
  urIs: Array(String),
  persistentIdentifier: String.Or(Null),
  isPeerReviewedArticle: Boolean,
  contentSource: String.Or(Null),
  contentImportDate: InstanceOf(Date).Or(Null),
  contentDN: Number.Or(Null),
  articlePPVPrice: Number.Or(Null),
  articlePPVBlock: Boolean,
  titleID: Number,
  issueID: Number,
  articleOrder: Number.Or(Null),
  pdfFileName: String.Or(Null),
  htmlFileName: String.Or(Null),
  publishArtifact: Boolean,
  doiListed: Boolean,
  pIListed: Boolean,
  uRIIndicator: Boolean,
  availability: String,
  fileSize: Number,
  accessRightId: NumberGreaterZero.Or(Null),
  publisherNotes: Array(CosmosDocumentNoteValidator),
  resourceManagerNotes: Array(CosmosDocumentNoteValidator),
  indexerNotes: Array(CosmosDocumentNoteValidator),
});

type TextArtifact = Static<typeof TextArtifactValidator>;

export default TextArtifact;
