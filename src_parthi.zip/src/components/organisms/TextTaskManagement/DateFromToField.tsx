/* eslint @typescript-eslint/no-explicit-any: 0 */
import React from 'react';

import {
  Grid, Typography, makeStyles, createStyles,
} from '@material-ui/core';
import TextInputField from '../../Shared/TextInputField';

const useStyles = makeStyles(() => createStyles({

  title: {
    fontSize: '0.8rem',
  },

}));

export interface DateFromToField{
    id: number;
    from: Date | string | null | undefined;
    to: Date | string | null | undefined;
}

export interface DateProps {
    value: DateFromToField;
    onChange(value: DateFromToField): void;
    keyName: string;
    isLoading: boolean;
    readonly: boolean;
    label?: string;
   // showLoadingSpinner: boolean;

    onBlur?(e: React.FocusEvent<HTMLDivElement>): void;

    disabled?: boolean;
    error?: boolean;
    errorMessage?: string | undefined;

}

const DateFromToFieldInput = (props: DateProps): JSX.Element => {
  const keyName = props.keyName;
  const label = props.label;
  // const value: DateFromToField = props.value;
  const classes = useStyles();

  function changeHanlder(e: any, field: 'from'|'to') {
    const newfieldValue = e.target.value as string;
    const value = { ...props.value };
    value[field] = newfieldValue;

    props.onChange(value);
  }

  return (
    <>
      {!props.isLoading && (
      <Grid container>
        <Grid item xs={12}>
          <Typography className={classes.title}>{label}</Typography>
        </Grid>
        <Grid item xs={12}>
          <TextInputField
            type="date"
            labelText="From"
            value={props.value.from}
            keyName={`${keyName}From`}
            onChangeFunction={(e: any) => {
              changeHanlder(e, 'from');
            }}
            onBlur={props.onBlur}
            error={!!props.error}
            errorMessage={props.errorMessage}
            readOnly={props.readonly}
          />
          <TextInputField
            type="date"
            labelText="to"
            value={props.value.to}
            keyName={`${keyName}To`}
            onChangeFunction={(e: any) => {
              changeHanlder(e, 'to');
            }}
            onBlur={props.onBlur}
            error={!!props.error}
            errorMessage={props.errorMessage}
            readOnly={props.readonly}
          />
        </Grid>

      </Grid>
      )}
    </>
  );
};
export default DateFromToFieldInput;
