import {
  ActionTypes, UPDATE_MEDIA_REFERENCE_DATA,
} from '../actions/ActnMediaReferenceData';
import MediaReferenceData from '../../interfaces/MediaIndexer/Reference Data/MediaReferenceData';

export interface MediaReferenceDataState {
  MediaReferenceData: MediaReferenceData;
}

export const initialState: MediaReferenceDataState = {
  MediaReferenceData: {
    genreLookup: [],
    languageLookup: [],
    classificationLookup: [],
    contentTypeLookup: [],
    resourceTypeLookup: [],
    broadSubjectLookup: [],
    errorCodes: [],
  },
};

export default (state = initialState, action: ActionTypes): MediaReferenceDataState => {
  switch (action.type) {
    case UPDATE_MEDIA_REFERENCE_DATA:
      return {
        ...state,
        MediaReferenceData: action.payload,
      };

    default:
      return state;
  }
};
