import { shallow } from 'enzyme';
import React from 'react';
import ExpansionPanelForTable from '../../components/organisms/ExpansionPanelForTable';

describe('ExpansionPanelForTable', () => {
  it('should render the correct title', () => {
    const wrapper = shallow(<ExpansionPanelForTable title="Test title" count={5} defaultExpanded />);
    expect(wrapper.find('[data-title]').text()).toContain('Test title');
  });
});
