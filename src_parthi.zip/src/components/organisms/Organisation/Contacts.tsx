import React from 'react';
import OrganisationContact from '../../../interfaces/Organisation/OrganisationContact';
import ContactList from './ContactList';
import LookupOption from '../../../interfaces/LookupOption';

interface ContactsProps {
  contacts: OrganisationContact[];
  organisationId: number;
  handleContactsChange(newContacts: OrganisationContact[]): void;
  contactRoleTypeLookup: LookupOption[];
};

const Contacts: React.FC<ContactsProps> = (props) => (
  <>
    <ContactList
      contacts={props.contacts}
      organisationId={props.organisationId}
      handleContactsChange={props.handleContactsChange}
      contactRoleTypeLookup={props.contactRoleTypeLookup}
    />
  </>
);

export default Contacts;
