import React from 'react';
import {
  ChipProps, makeStyles, createStyles, Chip,
} from '@material-ui/core';
import classnames from 'classnames';

const useStyles = makeStyles(() => createStyles({
  root: {
    padding: 3,
    color: '#000054',
    backgroundColor: '#EEEEFF',
    borderColor: '#EEEEFF',
    borderRadius: '5px',
    '& .MuiChip-label': {
      paddingLeft: '3px',
      paddingRight: '3px',
      fontSize: '0.6rem',
      fontWeight: 600,
    },
    '&.MuiChip-root': {
      height: 20,
    },
  },
}));

export default (props: ChipProps) => {
  const classes = useStyles();
  const { className, ...chipProps } = props;
  return (
    <Chip className={classnames(classes.root, className)} {...chipProps} />
  );
};
