import {
  Record, String, Array as RtArray, Undefined, Number, Null, Static, Boolean,
} from 'runtypes';
import Filters from '../../../classes/Filters';
import {
  SelectedOptionState,
  ID_LAST_MODIFIED_DATE, ID_ISSUE_FILES_RECEIVED, ID_READY_FOR_FILE_PREP,
  ID_READY_FOR_ISSUE_SPLITTING, ID_READY_FOR_LEGAL_INDEXING, ID_READY_FOR_ADVANCED_INDEXING, ID_READY_FOR_INDEXING, ID_INDEXING_COMPLETE,
} from './SimpleFilters';

export const RuntypeDeclaration = Record({
  status: RtArray(Record({ id: Number, value: String })).Or(Undefined),
  publisher: RtArray(String).Or(Undefined),
  grouping: RtArray(String).Or(Undefined),
  title: RtArray(String).Or(Undefined),
  manager: RtArray(Record({ id: Number, value: String })).Or(Undefined),

  organisations: RtArray(Record({ id: Number, value: String })).Or(Undefined),
  contentTypes: RtArray(Record({ id: Number, value: String })).Or(Undefined),
  issn: RtArray(String).Or(Undefined),
  isbn: RtArray(String).Or(Undefined),
  recordNumbers: RtArray(String).Or(Undefined),
  resources: RtArray(String).Or(Undefined),

  dates: RtArray(Record({ id: Number, from: String.Or(Null), to: String.Or(Null) })).Or(Undefined),
  datesLog: RtArray(Record({ id: Number, from: String.Or(Null), to: String.Or(Null) })).Or(Undefined),
  priority: RtArray(Record({ id: Number, value: String })).Or(Undefined),
  indexingCompany: RtArray(Record({ id: Number, value: String })).Or(Undefined),
  hasIndexerNotes: Boolean.Or(Undefined),
  hasPublisherNotes: Boolean.Or(Undefined),
  includeRelated: Boolean.Or(Undefined),
});

export type SelectedOptionFiltersRT = Static<typeof RuntypeDeclaration>;

export class SelectedOptionFilters extends Filters<SelectedOptionState> {
  constructor(filterContent: SelectedOptionFiltersRT) {
    try {
      RuntypeDeclaration.check(filterContent);
      super({
        status: filterContent.status === undefined ? [] : filterContent.status,
        publisher: filterContent.publisher === undefined ? [] : filterContent.publisher,
        grouping: filterContent.grouping === undefined ? [] : filterContent.grouping,
        title: filterContent.title === undefined ? [] : filterContent.title,
        manager: filterContent.manager === undefined ? [] : filterContent.manager,
        organisation: filterContent.organisations === undefined ? [] : filterContent.organisations,
        contentType: filterContent.contentTypes === undefined ? [] : filterContent.contentTypes,
        issn: filterContent.issn === undefined ? [] : filterContent.issn,
        isbn: filterContent.isbn === undefined ? [] : filterContent.isbn,
        documentNumber: filterContent.recordNumbers === undefined ? [] : filterContent.recordNumbers,
        resource: filterContent.resources === undefined ? [] : filterContent.resources,
        dates: filterContent.dates === undefined ? [] : filterContent.dates,
        datesLog: filterContent.datesLog === undefined ? [] : filterContent.datesLog,
        priority: filterContent.priority === undefined ? [] : filterContent.priority,
        indexingCompany: filterContent.indexingCompany === undefined ? [] : filterContent.indexingCompany,
        hasIndexerNotes: filterContent.hasIndexerNotes,
        hasPublisherNotes: filterContent.hasPublisherNotes,
        includeRelated: filterContent.includeRelated,
      });
    } catch (error) {
      console.error(error);
      throw error;
    }
  }

  static empty() {
    return new SelectedOptionFilters({
      status: [],
      grouping: [],
      title: [],
      publisher: [],
      manager: [],
      organisations: [],
      contentTypes: [],
      issn: [],
      isbn: [],
      recordNumbers: [],
      resources: [],
      dates: [
        { id: ID_LAST_MODIFIED_DATE, from: '', to: '' },
      ],
      datesLog: [
        { id: ID_ISSUE_FILES_RECEIVED, from: '', to: '' },
        { id: ID_READY_FOR_FILE_PREP, from: '', to: '' },
        { id: ID_READY_FOR_ISSUE_SPLITTING, from: '', to: '' },
        { id: ID_READY_FOR_LEGAL_INDEXING, from: '', to: '' },
        { id: ID_READY_FOR_ADVANCED_INDEXING, from: '', to: '' },
        { id: ID_READY_FOR_INDEXING, from: '', to: '' },
        { id: ID_INDEXING_COMPLETE, from: '', to: '' },
      ],
      priority: [],
      indexingCompany: [],
      hasIndexerNotes: undefined,
      hasPublisherNotes: undefined,
      includeRelated: undefined,
    });
  }
}
