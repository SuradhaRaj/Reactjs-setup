import React, { useContext } from 'react';
import { without } from 'lodash';
import { DateTime } from 'luxon';
import TypedownAsync, { TypedownAsyncProps } from './TypedownAsync';
import DocumentItemNode from '../../interfaces/MediaIndexer/DocumentItemNode';
import { AppContext } from '../Context';
import TypedownOption from '../../interfaces/TypedownOption';

interface Props extends Omit<TypedownAsyncProps, 'selectedOptions'|'onChange'|'onChangeMultiple'>{
  selectedOptions: DocumentItemNode[];
  initiallySelectedOptions: DocumentItemNode[];
  onChangeMultiple(data: DocumentItemNode[]): void;
  disabled?: boolean;
  error?: boolean;
  errorMessage?: string | undefined;
  typedownLimit: number;
}

const TypedownDocumentItemNode = (props: Props): JSX.Element => {
  const typedownSelectedOptions = props.selectedOptions.map((item): TypedownOption => ({ id: item.id, value: item.name }));
  const context = useContext(AppContext);

  const onChange = (data: TypedownOption[]) => {
    const itemAdded = without(data, ...typedownSelectedOptions);

    if (itemAdded.length > 0) {
      const initialDocumentItemNode = props.initiallySelectedOptions.find((option) => option.id === itemAdded[0].id);
      // if this item has initially been selected, preserve the data
      if (initialDocumentItemNode !== undefined) {
        const selectedDocumentItemNode = props.selectedOptions.find((option) => option.id === itemAdded[0].id);
        if (selectedDocumentItemNode === undefined) {
          const item: DocumentItemNode = {
            ...initialDocumentItemNode,
          };
          props.onChangeMultiple([...props.selectedOptions, item]);
        }
      } else {
        const selectedDocumentItemNode = props.selectedOptions.find((option) => option.id === itemAdded[0].id);
        if (selectedDocumentItemNode === undefined) {
          const item: DocumentItemNode = {
            createdBy: context.userInfo.data.name,
            createdDate: DateTime.local().toISO(),
            id: itemAdded[0].id,
            name: itemAdded[0].value.trim(),
          };
          props.onChangeMultiple([...props.selectedOptions, item]);
        }
      }
    } else {
      const newItems = props.selectedOptions.filter((item) => data.findIndex((newOption) => newOption.id === item.id) > -1);
      props.onChangeMultiple(newItems);
    }
  };

  return (
    <>
      <TypedownAsync
        {...props}
        selectedOptions={typedownSelectedOptions}
        allowMultiple
        onChangeMultiple={onChange}
        disabled={props.disabled || props.selectedOptions.length >= props.typedownLimit}
        error={props.error}
        errorMessage={props.errorMessage}
        typedownLimit={props.typedownLimit}
      />
    </>
  );
};

TypedownDocumentItemNode.defaultProps = TypedownAsync.defaultProps;
export default TypedownDocumentItemNode;
