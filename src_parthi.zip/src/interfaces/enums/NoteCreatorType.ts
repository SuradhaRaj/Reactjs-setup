enum NoteCreatorType {
    Publisher = 1,
    ResourceManager = 2,
    Indexer = 3
};

export default NoteCreatorType;
