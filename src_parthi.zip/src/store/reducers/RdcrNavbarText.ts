interface TaskTile {
    isClicked: boolean;
}
export const initialState: TaskTile = {
  isClicked: false,
};

export const TEXT_TILE = 'TEXT_TILE';
interface TextTile {
    type: typeof TEXT_TILE;
    payload: boolean;
}
export type ActionTypes = TextTile;
export const reducer = (state = initialState, action: ActionTypes) => {
  if (action.type === 'TEXT_TILE') {
    return {
      ...state,
      isClicked: action.payload,
    };
  }
  return state;
};
