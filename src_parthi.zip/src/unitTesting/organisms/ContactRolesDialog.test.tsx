import React from 'react';
import { mount } from 'enzyme';
import { Switch, FormControlLabel } from '@material-ui/core';
import { Icon } from '@iconify/react';
import ContactRolesDialog from '../../components/organisms/ContactRolesDialog';
import LookupOption from '../../interfaces/LookupOption';
import ContactRole from '../../interfaces/Organisation/ContactRole';

jest.mock('notistack', () => ({
  useSnackbar: () => ({
    enqueueSnackbar: jest.fn(),
  }),
}));

const sampleRoles: LookupOption[] = [
  { key: 1, value: 'Primary Contact' },
  { key: 2, value: 'File Provider' },
  { key: 3, value: 'Royalty Contact' },
];

const sampleInitialRoles: ContactRole[] = [
  { isCRM: true, name: 'Primary Contact', contactRoleId: 1 },
  { isCRM: false, name: 'Royalty Contact', contactRoleId: 3 },
];

describe('Contact Roles Dialog', () => {
  it('should render the correct number of switches', () => {
    const wrapper = mount(
      <ContactRolesDialog
        loading={false}
        contactName="Jane Doe"
        submitUpdatedRoles={() => undefined}
        handleClose={() => undefined}
        open
        contactRoleLookup={sampleRoles}
        initiallySelectedRoles={sampleInitialRoles}
      />,
    );

    expect(wrapper.find(Switch).length).toBe(3);
  });

  it('should render the crm role switch disabled', () => {
    const wrapper = mount(
      <ContactRolesDialog
        loading={false}
        contactName="Jane Doe"
        submitUpdatedRoles={() => undefined}
        handleClose={() => undefined}
        open
        contactRoleLookup={sampleRoles}
        initiallySelectedRoles={sampleInitialRoles}
      />,
    );

    expect(wrapper.find(Switch).at(0).prop('disabled')).toBeTruthy();
  });

  it('should render the HubSpot icon next to the crm role', () => {
    const wrapper = mount(
      <ContactRolesDialog
        loading={false}
        contactName="Jane Doe"
        submitUpdatedRoles={() => undefined}
        handleClose={() => undefined}
        open
        contactRoleLookup={sampleRoles}
        initiallySelectedRoles={sampleInitialRoles}
      />,
    );

    expect(wrapper.find(FormControlLabel).at(0).find(Icon).length).toBeTruthy();
    expect(wrapper.find(FormControlLabel).at(1).find(Icon).length).toBeFalsy();
    expect(wrapper.find(FormControlLabel).at(2).find(Icon).length).toBeFalsy();
  });

  it('should render the correct initial roles selected', () => {
    const wrapper = mount(
      <ContactRolesDialog
        loading={false}
        contactName="Jane Doe"
        submitUpdatedRoles={() => undefined}
        handleClose={() => undefined}
        open
        contactRoleLookup={sampleRoles}
        initiallySelectedRoles={sampleInitialRoles}
      />,
    );

    expect(wrapper.find(Switch).at(0).prop('checked')).toBeTruthy();
    expect(wrapper.find(Switch).at(1).prop('checked')).toBeFalsy();
    expect(wrapper.find(Switch).at(2).prop('checked')).toBeTruthy();
  });
});
