import { useState } from 'react';

interface PaginationState {
  page: number;
  resultsPerPage: number;
}

interface Props {
  resultsPerPage?: number;
}

const usePagination = (props?: Props) => {
  const [state, setState] = useState<PaginationState>({
    page: 2,
    resultsPerPage: props?.resultsPerPage ?? 10,
  });

  const getPage = <T, >(data: T[]): T[] => data.slice((state.page - 1) * state.resultsPerPage, state.page * state.resultsPerPage);

  const getNextPage = <T, >(data: T[]): T[] => {
    setState((prevState) => ({
      ...prevState,
      page: prevState.page + 1,
    }));

    return getPage(data);
  };

  const getInitialPage = <T, >(data: T[]): T[] => data.slice(0, state.resultsPerPage);

  const reset = (): void => {
    setState((prevState) => ({
      ...prevState,
      page: 2,
    }));
  };

  return { getNextPage, getInitialPage, reset };
};

export default usePagination;
