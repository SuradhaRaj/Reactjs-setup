import TableSortHelper, { Order } from '../../utils/TableSortHelper';

interface TypeSortRow {
    data: string | boolean | number | undefined | null;
}

describe('stable sort function tests', () => {
  it('sort by Number', () => {
    const numbers = new Array<TypeSortRow>();
    const num1: TypeSortRow = { data: 3 };
    const num2: TypeSortRow = { data: null };
    const num3: TypeSortRow = { data: 2 };
    const num4: TypeSortRow = { data: undefined };
    const num5: TypeSortRow = { data: 1 };
    let order: Order = 'asc';

    numbers.push(num1);
    numbers.push(num2);
    numbers.push(num3);
    numbers.push(num4);
    numbers.push(num5);

    const sortedAsc = TableSortHelper.stableSort(numbers, TableSortHelper.getSorting(order, 'data'));
    expect(sortedAsc[0] === num4 || sortedAsc[0] === num2).toBeTruthy();
    expect(sortedAsc[1] === num4 || sortedAsc[1] === num2).toBeTruthy();
    expect(sortedAsc[2] === num5).toBeTruthy();
    expect(sortedAsc[3] === num3).toBeTruthy();
    expect(sortedAsc[4] === num1).toBeTruthy();

    order = 'desc';
    const sortedDesc = TableSortHelper.stableSort(numbers, TableSortHelper.getSorting(order, 'data'));
    expect(sortedDesc[0] === num1).toBeTruthy();
    expect(sortedDesc[1] === num3).toBeTruthy();
    expect(sortedDesc[2] === num5).toBeTruthy();
    expect(sortedDesc[3] === num4 || sortedDesc[3] === num2).toBeTruthy();
    expect(sortedDesc[4] === num4 || sortedDesc[4] === num2).toBeTruthy();
  });

  it('sort by String', () => {
    const strings = new Array<TypeSortRow>();
    const string1: TypeSortRow = { data: 'b' };
    const string2: TypeSortRow = { data: undefined };
    const string3: TypeSortRow = { data: 'a' };
    const string4: TypeSortRow = { data: null };
    const string5: TypeSortRow = { data: 'c' };
    let order: Order = 'asc';
    strings.push(string1);
    strings.push(string2);
    strings.push(string3);
    strings.push(string4);
    strings.push(string5);

    const sortedAsc = TableSortHelper.stableSort(strings, TableSortHelper.getSorting(order, 'data'));
    expect(sortedAsc[0] === string2 || sortedAsc[0] === string4).toBeTruthy();
    expect(sortedAsc[1] === string2 || sortedAsc[1] === string4).toBeTruthy();
    expect(sortedAsc[2] === string3).toBeTruthy();
    expect(sortedAsc[3] === string1).toBeTruthy();
    expect(sortedAsc[4] === string5).toBeTruthy();

    order = 'desc';
    const sortedDesc = TableSortHelper.stableSort(strings, TableSortHelper.getSorting(order, 'data'));
    expect(sortedDesc[0] === string5).toBeTruthy();
    expect(sortedDesc[1] === string1).toBeTruthy();
    expect(sortedDesc[2] === string3).toBeTruthy();
    expect(sortedDesc[3] === string2 || sortedDesc[3] === string4).toBeTruthy();
    expect(sortedDesc[4] === string2 || sortedDesc[4] === string4).toBeTruthy();
  });

  it('sort by ISO String', () => {
    const isostrings = new Array<TypeSortRow>();
    const iso1: TypeSortRow = { data: null };
    const iso2: TypeSortRow = { data: '2019-10-25T00:00:00.000Z' };
    const iso3: TypeSortRow = { data: '2020-01-25T00:00:00.000Z' };
    const iso4: TypeSortRow = { data: '2020-01-10T00:00:00.000Z' };
    const iso5: TypeSortRow = { data: undefined };
    let order: Order = 'asc';

    isostrings.push(iso1);
    isostrings.push(iso2);
    isostrings.push(iso3);
    isostrings.push(iso4);
    isostrings.push(iso5);

    const sortedAsc = TableSortHelper.stableSort(isostrings, TableSortHelper.getSorting(order, 'data'));
    expect(sortedAsc[0] === iso1 || sortedAsc[0] === iso5).toBeTruthy();
    expect(sortedAsc[1] === iso1 || sortedAsc[1] === iso5).toBeTruthy();
    expect(sortedAsc[2] === iso2).toBeTruthy();
    expect(sortedAsc[3] === iso4).toBeTruthy();
    expect(sortedAsc[4] === iso3).toBeTruthy();

    order = 'desc';
    const sortedDesc = TableSortHelper.stableSort(isostrings, TableSortHelper.getSorting(order, 'data'));
    expect(sortedDesc[0] === iso3).toBeTruthy();
    expect(sortedDesc[1] === iso4).toBeTruthy();
    expect(sortedDesc[2] === iso2).toBeTruthy();
    expect(sortedDesc[3] === iso1 || sortedDesc[3] === iso5).toBeTruthy();
    expect(sortedDesc[4] === iso1 || sortedDesc[4] === iso5).toBeTruthy();
  });

  it('sort by boolean', () => {
    const bools = new Array<TypeSortRow>();
    const bool1 = { data: true };
    const bool2 = { data: false };
    const bool3 = { data: undefined };
    const bool4 = { data: false };
    const bool5 = { data: null };
    const bool6 = { data: true };
    let order: Order = 'asc';

    bools.push(bool1);
    bools.push(bool2);
    bools.push(bool3);
    bools.push(bool4);
    bools.push(bool5);
    bools.push(bool6);

    const sortedAsc = TableSortHelper.stableSort(bools, TableSortHelper.getSorting(order, 'data'));
    expect(sortedAsc[0].data === null || sortedAsc[0].data === undefined).toBeTruthy();
    expect(sortedAsc[1].data === null || sortedAsc[1].data === undefined).toBeTruthy();
    expect(sortedAsc[2].data).toBeFalsy();
    expect(sortedAsc[3].data).toBeFalsy();
    expect(sortedAsc[4].data).toBeTruthy();
    expect(sortedAsc[5].data).toBeTruthy();

    order = 'desc';
    const sortedDesc = TableSortHelper.stableSort(bools, TableSortHelper.getSorting(order, 'data'));
    expect(sortedDesc[0].data).toBeTruthy();
    expect(sortedDesc[1].data).toBeTruthy();
    expect(sortedDesc[2].data).toBeFalsy();
    expect(sortedDesc[3].data).toBeFalsy();
    expect(sortedDesc[4].data === null || sortedDesc[4].data === undefined).toBeTruthy();
    expect(sortedDesc[5].data === null || sortedDesc[5].data === undefined).toBeTruthy();
  });
});
