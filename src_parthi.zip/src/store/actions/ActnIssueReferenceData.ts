import IssueReferenceData from '../../interfaces/IssueManagement/IssueReferenceData';

export const UPDATE_ISSUE_REFERENCE_DATA = 'UPDATE_ISSUE_REFERENCE_DATA';

interface UpdateIssueReferenceDataAction {
  type: typeof UPDATE_ISSUE_REFERENCE_DATA;
  payload: IssueReferenceData;
}

export type ActionTypes = UpdateIssueReferenceDataAction;

export function updateIssueReferenceData(data: IssueReferenceData): ActionTypes {
  return {
    type: UPDATE_ISSUE_REFERENCE_DATA,
    payload: data,
  };
}
