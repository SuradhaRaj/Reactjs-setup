enum ArtifactSearchIndex {
  All=0,
  Media= 1,
  Article= 2,
  Issue= 3,
  Organisation= 4,
  Title= 5,
}
export default ArtifactSearchIndex;

type ArtifactSearchIndexNameMapping = {
  [indexName in ArtifactSearchIndex]: string;
}

export const ArtifactSearchIndexNameMapping: ArtifactSearchIndexNameMapping = {
  0: 'All',
  1: 'Media',
  2: 'Text',
  3: 'Issue',
  4: 'Organisation',
  5: 'Resource',
};
