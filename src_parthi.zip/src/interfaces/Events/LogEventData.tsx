/*eslint-disable*/
import LogEventOption from './LogEventOption';

export default interface LogEventData {
    logInfo: LogEventOption[];
}