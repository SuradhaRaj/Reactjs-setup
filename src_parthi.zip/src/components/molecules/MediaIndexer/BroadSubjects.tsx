/* eslint @typescript-eslint/no-explicit-any: 0 */
import React from 'react';
import { TextField, Grid } from '@material-ui/core';
import Autocomplete from '@material-ui/lab/Autocomplete';
import DocumentBroadSubject from '../../../interfaces/MediaIndexer/DocumentBroadSubject';

interface BroadSubjectsProps {
  options: DocumentBroadSubject[];
  handleValueChangeFunction: Function;
}

function getOptionRender(option: DocumentBroadSubject): JSX.Element {
  return (
    <>
      <Grid item xs={11}>
        <span>{option.name}</span>
      </Grid>
    </>
  );
}

export default function BroadSubjects(props: BroadSubjectsProps): JSX.Element {
  return (
    <>
      {/* <Typedown
        labelText="Broad Subjects"
        inputValue=""
        placeholderText=""
        getSuggestionsListFunction={getBroadSubjects}
        onValueChangeFunction={props.handleValueChangeFunction}
      /> */}
      <Autocomplete
        multiple
        id="tags-standard"
        options={props.options}
        onChange={() => props.handleValueChangeFunction}
        renderInput={(params: any) => (
          <TextField
            {...params}
            variant="standard"
            label="Broad Subject"
            margin="normal"
            fullWidth
          />
        )}
        renderOption={(option: DocumentBroadSubject) => getOptionRender(option)}
        renderTags={() => <></>}
      />
    </>
  );
}
