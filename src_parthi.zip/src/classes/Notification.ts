import {
  Record, Static, Array,
} from 'runtypes';

const NotificationRuntype = Array(Record({}));

type NotificationData = Static<typeof NotificationRuntype>;

class Notification {
  data: NotificationData;

  constructor(data: NotificationData) {
    try {
      NotificationRuntype.check(data);
      this.data = data;
    } catch (error) {
      console.error(`Unable to process ClientConfigurationData. [${error.key} - ${error.message}]`, error);
      throw error;
    }
  }

  static empty() {
    return new Notification([]);
  }
}

export default Notification;
