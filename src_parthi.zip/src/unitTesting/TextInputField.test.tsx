import React from 'react';
import { mount } from 'enzyme';
import TextInputField from '../components/Shared/TextInputField';

const wrapper = mount(
  <TextInputField
    labelText="This is a test label"
    inputText="This is test input text"
    required={false}
    keyName="Enzyme Test Input"
    onChangeFunction={() => undefined}
    onBlur={() => undefined}
    error={false}
    classes={{}}
  />,
);

describe('TextInputField Tests', () => {
  it('should display label that is passed into props', () => {
    expect(
      wrapper.contains('This is a test label'),
    ).toBe(true);
  });
});
