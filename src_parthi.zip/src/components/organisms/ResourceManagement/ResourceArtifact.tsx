import React from 'react';
import {
  Paper, makeStyles, createStyles, Theme, Grid, Typography, Divider, Button,
} from '@material-ui/core';
import { useHistory } from 'react-router-dom';

import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import SmallChip from '../../molecules/SmallChip';

import ArtifactLock from '../ArtifactLock';
import SecondaryData from '../../molecules/SecondaryData';
import { ResourceArtifactExtendItem } from '../../../interfaces/ResourceList/ResourceArticleData';
import BooleanIndicatorCircle from '../../molecules/BooleanIndicatorCircle';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    padding: theme.spacing(2),
    transition: 'all 0.2s',
    paddingRight: theme.spacing(6),
    position: 'relative',
  },
  rmitNumber: {
    fontSize: '0.85rem',
    marginLeft: theme.spacing(2),
    fontWeight: 600,
  },
  title: {
    fontSize: '0.85rem',
    marginLeft: theme.spacing(2),
  },
  row: {
    display: 'flex',
  },
  divider: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(1),
  },
  workflowState: {
    alignSelf: 'center',
    marginLeft: 'auto',
  },
  unlock: {
    marginLeft: 'auto',
  },
  navigateChevron: {
    visibility: 'visible',
    position: 'absolute',
    right: 0,
    top: '50%',
    opacity: 1,
    transition: 'all 0.2s',
    transform: 'translateY(-50%)',
  },
  button: {
    borderRadius: 50,

    right: 0,
    top: '50%',
    '& .MuiButton-label': {
      maxHeight: '15px',
    },
  },
}));

interface Props {
    result: ResourceArtifactExtendItem;
    canUnlock: boolean;
    updateItem(item: ResourceArtifactExtendItem): void;
}

export default function TextResult(props: Props) {
  const classes = useStyles();
  const history = useHistory();

  const navigateToIndexerUi = (): void => {
    history.push(`/artifact/${props.result.artifactId.toString()}`);
  };
  const unlock = () => {
    props.updateItem({ ...props.result, indexer: '' });
  };

  return (
    <Grid container>
      <Grid item xs={12}>
        <Paper className={classes.root}>
          <Grid container>
            <Grid item xs={12}>
              <Grid container>
                <Grid item xs={11} className={classes.row}>
                  <SmallChip label="TEXT ARTICLE" />

                  {/* A_001 Record Number */}
                  <Typography className={classes.rmitNumber}>{props.result.masId}</Typography>
                  {/* A_041 Section : Name: A_007 Title */}
                  <Typography className={classes.title}>
                    {props.result.sectionName}
                    :
                    {' '}
                    {props.result.itemTitle}
                  </Typography>
                  {props.result.indexer && (
                    <ArtifactLock
                      className={classes.unlock}
                      artifactId={props.result.artifactId}
                      canUnlock={props.canUnlock}
                      indexer={props.result.indexer}
                      title={props.result.itemTitle ?? props.result.masId}
                      onUnlocked={unlock}
                    />
                  )}

                </Grid>
                <Grid item xs={1} className={classes.row}>
                  <Button
                    size="small"
                    color="primary"
                    variant="outlined"
                    onClick={navigateToIndexerUi}
                    endIcon={<ArrowForwardIcon />}
                    className={classes.button}
                  >
                    Open
                  </Button>
                </Grid>
              </Grid>
              <Divider className={classes.divider} />
              <Grid container>
                <Grid item xs={9} className={classes.row}>
                  {/* A_047 Article Order */}
                  <SecondaryData title="Article Order" content={props.result.articleOrder} alwaysDisplay variantName="subtitle1" />

                  {/* A_011 Resource Type */}
                  <SecondaryData title="Resource Type" content={props.result.resourceType} alwaysDisplay variantName="subtitle1" />

                  {/* A_020 Pagination */}
                  <SecondaryData title="Pagination" content={props.result.pagination} alwaysDisplay variantName="subtitle1" />

                  {/* A_036 Peer Reviewed Article Indicator */}
                  <Typography>
                    <SecondaryData title="Peer Reviewed" content="" alwaysDisplay variantName="subtitle1" />
                    <Grid style={{ display: 'flex', justifyContent: 'left' }}>
                      <BooleanIndicatorCircle name="Active" status={props.result.peerReviewedArticleIndicator} />
                    </Grid>
                  </Typography>

                  {/* A_050 Publish Artefact */}
                  <Typography>
                    <SecondaryData title="Publish Artefact" content="" alwaysDisplay variantName="subtitle1" />
                    <Grid style={{ display: 'flex', justifyContent: 'left' }}>
                      <BooleanIndicatorCircle name="Active" status={props.result.publishArtefact} />
                    </Grid>
                  </Typography>

                </Grid>
                <Grid item xs={3} className={classes.row}>
                  {/* A_055 Artefact Indexing StatusWorkflow */}
                  <SmallChip className={classes.workflowState} label={props.result.workflowState} />
                </Grid>
              </Grid>

            </Grid>

          </Grid>

        </Paper>
      </Grid>
    </Grid>
  );
}
