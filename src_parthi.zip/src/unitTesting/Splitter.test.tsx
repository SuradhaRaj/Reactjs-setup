/* eslint-disable @typescript-eslint/no-empty-function */
import React from 'react';
import { mount } from 'enzyme';
import { MuiThemeProvider } from '@material-ui/core';
import Dropzone from '../components/organisms/TextIndexer/Dropzone';
import Splitter from '../components/organisms/Splitter';
import theme from '../config/theme';

describe('Splitter', () => {
  const wrapper = mount(
    <MuiThemeProvider theme={theme}>
      <Splitter
        isReplace={false}
        handleSuccessfulCompletion={() => {}}
        issuePath=""
        issueId={1234}
        downloadFiles={[]}
      />
      ,
    </MuiThemeProvider>,
  );

  it('should allow the user to drop files', () => {
    expect(wrapper.find(Dropzone).props().disabled).toBeFalsy();
  });
});
