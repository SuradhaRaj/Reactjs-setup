import React from 'react';
import {
  Grid, makeStyles, Theme, createStyles, Paper, Typography,
} from '@material-ui/core';
import {
  useHistory, useRouteMatch, useLocation,
} from 'react-router-dom';
import { GenerateLicenceTemplateQueryString, LicenceTemplateQueryParams, LicenceTemplateQueryParamKeys } from '../../../interfaces/Organisation/LicenceQueryParams';
import LicenceTemplateList from './LicenceTemplatesList';
import GetOrganisationReferenceDataResponse from '../../../interfaces/Organisation/GetOrganisationReferenceDataResponse';
import LicenceTemplate from '../../../interfaces/Organisation/LicenceTemplate';

const useStyles = makeStyles((theme: Theme) => createStyles({
  paper: {
    padding: theme.spacing(3),
    textAlign: 'center',
  },
}));

interface LicenceTemplatesProps {
  licenceTemplates: LicenceTemplate[];
  onChangeHandler(newLicenceTemplates: LicenceTemplate[]): void;
  referenceData: GetOrganisationReferenceDataResponse;
};

interface LicenceTemplatesState {
  licenceTemplateToEdit: number;
}

const LicenceTemplates: React.FC<LicenceTemplatesProps> = (props) => {
  const [state, setState] = React.useState<LicenceTemplatesState>({
    licenceTemplateToEdit: 0,
  });

  const classes = useStyles();
  const history = useHistory();
  const match = useRouteMatch();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);

  // on location change, check the query params to determine if the licence should be open
  React.useEffect(() => {
    const licenceTemplateId = Number(queryParams.get(LicenceTemplateQueryParamKeys.licenceTemplateId));

    setState((prevState) => ({
      ...prevState,
      licenceTemplateToEdit: licenceTemplateId,
    }));
  }, [location]);

  const onLicenceChangeHandler = (licenceTemplate: LicenceTemplate) => {
    const originalLicenceTemplateIndex = props.licenceTemplates.findIndex((l) => l.licenceTemplateId === licenceTemplate.licenceTemplateId);

    if (originalLicenceTemplateIndex !== -1) {
      const newLicenceTemplates = [...props.licenceTemplates];
      newLicenceTemplates[originalLicenceTemplateIndex] = licenceTemplate;
      props.onChangeHandler(newLicenceTemplates);
    }
  };

  const onEditLicenceTemplateClick = (licenceTemplateId: number) => {
    const params: LicenceTemplateQueryParams = { licenceTemplateId };
    history.push(`${match.url}${GenerateLicenceTemplateQueryString(params)}`);
  };

  const closeDialog = () => (
    history.push(match.url)
  );

  return (
    <>
      <Grid container>
        {props.licenceTemplates.length ? (
          <>
            <Grid item xs={12}>
              <LicenceTemplateList
                onLicenceTemplateChangeHandler={onLicenceChangeHandler}
                referenceData={props.referenceData}
                onEditClick={onEditLicenceTemplateClick}
                licenceTemplates={props.licenceTemplates}
                handleCloseDialog={closeDialog}
                templateIdToEdit={state.licenceTemplateToEdit}
              />
            </Grid>
          </>
        ) : (
          <Grid item xs={12}>
            <Paper className={classes.paper}>
              <Typography>
                There are currently no licence templates to view.
              </Typography>
            </Paper>
          </Grid>
        )}
      </Grid>
    </>
  );
};

export default LicenceTemplates;
