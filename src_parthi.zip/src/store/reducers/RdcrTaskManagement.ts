import {
  ActionTypes, UPDATE_TASK_LIST, UPDATE_FILTERS, CLEAR_FILTERS,
} from '../actions/ActnTaskManagement';
import TaskManagementTask from '../../interfaces/TaskManagementTask';
import TaskManagementFilters from '../../classes/TaskManagementFilters';

export interface TaskManagementState {
  FilteredTasks: Array<TaskManagementTask>;
  AllTasks: Array<TaskManagementTask>;
  Filters: TaskManagementFilters;
}

export const initialState: TaskManagementState = {
  FilteredTasks: [],
  AllTasks: [],
  Filters: TaskManagementFilters.empty(),
};

export default (state = initialState, action: ActionTypes): TaskManagementState => {
  switch (action.type) {
    case UPDATE_TASK_LIST:
      return {
        ...state,
        FilteredTasks: state.Filters.filterTasks(action.payload),
        AllTasks: action.payload,
      };
    case UPDATE_FILTERS:
      return {
        ...state,
        FilteredTasks: action.payload.filterTasks(state.AllTasks),
        Filters: action.payload,
      };
    case CLEAR_FILTERS:
      return {
        ...state,
        FilteredTasks: [...state.AllTasks],
        Filters: TaskManagementFilters.empty(),
      };
    default:
      return state;
  }
};
