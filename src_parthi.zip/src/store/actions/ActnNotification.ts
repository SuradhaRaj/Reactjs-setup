import Notification from '../../classes/Notification';

export const ADD_NOTIFICATION = 'ADD_NOTIFICATION';
export const REMOVE_NOTIFICATION = 'REMOVE_NOTIFICATION';

interface AddNotification {
  type: typeof ADD_NOTIFICATION;
  payload: Notification;
}
interface RemoveNotification {
  type: typeof REMOVE_NOTIFICATION;
  payload: Notification;
}

export type ActionTypes = AddNotification | RemoveNotification;

export function addNotification(data: Notification): ActionTypes {
  return {
    type: ADD_NOTIFICATION,
    payload: data,
  };
}

export function removeNotification(data: Notification): ActionTypes {
  return {
    type: REMOVE_NOTIFICATION,
    payload: data,
  };
}
