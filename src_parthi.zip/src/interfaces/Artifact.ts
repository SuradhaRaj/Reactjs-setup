import ArtifactType from './enums/ArtifactType';

type Artifact = {
  artifactType: ArtifactType;

  artifactId: number;
}

export default Artifact;
