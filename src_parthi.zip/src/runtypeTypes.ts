import {
  String, Number, Array, Runtype, Record,
} from 'runtypes';
import { DateTime } from 'luxon';

export const NonEmptyString = String.withConstraint((s) => !!s || 'Non empty string is required');
export const NumberGreaterZero = Number.withConstraint((n) => n > 0);
export const IsoDate = String.withConstraint((d) => DateTime.fromISO(d).isValid);
export const LifeStartEndDate = String.withConstraint((d) => Math.max(0, parseInt(d)).toString().length <= 4 || 'Number with not more than 4 digits required');
export const ArrayWithElements = <T extends Runtype>(t: T) => Array(t).withConstraint((a) => a.length > 0 || 'Non empty array is required');
export const KeyValue = <T extends Runtype>(t: T) => Record({ Key: NumberGreaterZero, Value: t });
