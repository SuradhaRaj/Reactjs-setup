import React, { useContext } from 'react';
import { makeStyles, createStyles, Theme } from '@material-ui/core/styles';
import { Typography, Paper } from '@material-ui/core';
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';
import MediaResult from './MediaResult';
import SearchResult from '../../../interfaces/Search/SearchResult';
import ArtifactSearchIndex from '../../../interfaces/enums/ArtifactSearchIndex';
import MediaSearchResult from '../../../interfaces/Search/MediaSearchResult';
import ErrorPaper from '../ErrorPaper';
import { AppContext } from '../../Context';
import LoadingResult from './LoadingResult';
import TextResult from './TextResult';
import TextSearchResult from '../../../interfaces/Search/TextSearchResult';
import OrganisationSearchResult from '../../../interfaces/Search/OrganisationSearchResult';
import OrganisationResult from './OrganisationResult';
import TitleResult from './TitleResult';
import TitleSearchResult from '../../../interfaces/Search/TitleSearchResult';
import IssueResult from './IssueResult';
import IssueSearchResult from '../../../interfaces/Search/IssueSearchResult';

interface Props {
  isLoading: boolean;
  results: Array<SearchResult>;
  updateItem(item: SearchResult): void;
}

const useStyles = makeStyles((theme: Theme) => createStyles({
  result: {
    marginBottom: theme.spacing(2),
  },
  noResults: {
    padding: theme.spacing(4),
    textAlign: 'center',
  },
  warningIcon: {
    color: theme.palette.warning.main,
    marginRight: theme.spacing(1),
  },
  headingRoot: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: theme.spacing(2),
  },
}));

function SearchResults(props: Props) {
  const context = useContext(AppContext);
  const canUnlock = context.userInfo.isInAnyRole(['InformitAdmin', 'IndexersAdmin']);

  const getSearchResult = (item: SearchResult) => {
    switch (item.searchIndex) {
      case ArtifactSearchIndex.Media:
        return (
          <MediaResult
            result={item as MediaSearchResult}
            canUnlock={canUnlock}
            key={item.id}
            updateItem={props.updateItem}
          />
        );
      case ArtifactSearchIndex.Article:
        return (
          <TextResult
            result={item as TextSearchResult}
            canUnlock={canUnlock}
            key={item.id}
            updateItem={props.updateItem}
          />
        );
      case ArtifactSearchIndex.Organisation:
        return (
          <OrganisationResult
            result={item as OrganisationSearchResult}
            key={item.id}
          />
        );
      case ArtifactSearchIndex.Title:
        return (
          <TitleResult
            result={item as TitleSearchResult}
            key={item.id}
          />
        );
      case ArtifactSearchIndex.Issue:
        return (
          <IssueResult
            result={item as IssueSearchResult}
            key={item.id}
          />
        );
      default:
        return (<ErrorPaper text="Unable to determine result type." />);
    }
  };

  const classes = useStyles();

  if (props.isLoading) {
    return (
      <>
        {[...Array(3)].map(() => (
          <div data-loading-group className={classes.result}>
            <LoadingResult />
          </div>
        ))}
      </>
    );
  }

  if (props.results.length === 0) {
    return (
      <Paper data-no-results className={classes.noResults}>
        <div className={classes.headingRoot}>
          <ErrorOutlineIcon className={classes.warningIcon} />
          <Typography><strong>No results found</strong></Typography>
        </div>
        <Typography>We could not find any results, please modify your search.</Typography>
      </Paper>
    );
  }

  return (
    <>
      {props.results.map((item) => (<div className={classes.result}>{getSearchResult(item)}</div>))}
    </>
  );
}

export default React.memo(SearchResults);
