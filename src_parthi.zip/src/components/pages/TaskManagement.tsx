import React, { useEffect, useState } from 'react';
import Grid from '@material-ui/core/Grid';
import Axios, { AxiosResponse } from 'axios';

import {
  Paper, Drawer, Button, Hidden, CircularProgress, Typography,
} from '@material-ui/core';
import { useDispatch } from 'react-redux';
import { makeStyles, createStyles, Theme } from '@material-ui/core/styles';
import FilterListIcon from '@material-ui/icons/FilterList';
import { ExportToCsv } from 'export-to-csv';
import TaskManagementTable from '../organisms/TaskManagementTable';
import LoadingTable from '../organisms/LoadingTable';
import ErrorPaper from '../organisms/ErrorPaper';
import TaskManagementFilters, { SelectedFilter } from '../organisms/TaskManagementFilters';
import { updateTaskManagementList } from '../../store/actions/ActnTaskManagement';
import { useTypedSelector } from '../../store/store';
import TaskManagementTask from '../../interfaces/TaskManagementTask';
import { isKeyValue } from '../../interfaces/TaskManagementText/TextTaskManagementRequest';
import WorkflowStatus, { WorkflowStatusDisplayNames } from '../../interfaces/enums/WorkflowStatus';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    paddingLeft: theme.spacing(2),
    paddingRight: theme.spacing(2),
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
  },
  paper: {
    position: 'sticky',
    top: theme.spacing(2),
  },
  filterIcon: {
    marginLeft: theme.spacing(1),
  },
  updatingSpinner: {
    position: 'absolute',
    top: -36,
    right: 12,
    display: 'flex',
    alignItems: 'center',
  },
}));

const csvoptions = {
  fieldSeparator: ',',
  quoteStrings: '"',
  decimalSeparator: '.',
  showLabels: true,
  showTitle: true,
  filename: 'Exported_CSV',
  useTextFile: false,
  useBom: true,
  useKeysAsHeaders: true,
};

interface QueryRequestParams extends Omit<SelectedFilter, 'status'> {
    status: { key: number; value: string }[];
}

let queryParam: SelectedFilter = {
  channel: [],
  status: [],
  program: [],
  product: [],
  broadcastdate: [],
};

interface Pager {
    pages: number[];
    totalItems: number;
    currentPage: number;
    pageSize: number;
    totalPages: number;
}

interface State {
  IsError: boolean;
  IsLoading: boolean;
  FilterDrawerOpen: boolean;
  IsUpdating: boolean;
    Pager?: Pager;
    NumPerPage: number;
}

export default (): JSX.Element => {
  const [state, setState] = useState<State>({
    IsError: false,
    IsLoading: true,
    FilterDrawerOpen: false,
    IsUpdating: false,
    NumPerPage: 100,

  });

  const classes = useStyles();
  const tasks = useTypedSelector((store) => store.TaskManagement.FilteredTasks);
  const allTasks = useTypedSelector((store) => store.TaskManagement.AllTasks);

  const dispatch = useDispatch();
  const toggleDrawer = () => {
    setState((prevState) => ({
      ...prevState,
      FilterDrawerOpen: !prevState.FilterDrawerOpen,
    }));
  };

  function updateMediaPage(numPerPage: number, page: number) {
    Axios.get(`${process.env.REACT_APP_API_URL}/api/taskmanagement/media?pageSize=${state.NumPerPage}&page=${page}`)

      .then((response) => {
        setState({
          ...state,
          IsLoading: false,
          IsError: false,
          IsUpdating: false,
          Pager: response.data.pager,
        });

        dispatch(updateTaskManagementList(response.data.artifactListItems));
      })
      .catch(() => {
        setState({
          ...state,
          IsLoading: false,
          IsError: true,
          IsUpdating: false,
        });
      });
  };

  useEffect(() => {
    if (allTasks.length === 0) {
      setState((prevState) => ({
        ...prevState,
        IsLoading: true,
        IsUpdating: true,
      }));
    } else {
      setState((prevState) => ({
        ...prevState,
        IsLoading: false,
        IsUpdating: true,
      }));
    }

    updateMediaPage(state.NumPerPage, 1);
  }, []);

  // function paginationHandleChange(event: React.ChangeEvent<unknown>, value: number) {
  //  setState({
  //    ...state,
  //    IsLoading: true,
  //  });

  //  updateMediaPage(state.NumPerPage, value);
  // }

  const processRequestQuery = (queryObject: SelectedFilter | undefined, page?: number, numPerPage?: number) => {
    // page = ;
    // numPerPage = ;
    const queryRequest: QueryRequestParams & { page: number; pageSize: number; exportCSV: boolean } = {
      channel: [],
      status: [],
      program: [],
      product: [],
      broadcastdate: [],
      page: page ?? 1,
      pageSize: numPerPage ?? state.NumPerPage,

      exportCSV: false,
    };
    let statusResult: { key: number; value: string }[];
    if (queryObject !== undefined) {
      statusResult = queryObject.status
        .map((x) => {
          const id = Object.keys(WorkflowStatusDisplayNames).find((key) => WorkflowStatusDisplayNames[parseInt(key) as keyof {
                [key in WorkflowStatus]: string;
            }] === x);
          return { key: Number(id), value: x };
        });
    } else {
      statusResult = [];
    }
    queryParam = queryObject || queryParam;
    const queryfinal: QueryRequestParams = {
      ...queryParam,
      status: statusResult,
    };

    if (queryfinal !== null && queryfinal !== undefined) {
      Object.keys(queryfinal).forEach((x) => {
        // @ts-ignore
        queryRequest[x] = Array.isArray(queryfinal[x])
        // @ts-ignore
          ? queryfinal[x].map((item) => (isKeyValue(item) ? { key: item.id, value: item.value } : item))
        // @ts-ignore
          : queryfinal[x];
      });
    }
    // ['dates', 'datesLog'].forEach((dategroup) => {
    //    // @ts-ignore
    //    queryRequest[dategroup] = queryRequest[dategroup].map((x: DateFromToField) => {
    //        const datefield = { ...x } as DateFromToField;
    //        datefield.from = datefield.from !== '' ? new Date(datefield.from as string) : null;
    //        datefield.to = datefield.to !== '' ? new Date(datefield.to as string) : null;

    //        return datefield;
    //    })
    //        // @ts-ignore
    //        .filter((x) => x.from !== null && x.to !== null);
    // });

    return queryRequest;
  };

  const checkFiltered = (queryObject: SelectedFilter): boolean => {
    let isFiltered = false;
    if (queryObject !== null && queryObject !== undefined) {
      // @ts-ignore
      isFiltered = Object.keys(queryObject).reduce((sum, x) => (Array.isArray(x) && queryObject[x].length > 0) || sum, false);
    } else {
      isFiltered = true;
    }

    return isFiltered;
  };

  const downloadCSV = (queryJson: SelectedFilter) => {
    const isFiltered = checkFiltered(queryJson);
    setState((prestate) => ({ ...prestate, filterSelected: queryJson, isFiltered }));
    const queryRequest = processRequestQuery(queryJson, 1, state.NumPerPage);
    queryRequest.exportCSV = true;
    Axios.post(`${process.env.REACT_APP_API_URL}/api/taskmanagement/media`, queryRequest)
      .then((response: AxiosResponse<{ data: TaskManagementTask; pager: Pager }>) => {
        const records = response.data.data;

        // setHasTasks(true);
        const csvExporter = new ExportToCsv(csvoptions);
        csvExporter.generateCsv(records);
      })
      .catch(() => {
        setState((prevState) => ({
          ...prevState,
          isError: true,
        }));
      });
  };

  return (
    <>
      { !state.IsError ? (
        <>
          <Grid container justify="center" spacing={2} className={classes.root}>
            <Hidden mdDown>
              <Grid item xs={3} lg={2} xl={2}>
                <Paper className={classes.paper}>
                  <TaskManagementFilters isLoading={state.IsLoading} onDownloadCSV={downloadCSV} />
                </Paper>
              </Grid>
            </Hidden>
            <Grid item xs={11} md={10} xl={8}>
              {!state.IsLoading ? (
                <Grid container style={{ position: 'relative' }}>
                  <Grid item xs={2}>
                    <Hidden lgUp>
                      <Drawer open={state.FilterDrawerOpen} onClose={() => toggleDrawer()}>
                        <TaskManagementFilters isLoading={state.IsLoading} onDownloadCSV={downloadCSV} />
                      </Drawer>
                      <Button variant="text" color="primary" onClick={() => toggleDrawer()}>
                        Filter
                        {' '}
                        <FilterListIcon className={classes.filterIcon} />
                      </Button>
                    </Hidden>
                  </Grid>
                  <Grid item xs={12} style={{ position: 'relative' }}>
                    <TaskManagementTable data={tasks} />
                    {state.Pager

                      ? (
                        <>

                        </>
                      )
                      : ''}

                    {state.IsUpdating && (
                    <div className={classes.updatingSpinner}>
                      <CircularProgress size={20} />
                      <Typography variant="overline" style={{ display: 'inline', marginLeft: 6 }}>Updating</Typography>
                    </div>
                    )}
                  </Grid>
                </Grid>
              ) : (
                <LoadingTable NumberOfRows={3} />
              )}
            </Grid>
          </Grid>
        </>
      ) : (<ErrorPaper text="Unable to load the list of tasks." />)}
    </>
  );
};
