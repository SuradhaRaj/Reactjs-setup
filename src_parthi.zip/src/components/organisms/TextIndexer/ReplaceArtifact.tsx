import React, { useState, useContext } from 'react';
import CachedIcon from '@material-ui/icons/Cached';
import {
  Button, makeStyles, createStyles, Dialog, Theme, ListItemIcon, ListItemText,
} from '@material-ui/core';
import { useSnackbar } from 'notistack';
import Splitter from '../Splitter';
import { IndexerArtifactContext } from '../../contexts/IndexerArtifact';
import TextData from '../../../interfaces/TextIndexer/TextData';
import ConfirmationDialog from '../../molecules/ConfirmationDialog';
import StyledMenuItem from '../../molecules/StyledMenuItem';

const useStyles = makeStyles((theme: Theme) => createStyles({
  button: {
    borderRadius: 50,
    margin: 5,
  },
  dialog: {
    padding: theme.spacing(4),
  },
}));

interface State {
  showReplaceDialog: boolean;
  showWarningDialog: boolean;
}

interface Props {
  artifactId: number;
  menuOption?: boolean;
  isPublished?: boolean;
}

export default function ReplaceArtifact(props: Props) {
  const [state, setState] = useState<State>({
    showReplaceDialog: false,
    showWarningDialog: false,
  });
  const classes = useStyles();
  const context = useContext(IndexerArtifactContext);
  const artifact = context.Artifact as TextData;
  const snackbar = useSnackbar();

  const toggleReplaceDialog = (open: boolean) => {
    setState((prevState) => ({ ...prevState, showReplaceDialog: open }));
  };

  const toggleWarningDialog = (open: boolean) => {
    setState((prevState) => ({ ...prevState, showWarningDialog: open }));
  };

  const success = (didRestartWorkflow: boolean) => {
    toggleReplaceDialog(false);

    snackbar.enqueueSnackbar('Artifact replacement successful', { variant: 'success' });

    if (didRestartWorkflow) {
      // if the workflow has been restarted, we want to make the page readonly so the user can use the table of contents to navigate somewhere else
      context.updateArtifact<TextData>({
        ...artifact,
        isReadOnly: true,
      });
      context.setHasChanges(false);
    } else {
      context.setShouldRefreshArtifact(true);
    }
  };

  const handleReplaceButtonClick = () => {
    if (context.hasChanges) {
      toggleWarningDialog(true);
    } else {
      toggleReplaceDialog(true);
    };
  };

  const handleWarningResponse = (shouldProceed: boolean) => {
    toggleWarningDialog(false);
    if (shouldProceed) toggleReplaceDialog(true);
  };

  return (
    <>
      {props.menuOption ? (
        <>
          <StyledMenuItem>
            <ListItemIcon>
              <CachedIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText
              primary="Replace"
              onClick={handleReplaceButtonClick}
            />
          </StyledMenuItem>
        </>
      ) : (
        <>
          <Button
            variant="contained"
            color="primary"
            size="small"
            type="button"
            startIcon={<CachedIcon />}
            onClick={handleReplaceButtonClick}
            className={classes.button}
          >
            Replace
          </Button>
        </>
      )}
      <ConfirmationDialog
        dialogTitle="Are you sure you want to continue?"
        dialogBodyText="If you continue with replacing the artifact, you will lose any unsaved changes"
        onProceed={() => handleWarningResponse(true)}
        onReturn={() => handleWarningResponse(false)}
        isOpen={state.showWarningDialog}
        successButtonText="Continue"
      />
      <Dialog onClose={() => toggleReplaceDialog(false)} open={state.showReplaceDialog} fullWidth maxWidth="lg">
        <div className={classes.dialog}>
          <Splitter
            downloadFiles={artifact.dropboxIssue?.files || []}
            handleSuccessfulCompletion={success}
            isDisabled={false}
            isPublished={props.isPublished}
            isReplace
            issueId={artifact.dropboxIssue?.issueId}
            issuePath={`${artifact.dropboxIssue?.resourceId}\\${artifact.dropboxIssue?.grouping}`}

            artifactId={props.artifactId}

          />
        </div>
      </Dialog>
    </>
  );
}
