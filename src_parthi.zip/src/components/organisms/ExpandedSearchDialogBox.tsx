/* eslint @typescript-eslint/no-explicit-any: 0 */
import React, { useState } from 'react';
import {
  Dialog, useTheme, useMediaQuery, DialogTitle, DialogContent, DialogContentText,
  DialogActions, Button, TextField, makeStyles, createStyles, Grid, Typography,
} from '@material-ui/core';
import Autocomplete, { AutocompleteRenderOptionState } from '@material-ui/lab/Autocomplete';
import match from 'autosuggest-highlight/match';
import parse from 'autosuggest-highlight/parse';
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';
import StringExtensions from '../../utils/StringExtensions';

const useStyles = makeStyles(() => createStyles({
  textField: {
    marginTop: '0px',
  },
  renderOptionHighlighted: {
    fontWeight: 550,
  },
  dialogContent: {
    overflowY: 'visible',
  },
}));

interface Props {
  open: boolean;
  handleAddOptionFunction: Function;
  handleCloseFunction: Function;
  searchApiEndpoint: string;
  title: string;
  subheading: string;
  artifactTypeId: number;
}

interface State {
  options: SearchOption[];
  loading: boolean;
}

interface SearchOption {
  id: number;
  name: string;
  count: number;
  warningText: string;
}

export default function ExpandedSearchDialogBox(props: Props): JSX.Element {
  const fullScreen = useMediaQuery(useTheme().breakpoints.down('sm'));
  const classes = useStyles();

  const [state, setState] = useState<State>({
    options: [],
    loading: false,
  });

  const getSearchResults = (searchTerm: string): Promise<SearchOption[]> => {
    const returnList: SearchOption[] = [];
    const suggestionsPromise = new Promise<SearchOption[]>((resolve, reject) => {
      setState((prevState) => ({
        ...prevState,
        options: [],
      }));

      fetch(`${process.env.REACT_APP_API_URL}/api/${props.searchApiEndpoint}?searchTerm=${searchTerm}&artifactTypeId=${props.artifactTypeId}`)
        .then((res) => res.json())
        .then(
          (result) => {
            if (result.status === 200) {
              for (let i = 0; i < result.results.length; i += 1) {
                returnList.push({
                  id: result.results[i].fastID,
                  name: result.results[i].name,
                  count: result.results[i].count,
                  warningText: result.results[i].warningText,
                });
              }
            }
            resolve(returnList);
          },
          (error: Error) => {
            reject(error);
          },
        ).finally(() => {
          setState((prevState) => ({
            ...prevState,
            loading: false,
          }));
        });
    });

    return suggestionsPromise;
  };

  const clearTypedownOptions = (): void => {
    setState((prevState) => ({
      ...prevState,
      options: [],
    }));
  };

  const handleSearchTermChange = (event: any): void => {
    const value: string = event.target.value;

    if (value.length > 2 && value.length < 100) {
      getSearchResults(value)
        .then((result: SearchOption[]) => {
          setState((prevState) => ({
            ...prevState,
            options: result,
          }));
        });
    }
  };

  const getOptionRender = (option: SearchOption, renderOptionState: AutocompleteRenderOptionState): JSX.Element => {
    if (option.id === 0) {
      return (
        <>
          <Grid item xs={11}>
            <span>{option.name}</span>
          </Grid>
        </>
      );
    }

    if (option.warningText === '' || option.warningText === null) {
      const matches = match(option.name, renderOptionState.inputValue);
      const parts = parse(option.name, matches);

      return (
        <>
          <Grid item xs={11}>
            {parts.map((part) => (
              <span className={part.highlight ? classes.renderOptionHighlighted : ''}>
                {/* If the first character of a non-matched part is a non-ascii character, do not render it. */}
                {part.text && StringExtensions.RemoveInitialNonAscii(part.text)}
              </span>
            ))}
          </Grid>
        </>
      );
    }

    return (
      <>
        <Grid item xs={11}>
          <span>{option.name}</span>
        </Grid>
        <Grid item xs={1}>
          <ErrorOutlineIcon />
        </Grid>
      </>
    );
  };

  return (
    <Dialog
      fullScreen={fullScreen}
      open={props.open}
      onClose={() => props.handleCloseFunction()}
      aria-labelledby="responsive-dialog-title"
    >
      <DialogTitle id="responsive-dialog-title">{props.title}</DialogTitle>
      <DialogContent className={classes.dialogContent}>
        <DialogContentText>
          <Typography variant="body2" gutterBottom>
            {props.subheading}
          </Typography>
        </DialogContentText>
        <Autocomplete
          multiple
          filterOptions={(x) => (x)}
          options={state.options}
          onOpen={() => clearTypedownOptions}
          onChange={(event: object, value: SearchOption[]) => props.handleAddOptionFunction(value[0].id, value[0].name, value[0].warningText)}
          renderInput={(params: any) => (
            <TextField
              {...params}
              className={classes.textField}
              variant="outlined"
              label={props.title}
              margin="normal"
              fullWidth
              onChange={handleSearchTermChange}
            />
          )}
          renderOption={(option: SearchOption, renderOptionState: AutocompleteRenderOptionState) => getOptionRender(option, renderOptionState)}
          renderTags={() => <></>}
        />
      </DialogContent>
      <DialogActions>
        <Button autoFocus onClick={() => props.handleCloseFunction()} color="primary">
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
}
