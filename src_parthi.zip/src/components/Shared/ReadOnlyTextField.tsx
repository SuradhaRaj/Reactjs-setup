import React from 'react';
import Grid from '@material-ui/core/Grid';
import {
  Typography, FormLabel, makeStyles, createStyles, Theme,
} from '@material-ui/core';
import classnames from 'classnames';

const useStyles = makeStyles((theme: Theme) => createStyles({
  formLabel: {
    fontSize: '14px',
    fontWeight: 600,
    color: '#000054',
  },
  displayText: {
    fontSize: '12px',
    color: '#000054',
  },
  oneLineMargin: {
    marginLeft: theme.spacing(1),
  },
}));

interface ReadOnlyTextFieldProps {
  labelText: string;
    displayText: string | number | null | JSX.Element |undefined;
  oneLine: boolean;
}

export default function ReadOnlyTextField(props: ReadOnlyTextFieldProps): JSX.Element {
  const classes = useStyles();

  return (
    <Grid container alignItems="baseline">
      <Grid item xs={props.oneLine ? 3 : 12}>
        <FormLabel className={classes.formLabel}>{props.labelText}</FormLabel>
      </Grid>
      <Grid item xs={props.oneLine ? 9 : 12}>
        <Typography className={classnames(classes.displayText, { [classes.oneLineMargin]: props.oneLine })}>{props.displayText}</Typography>
      </Grid>
    </Grid>
  );
}
