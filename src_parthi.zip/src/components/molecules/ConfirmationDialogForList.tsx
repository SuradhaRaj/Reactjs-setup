import React from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, Button, Typography,
} from '@material-ui/core';

interface Props {
  dialogTitle: string;
  dialogBodyText: string;
  dialogBodyList: string[];
  onProceed(): void;
  onReturn(): void;
  isOpen: boolean;
}

const ConfirmationDialogForList: React.FC<Props> = (props) => (
  <Dialog
    open={props.isOpen}
    keepMounted
    aria-labelledby="alert-dialog-slide-title"
    aria-describedby="alert-dialog-slide-description"
    maxWidth="md"
  >
    <DialogTitle id="alert-dialog-slide-title">{props.dialogTitle}</DialogTitle>
    <DialogContent>
      <DialogContentText id="alert-dialog-slide-description">
        <Typography variant="subtitle2">{props.dialogBodyText}</Typography>
        <br />
        <ul>
          {props.dialogBodyList.map((value) => (
            <li>{value}</li>
          ))}
        </ul>
      </DialogContentText>
    </DialogContent>
    <DialogActions>
      <Button onClick={props.onReturn} variant="outlined" color="primary">
        Return
      </Button>
      <Button onClick={props.onProceed} variant="text" color="primary">
        Confirm
      </Button>
    </DialogActions>
  </Dialog>
);

export default ConfirmationDialogForList;
