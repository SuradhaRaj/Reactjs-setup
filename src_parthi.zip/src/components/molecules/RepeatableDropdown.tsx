import React from 'react';
import {
  Zoom, Chip, Grid, TextField, makeStyles, createStyles,
} from '@material-ui/core';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { DateTime } from 'luxon';
import DocumentItemNode from '../../interfaces/MediaIndexer/DocumentItemNode';
import LookupOption from '../../interfaces/LookupOption';

const useStyles = makeStyles(createStyles({
  Autocomplete: {
    width: '100%',
  },
}));

interface RepeatableDropdownProps {
  selectedOptions: DocumentItemNode[];
  initiallySelectedOptions: DocumentItemNode[];
  currentUser: string;
  allOptions: LookupOption[];
  disabled?: boolean;
  error?: boolean;
  errorMessage?: string;
  keyName: string;
  label: string;
  onChangeFunction(key: string, value: DocumentItemNode[]): void;
};

const RepeatableDropdown = (props: RepeatableDropdownProps) => {
  const classes = useStyles();

  const addSelectedOption = (event: React.ChangeEvent<{}>, newOption: LookupOption | null) => {
    // first check if the item has already been added, if so, do nothing
    if (!newOption || props.selectedOptions.find((option) => option.id === newOption.key)) return;

    // then check if it had been added initially
    const initialOption = props.initiallySelectedOptions.find((option) => option.id === newOption.key);
    if (initialOption) {
      props.onChangeFunction(props.keyName, [...props.selectedOptions, initialOption]);
    } else {
      const newSelection: DocumentItemNode = {
        name: newOption.value,
        id: newOption.key,
        createdBy: props.currentUser,
        createdDate: DateTime.local().toString(),
      };

      props.onChangeFunction(props.keyName, [...props.selectedOptions, newSelection]);
    }
  };

  const removeSelectedOption = (deletedOption: DocumentItemNode) => {
    if (props.selectedOptions !== undefined) {
      const newSelectedOptions = [...props.selectedOptions].filter((option) => option.name !== deletedOption.name);
      props.onChangeFunction(props.keyName, newSelectedOptions);
    }
  };

  const renderChips = () => {
    if (props.selectedOptions !== undefined) {
      return (
        props.selectedOptions.map((option: DocumentItemNode) => (
          <Zoom in={props.selectedOptions?.includes(option)} key={option.id}>
            <Chip
              tabIndex={-1}
              style={{ margin: '5px' }}
              variant="outlined"
              disabled={props.disabled}
              label={option.name}
              onDelete={() => removeSelectedOption(option)}
              color="primary"
            />
          </Zoom>
        ))
      );
    }

    return null;
  };

  return (
    <>
      <Grid container xs={12}>
        <Autocomplete
          options={props.allOptions}
          getOptionLabel={(option) => option.value}
          onChange={addSelectedOption}
          className={classes.Autocomplete}
          disabled={props.disabled}
          renderInput={(params) => (
            <TextField
              {...params}
              variant="outlined"
              label={props.label}
              margin="normal"
              // className={classes.identifiersTextField}
              fullWidth
              error={props.error}
              helperText={props.error ? props.errorMessage : ''}
            />
          )}
        />
      </Grid>
      <Grid container xs={9}>
        {renderChips()}
      </Grid>
    </>
  );
};

export default RepeatableDropdown;
