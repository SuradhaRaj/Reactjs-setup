import React from 'react';
import Paper from '@material-ui/core/Paper';
import {
  makeStyles, Theme, createStyles, Typography,
} from '@material-ui/core';
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    padding: theme.spacing(4),
    alignContent: 'center',
    // height: 64,
  },
  textContainer: {
    display: 'inline-block',
    textAlign: 'left',
    marginLeft: theme.spacing(2),
  },
  errorIcon: {
    verticalAlign: 'top',
    display: 'inline-block',
  },
}));

interface Props {
  title: string;
  secondaryText: string;
}

export default function ErrorPaper(props: Props): JSX.Element {
  const classes = useStyles();

  return (
    <>
      <Paper className={classes.root}>
        <ErrorOutlineIcon color="secondary" className={classes.errorIcon} />
        <div className={classes.textContainer}>
          <Typography>
            {props.title}
          </Typography>
          <Typography
            color="textSecondary"
          >
            {props.secondaryText}
          </Typography>
        </div>
      </Paper>
    </>
  );
}
