import { Record, Static, Boolean } from 'runtypes';
import { NonEmptyString, NumberGreaterZero } from '../../runtypeTypes';

export const ContactRoleValidator = Record({
  name: NonEmptyString,
  isCRM: Boolean,
  contactRoleId: NumberGreaterZero,
});

type ContactRole = Static<typeof ContactRoleValidator>;

export default ContactRole;
