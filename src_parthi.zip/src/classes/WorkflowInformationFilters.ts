import {
  Record, Array as RtArray, Static, String, Number, Undefined,
} from 'runtypes';
import { some } from 'lodash';
import Filters from './Filters';
import { KeyValue } from '../interfaces/TaskManagementText/TextTaskManagementRequest';
import LookupOption, { LookupOptionValidator } from '../interfaces/LookupOption';
// import { ListType } from '../components/organisms/ResourceManagement/TitleInformation';
import { TypedownOption, StrStrTypedownOption } from '../interfaces/TypedownOption';

interface WorkflowInformationFiltersData {
  resourcetype: Array<TypedownOption | StrStrTypedownOption>;
  resource: Array<TypedownOption | StrStrTypedownOption>;
  search: string;
  workflowStatus: Array<TypedownOption | StrStrTypedownOption>;
  accessRights: Array<TypedownOption | StrStrTypedownOption>;
  indexingCompany: Array<TypedownOption | StrStrTypedownOption>;
  resourceManager: Array<TypedownOption | StrStrTypedownOption>;
  resourceSV: string;
  resourcetypeSV: string;
}
const RuntypeDeclaration = Record({

  resourcetype: RtArray(Record({ id: Number, value: String })).Or(Undefined),
  resource: RtArray(Record({ id: Number, value: String })).Or(Undefined),
  search: String,
  workflowStatus: RtArray(Record({ id: Number, value: String })).Or(Undefined),
  accessRights: RtArray(Record({ id: Number, value: String })).Or(Undefined),
  indexingCompany: RtArray(Record({ id: Number, value: String })).Or(Undefined),
  resourceManager: RtArray(Record({ id: Number, value: String })).Or(Undefined),
  resourceSV: String,
  resourcetypeSV: String,
});
type WorkflowInformationFiltersDataRt = Static<typeof RuntypeDeclaration>;

class WorkflowInformationFilters extends Filters<WorkflowInformationFiltersData> {
  constructor(filterContent: WorkflowInformationFiltersDataRt) {
    try {
      RuntypeDeclaration.check(filterContent);

      super({

        resourcetype: filterContent.resourcetype === undefined ? [] : filterContent.resourcetype,
        resource: filterContent.resource === undefined ? [] : filterContent.resource,
        search: filterContent.search === '' ? '' : filterContent.search,
        workflowStatus: filterContent.workflowStatus === undefined ? [] : filterContent.workflowStatus,
        accessRights: filterContent.accessRights === undefined ? [] : filterContent.accessRights,
        indexingCompany: filterContent.indexingCompany === undefined ? [] : filterContent.indexingCompany,
        resourceManager: filterContent.resourceManager === undefined ? [] : filterContent.resourceManager,
        resourceSV: filterContent.resourceSV === '' ? '' : filterContent.resourceSV,
        resourcetypeSV: filterContent.resourceSV === '' ? '' : filterContent.resourceSV,
      });
    } catch (error) {
      console.error(error);
      throw error;
    }
  }

  static empty() {
    return new WorkflowInformationFilters({
      search: '',
      resourceSV: '',
      resourcetypeSV: '',
      resourcetype: [],
      resource: [],
      workflowStatus: [],
      accessRights: [],
      indexingCompany: [],
      resourceManager: [],

    });
  }

  // filterTasks(tasksToFilter: TitleInformation[]): TitleInformation[] {
  //    const compare = (item1: string, item2: string) => item1.trim().toUpperCase() === item2.trim().toUpperCase();

  //    let results = tasksToFilter;

  //    if (results.length > 0) {
  //        //if (this.data.uniformtitle.length > 0) {
  //        //    results = results.filter((task) => some(this.data.uniformtitle, (filterItem) => compare(task.uniformtitle, filterItem.value)));
  //        //}
  //        //if (this.data.language.length > 0) {
  //        //    results = results.filter((task) => some(this.data.language, (filterItem) => compare(task.language, filterItem.value)));
  //        //}
  //        //if (this.data.frequency.length > 0) {
  //        //    results = results.filter((task) => some(this.data.frequency, (filterItem) => compare(task.frequency, filterItem.value)));
  //        //}
  //    }
  //    return results;
  // };
}

export default WorkflowInformationFilters;
