import React from 'react';
import {
  makeStyles,
  Theme,
  createStyles,
  ExpansionPanel,
  Grid,
  ExpansionPanelSummary,
  ExpansionPanelDetails,
  ExpansionPanelActions,
  Button,
  Typography,
} from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import LicenceReadonlyFields from './LicenceTemplateReadonlyFields';
import GetOrganisationReferenceDataResponse from '../../../interfaces/Organisation/GetOrganisationReferenceDataResponse';
import LookupOption from '../../../interfaces/LookupOption';
import LicenceTemplate, { LicenceTemplateValidator } from '../../../interfaces/Organisation/LicenceTemplate';
import useRuntypeError from '../../hooks/useRuntypeError';
import LicenceTemplateDialog from './LicenceTemplateDialog';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    marginTop: theme.spacing(1),
  },
  panelTitle: {
    fontSize: '1rem',
    fontWeight: 500,
  },
}));

interface LicenceTemplatesListItemProps{
  licenceTemplate: LicenceTemplate;
  referenceData: GetOrganisationReferenceDataResponse;
  onEditLicenceClick: () => void;
  dialogOpen: boolean;
  handleCloseDialog(): void;
  onLicenceTemplateChangeHandler(newTemplateLicence: LicenceTemplate): void;
};

const getValueFromLookup = (lookup: LookupOption[], id: number | null) => (
  lookup.find((lo) => lo.key === id)?.value || null
);

export const LicenceTemplatesListItem: React.FunctionComponent<LicenceTemplatesListItemProps> = (props) => {
  const classes = useStyles();
  const runtypeValidator = useRuntypeError(LicenceTemplateValidator);

  React.useEffect(() => {
    runtypeValidator.validate(props.licenceTemplate);
  }, [props.licenceTemplate]);

  if (!runtypeValidator.isValid) {
    return <div>{runtypeValidator.error()}</div>;
  }

  return (
    <>
      <ExpansionPanel>
        <ExpansionPanelSummary
          expandIcon={<ExpandMoreIcon />}
        >
          <Grid container>
            <Grid item xs={4}>
              <Typography className={classes.panelTitle}>
                {props.licenceTemplate.agreementNumber}
              </Typography>
            </Grid>
          </Grid>
        </ExpansionPanelSummary>
        <ExpansionPanelDetails>
          <LicenceReadonlyFields
            clearedBy={getValueFromLookup(props.referenceData.clearedBy, props.licenceTemplate.clearedById)}
            accessType={getValueFromLookup(props.referenceData.accessType, props.licenceTemplate.accessTypeId)}
            contractStartDate={props.licenceTemplate.contractStartDate}
            contractEndDate={props.licenceTemplate.contractEndDate}
            price={props.licenceTemplate.price}
            accessRights={getValueFromLookup(props.referenceData.accessRight, props.licenceTemplate.accessRightId)}
            royaltyRate={props.licenceTemplate.royaltyRate}
          />
        </ExpansionPanelDetails>
        <ExpansionPanelActions>
          <Button
            onClick={props.onEditLicenceClick}
            color="primary"
            variant="contained"
          >
            View/Edit Template
          </Button>
        </ExpansionPanelActions>
      </ExpansionPanel>
      <LicenceTemplateDialog
        ccLicenceTypeLookup={props.referenceData.ccLicenceType}
        clearedByLookup={props.referenceData.clearedBy}
        clearanceStatusLookup={props.referenceData.clearanceStatus}
        accessRightsLookup={props.referenceData.accessRight}
        accessTypeLookup={props.referenceData.accessType}
        licenceTemplate={props.licenceTemplate}
        onLicenceTemplateChangeHandler={props.onLicenceTemplateChangeHandler}
        open={props.dialogOpen}
        handleClose={props.handleCloseDialog}
      />
    </>
  );
};

interface LicenceTemplatesListProps {
  licenceTemplates: LicenceTemplate[];
  referenceData: GetOrganisationReferenceDataResponse;
  onEditClick: (licenceTemplateId: number) => void;
  templateIdToEdit: number | null;
  handleCloseDialog(): void;
  onLicenceTemplateChangeHandler(newTemplateLicence: LicenceTemplate): void;
}

const LicenceTemplatesList: React.FunctionComponent<LicenceTemplatesListProps> = (props) => {
  const classes = useStyles();

  return (
    <Grid container className={classes.root}>
      <Grid item xs={12}>
        {props.licenceTemplates.map((template) => (
          <LicenceTemplatesListItem
            key={template.licenceTemplateId}
            referenceData={props.referenceData}
            licenceTemplate={template}
            onEditLicenceClick={() => props.onEditClick(template.licenceTemplateId)}
            dialogOpen={template.licenceTemplateId === props.templateIdToEdit}
            handleCloseDialog={props.handleCloseDialog}
            onLicenceTemplateChangeHandler={props.onLicenceTemplateChangeHandler}
          />
        ))}
      </Grid>
    </Grid>
  );
};

export default LicenceTemplatesList;
