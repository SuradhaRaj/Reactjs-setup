import {
  Record, Number, String, Static, Null, Partial,
} from 'runtypes';

export const TypedownOptionValidator = Record({
  id: Number,
  value: String,
  // adds scope note as an optional parameter similar to scopeNote?: string | null
}).And(Partial({
  scopeNote: String.Or(Null),
}));

export const StrStrTypedownOptionValidator = Record({
  id: String,
  value: String,
}).And(Partial({
  scopeNote: String.Or(Null),
}));

export type TypedownOption = Static<typeof TypedownOptionValidator>;
export type StrStrTypedownOption = Static<typeof StrStrTypedownOptionValidator>;

export default TypedownOption;
