import React, { useState, useContext } from 'react';
import {
  BrowserRouter as Router,
  Route,
  NavLink,
} from 'react-router-dom';
import {
  makeStyles, createStyles, Divider, Theme,
} from '@material-ui/core';
import { Functions } from 'firebase/functions';
import { UserContext } from '../Layout';
import { AppContext } from '../Context';

const useStyles = makeStyles((theme: Theme) => createStyles({

  divider: {
    marginTop: 1,
  },

}));

const Dashboard = () => <div>Dashboard</div>;
const Resource = () => <div>Resource</div>;
export default function NavbarText() {
  const classes = useStyles();
  // const currentPath = window.location.pathname;
  // @ts-ignore
  const { navstate, setNavState } = useContext(UserContext);
  const context = useContext(AppContext);
  const isAdmin = context.userInfo.isInAnyRole(['InformitAdmin', 'IndexersAdmin']);
  console.log(navstate);
  console.log(isAdmin);
  return (
    <nav className="nav-bar">

      <ul className="nav-links">
        {navstate.isClicked ? (

          <li>
            <NavLink to="/" exact>
              Dashboard
            </NavLink>
          </li>
        ) : null}
        {navstate.isClicked && isAdmin ? (

          <>
            <Divider orientation="vertical" flexItem variant="middle" />
            <li>

              <NavLink to="/resource-management" activeClassName="active">
                Resource Management
              </NavLink>
            </li>
          </>
        ) : null}
        {navstate.isClicked ? (
          <>
            <Divider orientation="vertical" flexItem variant="middle" />
            <li>
              <NavLink to="/tasks/text" activeClassName="active">Indexing</NavLink>
            </li>
          </>
        ) : null}
      </ul>
    </nav>

  );
}
