import LogEventData from '../../interfaces/Events/LogEventData';

export const UPDATE_LOGEVENT_DATA = 'UPDATE_LOGEVENT_DATA';

interface UpdateLogEventDataAction {
  type: typeof UPDATE_LOGEVENT_DATA;
  payload: LogEventData;
}

export type ActionTypes = UpdateLogEventDataAction;

export function updateLogEventData(data: LogEventData): ActionTypes {
  return {
    type: UPDATE_LOGEVENT_DATA,
    payload: data,
  };
}
