const CleanHtmlString = (stringToClean: string): string => {
  const doc = new DOMParser();

  let stringContent = doc.parseFromString(stringToClean, 'text/html').body.textContent;
  // lets do a rudimentary check to see if we still have html.
  // it could be that the html itself was also encoded.
  if (stringContent?.includes('<')) {
    stringContent = doc.parseFromString(stringContent, 'text/html').body.textContent;
  }

  return stringContent || '';
};

const RemoveInitialNonAscii = (stringToFormat: string): string => (
  stringToFormat.charCodeAt(0) <= 127 ? stringToFormat : stringToFormat.substr(1)
);

export default {
  CleanHtmlString,
  RemoveInitialNonAscii,
};
