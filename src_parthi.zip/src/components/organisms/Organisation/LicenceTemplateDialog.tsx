import React from 'react';
import {
  DialogProps, Dialog, DialogTitle, DialogContent, DialogActions, Button, Typography,
} from '@material-ui/core';
import Axios from 'axios';
import { useSnackbar } from 'notistack';
import { useFormik } from 'formik';
import { isEqual } from 'lodash';
import * as Yup from 'yup';
import LicenceTemplateForm from './LicenceTemplateForm';
import LoadingButton from '../../molecules/LoadingButton';
import ButtonWithDialog from '../../molecules/ButtonWithDialog';
import LookupOption from '../../../interfaces/LookupOption';
import LicenceTemplate from '../../../interfaces/Organisation/LicenceTemplate';
import SaveLicenceTemplateRequest from '../../../interfaces/Organisation/SaveLicenceTemplateRequest';
import DateExtensions from '../../../utils/DateExtensions';
import SaveLicenceTemplateResponse from '../../../interfaces/Organisation/SaveLicenceTemplateResponse';

interface LicenceTemplateDialogProps extends Omit<DialogProps, 'disableBackdropClick' | 'onClose' | 'maxWidth' | 'fullWidth'>{
  licenceTemplate: LicenceTemplate;
  handleClose(): void;
  onLicenceTemplateChangeHandler(newTemplateLicence: LicenceTemplate): void;
  clearanceStatusLookup: LookupOption[];
  accessRightsLookup: LookupOption[];
  clearedByLookup: LookupOption[];
  ccLicenceTypeLookup: LookupOption[];
  accessTypeLookup: LookupOption[];
}

interface LicenceTemplateDialogState {
  submitting: boolean;
}

const LicenceTemplateDialog: React.FC<LicenceTemplateDialogProps> = (props) => {
  const [state, setState] = React.useState<LicenceTemplateDialogState>({
    submitting: false,
  });

  const { enqueueSnackbar } = useSnackbar();

  const formik = useFormik<LicenceTemplate>({
    initialValues: {
      ...props.licenceTemplate,
      // first we need to convert the response iso date strings to yyy-mm-dd format
      contractStartDate: DateExtensions.convertDateToFormFormat(props.licenceTemplate.contractStartDate),
      contractEndDate: DateExtensions.convertDateToFormFormat(props.licenceTemplate.contractEndDate),
    },
    validationSchema: Yup.object().shape<Partial<LicenceTemplate>>({
      price: Yup
        .number()
        .required('Price is required')
        .min(0, 'Invalid price'),
    }),
    onSubmit: () => undefined,
  });

  // reset the form whenever the licence template changes
  React.useEffect(() => {
    formik.resetForm();
  }, [props.licenceTemplate]);

  const submitLicenceTemplate = (template: LicenceTemplate) => {
    setState((prevState) => ({
      ...prevState,
      submitting: true,
    }));

    const requestData: SaveLicenceTemplateRequest = {
      template,
    };

    Axios.post<SaveLicenceTemplateResponse>(`${process.env.REACT_APP_API_URL}/api/organisation/savelicencetemplate`, requestData)
      .then((response) => {
        props.onLicenceTemplateChangeHandler(response.data.template);
        enqueueSnackbar('Licence template updated successfully', { variant: 'success' });
        props.handleClose();
      })
      .catch(() => {
        enqueueSnackbar('An error occurred while trying to update the licence template', { variant: 'error' });
      })
      .finally(() => {
        setState((prevState) => ({
          ...prevState,
          submitting: false,
        }));
      });
  };

  const handleSubmit = () => {
    if (formik.isValid) {
      // we first need to make sure we convert the dates from yyyy-mm-dd format to ISO format
      const {
        contractStartDate,
        contractEndDate,
      } = formik.values;

      const licenceTemplate: LicenceTemplate = {
        ...formik.values,
        contractStartDate: DateExtensions.convertFormDatesToIso(contractStartDate),
        contractEndDate: DateExtensions.convertFormDatesToIso(contractEndDate),
      };

      submitLicenceTemplate(licenceTemplate);
    }
  };

  const formHasChanges = () => !isEqual(formik.initialValues, formik.values);

  return (
    <>
      <Dialog
        {...props}
        maxWidth="md"
        fullWidth
        disableBackdropClick
      >
        <DialogTitle>
          Update Licence Template
        </DialogTitle>
        <DialogContent>
          <LicenceTemplateForm
            ccLicenceTypeLookup={props.ccLicenceTypeLookup}
            clearanceStatusLookup={props.clearanceStatusLookup}
            accessRightsLookup={props.accessRightsLookup}
            accessTypeLookup={props.accessTypeLookup}
            clearedByLookup={props.clearedByLookup}
            licenceTemplateValues={formik.values}
            submitting={state.submitting}
            handleChange={formik?.handleChange || (() => undefined)}
            handleBlur={formik?.handleBlur}
            setFieldValue={formik?.setFieldValue || (() => undefined)}
            errors={formik?.errors}
          />
        </DialogContent>
        <DialogActions>
          {formHasChanges() ? (
            <ButtonWithDialog
              buttonProps={{
                color: 'primary',
              }}
              dialogTitle="Discard changes?"
              dialogContent={() => (
                <Typography>
                  Are you sure you want to
                  {' '}
                  <strong>discard</strong>
                  {' '}
                  all of your current changes?
                </Typography>
              )}
              dialogActions={(closeDialog) => (
                <>
                  <Button variant="outlined" color="primary" onClick={() => closeDialog()}>Cancel</Button>
                  <Button color="primary" onClick={() => { closeDialog(); props.handleClose(); }}>Discard changes</Button>
                </>
              )}
            >
              Discard
            </ButtonWithDialog>
          ) : (
            <Button
              color="primary"
              disabled={state.submitting}
              onClick={props.handleClose}
            >
              Close
            </Button>
          )}
          {formHasChanges() && (
            <LoadingButton
              color="primary"
              isLoading={state.submitting}
              onClick={handleSubmit}
              disabled={!formik.isValid}
            >
              Update
            </LoadingButton>
          )}
        </DialogActions>
      </Dialog>
    </>
  );
};

export default LicenceTemplateDialog;
