import React from 'react';
import {
  makeStyles, createStyles, Zoom, Chip, Button, Grid,
} from '@material-ui/core';
import TextInputField from '../Shared/TextInputField';

const useStyles = makeStyles(createStyles({
  chipContainer: {
    textAlign: 'left',
  },
  addButton: {
    top: '15px',
    marginLeft: '10px',
  },
}));

interface RepeatableTextInputFieldProps {
  addedItems: string[];
  onChangeFunction(key: string, value: string[], shouldValidate?: boolean): void;
  keyName: string;
  labelText: string;
  error?: boolean;
  onBlur: Function;
  disabled?: boolean;
  errorMessage?: string;
  className?: string;
}

interface RepeatableTextInputFieldState {
  inputText: string;
}

const RepeatableTextInputField = (props: RepeatableTextInputFieldProps) => {
  const classes = useStyles();

  const [state, setState] = React.useState<RepeatableTextInputFieldState>({ inputText: '' });

  const handleTextChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setState({
      ...state,
      inputText: event.target.value.trim(),
    });
  };

  const removeItem = (deletedItem: string) => {
    const newSelectedItems = [...props.addedItems].filter((item) => item !== deletedItem);
    props.onChangeFunction(props.keyName, newSelectedItems, true);
  };

  const addItem = (newItem: string) => {
    if (!props.addedItems.includes(newItem)) {
      props.onChangeFunction(props.keyName, [...props.addedItems, newItem], true);
    }
    setState((prevState) => ({
      ...prevState,
      inputText: '',
    }));
  };

  const renderChips = () => (
    props.addedItems.map((item) => (
      <Zoom in={props.addedItems?.includes(item)} key={item}>
        <Chip
          tabIndex={-1}
          style={{ margin: '5px' }}
          variant="outlined"
          size="medium"
          disabled={props.disabled}
          label={item}
          onDelete={() => removeItem(item)}
          color="primary"
        />
      </Zoom>
    ))
  );

  return (

    <div className={props.className}>
      <Grid container>
        <Grid item xs={11} style={{ position: 'relative' }}>
          <TextInputField
            labelText={props.labelText}
            value={state.inputText}
            inputText=""
            onChangeFunction={handleTextChange}
            keyName={props.keyName}
            error={props.error || false}
            onBlur={props.onBlur}
            errorMessage={props.error ? props.errorMessage : ''}
            readOnly={props.disabled}
          />
        </Grid>
        <Grid item xs={1}>
          {state.inputText.trim() !== '' && (
            <Button
              onClick={() => addItem(state.inputText)}
              disabled={props.disabled}
              className={classes.addButton}
            >
              add
            </Button>
          )}
        </Grid>
      </Grid>
      <Grid container item xs={9} className={classes.chipContainer}>
        {renderChips()}
      </Grid>
    </div>
  );
};

export default RepeatableTextInputField;
