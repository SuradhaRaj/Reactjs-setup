import { DateTime, Duration } from 'luxon';
import LuxonExtensions from '../../utils/LuxonExtensions';

describe('Luxon extensions - ToFriendlyDateString', () => {
  it('should contain "today" for a date 10 minutes ago', () => {
    const date = DateTime.local().minus(10000);
    const result = LuxonExtensions.ToFriendlyDateString(date);

    expect(result).toContain('Today');
  });

  it('should contain "today" for a date right now', () => {
    const date = DateTime.local();
    const result = LuxonExtensions.ToFriendlyDateString(date);

    expect(result).toContain('Today');
  });

  // this fails on the build server
  // it('should contain "yesterday" for a date yesterday', () => {
  //   const date = DateTime.local().minus({ hour: 25 });
  //   const result = LuxonExtensions.ToFriendlyDateString(date);

  //   expect(result).toContain('Yesterday');
  // });

  it('should contain "today" for 12:00am last night', () => {
    const date = DateTime.local().startOf('day');
    const result = LuxonExtensions.ToFriendlyDateString(date);

    expect(result).toContain('Today');
  });

  it('should contain the month for a date last week', () => {
    const date = DateTime.local().minus({ day: 7 });
    const shortMonth = date.toFormat('LLL');
    const result = LuxonExtensions.ToFriendlyDateString(date);

    expect(result).toContain(shortMonth);
  });

  it('should contain the month for a date before yesterday', () => {
    const date = DateTime.local().minus({ day: 2 });
    const shortMonth = date.toFormat('LLL');
    const result = LuxonExtensions.ToFriendlyDateString(date);

    expect(result).toContain(shortMonth);
  });
});

describe('Luxon extensions - FormatDuration', () => {
  it('should show hh mm ss', () => {
    const duration = Duration.fromObject({ hour: 1, minute: 2, second: 3 });
    const result = LuxonExtensions.FormatDuration(duration.shiftTo('second').seconds);

    expect(result).toBe('1h 2m 3s');
  });

  it('should show ss', () => {
    const duration = Duration.fromObject({ second: 3 });
    const result = LuxonExtensions.FormatDuration(duration.shiftTo('second').seconds);

    expect(result).toBe('3s');
  });

  it('should show mm', () => {
    const duration = Duration.fromObject({ minute: 3 });
    const result = LuxonExtensions.FormatDuration(duration.shiftTo('second').seconds);

    expect(result).toBe('3m');
  });

  it('should show hh', () => {
    const duration = Duration.fromObject({ hour: 2 });
    const result = LuxonExtensions.FormatDuration(duration.shiftTo('second').seconds);

    expect(result).toBe('2h');
  });
});
