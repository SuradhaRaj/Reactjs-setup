import TaskManagementTask from '../../interfaces/TaskManagementTask';
import TaskManagementFilters from '../../classes/TaskManagementFilters';

export const UPDATE_TASK_LIST = 'UPDATE_TASK_MANAGEMENT_LIST';
export const UPDATE_FILTERS = 'UPDATE_FILTERS';
export const CLEAR_FILTERS = 'CLEAR_FILTERS';

interface UpdateTaskListAction {
  type: typeof UPDATE_TASK_LIST;
  payload: Array<TaskManagementTask>;
}

interface UpdateFiltersAction {
  type: typeof UPDATE_FILTERS;
  payload: TaskManagementFilters;
}

interface ClearFiltersAction {
  type: typeof CLEAR_FILTERS;
}

export type ActionTypes = UpdateTaskListAction | UpdateFiltersAction | ClearFiltersAction;

export function updateTaskManagementList(tasks: Array<TaskManagementTask>): ActionTypes {
  return {
    type: UPDATE_TASK_LIST,
    payload: tasks,
  };
}

export function updateFilters(newFilters: TaskManagementFilters): ActionTypes {
  return {
    type: UPDATE_FILTERS,
    payload: newFilters,
  };
}

export function clearFilters(): ActionTypes {
  return {
    type: CLEAR_FILTERS,
  };
}
