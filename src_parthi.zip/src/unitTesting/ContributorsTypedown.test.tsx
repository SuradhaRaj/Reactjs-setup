import React from 'react';
import { mount } from 'enzyme';
import { CircularProgress } from '@material-ui/core';
import { ContributorsTypedown } from '../components/molecules/MediaIndexer/ContributorsTypedown';

describe('Contributors Typedown Tests', () => {
  it('loading wheel should react to loading flag changes', () => {
    const wp = mount((
      <ContributorsTypedown
        selectedContributors={[]}
        onChangeFunction={() => undefined}
        classes={{}}
        errorSnackbarFunction={() => undefined}
      />
    ));

    // loading should be hidden
    expect(wp.contains(<CircularProgress color="inherit" size={20} />)).toBeFalsy();

    // set loading to true
    wp.setState({ loading: true });

    // check is loading is shown
    expect(wp.contains(<CircularProgress color="inherit" size={20} />)).toBeTruthy();

    // set loading to false
    wp.setState({ loading: false });

    // check is loading is not shown
    expect(wp.contains(<CircularProgress color="inherit" size={20} />)).toBeFalsy();
  });
});
