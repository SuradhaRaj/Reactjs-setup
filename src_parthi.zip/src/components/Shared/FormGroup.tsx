import {
  createStyles, Grid, makeStyles, Theme, Typography,
} from '@material-ui/core';
import React from 'react';

const FormGroup = (props: React.PropsWithChildren<{ groupName: string; isFirst?: boolean }>) => {
  const useStyles = makeStyles((theme: Theme) => createStyles({
    groupingTitle: {
      borderRight: 'solid 2px #e6e6e6',
      borderTop: () => (!props.isFirst ? 'solid 2px #e6e6e6' : 'none'),
      textAlign: 'right',
      paddingTop: theme.spacing(2),
      paddingRight: theme.spacing(2),

    },
    formPanel: {
      padding: theme.spacing(2),
    },
    sticky: {
      position: 'sticky',
      top: 10,
    },
  }));
  const classes = useStyles();

  return (
    <Grid container>
      <Grid item xs={2} className={classes.groupingTitle}>
        <div className={classes.sticky}>
          <Typography variant="overline">{props.groupName}</Typography>
        </div>
      </Grid>
      <Grid item xs={10} className={classes.formPanel}>
        {props.children}
      </Grid>
    </Grid>
  );
};

export default FormGroup;
