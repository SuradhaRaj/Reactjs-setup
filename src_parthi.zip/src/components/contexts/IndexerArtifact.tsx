import React, { useState } from 'react';
import Axios from 'axios';
import { useSnackbar } from 'notistack';
import Artifact from '../../interfaces/Artifact';
import ArtifactType from '../../interfaces/enums/ArtifactType';

const initialState: State = {
  Artifact: {
    artifactType: ArtifactType.None,

    artifactId: 0,
  },
  shouldRefreshArtifact: false,
  doImplicitUnlock: false,
  hasChanges: null,
};
const initialFunctions: Functions = {
  updateArtifact: () => undefined,
  setDoImplicitUnlock: () => undefined,
  setHasChanges: () => undefined,
  setShouldRefreshArtifact: () => undefined,
  getUpdatedArtifact: () => undefined,
};

export const IndexerArtifactContext = React.createContext<State & Functions>({ ...initialState, ...initialFunctions });

interface Functions {
  updateArtifact<T extends Artifact>(artifact: T): void;
  setDoImplicitUnlock(value: boolean): void;
  setHasChanges(value: boolean): void;
  setShouldRefreshArtifact(value: boolean): void;
    getUpdatedArtifact(): void;
}

interface State {
  Artifact: Artifact;
  doImplicitUnlock: boolean;
  hasChanges: boolean | null;
  shouldRefreshArtifact: boolean | null;
}

export const IndexerArtifactContextProvider: React.FC<React.PropsWithChildren<{}>> = ({ children }) => {
  const [state, setState] = useState<State>(initialState);
  const { enqueueSnackbar } = useSnackbar();
  function updateArtifact<T extends Artifact>(artifact: T) {
    setState((prevState) => ({
      ...prevState,
      Artifact: artifact,
    }));
  };

  function setDoImplicitUnlock(value: boolean): void{
    setState((prevState) => ({
      ...prevState,
      doImplicitUnlock: value,
    }));
  }

  function setHasChanges(value: boolean): void {
    setState((prevState) => ({
      ...prevState,
      hasChanges: value,
    }));
  }

  function setShouldRefreshArtifact(value: boolean): void {
    setState((prevState) => ({
      ...prevState,
      shouldRefreshArtifact: value,
    }));
  };
  function getUpdatedArtifact(): void {
    Axios.get(`${process.env.REACT_APP_API_URL}/api/artifact/getartifact?artifactId=${state.Artifact.artifactId}&type=${state.Artifact.artifactType}`)
      .then((response) => {
        updateArtifact(response.data);
      })
      .catch(() => {
        enqueueSnackbar('An error occurred when trying to get updated artifact', {
          variant: 'error',
        });
      });
  }
  const contextValue = {
    ...state, updateArtifact, setDoImplicitUnlock, setHasChanges, setShouldRefreshArtifact, getUpdatedArtifact,
  };

  return (
    <IndexerArtifactContext.Provider value={contextValue}>
      {children}
    </IndexerArtifactContext.Provider>

  );
};
