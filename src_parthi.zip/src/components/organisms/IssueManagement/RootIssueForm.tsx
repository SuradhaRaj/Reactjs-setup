import React, { forwardRef, useImperativeHandle } from 'react';
import {
  makeStyles, Theme, createStyles, Box,
  Divider, Grid,

} from '@material-ui/core';

import { FormikConfig, useFormik } from 'formik';

import _ from 'lodash';
import Issue from '../../../interfaces/IssueManagement/Issue';

import TextInputField from '../../Shared/TextInputField';

// import IssueValidationSchema from '../../../validationSchemas/IssueValidationSchema';
import ReadOnlyTextField from '../../Shared/ReadOnlyTextField';

import FormGroup from '../../Shared/FormGroup';
import FilterableItem from '../../Shared/FilterableItem';
import SingleCheckbox from '../../molecules/SingleCheckbox';
import Dropdown from '../../Shared/Dropdown';
import { useTypedSelector } from '../../../store/store';
import FastTextField from '../../molecules/FastTextField';

function useFormikTyped(config: FormikConfig<Issue>) {
  return useFormik<Issue>(config);
}

export type RootIssueFormik = ReturnType<typeof useFormikTyped>;

interface Props {
    formik: RootIssueFormik;
    filterValue: string;
    readonly: boolean;
}

interface Handles {
    customFunction: () => void;
}

const RootIssueFormComponent: React.RefForwardingComponent<Handles, Props> = (props, ref) => {
  const useStyles = makeStyles((theme: Theme) => createStyles({
    '@global': {
      input: { display: 'block' },
      '.MuiTextField-root': {
        display: 'block',
        marginTop: 20,
      },
      '.MuiInputBase-root': {
        width: '100%',
      },
      '.MuiOutlinedInput-input': {
        padding: '10px 14px',
        fontSize: '0.8rem',
      },
      '.MuiOutlinedInput-multiline': {
        padding: '10px 14px',
        fontSize: '0.8rem',
      },
      '.MuiChip-label': {
        fontSize: '0.7rem',
      },
      '.MuiChip-root': {
        height: 24,
      },
      '.MuiChip-deleteIcon': {
        height: 16,
      },
      '.MuiFormControl-marginNormal': {
        marginTop: 12,
        marginBottom: 0,
      },
      '.MuiAutocomplete-inputRoot[class*="MuiOutlinedInput-root"] .MuiAutocomplete-input': {
        padding: '3px 0',
      },
      '.MuiInputLabel-outlined': {
        transform: 'translate(14px, 14px) scale(1)',
        fontSize: '0.8rem',
      },
      '.MuiOutlinedInput-root legend': {
        fontSize: '0.6rem',
      },
    },
    formField: {
      marginBottom: theme.spacing(2),
      display: 'block',
    },
    divider: {
      marginTop: theme.spacing(2),
      marginBottom: theme.spacing(2),
    },
  }));

  const formik: RootIssueFormik = props.formik;
  const notesIssueManagementInputRef = React.useRef<HTMLInputElement>();
  const {
    values, errors, handleChange, handleBlur, setFieldValue,
  } = formik;

  const classes = useStyles();
  const referenceData = useTypedSelector((store) => store.IssueReferenceData.IssueReferenceData);

  useImperativeHandle(ref, () => ({
    customFunction: () => {
      if (props.readonly === false && !!notesIssueManagementInputRef.current) {
        notesIssueManagementInputRef.current.focus();
      }
    },
  }));

  return (
    <>
      <form>
        <div className={classes.formField} />
        <FormGroup groupName="Description" isFirst>

          { /* Resource Name */}
          <ReadOnlyTextField
            labelText="Resource Name"
            displayText={values.resouceName}
            oneLine
          />

          { /* Resource Title */}
          <ReadOnlyTextField
            labelText="Resource Title"
            displayText={values.resouceTitle}
            oneLine
          />

          { /* grouping */}
          <ReadOnlyTextField
            labelText="Grouping"
            displayText={values.grouping}
            oneLine
          />

          { /* I_020 Issue Indexing Status */}
          <Box width={4 / 12}>
            <FilterableItem filterValue={props.filterValue} showValues={['issueWorkflowStates']}>
              <div className={classes.formField}>
                <Dropdown
                  id="issueIndexingStatusId"
                  keyName="issueIndexingStatusId"
                  options={_.uniqBy(referenceData.issueWorkflowStates, 'key').map((o) => ({ display: o.value, value: o.key }))}
                  value={values.issueIndexingStatusId ?? null}
                  labelText="Issue Indexing Status"
                  onChangeFunction={(key: string, value: string) => setFieldValue('issueIndexingStatusId',
                    value,
                    true)}
                  error={!!errors.issueIndexingStatusId}
                  errorMessage={errors.issueIndexingStatusId}
                  isReadOnly={props.readonly}
                />
              </div>
            </FilterableItem>
          </Box>

          {/* I_014 publish issue */}
          <Box width={1}>
            <FilterableItem filterValue={props.filterValue} showValues={['publishissue']}>
              <SingleCheckbox
                label="Publish Issue"
                checked={values.publishIssue ?? false}
                onChange={() => { setFieldValue('publishIssue', !values.publishIssue, true); }}
                onBlur={handleBlur}
                keyName="publishIssue"
                error={!!errors.publishIssue}
                helperText={errors.publishIssue}
                isReadOnly={props.readonly}
              />
            </FilterableItem>

          </Box>

          <Divider className={classes.divider} />
          <Grid container style={{ position: 'relative' }}>
            <Grid item xs={6}>
              {/* I_008 volumeNumber */}
              <Box width={8 / 12}>
                <FilterableItem
                  filterValue={props.filterValue}
                  showValues={['volumeNumber']}
                >
                  <TextInputField
                    labelText="Volume Number"
                    value={values.volumeNumber}
                    keyName="volumeNumber"
                    onChangeFunction={handleChange}
                    onBlur={handleBlur}
                    error={!!errors.volumeNumber}
                    errorMessage={errors.volumeNumber}
                    readOnly={props.readonly}
                  />
                </FilterableItem>
              </Box>

            </Grid>
            <Grid item xs={6}>
              {/* I_009 Issue Number */}
              <Box width={8 / 12}>
                <FilterableItem
                  filterValue={props.filterValue}
                  showValues={['issueNumber']}
                >
                  <TextInputField
                    labelText="Issue Number"
                    value={values.issueNumber}
                    keyName="issueNumber"
                    onChangeFunction={handleChange}
                    onBlur={handleBlur}
                    error={!!errors.issueNumber}
                    errorMessage={errors.issueNumber}
                    readOnly={props.readonly}
                  />
                </FilterableItem>
              </Box>
            </Grid>
            <Grid item xs={6}>
              { /* Issue Edition */}
              <Box width={8 / 12}>
                <FilterableItem filterValue={props.filterValue} showValues={['issueEdition']}>
                  <TextInputField
                    labelText="Issue Edition"
                    value={values.issueEdition}
                    keyName="issueEdition"
                    onChangeFunction={handleChange}
                    onBlur={handleBlur}
                    error={!!errors.issueEdition}
                    errorMessage={errors.issueEdition}
                    readOnly={props.readonly}
                  />
                </FilterableItem>
              </Box>
            </Grid>
            <Grid item xs={6}>
              { /*  I_004 Issue Title */}
              <Box width={8 / 12}>
                <FilterableItem filterValue={props.filterValue} showValues={['issueTitle']}>
                  <TextInputField
                    labelText="Issue Title"
                    value={values.issueTitle}
                    keyName="issueTitle"
                    onChangeFunction={handleChange}
                    onBlur={handleBlur}
                    error={!!errors.issueTitle}
                    errorMessage={errors.issueTitle}
                    readOnly={props.readonly}
                  />
                </FilterableItem>
              </Box>
            </Grid>
            <Grid item xs={6}>
              {/*  I_010 Issue Month Season */}
              <Box width={8 / 12}>
                <FilterableItem
                  filterValue={props.filterValue}
                  showValues={['issueMonthSeason']}
                >
                  <TextInputField
                    labelText="Issue Month Season"
                    value={values.issueMonthSeason ?? null}
                    keyName="issueMonthSeason"
                    onChangeFunction={handleChange}
                    onBlur={handleBlur}
                    error={!!errors.issueMonthSeason}
                    errorMessage={errors.issueMonthSeason}
                    readOnly={props.readonly}
                  />
                </FilterableItem>
              </Box>
            </Grid>
            <Grid item xs={6}>
              {/* I_005 publication year */}
              <Box width={8 / 12}>
                <FilterableItem
                  filterValue={props.filterValue}
                  showValues={['publicationYear']}
                >
                  <TextInputField
                    labelText="Publication Year"
                    value={values.publicationYear}
                    keyName="publicationYear"
                    onChangeFunction={handleChange}
                    onBlur={handleBlur}
                    error={!!errors.publicationYear}
                    errorMessage={errors.publicationYear}
                    readOnly={props.readonly}
                  />
                </FilterableItem>
              </Box>
            </Grid>
          </Grid>

          { /* I_021 Notes For Informit (Publisher Notes) */}
          <Box width={8 / 12}>
            <FilterableItem filterValue={props.filterValue} showValues={['notesForInformit']}>
              <FastTextField
                variant="outlined"
                label="Publisher Notes"
                onUpdate={formik.setFieldValue}
                defaultValue={values.notesForRmitPublishing}
                name="notesForRmitPublishing"
                multiline
                rows={3}
                helperText={errors.notesForRmitPublishing}
                error={!!errors.notesForRmitPublishing}
                disabled={props.readonly}

              />
            </FilterableItem>
          </Box>
          <Divider className={classes.divider} />
          <Grid container style={{ position: 'relative' }}>
            <Grid item xs={6}>
              {/* I_006 Date Of Publication */}
              <Box width={8 / 12}>
                <FilterableItem
                  filterValue={props.filterValue}
                  showValues={['dateOfPublication']}
                >
                  <TextInputField
                    labelText="Date Of Publication"
                    value={values.dateOfPublication}
                    keyName="dateOfPublication"
                    onChangeFunction={handleChange}
                    onBlur={handleBlur}
                    error={!!errors.dateOfPublication}
                    errorMessage={errors.dateOfPublication}
                    readOnly={props.readonly}
                  />
                </FilterableItem>
              </Box>

            </Grid>
            <Grid item xs={6}>
              {/* I_016 Schedule Date */}
              <Box width={8 / 12}>
                <FilterableItem
                  filterValue={props.filterValue}
                  showValues={['scheduleDate']}
                >
                  <TextInputField
                    type="date"
                    labelText="Schedule Date"
                    value={values.scheduleDate}
                    keyName="scheduleDate"
                    onChangeFunction={handleChange}
                    onBlur={handleBlur}
                    error={!!errors.scheduleDate}
                    errorMessage={errors.scheduleDate}
                    readOnly={props.readonly}
                  />
                </FilterableItem>
              </Box>
            </Grid>

          </Grid>

          { /* I_022 Issue Management Notes */}
          <Box width={8 / 12}>
            <FilterableItem filterValue={props.filterValue} showValues={['notesIssueManagement']}>
              <FastTextField
                variant="outlined"
                label="Issue Management Notes"
                onUpdate={formik.setFieldValue}
                defaultValue={values.notesIssueManagement}
                name="notesIssueManagement"
                multiline
                rows={3}
                helperText={errors.notesIssueManagement}
                error={!!errors.notesIssueManagement}
                disabled={props.readonly}
                inputRef={notesIssueManagementInputRef}
              />
            </FilterableItem>
          </Box>
          { /* I_021 Notes For Informit */}
          <Box width={8 / 12}>
            <FilterableItem filterValue={props.filterValue} showValues={['notesIndexer']}>
              <FastTextField
                variant="outlined"
                label="Indexer Notes"
                onUpdate={formik.setFieldValue}
                defaultValue={values.notesIndexer}
                name="notesIndexer"
                multiline
                rows={3}
                helperText={errors.notesIndexer}
                error={!!errors.notesIndexer}
                disabled={props.readonly}
              />
            </FilterableItem>
          </Box>

          { /* I_024 Metadata Indexer */}
          <Box width={8 / 12}>
            <TextInputField
              labelText="Metadata Indexer"
              value={values.metadataIndexer}
              keyName="metadataIndexer"
              onChangeFunction={handleChange}
              onBlur={handleBlur}
              error={!!errors.metadataIndexer}
              errorMessage={errors.metadataIndexer}
              readOnly
            />
          </Box>
          { /* I_L&R001 Access Rights */}
          <Box width={4 / 12}>
            <FilterableItem filterValue={props.filterValue} showValues={['accessrights']}>
              <div className={classes.formField}>
                <Dropdown
                  id="accessRightId"
                  keyName="accessRightId"
                  options={referenceData.accessRights.map((o) => ({ display: o.value, value: o.key }))}
                  selectedOption={values.accessRightId ?? null}
                  labelText="Access Rights"
                  onChangeFunction={(key: string, value: string) => setFieldValue('accessRightId',
                    value,
                    true)}
                  error={!!errors.accessRightId}
                  errorMessage={errors.accessRightId}
                  isReadOnly={props.readonly}
                />
              </div>
            </FilterableItem>
          </Box>
          <Grid container style={{ position: 'relative' }}>
            <Grid item xs={6}>
              {/*  Date Of ISSUE HARD COPY RCVD DATE */}
              <Box width={8 / 12}>
                <FilterableItem
                  filterValue={props.filterValue}
                  showValues={['issueHardCopyRcvdDate']}
                >
                  <TextInputField
                    type="date"
                    labelText="Date Of Issue Hard Copy Rcvd Date"
                    value={values.issueHardCopyRcvdDate}
                    keyName="issueHardCopyRcvdDate"
                    onChangeFunction={handleChange}
                    onBlur={handleBlur}
                    error={!!errors.issueHardCopyRcvdDate}
                    errorMessage={errors.issueHardCopyRcvdDate}
                    readOnly={props.readonly}
                  />
                </FilterableItem>
              </Box>
            </Grid>
            <Grid item xs={6}>

              {/*  Date Of ISSUE HARD COPY SENT DATE */}
              <Box width={8 / 12}>
                <FilterableItem
                  filterValue={props.filterValue}
                  showValues={['issueHardCopySentDate']}
                >
                  <TextInputField
                    type="date"
                    labelText="Date Of Issue Hard Copy Sent Date"
                    value={values.issueHardCopySentDate}
                    keyName="issueHardCopySentDate"
                    onChangeFunction={handleChange}
                    onBlur={handleBlur}
                    error={!!errors.issueHardCopySentDate}
                    errorMessage={errors.issueHardCopySentDate}
                    readOnly={props.readonly}
                  />
                </FilterableItem>
              </Box>
            </Grid>
          </Grid>
        </FormGroup>

      </form>

    </>
  );
};
const RootIssueForm = forwardRef(RootIssueFormComponent);
export default RootIssueForm;
