import React from 'react';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableContainer from '@material-ui/core/TableContainer';
import Paper from '@material-ui/core/Paper';
import { getStorageZoomPercent } from '../../utils/LocalStorage';

const useStyles = makeStyles(createStyles({
  tc: {
    zoom: `${getStorageZoomPercent()}%`,
  },
  tableRoot: {
    tableLayout: 'fixed',
    '& .MuiTableCell-body': {
      padding: '0px 5px 0px 5px',
      fontSize: '0.8rem',
      // whiteSpace: 'nowrap',
      textOverflow: 'ellipsis',
      overflow: 'hidden',
    },
    '& .MuiTableCell-head': {
    //  whiteSpace: 'nowrap',
    },
    '& tr': {
      height: 34,
      transition: 'all 0.4s',
    },
  },
}));

export default (props: React.PropsWithChildren<{ forwordRef?: React.RefObject<HTMLDivElement> }>) => {
  const classes = useStyles();

  return (
    <TableContainer component={Paper} ref={props.forwordRef} className={classes.tc}>
      <Table aria-label="simple table" className={classes.tableRoot}>
        {props.children}
      </Table>
    </TableContainer>
  );
};
