import {
  ActionTypes, UPDATE_TASK_LIST, UPDATE_FILTERS, CLEAR_FILTERS,
} from '../actions/ActnTextTaskManagement';
import TextTaskManagementTasks from '../../interfaces/TaskManagementText/TextTaskManagementTasks';
import TextTaskManagementFilters from '../../classes/TextTaskManagementFilters';

export interface TextTaskManagementState {
  FilteredTasks: TextTaskManagementTasks;
  AllTasks: TextTaskManagementTasks;
  Filters: TextTaskManagementFilters;
}

export const initialState: TextTaskManagementState = {
  FilteredTasks: [],
  AllTasks: [],
  Filters: TextTaskManagementFilters.empty(),
};

export default (state = initialState, action: ActionTypes): TextTaskManagementState => {
  switch (action.type) {
    case UPDATE_TASK_LIST:
      return {
        ...state,
        FilteredTasks: state.Filters.filterTasks(action.payload),
        //   FilteredTasks: action.payload,
        AllTasks: action.payload,
      };
    case UPDATE_FILTERS:
      return {
        ...state,
        FilteredTasks: action.payload.filterTasks(state.AllTasks),
        // FilteredTasks: state.AllTasks,
        Filters: action.payload,
      };
    case CLEAR_FILTERS:
      return {
        ...state,
        FilteredTasks: { ...state.AllTasks },
        Filters: TextTaskManagementFilters.empty(),
      };
    default:
      return state;
  }
};
