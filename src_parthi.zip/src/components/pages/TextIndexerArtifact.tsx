import React, { useState } from 'react';
import {
  makeStyles, createStyles, Grid, Button, CircularProgress,
} from '@material-ui/core';
import Alert from '@material-ui/lab/Alert';
import Axios from 'axios';
import bytes from 'bytes';
import GetAppIcon from '@material-ui/icons/GetApp';
import { useHistory, useLocation } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { useSnackbar } from 'notistack';
import SplitPane from 'react-split-pane';
import TextIndexerInputFields from '../organisms/TextIndexer/TextIndexerInputFields';
import StickyNotification from '../molecules/StickyNotification';
import WorkflowInfoDrawer from '../organisms/WorkFlowInfoDrawer';
import MediaWorkflowInfo from '../molecules/MediaWorflowInfo';
import TextData from '../../interfaces/TextIndexer/TextData';
import PdfViewer from '../organisms/PdfViewer';
import ErrorPaper from '../organisms/ErrorPaperWithSecondaryText';
import ReadonlyTextFields from '../molecules/ReadonlyTextFields';
import { TextReferenceDataValidator } from '../../interfaces/TextIndexer/ReferenceData/TextReferenceData';
import ArticleList, { ArticleStep } from '../organisms/ArticleList';
import ArticleStatus from '../../interfaces/enums/ArticleStatus';
import IssueTableOfContents, { TableOfContentsArticle } from '../../interfaces/TextIndexer/IssueTableOfContents';
import { updateTextReferenceData } from '../../store/actions/ActnTextReferenceData';
import { useTypedSelector } from '../../store/store';
import { IndexerArtifactContext } from '../contexts/IndexerArtifact';
import ConvertTextGenresHelper from '../../utils/ConvertTextGenresHelper';
import ConfirmationDialog from '../molecules/ConfirmationDialog';
import { AppContext } from '../Context';
import TextArtifact from '../../interfaces/TextIndexer/TextArtifact';
import ApproveIssueQARequest from '../../interfaces/TextIndexer/ApproveIssueQARequest';
import { TextValidationErrorDialog } from '../organisms/TextIndexer/TextValidationErrorDialog';
import WorkflowStatus, { WorkflowStatusDisplayNames } from '../../interfaces/enums/WorkflowStatus';
import TOCDrawer from '../organisms/TOCDrawer';
import { updateLogEventData } from '../../store/actions/ActnLogEventData';
import EventHelper from '../../utils/EventHelper';

const useStyles = makeStyles(createStyles({
  grid: {
    marginTop: 'none',
  },
  root: {
    flexGrow: 1,
  },
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  indexerPanel: {
    paddingLeft: '12px',
    paddingRight: '12px',
  },
  downloadButton: {
    float: 'right',
    marginRight: '10px',
    borderRadius: '50px',
  },
  stickyRight: {
    position: 'sticky',
    top: (props: TextIndexerArtifactProps) => (props.artifact.isReadOnly ? 64 : 16),
  },
}));

const translateArticlesForList = (articles: TableOfContentsArticle[]) => {
  const articlesStepList: ArticleStep[] = [];
  for (let i = 0; i < articles.length; i++) {
    if (articles[i].workflowState === 'Indexing Complete') {
      articlesStepList.push({
        workflowStatus: articles[i].workflowState,
        id: articles[i].artifactId,
        status: ArticleStatus.Complete,
        title: articles[i].title,
        fallbackTitle: articles[i].fallbackTitle,
        indexer: articles[i].indexer,
      });
    } else if (articles[i].indexer) {
      articlesStepList.push({
        workflowStatus: articles[i].workflowState,
        id: articles[i].artifactId,
        status: ArticleStatus.Locked,
        title: articles[i].title,
        fallbackTitle: articles[i].fallbackTitle,
        indexer: articles[i].indexer,
      });
    } else {
      articlesStepList.push({
        workflowStatus: articles[i].workflowState,
        id: articles[i].artifactId,
        status: ArticleStatus.Available,
        title: articles[i].title,
        fallbackTitle: articles[i].fallbackTitle,
        indexer: articles[i].indexer,
      });
    }
  }
  return articlesStepList;
};

interface TextIndexerArtifactProps {
 artifact: TextData;
}

interface TextIndexerArtifactState {
  loadingPdf: boolean;
  pdfData: string;
  validData: boolean;
  isLoading: boolean;
  tableOfContents: IssueTableOfContents;
  openDialog: boolean;
    dialogArtifactId: number;
    errorsList: string[];
}

interface ValidationDialogData {
  isOpen: boolean;
  errors: number[];
  failedArtifactTitle: string;
}

export default (props: TextIndexerArtifactProps): JSX.Element => {
  const classes = useStyles(props);
  const history = useHistory();
  const location = useLocation();
  const dispatch = useDispatch();
  const context = React.useContext(AppContext);
  const { enqueueSnackbar } = useSnackbar();

  const indexerContext = React.useContext(IndexerArtifactContext);

  const [state, setState] = React.useState<TextIndexerArtifactState>({
    loadingPdf: true,
    pdfData: '',
    // validData: TextArtifactValidator.guard(props.artifact.articleArtifactDocument),
    validData: true,
    isLoading: true,
    tableOfContents: { articles: [] },
    openDialog: false,
    dialogArtifactId: 0,
    errorsList: [],
  });

  const [validationDialogData, setValidationDialogData] = useState<ValidationDialogData>({
    isOpen: false,
    errors: [],
    failedArtifactTitle: '',
  });

  const validateUrl = `${process.env.REACT_APP_API_URL}/api/ArticleIndexer/validate/${props.artifact.artifactId}`;

  const issuePath = `${props.artifact.resourceId}\\${props.artifact.grouping}`;

  const pdfDownloadUrl = `${process.env.REACT_APP_API_URL}/api/articleindexer/downloadarticle?IssuePath=`
      + `${issuePath}&filename=${props.artifact.articleArtifactDocument.pdfFileName}`;

  let referenceData = useTypedSelector((store) => store.TextReferenceData.TextReferenceData);
  let logInfo = useTypedSelector((store) => store.LogEventData.LogEventData);

  const updateWorkflowInfo = () => {
    const loginfoUrl = `${process.env.REACT_APP_API_URL}/api/indexing/indexer-events/${props.artifact.artifactId}`;
    Axios.get(loginfoUrl)
      .then((response) => {
        logInfo = response.data;
        dispatch(updateLogEventData(response.data));
      })
      .catch(() => {
        setState((prevState) => ({
          ...prevState,
          validData: false,
        }));
      })
      .finally(() => {
        setState((prevState) => ({
          ...prevState,
          isLoading: false,
        }));
      });
  };

  React.useEffect(() => {
    // pdfDownloadUrl = 'api/articleindexer/downloadarticle?IssuePath='
    // + `${props.artifact.resourceId}\\${props.artifact.grouping}&filename=${props.artifact.articleArtifactDocument.pdfFileName}`;

    setState((prevState) => ({
      ...prevState,
      loadingPdf: true,
    }));

    // get pdf data
    Axios.get(pdfDownloadUrl, { responseType: 'blob' })
      .then((response) => {
        setState((prevState) => ({
          ...prevState,
          loadingPdf: false,
          pdfData: window.URL.createObjectURL(new Blob([response.data])),
        }));
      })
      .catch(() => {
        setState((prevState) => ({
          ...prevState,
          loadingPdf: false,
        }));
      });

    // validate error
    Axios.get(validateUrl)
      .then(() => {
        setState((prevState) => ({
          ...prevState,
          errorsList: [],
        }));
      })
      .catch((error) => {
        if (error.response.status === 400 && error.response.data !== null && error.response.data !== undefined
                  && error.response.data.length > 0) {
          const errors: string[] = error.response.data.map((x: { errorMessage: string }) => x.errorMessage);
          if (errors) {
            const errorStringList: string[] = errors;
            setState((prevState) => ({
              ...prevState,
              errorsList: errorStringList,
            }));
          }
        }
      });

    updateWorkflowInfo();
  }, [props.artifact]);

  React.useEffect(() => {
    // setup event
    const updateMediaArtifactHandler = (evt: CustomEvent): void => {
      if (props.artifact.artifactId !== evt.detail.EntityId) { return; }// prevent wrong trigger.
      /// /console.log('update-media-artifact event:', event.detail);
      // indexerContext.getUpdatedArtifact();
      updateWorkflowInfo();
    };
    EventHelper.on('update-media-artifact', updateMediaArtifactHandler);
    updateWorkflowInfo();
    return () => {
      // Anything in here is fired on component unmount.
      // console.log('event off');
      EventHelper.off('update-media-artifact', updateMediaArtifactHandler);
    };
  }, []);

  React.useEffect(() => {
    Axios.get(`${process.env.REACT_APP_API_URL}/api/articleindexer/tableofcontents?issueId=${props.artifact.articleArtifactDocument.issueID}`)
      .then((response) => {
        setState((prevState) => ({
          ...prevState,
          tableOfContents: response.data,
        }));
      });
  }, [location]);

  React.useEffect(() => {
    // get reference data
    if (TextReferenceDataValidator.validate(referenceData).success) {
      setState((prevState) => ({
        ...prevState,
        isLoading: false,
      }));
    } else {
      Axios.get(`${process.env.REACT_APP_API_URL}/api/indexing/getarticlereferencedata`)
        .then((response) => {
          if (TextReferenceDataValidator.guard(response.data)) {
            setState((prevState) => ({
              ...prevState,
              referenceData: response.data,
              isLoading: false,
            }));

            dispatch(updateTextReferenceData(response.data));
            referenceData = response.data;
          } else {
            setState((prevState) => ({
              ...prevState,
              validData: false,
              isLoading: false,
            }));
          }
        })
        .catch(() => {
          setState((prevState) => ({
            ...prevState,
            validData: false,
            isLoading: false,
          }));
        });
    }
  }, []);

  const updateValidationError = (errorStringList: string[]) => {
    setState((prevState) => ({
      ...prevState,
      errorsList: errorStringList,
    }));
  };

  const navigateToArticle = (artifactId: number) => {
    if (indexerContext.hasChanges) {
      if (state.openDialog) {
        const artifact = state.tableOfContents.articles.find((x) => x.artifactId === artifactId);
        history.push(`/artifact/${artifact?.artifactId}`);

        setState((prevState) => ({
          ...prevState,
          openDialog: false,
        }));
      } else {
        setState((prevState) => ({
          ...prevState,
          openDialog: true,
          dialogArtifactId: artifactId,
        }));
      }
    } else {
      const artifact = state.tableOfContents.articles.find((x) => x.artifactId === artifactId);
      history.push(`/artifact/${artifact?.artifactId}`);
    }
  };

  const updateArtifactStatus = (newStatus: number) => {
    const artifact = { ...props.artifact };
    artifact.artifactStatusId = newStatus;

    indexerContext.updateArtifact<TextData>(artifact);
  };

  const saveArtifact = (data: TextArtifact) => {
    context.showBlockUi();
    Axios.post(`${process.env.REACT_APP_API_URL}/api/ArticleIndexer/SaveArticleArtifact`, data)
      .then(() => {
        enqueueSnackbar('Artifact Saved', {
          variant: 'success',
        });
        indexerContext.setHasChanges(false);
        updateWorkflowInfo();
        // indexerContext.getUpdatedArtifact();
      })
      .catch(() => {
        enqueueSnackbar('An error occurred when trying to save the artifact', {
          variant: 'error',
        });
      })
      .finally(() => {
        context.hideBlockUi();
      });
  };

  const approveIssueQA = () => {
    context.showBlockUi();

    const request: ApproveIssueQARequest = {
      IssueID: props.artifact.articleArtifactDocument.issueID,
    };

    Axios.post(`${process.env.REACT_APP_API_URL}/api/issueqa/approveissueqa`, request)
      .then(() => {
        enqueueSnackbar('Successfully approved Issue and associated Articles in QA', { variant: 'success' });
        history.goBack();
      })
      .catch((error) => {
        // Check if we have received any validation errors and if so display them
        if (error.response.status === 400 && error.response.data !== null && error.response.data !== undefined
          && error.response.data.validationStringNumbers.length > 0) {
          // Get the title of the failed article
          const failedArticle = state.tableOfContents.articles.find((article) => article.artifactId === error.response.data.failedArtifactID);

          setValidationDialogData({
            isOpen: true,
            errors: error.response.data.validationStringNumbers,
            failedArtifactTitle: failedArticle === undefined ? '' : failedArticle.title,
          });
        } else {
          enqueueSnackbar('An error ocurred while trying to approve issue in QA', { variant: 'error' });
        }
      })
      .finally(() => {
        context.hideBlockUi();
      });
  };

  const readyToApproveArticle = (): boolean => {
    if (state.tableOfContents.articles.length === 0) {
      return false;
    }

    // TODO: REMOVE REPLACE AFTER 'READY FOR ARTICLE QA' NAME IS FIXED IN DATABASE
    const result = state.tableOfContents.articles.filter((x) => x.workflowState.toLowerCase() !== WorkflowStatusDisplayNames[WorkflowStatus.ReadyForArticleQA].replace('QA', 'Q A').toLowerCase()).length === 0;

    return result;
  };

  if (state.isLoading) {
    return (
      <>
        <CircularProgress />
      </>
    );
  }
  const styles = {
    background: '#000',
    width: '5px',
    cursor: 'col-resize',
    margin: '0 0px',
    height: '100%',
  };
  return (
    <>

      {state.validData && !state.isLoading ? (
        <div className={classes.root}>
          {props.artifact.isReadOnly && (
            <StickyNotification text="This artifact is not currently available to edit." />)}
          <Grid container className={classes.grid}>
            <SplitPane
              split="vertical"
              minSize="50%"
              defaultSize="50%"
              resizerStyle={styles}
            >

              <Grid item xs={12} className={classes.indexerPanel}>
                {state.errorsList ? (
                  <>
                    {state.errorsList.map((x) => (
                      <div>
                        <Alert severity="error">
                          {x}
                          {' '}
                        </Alert>
                      </div>
                    ))}
                  </>
                ) : (<></>)}

                <TextIndexerInputFields
                  initialDocumentData={props.artifact.articleArtifactDocument}
                  artifactArticleId={props.artifact.articleArtifactDocument.artifactArticleId}
                  readonly={props.artifact.isReadOnly}
                  sectionNameOptions={referenceData.sectionNameOptions}
                  languagesLookup={referenceData.languageLookup}
                  authorRoleTypeLookup={referenceData.authorRoleTypeLookup}
                  genreLookup={ConvertTextGenresHelper.ConvertGenres(referenceData.genres)}
                  descriptionTypeLookup={referenceData.descriptionTypes}
                  resourceTypeLookup={referenceData.resourceTypes}
                  mediaTypeLookup={referenceData.mediaTypes}
                  accessRightLookup={referenceData.accessRight}
                  locationSuggestions={[]}
                  topicSuggestions={[]}
                  submitTasks={props.artifact.submitTasks}
                  errorCodes={[]}
                  updateArtifactStatus={updateArtifactStatus}
                  artifactStatusId={props.artifact.artifactStatusId}
                  workflowStatusId={props.artifact.workflowStatusId}
                  indexingTypes={props.artifact.indexingTypes}
                  issueResourceTypeId={props.artifact.issueResourceTypeId}
                  saveArtifact={saveArtifact}
                  approveIssueQA={approveIssueQA}
                  approveIssueQAReady={readyToApproveArticle()}
                  updateValidationError={updateValidationError}
                />
              </Grid>

              <Grid item xs={12} className={classes.indexerPanel}>
                <Grid container className={classes.stickyRight}>
                  <Grid item xs={12}>
                    <WorkflowInfoDrawer content={(
                      <MediaWorkflowInfo
                        LogInfo={logInfo.logInfo}
                        WorkflowInfoItems={[
                          {
                            labelText: 'Date Created',
                            isDate: true,
                            value: props.artifact.articleArtifactDocument.createdDate,
                          },
                          {
                            labelText: 'Last Revision Date',
                            isDate: false,
                            value: props.artifact.revisionDate?.toString(),
                          },
                          {
                            labelText: 'Date Last Modified',
                            isDate: true,
                            value: props.artifact.articleArtifactDocument.modifiedDate?.toString(),
                          },
                          {
                            labelText: 'Item Indicator',
                            isDate: false,
                            value: props.artifact.articleArtifactDocument.isItem,
                          },
                          {
                            labelText: 'Article Id',
                            isDate: false,
                            value: props.artifact.articleArtifactDocument.artifactArticleId,
                          },
                          {
                            labelText: 'Title Id',
                            isDate: false,
                            value: props.artifact.articleArtifactDocument.titleID,
                          },
                          {
                            labelText: 'Issue Id',
                            isDate: false,
                            value: props.artifact.articleArtifactDocument.issueID,
                          },
                          {
                            labelText: 'Grouping',
                            isDate: false,
                            value: props.artifact.articleArtifactDocument.grouping,
                          },
                          {
                            labelText: 'DOI Indicator',
                            isDate: false,
                            value: props.artifact.articleArtifactDocument.doi !== undefined
                                  && props.artifact.articleArtifactDocument.doi !== null
                                  && props.artifact.articleArtifactDocument.doi.trim().length > 0,
                          },
                          {
                            labelText: 'PI Indicator',
                            isDate: false,
                            value: props.artifact.articleArtifactDocument.pIListed,
                          },
                          {
                            labelText: 'URI Indicator',
                            isDate: false,
                            value: props.artifact.articleArtifactDocument.uRIIndicator,
                          },
                          {
                            labelText: 'Availability',
                            isDate: false,
                            value: props.artifact.articleArtifactDocument.availability,
                          },
                          {
                            labelText: 'Content Source',
                            isDate: false,
                            value: props.artifact.articleArtifactDocument.contentSource,
                          },
                          {
                            labelText: 'Content Import Date',
                            isDate: true,
                            value: props.artifact.articleArtifactDocument.contentImportDate?.toString(),
                          },
                          {
                            labelText: 'Content DN',
                            isDate: false,
                            value: props.artifact.articleArtifactDocument.contentDN,
                          },
                        ]}
                      />
                    )}
                    />
                    <TOCDrawer content={(
                      <>
                        {/* <Grid item xs={1}> */}
                        {state.tableOfContents.articles.length >= 1 && (
                        <ArticleList
                          articles={translateArticlesForList(state.tableOfContents.articles)}
                          activeArticleId={props.artifact.artifactId}
                          handleChange={(id: number) => navigateToArticle(id)}
                          issuePath={issuePath}
                        />
                        )}
                      </>
                      /* </Grid> */
                    )}
                    />
                    <Button
                      href={pdfDownloadUrl}
                      color="primary"
                      variant="outlined"
                      size="small"
                      className={classes.downloadButton}
                      startIcon={<GetAppIcon />}
                    >
                      Download PDF
                    </Button>
                  </Grid>
                  <Grid item xs={12}>
                    <div style={{ height: 700 }}>
                      {state.loadingPdf ? (
                        <div style={{ textAlign: 'center' }}>
                          <div style={{ display: 'inline-block', marginTop: 300 }}>
                            <CircularProgress />
                          </div>
                        </div>
                      ) : (
                        <PdfViewer
                          filename={props.artifact.articleArtifactDocument.pdfFileName || 'unknown'}
                          file={state.pdfData}
                        />
                      )}
                    </div>
                  </Grid>
                  <Grid item xs={12} style={{ marginTop: '50px' }}>
                    <ReadonlyTextFields
                      fields={[
                        {
                          label: 'Record Number',
                          displayText: props.artifact.articleArtifactDocument.rmitNumber,
                        },
                        {
                          label: 'Filename PDF',
                          displayText: props.artifact.articleArtifactDocument.pdfFileName,
                        },
                        {
                          label: 'Filename HTML',
                          displayText: props.artifact.articleArtifactDocument.htmlFileName,
                        },
                        {
                          label: 'File Type',
                          displayText: props.artifact.articleArtifactDocument.mimeType,
                        },
                        {
                          label: 'File Size',
                          displayText: bytes(props.artifact.articleArtifactDocument.fileSize, { decimalPlaces: 2 }),
                        },
                      ]}
                    />
                  </Grid>
                </Grid>
              </Grid>

            </SplitPane>
          </Grid>
          <ConfirmationDialog
            dialogTitle="Unsaved Changes"
            dialogBodyText="You have changes that have not been saved. Are you sure you want to navigate away, and discard your changes?"
            successButtonText="Discard Changes"
            onReturn={() => {
              setState((prevState) => ({
                ...prevState,
                openDialog: false,
              }));
            }}
            onProceed={() => navigateToArticle(state.dialogArtifactId)}
            isOpen={state.openDialog}
          />
          <TextValidationErrorDialog
            isOpen={validationDialogData.isOpen}
            onReturn={() => setValidationDialogData({
              isOpen: false,
              errors: [],
              failedArtifactTitle: '',
            })}
            errors={validationDialogData.errors}
            onProceed={() => undefined}
            allowSkip={false}
            failedArtifactTitle={validationDialogData.failedArtifactTitle}
          />
        </div>

      ) : (
        <ErrorPaper
          title="Unable to read data from retrieved artifact"
          secondaryText={`Artifact ID: ${props.artifact.articleArtifactDocument.artifactId}`}
        />
      )}
    </>

  );
};
