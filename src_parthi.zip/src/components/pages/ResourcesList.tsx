import React, { useState, useEffect } from 'react';
import {
  Paper, Grid, TextField, Button, createStyles, makeStyles, Theme, Typography, Breadcrumbs, Link,
} from '@material-ui/core';
import SearchIcon from '@material-ui/icons/Search';
import InfoOutlinedIcon from '@material-ui/icons/InfoOutlined';
import { useLocation, useParams } from 'react-router-dom';
import Axios from 'axios';
import usePagination from '../hooks/usePagination';
import TitleSearchResult from '../../interfaces/Search/TitleSearchResult';
import TitleResult from '../organisms/Search/TitleResult';
import ResourceListResponse, { ResourceListResponseValidator } from '../../interfaces/ResourceList/ResourceListResponse';
import ErrorPaper from '../organisms/ErrorPaper';
import LoadingResult from '../organisms/Search/LoadingResult';
import useRuntypeError from '../hooks/useRuntypeError';

interface State {
  allData: ResourceListResponse;
  filteredResources: TitleSearchResult[];
  pagedResources: TitleSearchResult[];
  isLoading: boolean;
  hasError: boolean;
}

const useStyles = makeStyles((theme: Theme) => createStyles({
  input: {
    '& .MuiInputBase-input': {
      padding: 10,
    },

    marginBottom: theme.spacing(2),
    display: 'inline-block',
  },
  noRecordsFilter: {
    padding: theme.spacing(4),
    display: 'flex',
    justifyContent: 'center',
  },
  searchRow: {
    display: 'flex',
    alignItems: 'center',
  },
  resultsCounter: {
    marginLeft: 'auto',
  },
  infoIcon: {
    marginRight: theme.spacing(1),
    color: theme.palette.warning.main,
  },
  result: {
    marginBottom: theme.spacing(2),
  },
  nav: {
    position: 'absolute',
    top: theme.spacing(-4),
    left: theme.spacing(2),
  },
  '@global': {
    '.MuiInputLabel-outlined': {
      transform: 'translate(14px, 14px) scale(1)',
    },
  },
}));

export default function Resources() {
  const { partnerId } = useParams();
  const classes = useStyles();
  const location = useLocation();
  const { getNextPage, getInitialPage, reset } = usePagination();
  const runtypeValidator = useRuntypeError(ResourceListResponseValidator);

  const [state, setState] = useState<State>({
    allData: {
      organisationName: '',
      resources: [],
    },
    filteredResources: [],
    pagedResources: [],
    isLoading: true,
    hasError: false,
  });

  useEffect(() => {
    Axios.get<ResourceListResponse>(`${process.env.REACT_APP_API_URL}/api/resource/list`, { params: { parId: partnerId } }).then((response) => {
      if (!runtypeValidator.validate(response.data)) {
        return;
      }

      reset();
      setState((prevState) => ({
        ...prevState,
        allData: response.data,
        filteredResources: response.data.resources,
        pagedResources: getInitialPage(response.data.resources),
      }));
    }).catch(() => {
      setState((prevState) => ({
        ...prevState,
        hasError: true,
      }));
    }).finally(() => setState((prevState) => ({ ...prevState, isLoading: false })));
  }, [location]);

  const onChange = (filterString: string) => {
    const newData: TitleSearchResult[] = [];
    const filterStringUpperCase = filterString.toLocaleUpperCase();
    state.allData.resources.forEach((item) => {
      let match = false;
      Object.entries(item).forEach(([_, value]) => {
        if (value === undefined || value === null || typeof (value) !== 'string') {
          return;
        }

        if (value.toLocaleUpperCase().indexOf(filterStringUpperCase) > -1) {
          match = true;
        }
      });

      if (match) {
        newData.push(item);
      }
    });
    reset();
    setState((prevState) => ({
      ...prevState,
      filteredResources: newData,
      pagedResources: getInitialPage(newData),
    }));
  };

  const showNextPage = () => {
    setState((prevState) => ({
      ...prevState,
      pagedResources: [...prevState.pagedResources, ...getNextPage(prevState.filteredResources)],
    }));
  };

  if (!runtypeValidator.isValid) {
    return (<div data-testid="dataError">{runtypeValidator.error()}</div>);
  }
  if (state.hasError) {
    return (<ErrorPaper data-testid="genericError" text="Something went wrong trying to retrieve the list of resources." />);
  }

  return (
    <Grid container justify="center" style={{ position: 'relative' }}>

      {state.allData.organisationName && (
        <Breadcrumbs className={classes.nav}>
          <Link color="inherit" href={`/partner/${partnerId}`}>
            {state.allData.organisationName}
          </Link>
          <Typography color="textPrimary">All resources</Typography>
        </Breadcrumbs>
      )}

      <Grid item xs={10} md={9} lg={6}>
        {state.allData.resources.length > 0 && (
          <>
            <div className={classes.searchRow}>
              <TextField
                className={classes.input}
                data-testid="filter"
                onChange={(event) => onChange(event.target.value)}
                variant="outlined"
                InputProps={{
                  endAdornment: (<SearchIcon />),
                }}
                label="Filter"
              />
              <Typography className={classes.resultsCounter}>
                Showing
                {' '}
                <strong data-testid="showingCount">{state.pagedResources.length}</strong>
                {' '}
                of
                {' '}
                <strong data-testid="totalCount">{state.allData.resources.length}</strong>
                {' '}
                records
              </Typography>
            </div>
            {state.pagedResources.map((item) => (<div className={classes.result}><TitleResult key={item.id} result={item} /></div>))}
            {state.filteredResources.length > state.pagedResources.length && (
            <div style={{ textAlign: 'center' }}>
              <Button data-testid="showMore" onClick={showNextPage} variant="outlined">Show more</Button>
            </div>
            )}
            {state.filteredResources.length === 0 && state.allData.resources.length > 0 && (
            <Paper className={classes.noRecordsFilter}>
              <InfoOutlinedIcon className={classes.infoIcon} />
              <Typography>
                There are no records that match the current filter.
              </Typography>
            </Paper>
            )}
          </>
        )}
        {state.allData.resources.length === 0 && !state.isLoading && (
        <Paper className={classes.noRecordsFilter} data-testid="noResources">
          <InfoOutlinedIcon className={classes.infoIcon} />
          <Typography>
            We could not find any resources for this partner.
          </Typography>
        </Paper>
        )}
        {state.isLoading && (
          <>
            {Array(5).fill((<div className={classes.result}><LoadingResult /></div>))}
          </>
        )}
      </Grid>
    </Grid>
  );
}
