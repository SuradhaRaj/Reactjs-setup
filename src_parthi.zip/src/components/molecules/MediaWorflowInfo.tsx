import React from 'react';
import { makeStyles, Grid, Typography } from '@material-ui/core';
import { DateTime } from 'luxon';
import ReadOnlyTextField from '../Shared/ReadOnlyTextField';
import LogEventInfo from './LogEventInfo';
import LogEventOption from '../../interfaces/Events/LogEventOption';

interface WorkflowInfoItem {
    labelText: string;
    isDate: boolean;
    value: string | number | undefined | boolean | null;
}

interface Props {
    WorkflowInfoItems: WorkflowInfoItem[];
    LogInfo: LogEventOption[];
}

const useStyles = makeStyles({
  heading: {
    float: 'right',
  },
});

export default function MediaWorkflowInfo(props: Props): JSX.Element {
  const classes = useStyles();
  const fields: Array<JSX.Element> = [];

  props.WorkflowInfoItems.forEach((item) => {
    if (item.value !== undefined && item.value !== null && item.value !== '') {
      if (item.isDate) {
        fields.push(
          <Grid item xs={12}>
            <ReadOnlyTextField displayText={DateTime.fromISO(item.value.toString()).toFormat('d LLL yyyy h:mm a')} labelText={item.labelText} oneLine={false} />
          </Grid>,
        );
      } else if (typeof item.value === 'boolean') {
        fields.push(
          <Grid item xs={12}>
            <ReadOnlyTextField displayText={item.value ? 'Yes' : 'No'} labelText={item.labelText} oneLine={false} />
          </Grid>,
        );
      } else {
        fields.push(
          <Grid item xs={12}>
            <ReadOnlyTextField displayText={item.value} labelText={item.labelText} oneLine={false} />
          </Grid>,
        );
      }
    } else {
      /* We want to show a dash where we have no data, that way it doesn't look like the field is just missing */
      fields.push(
        <Grid item xs={12}>
          <ReadOnlyTextField displayText="-" labelText={item.labelText} oneLine={false} />
        </Grid>,
      );
    }
  });

  return (
    <>
      <Grid container alignContent="flex-start" spacing={2}>
        {fields}
      </Grid>
      <Grid item xs={12}>
        <Typography color="primary" className={classes.heading} variant="overline">Transaction Logs</Typography>
      </Grid>
      <LogEventInfo info={props.LogInfo} />
    </>
  );
}
