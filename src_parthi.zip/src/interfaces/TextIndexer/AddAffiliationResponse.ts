import {
  Record, String, Number, Static,
} from 'runtypes';

export const AddAffiliationResponseValidator = Record({
  affiliation: String,
  affiliationId: Number.withConstraint((n) => n > 0),
});

type AddAffiliationResponse = Static<typeof AddAffiliationResponseValidator>;
export default AddAffiliationResponse;
