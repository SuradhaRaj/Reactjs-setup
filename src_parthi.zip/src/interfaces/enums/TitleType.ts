enum TitleType {
  Unassigned=1,
  FullText= 2,
  Index= 3,

}
export default TitleType;

type TitleTypeNameMapping = {
  [indexName in TitleType]: string;
}

export const TitleTypeNameMapping: TitleTypeNameMapping = {

  1: 'Unassigned',
  2: 'FullText',
  3: 'Index',

};
