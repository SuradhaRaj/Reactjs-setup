// @ts-nocheck
/* eslint-disable @typescript-eslint/no-unused-vars */
import TextTaskManagementFilters from '../../classes/TextTaskManagementFilters';
import WorkflowStatus, { WorkflowStatusDisplayNames } from '../../interfaces/enums/WorkflowStatus';

const tasks = {
  issues: [{
    artifactId: 1,
    title: 'Occlusion of Right Main Bronchus with Extraluminal Device, Open Approach',
    grouping: 'Often',
    publisher: 'Gabvine',
    delivered: true,
    manager: 'CN',
    files: 9,
    publisherNotes: '',
    indexerNotes: 'Aenean sit amet justo. Morbi ut odio.',
    indexer: null,
    workflowStatusId: WorkflowStatus.FilePrepInProgress,
    rmitNumber: 'RMIT9076976107',
  }, {
    artifactId: 2,
    title: 'Issue1',
    grouping: 'Never',
    publisher: 'Publisher1',
    delivered: false,
    manager: 'ID',
    files: 98,
    publisherNotes: 'Phasellus in felis. Donec semper sapien a libero.',
    indexerNotes: 'Pellentesque ultrices mattis odio.',
    indexer: null,
    workflowStatusId: WorkflowStatus.ReadyForIssueSplitting,
    rmitNumber: 'RMIT6132797529',
  }, {
    artifactId: 3,
    title: 'Fusion of Left Elbow Joint with Synthetic Substitute, Percutaneous Approach',
    grouping: 'Seldom',
    publisher: 'Thoughtbeat',
    delivered: true,
    manager: 'ID',
    files: 57,
    publisherNotes: 'Etiam pretium iaculis justo. In hac habitasse platea dictumst.',
    indexerNotes: 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Etiam vel augue.',
    indexer: null,
    workflowStatusId: WorkflowStatus.FilePrepInProgress,
    rmitNumber: 'RMIT7688677357',
  }],
  articles: [{
    artifactId: 1,
    articleTitle: 'Immobilization of Right Lower Leg using Brace',
    grouping: 'Often',
    publisher: 'Buzzshare',
    delivered: null,
    manager: 'CN',
    publisherNotes: 'Vestibulum sed magna at nunc commodo placerat. Praesent blandit.',
    indexerNotes: 'Nulla mollis molestie lorem.',
    indexer: null,
    workflowStatusId: WorkflowStatus.IndexingInProgress,
    rmitNumber: 'RMIT9532604866',
    title: 'Major Pharmaceuticals',
  }, {
    artifactId: 2,
    articleTitle: 'Removal of Nonautologous Tissue Substitute from Right Metacarpal, Percutaneous Approach',
    grouping: 'Often',
    publisher: 'Photobug',
    delivered: null,
    manager: 'HU',
    publisherNotes: 'In hac habitasse platea dictumst.',
    indexerNotes: 'Nullam sit amet turpis elementum ligula vehicula consequat. Morbi a ipsum. Integer a nibh.',
    indexer: 'Wang Treske',
    workflowStatusId: WorkflowStatus.ReadyForIndexing,
    rmitNumber: 'RMIT5472837365',
    title: 'Real Estate Investment Trusts',
  }, {
    artifactId: 3,
    articleTitle: 'Bypass Middle Esophagus to Duodenum with Nonautologous Tissue Substitute, Via Natural or Artificial Opening Endoscopic',
    grouping: 'Seldom',
    publisher: 'Publisher1',
    delivered: null,
    manager: 'PH',
    publisherNotes: 'Ut tellus. Nulla ut erat id mauris vulputate elementum. Nullam varius.',
    indexerNotes: 'Pellentesque ultrices mattis odio. Donec vitae nisi.',
    indexer: null,
    workflowStatusId: WorkflowStatus.IndexingInProgress,
    rmitNumber: 'RMIT4577314353',
    title: 'Issue1',
  }],
};

describe('Task management filters - Filter tasks', () => {
  it('should return all items when no filter is applied', () => {
    const filters = TextTaskManagementFilters.empty();

    // const result = filters.filterTasks(tasks);
    // expect(result.articles.length).toBe(3);
    // expect(result.issues.length).toBe(3);
  });

  it('should return items matching the status filter (issues)', () => {
    const filters = new TextTaskManagementFilters({
      status: [WorkflowStatusDisplayNames[WorkflowStatus.ReadyForIssueSplitting]], grouping: [], title: [], publisher: [], manager: [],
    });

    // const result = filters.filterTasks(tasks);
    // expect(result.articles).toHaveLength(0);
    // expect(result.issues).toHaveLength(1);
  });

  it('should return items matching the status filter (artifacts)', () => {
    const filters = new TextTaskManagementFilters({
      status: [WorkflowStatusDisplayNames[WorkflowStatus.IndexingInProgress]], grouping: [], title: [], publisher: [], manager: [],
    });

    // const result = filters.filterTasks(tasks);
    // expect(result.articles).toHaveLength(2);
    // expect(result.issues).toHaveLength(0);
  });

  it('should return items matching the grouping filter', () => {
    const filters = new TextTaskManagementFilters({
      status: [], grouping: ['often'], title: [], publisher: [], manager: [],
    });

    // const result = filters.filterTasks(tasks);
    // expect(result.articles).toHaveLength(2);
    // expect(result.issues).toHaveLength(1);
  });

  it('should return items matching the title filter', () => {
    const filters = new TextTaskManagementFilters({
      status: [], grouping: [], title: ['Issue1'], publisher: [], manager: [],
    });

    // const result = filters.filterTasks(tasks);
    // expect(result.articles).toHaveLength(1);
    // expect(result.issues).toHaveLength(1);
  });

  it('should return items matching the publisher filter', () => {
    const filters = new TextTaskManagementFilters({
      status: [], grouping: [], title: [], publisher: ['Publisher1'], manager: [],
    });

    // const result = filters.filterTasks(tasks);
    // expect(result.articles).toHaveLength(1);
    // expect(result.issues).toHaveLength(1);
  });

  it('should return items matching the manager filter', () => {
    const filters = new TextTaskManagementFilters({
      status: [], grouping: [], title: [], publisher: [], manager: ['CN'],
    });

    // const result = filters.filterTasks(tasks);
    // expect(result.articles).toHaveLength(1);
    // expect(result.issues).toHaveLength(1);
  });
});
