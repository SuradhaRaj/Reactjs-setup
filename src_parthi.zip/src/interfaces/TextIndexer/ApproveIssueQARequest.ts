interface ApproveIssueQARequest {

  IssueID: number;
}

export default ApproveIssueQARequest;
