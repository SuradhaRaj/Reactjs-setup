import React from 'react';
import { mount } from 'enzyme';
import AuthorForm from '../../../components/organisms/TextIndexer/AuthorForm';
import AuthorTypedown from '../../../components/organisms/TextIndexer/AuthorTypedown';
import LoadingButton from '../../../components/molecules/LoadingButton';

const wrapper = mount(<AuthorForm
  affiliationOptions={['Test aff 1', 'Test aff 2']}
  loading={false}
  handleAddAuthor={() => undefined}
  handleCreateAuthor={() => undefined}
  updateAffiliationOptions={() => undefined}
  clearAffiliationOptions={() => undefined}
  roleTypeLookup={[{ authorRoleTypeId: 1, authorRoleCode: '', name: 'Author' }]}
/>);

describe('Author Form', () => {
  it('should not initially show the add new fields', () => {
    expect(wrapper.find(AuthorTypedown)).toBeTruthy();
  });

  it('should initially not allow the author to be added', () => {
    expect(wrapper.find(LoadingButton).prop('disabled')).toBeTruthy();
  });

  it('should still not allow an author to be created after switching', () => {
    expect(wrapper.find(LoadingButton).prop('disabled')).toBeTruthy();
  });
});
