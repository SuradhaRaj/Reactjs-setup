import { useContext } from 'react';
import { DateTime } from 'luxon';
import DocumentFastNode from '../../interfaces/MediaIndexer/DocumentFastNode';
import { AppContext } from '../Context';

const useDocumentFastNode = () => {
  const context = useContext(AppContext);

  const setDocumentFastNode = (
    key: string,
    currentValues: DocumentFastNode[],
    setFieldValue: ((field: string, value: DocumentFastNode[], shouldValidate?: boolean | undefined) => void),
  ) => {
    const newValues: DocumentFastNode[] = [];

    currentValues.forEach((currentValue) => {
      if (currentValue.createdBy === '') {
        newValues.push({
          ...currentValue,
          createdBy: context.userInfo.data.name,
          createdDate: DateTime.local().toString(),
        });
      // if the node was already present initially, populate it with the same data
      } else {
        newValues.push(currentValue);
      }
      setFieldValue(key, newValues, true);
    });
  };

  return { setDocumentFastNode };
};
export default useDocumentFastNode;
