import React from 'react';
import { Grid, Typography } from '@material-ui/core';
import ReadOnlyTextField from '../Shared/ReadOnlyTextField';
import LogEventOption from '../../interfaces/Events/LogEventOption';

interface Props {
  info: LogEventOption[];
}

export default function LogEventInfo(props: Props): JSX.Element {
  const fields: Array<JSX.Element> = [];

  props.info.forEach((item) => {
    const desc1 = item.eventType;
    const desc2 = item.workflowStatus;
    fields.push(
      <Grid item xs={12}>
        <ReadOnlyTextField displayText={item.timestamp} labelText={desc1} oneLine={false} />
        <Typography color="primary" variant="caption">{desc2}</Typography>
      </Grid>,
    );
  });

  return (
    <>
      <Grid container alignContent="flex-start" spacing={2}>
        {fields}
      </Grid>
    </>
  );
}
