import { Static, Record } from 'runtypes';
import { ContactRoleValidator } from './ContactRole';
import { ArrayWithElements } from '../../runtypeTypes';

export const UpdateOrganisationContactResponseValidator = Record({
  contactRoles: ArrayWithElements(ContactRoleValidator),
});

type UpdateOrganisationContactResponse = Static<typeof UpdateOrganisationContactResponseValidator>;
export default UpdateOrganisationContactResponse;
