interface SendErrorRerquest {
  ArtifactID: number;

  ArtifactErrorTypeID: number;
  Text: string;
}

export default SendErrorRerquest;
