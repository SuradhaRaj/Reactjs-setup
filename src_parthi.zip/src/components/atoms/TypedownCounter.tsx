import React from 'react';
import { makeStyles } from '@material-ui/core';

const useStyles = makeStyles({
  typedownCounter: {
    textAlign: 'right',
    fontSize: '9pt',
    color: 'grey',
  },
});

export interface TypedownCounterProps {
  selected: number;
  limit: number;
}

const TypedownCounter: React.FunctionComponent<TypedownCounterProps> = (props: TypedownCounterProps) => {
  const classes = useStyles();
  const remaining = props.limit - props.selected;

  return (
    <div className={classes.typedownCounter}>
      { remaining > 0
        ? (
          <>
            {'Up to '}
            <span data-remaining>{ remaining }</span>
            {' remaining'}
          </>
        )
        : 'Limit reached'}
    </div>
  );
};

export default TypedownCounter;
