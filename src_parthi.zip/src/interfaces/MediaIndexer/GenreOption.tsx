/*eslint-disable*/
export default interface GenreOption {
    id: number;
    name: string;
}