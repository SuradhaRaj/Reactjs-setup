import React, { createContext, useReducer } from 'react';
import { Grid, CircularProgress, Divider } from '@material-ui/core';
import { makeStyles, Theme, createStyles } from '@material-ui/core/styles';
import { Route, Switch } from 'react-router-dom';

import routes from '../RouteConfig';
import { AppContext } from './Context';
import LoadingOverlay from './molecules/LoadingOverlay';
import BuildDetails from './atoms/BuildDetails';
import FirebaseComponent from './atoms/FirebaseComponent';

import NavbarText from './organisms/NavbarText';
import Navbar from './organisms/Navbar';
import { initialState, reducer } from '../store/reducers/RdcrNavbarText';

const useStyles = makeStyles((theme: Theme) => createStyles({
  grid: {
    marginTop: theme.spacing(2),
    marginBottom: theme.spacing(2),
  },
}));

// @ts-ignore
export const UserContext = createContext();
export default function Layout(): JSX.Element {
  const classes = useStyles();
  const [navstate, setNavState] = useReducer(reducer, initialState);

  return (
    <UserContext.Provider value={{ navstate, setNavState }}>
      <AppContext.Consumer>
        {(context) => (
          <>
            {context.isBlocked && <LoadingOverlay />}
            <Navbar />
            <Grid container direction="row">
              <Grid container item xs={11}>
                <NavbarText />
              </Grid>
              <Grid container item xs={1}>
                <FirebaseComponent />
              </Grid>
              <Grid xs={12}>
                {navstate.isClicked
                  ? <Divider />
                  : null}
              </Grid>
            </Grid>
            <Grid container justify="center" className={classes.grid}>
              <React.Suspense fallback={<CircularProgress />}>
                <Switch>
                  {routes.map((route) => (
                    <Route
                      path={route.path}
                      component={route.component}
                      exact={route.exact}
                    />
                  ))}
                </Switch>
              </React.Suspense>
            </Grid>
            <BuildDetails />
          </>
        )}
      </AppContext.Consumer>
    </UserContext.Provider>
  );
}
