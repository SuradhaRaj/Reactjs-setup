import TaskManagementFilters from '../../../classes/TaskManagementFilters';
import RdcrTaskManagement, { TaskManagementState } from '../../../store/reducers/RdcrTaskManagement';
import { clearFilters, updateFilters, updateTaskManagementList } from '../../../store/actions/ActnTaskManagement';
import TaskManagementTask from '../../../interfaces/TaskManagementTask';

describe('Reducer - Task management - Channel filter', () => {
  it('should return a filter with the updated items in the channel array after updating the channel filter', () => {
    const state: TaskManagementState = {
      AllTasks: [],
      FilteredTasks: [],
      Filters: TaskManagementFilters.empty(),
    };

    const newState = RdcrTaskManagement(state, updateFilters(new TaskManagementFilters({ channel: ['Item1'], status: undefined })));

    expect(newState.Filters.data.channel.length).toBe(1);
    expect(newState.Filters.data.channel[0]).toBe('Item1');
  });

  it('should return a filter with the updated items in the status array after updating the status filter', () => {
    const state: TaskManagementState = {
      AllTasks: [],
      FilteredTasks: [],
      Filters: TaskManagementFilters.empty(),
    };

    const newState = RdcrTaskManagement(state, updateFilters(new TaskManagementFilters({ channel: [], status: ['State1'] })));

    expect(newState.Filters.data.status.length).toBe(1);
    expect(newState.Filters.data.status[0]).toBe('State1');
  });

  it('should return a filter object with no channel filters applied after clearing', () => {
    const state: TaskManagementState = {
      AllTasks: [],
      FilteredTasks: [],
      Filters: new TaskManagementFilters({ channel: ['Item1'], status: undefined }),
    };

    const newState = RdcrTaskManagement(state, clearFilters());

    expect(newState.Filters.data.channel.length).toBe(0);
  });
  it('should return a filter object with no status filters applied after clearing', () => {
    const state: TaskManagementState = {
      AllTasks: [],
      FilteredTasks: [],
      Filters: new TaskManagementFilters({ channel: undefined, status: ['Item1'] }),
    };

    const newState = RdcrTaskManagement(state, clearFilters());

    expect(newState.Filters.data.status.length).toBe(0);
  });

  it('should return a filtered list of tasks, when updating the task list and a filter is already applied', () => {
    const state: TaskManagementState = {
      AllTasks: [],
      FilteredTasks: [],
      Filters: new TaskManagementFilters({ channel: ['Channel1'], status: undefined }),
    };

    const tasks: TaskManagementTask[] = [
      {
        artifactId: 1,
        broadcastDate: '',
        channel: 'Channel1',
        documentId: '',
        indexer: '',
        isLocked: false,
        itemTitle: '',
        programTitle: 'ProgramTitle3',
        rmitNumber: '',
        workflowState: 'State3',
      }, {
        artifactId: 1,
        broadcastDate: '',
        channel: 'Channel2',
        documentId: '',
        indexer: '',
        isLocked: false,
        itemTitle: '',
        programTitle: 'ProgramTitle1',
        rmitNumber: '',
        workflowState: 'State2',
      }];
    const newState = RdcrTaskManagement(state, updateTaskManagementList(tasks));

    expect(newState.AllTasks).toHaveLength(2);
    expect(newState.FilteredTasks).toHaveLength(1);
  });
});
