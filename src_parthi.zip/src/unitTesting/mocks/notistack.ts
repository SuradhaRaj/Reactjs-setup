export default () => jest.mock('notistack', () => ({
  useSnackbar: () => ({
    push: jest.fn(),
    enqueueSnackbar: jest.fn(),
    dequeueSnackbar: jest.fn(),
  }),
}));
