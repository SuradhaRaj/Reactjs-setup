import {
  String, Record, Static, Null, Boolean,
} from 'runtypes';
import {
  NumberGreaterZero, IsoDate,
} from '../../runtypeTypes';

export const IssueValidator = Record({
  issueId: NumberGreaterZero,
  resourceId: NumberGreaterZero,
  resouceName: String.Or(Null),
  resouceTitle: String.Or(Null),
  grouping: String.Or(Null),
  issueNumber: String.Or(Null),
  volumeNumber: String.Or(Null),
  issueEdition: String.Or(Null),
  issueTitle: String.Or(Null),
  dateOfPublication: String.Or(Null),
  issueMonthSeason: String.Or(Null),
  scheduleDate: IsoDate.Or(Null),
  publicationYear: NumberGreaterZero.Or(Null),
  issueIndexingStatusId: NumberGreaterZero.Or(Null),
  publishIssue: Boolean.Or(Null),
  lastRevisionDate: IsoDate.Or(Null),
  lastModified: IsoDate.Or(Null),
  dateCreated: IsoDate.Or(Null),
  contentSource: String.Or(Null),
  contentImportDate: IsoDate.Or(Null),
  contentRcvdDate: IsoDate.Or(Null),
  filesSentDate: IsoDate.Or(Null),
  filesRcvdDate: IsoDate.Or(Null),
  metadataIndexer: String.Or(Null),
  filesAcceptedDate: IsoDate.Or(Null),
  issueCreated: IsoDate.Or(Null),
  issueLiveDate: IsoDate.Or(Null),
  issueHardCopyRcvdDate: IsoDate.Or(Null),
  issueHardCopySentDate: IsoDate.Or(Null),
  notesForRmitPublishing: String.Or(Null),
  notesIssueManagement: String.Or(Null),
  notesIndexer: String.Or(Null),
  accessRightId: NumberGreaterZero.Or(Null),
  workflowStatusId: NumberGreaterZero.Or(Null),
  emailEnabled: Boolean,
});

type Issue = Static<typeof IssueValidator>;
export type TypeIssueAdd = Pick<Issue, 'resourceId' | 'issueNumber' | 'volumeNumber' | 'publicationYear' | 'scheduleDate' | 'issueMonthSeason' |'dateOfPublication'>;
export default Issue;
