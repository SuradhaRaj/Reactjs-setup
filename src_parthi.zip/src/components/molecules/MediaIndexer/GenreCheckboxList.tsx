import React from 'react';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import FormLabel from '@material-ui/core/FormLabel';
import FormControl from '@material-ui/core/FormControl';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import { Grid } from '@material-ui/core';
import DocumentItemNode from '../../../interfaces/MediaIndexer/DocumentItemNode';
import TypedownCounter from '../../atoms/TypedownCounter';
// import GenreOption from '../../interfaces/MediaIndexer/GenreOption';
import LookupOption from '../../../interfaces/LookupOption';

const useStyles = makeStyles(() => createStyles({
  root: {
    display: 'flex',
    marginTop: '20px',
    marginBottom: '20px',
    '& .MuiFormControlLabel-label': {
      fontSize: '0.8rem',
    },
    '& .MuiFormControlLabel-root': {
      margin: 0,
    },
    '& .MuiCheckbox-root': {
      padding: 0,
    },
  },
  checkboxListLabel: {
    textAlign: 'left',
    fontSize: '0.8rem',
  },
}));

interface GenreCheckboxListProps {
  labelText: string;
  preSelectedOptions: DocumentItemNode[];
  keyName: string;
  onChangeFunction: Function;
  readOnly?: boolean;
  checkboxLimit: number;
  checkboxOptions: LookupOption[];
}

interface CheckboxItem {
  label: string;
  id: number;
  isChecked: boolean;
}

interface CheckboxItem {
  label: string;
  isChecked: boolean;
}

export default function GenreCheckboxList(props: GenreCheckboxListProps) {
  const classes = useStyles();

  function transformInitialData(): CheckboxItem[] {
    const checkboxItemList: CheckboxItem[] = [];

    // Create initial data and set the correct options to selected
    for (let i = 0; i < props.checkboxOptions.length; i++) {
      const existingOption: DocumentItemNode[] = props.preSelectedOptions.filter(
        (selectedOption) => selectedOption.id === props.checkboxOptions[i].key,
      );

      // If this option exists
      if (existingOption !== undefined && existingOption !== null && existingOption.length > 0) {
        checkboxItemList.push({ id: props.checkboxOptions[i].key, label: props.checkboxOptions[i].value, isChecked: true });
      } else {
        checkboxItemList.push({ id: props.checkboxOptions[i].key, label: props.checkboxOptions[i].value, isChecked: false });
      }
    }

    return checkboxItemList;
  }

  const [state, setState] = React.useState({
    checkboxList: transformInitialData(),
  });

  const error = (state.checkboxList.filter((checkbox) => checkbox.isChecked).length > props.checkboxLimit)
    || (state.checkboxList.filter((checkbox) => checkbox.isChecked).length < 1);

  const isDisabled = (selected: boolean) => props.readOnly || (state.checkboxList.filter(
    (checkbox) => checkbox.isChecked,
  ).length === props.checkboxLimit && !selected);

  const handleChange = (id: number) => () => {
    const genreList: CheckboxItem[] = state.checkboxList;
    const selectedGenreList: DocumentItemNode[] = [];

    // Flip the isChecked flag for the relative genre option
    for (let i = 0; i < genreList.length; i++) {
      if (genreList[i].id === id) {
        genreList[i].isChecked = !genreList[i].isChecked;
      }

      // Add selected genres to the id list for the onChangeFunction
      if (genreList[i].isChecked) {
        selectedGenreList.push({
          id: genreList[i].id, name: genreList[i].label, createdBy: '', createdDate: '',
        });
      }
    }

    setState((prevState) => ({
      ...prevState,
      checkboxList: genreList,
    }));

    props.onChangeFunction(props.keyName, selectedGenreList);
  };

  return (
    <div className={classes.root}>
      <FormControl error={error && !props.readOnly} style={{ width: '100%' }} component="fieldset">
        <FormLabel className={classes.checkboxListLabel} component="legend">{props.labelText}</FormLabel>
        <FormGroup>
          <Grid container spacing={0}>
            {state.checkboxList.map((checkbox) => (
              <Grid item xs={4}>
                <FormControlLabel
                  label={checkbox.label}
                  key={checkbox.id}
                  control={(
                    <Checkbox
                      checked={checkbox.isChecked}
                      disabled={isDisabled(checkbox.isChecked)}
                      disableRipple={false}
                      color="primary"
                      value={checkbox.label}
                      onChange={handleChange(checkbox.id)}
                      onKeyUp={() => {
                        if (props.keyName === 'Enter') {
                          props.onChangeFunction(checkbox.id);
                        }
                      }}
                    />
                  )}
                />
              </Grid>
            ))}
            <Grid item xs={10}>
              <TypedownCounter
                limit={props.checkboxLimit}
                selected={state.checkboxList.filter((checkbox) => checkbox.isChecked).length}
              />
            </Grid>
          </Grid>
        </FormGroup>
      </FormControl>
    </div>
  );
}
