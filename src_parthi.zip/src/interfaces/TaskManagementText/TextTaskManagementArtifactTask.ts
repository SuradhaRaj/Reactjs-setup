import {
  Record, String, Static, Null, Number, Boolean,
} from 'runtypes';
import { TextTaskManagementBaseTaskValidator } from './TextTaskManagementBaseTask';

export const TextTaskManagementArtifactTaskValidator = Record({
  rmitNumber: String,
  artifactStatusId: Number,
  modifiedBy: String.Or(Null),
  lockedDate: String,
  lockedBy: String,
  issueId: Number,
  resourceId: Number,
  grouping: String,
  publicationYear: String,
  dateOfPublication: String,
  publishIssue: Boolean,
  issueLocked: Boolean,
  lastModified: String,
  filePrepDate: String.Or(Null),
  title: String.Or(Null),
  notesIndexer: String.Or(Null),
  notesPublisher: String.Or(Null),
  nameOfPublisher: String,
  resourceTitle: String,
  resource: String,
  managerName: String,
  companyName: String,
  artifactTypeId: Number,
  isRelated: Boolean,
  source: String.Or(Null),
  titleTypeId: Number,
  contentType: String,
}).And(TextTaskManagementBaseTaskValidator);

type TextTaskManagementArtifactTask = Static<typeof TextTaskManagementArtifactTaskValidator>
export default TextTaskManagementArtifactTask;
