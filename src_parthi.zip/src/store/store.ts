import { createStore } from 'redux';
import { useSelector, TypedUseSelectorHook } from 'react-redux';
import { rootReducer, RootState } from './root';

const store = createStore(rootReducer);

export const useTypedSelector: TypedUseSelectorHook<RootState> = useSelector;
export default store;
