import {
  Record, Number, String, Static, Runtype,
} from 'runtypes';

  interface LookIOption {
    Key: number;
    Value: string;
  }

export const custLookupOptionValidator: Runtype<LookIOption> = Record({
  Key: Number.withConstraint((n) => n > 0),
  Value: String,
});

  type LookupOption = Static<typeof custLookupOptionValidator>;
export default LookupOption;
