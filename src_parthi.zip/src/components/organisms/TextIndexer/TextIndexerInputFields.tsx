import React, { useState } from 'react';
import {
  createStyles, makeStyles, Paper, Grid, Typography, Divider, TextField, Tabs, Tab, Badge,
} from '@material-ui/core';
import { Formik } from 'formik';
// import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import * as Yup from 'yup';
import { useSnackbar } from 'notistack';
import { DateTime } from 'luxon';
import { useHistory } from 'react-router-dom';
import axios from 'axios';
import Autocomplete from '@material-ui/lab/Autocomplete';
import TabPanel from '../ResourceManagement/Tabs/TabPanel';
import TextArtifact from '../../../interfaces/TextIndexer/TextArtifact';
import TextInputField from '../../Shared/TextInputField';
import LongTextInputField from '../../Shared/LongTextInputField';
import LanguageTypedown from '../../molecules/MediaIndexer/LanguageTypedown';
import DocumentItemNode from '../../../interfaces/MediaIndexer/DocumentItemNode';
import DocumentLangNode from '../../../interfaces/MediaIndexer/DocumentLangNode';
import Dropdown from '../../Shared/Dropdown';
import SingleCheckbox from '../../molecules/SingleCheckbox';
import RepeatableDropdown from '../../molecules/RepeatableDropdown';
import TermsTypedown from '../../molecules/MediaIndexer/TermsTypedown';
import DocumentFastNode from '../../../interfaces/MediaIndexer/DocumentFastNode';
import Identifiers from '../../molecules/MediaIndexer/Identifiers';
import GeolocationsTypedown from '../../molecules/MediaIndexer/GeolocationsTypedown';
import RepeatableTextInputField from '../../molecules/RepeatableTextInputField';
import StickyActionBar from '../../atoms/StickyActionBar';
import TextIndexerInputActionButtons from './TextIndexerInputActionButtons';
import LookupOption from '../../../interfaces/LookupOption';
import { AppContext } from '../../Context';
import ArtifactErrorCode from '../../../interfaces/MediaIndexer/ArtifactErrorCode';
import ArtifactType from '../../../interfaces/enums/ArtifactType';
import SaveAndSubmitTextArtifactRequest from '../../../interfaces/TextIndexer/SaveAndSubmitTextArtifactRequest';
import TypedownDocumentItemNode from '../TypedownDocumentItemNode';
import CorporateAuthorTypedown from './CorporateAuthorTypedown';
import CorporateAuthor from '../../../interfaces/TextIndexer/CorporateAuthor';
import AuthorComponent from './AuthorComponent';
import TextResourceType from '../../../interfaces/TextIndexer/ReferenceData/TextResourceType';
import TextValidationSchemaComposer from '../../../utils/TextValidationSchemaComposer';
import LegalCaseComponent from './LegalCaseComponent';
import ResourceTypesHelper from '../../../utils/ConvertResourceTypesHelper';
import ResourceTypesDropdown from './ResourceTypesDropdown';
import AuthorRoleType from '../../../interfaces/TextIndexer/ReferenceData/AuthorRoleType';
import RadioButtonGroup from '../../molecules/RadioButtonGroup';
import ConfirmationDialogForList from '../../molecules/ConfirmationDialogForList';
import IndexerValidationHelper from '../../../utils/IndexerValidationHelper';
import ResourceStringHelper from '../../../utils/ResourceStringHelper';
import TextIndexingWarningStrings from '../../../res/TextIndexingWarningStrings';
import WorkflowStatus from '../../../interfaces/enums/WorkflowStatus';
import IndexingTypes from '../../../interfaces/enums/IndexingTypes';
import DropdownOption from '../../../interfaces/MediaIndexer/DropdownOption';
import NotesButton from '../../molecules/MediaIndexer/NotesButton';
import NoteCreatorType from '../../../interfaces/enums/NoteCreatorType';
import DocumentNote from '../../../interfaces/MediaIndexer/DocumentNote';
import { IndexerArtifactContext } from '../../contexts/IndexerArtifact';
import TextData from '../../../interfaces/TextIndexer/TextData';
import { TextValidationErrorDialog } from './TextValidationErrorDialog';
import * as Constants from '../../../constants/TextIndexerConstants';
import MaskedInputField from '../../molecules/MaskedInputField';
import LanguageOption from '../../../interfaces/MediaIndexer/LanguageOption';
import theme from '../../../config/theme';

const useStyles = makeStyles(createStyles({
  padding: {
    padding: theme.spacing(3),
  },
  demo1: {
    backgroundColor: theme.palette.background.paper,
  },
  demo2: {
    backgroundColor: '#2e1534',
  },
  root: {
    flexGrow: 1,
    backgroundColor: '#f9f9fc',
  },
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  textField: {
    width: 200,
  },
  mainContent: {
    marginTop: '80px',
    marginBottom: '10px',
    minWidth: '1585px',
  },
  contentRow: {
    marginBottom: 0,
    minWidth: 175,
  },
  sectionHeading: {
    textAlign: 'left',
    paddingTop: '15px',
  },
  thumbnailRow: {
    marginBottom: '30px',
  },
  thumbnailSubtitle: {
    textAlign: 'left',
    marginBottom: '15px',
  },
  button: {
    borderRadius: 50,
    margin: 5,
  },
  switchMediaPlayer: {
    top: '15px',
    left: '15px',
    height: '99%',
  },
  buttonContainer: {
    paddingTop: '20px',
  },
  divider: {
    marginTop: 20,
  },
  dividerContainer: {
    textAlign: 'right',
    '& .MuiTypography-overline': {
      fontWeight: 600,
    },
  },
  '@global': {
    '.MuiChip-label': {
      fontSize: '0.7rem',
    },
    '.MuiChip-root': {
      height: 24,
    },
    '.MuiChip-deleteIcon': {
      height: 16,
    },
  },
}));

interface TextIndexerInputFieldsProps {
  initialDocumentData: TextArtifact;
  artifactArticleId: number;
  readonly?: boolean;
  sectionNameOptions: string[];
  languagesLookup: LanguageOption[];
  authorRoleTypeLookup: AuthorRoleType[];
  genreLookup: DropdownOption[];
  descriptionTypeLookup: LookupOption[];
  resourceTypeLookup: TextResourceType[];
  mediaTypeLookup: LookupOption[];
  accessRightLookup: LookupOption[];
  locationSuggestions: string[];
  topicSuggestions: string[];
  submitTasks: string[];
  errorCodes: ArtifactErrorCode[];

  updateArtifactStatus(newStatus: number): void;
  artifactStatusId: number;
  workflowStatusId: WorkflowStatus;
  indexingTypes: IndexingTypes[];
  issueResourceTypeId: number;
  saveArtifact(data: TextArtifact): void;
  approveIssueQA(): void;
  approveIssueQAReady: boolean;
  updateValidationError(errorStringList: string[]): void;
}

interface WarningDialogData {
  isOpen: boolean;
  warnings: string[];
  action: string;
}

interface ValidationDialogData {
  isOpen: boolean;
  errors: number[];
  action: string;
  isPublishing: boolean;
}

const compareDateTimes = (a: DateTime, b: DateTime) => {
  if (a === b) return 0;
  return a > b ? 1 : -1;
};

export default (props: TextIndexerInputFieldsProps): JSX.Element => {
  const classes = useStyles();
  const [Tabvalue, setTabvalue] = React.useState(0);
  const { enqueueSnackbar } = useSnackbar();
  const context = React.useContext(AppContext);
  const history = useHistory();
  const indexerContext = React.useContext(IndexerArtifactContext);

  const errorSnackbarFunction = (message: string) => enqueueSnackbar(message, { variant: 'error' });
  const [warningDialogData, setWarningDialogData] = useState<WarningDialogData>({
    isOpen: false,
    warnings: [],
    action: '',
  });

  const [validationDialogData, setValidationDialogData] = useState<ValidationDialogData>({
    isOpen: false,
    errors: [],
    action: '',
    isPublishing: false,
  });

  // const onBackButtonClick = () => {
  //  if (history.length) {
  //    history.goBack();
  //  } else {
  //    history.push('/');
  //  }
  // };
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const handleTabChange = (event: any, newValue: React.SetStateAction<number>) => {
    setTabvalue(newValue);
  };
  const baseValidationSchema: Yup.ObjectSchema = TextValidationSchemaComposer.GetSchema(props.workflowStatusId).schema;
  const DateMask = [/[1-9]/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/];

  return (
    <>
      <Formik
        initialValues={props.initialDocumentData}
        onSubmit={() => undefined}
        validationSchema={baseValidationSchema}
        validateOnBlur
        validateOnChange
      >
        {(formikProps) => {
          const {
            values,
            // touched,
            errors,
            // dirty,
            setFieldValue,
            // isSubmitting,
            handleChange,
            handleBlur,
            // handleSubmit,
            // handleReset,
            validateForm,
            // isValid,
            initialValues,
          } = formikProps;

          const setGenreFieldWithId = (
            valueKey: string,
            idKey: string,
            value: number,
            lookup: DropdownOption[],
          ) => {
            const lookupOption = lookup.find((option) => option.value === value);
            // first update the field holding the string value
            setFieldValue(valueKey, lookupOption?.display, true);
            // then update the field holding the id
            setFieldValue(idKey, value, false);
          };

          /*           const setRecourceTypeFieldWithId = (
            valueKey: string,
            idKey: string,
            id: number,
            stringValue: string,
          ) => {
            // first update the field holding the string value
            setFieldValue(valueKey, stringValue.trim(), true);
            // then update the field holding the id
            setFieldValue(idKey, id, true);
          }; */

          const setDocumentItemNodeArray = (
            key: string,
            currentValues: DocumentItemNode[],
            initialArrayValues: DocumentItemNode[],
          ) => {
            const newValues: DocumentItemNode[] = [];

            // check if the node was present in the initial values
            currentValues.forEach((currentValue) => {
              const initiallyExistingNode = initialArrayValues.find((initialValue) => initialValue.id === currentValue.id);
              // if this is a new node, fill it with data
              if (initiallyExistingNode === undefined) {
                newValues.push({
                  ...currentValue,
                  createdBy: context.userInfo.data.name,
                  createdDate: DateTime.local().toString(),
                });
              // if the node was already present initially, populate it with the same data
              } else {
                newValues.push({ ...initiallyExistingNode });
              }
              setFieldValue(key, newValues, true);
            });
          };

          const setDocumentFastNode = (
            key: string,
            currentValues: DocumentFastNode[],
          ) => {
            const newValues: DocumentFastNode[] = [];

            currentValues.forEach((currentValue) => {
              if (currentValue.createdBy === '') {
                newValues.push({
                  ...currentValue,
                  createdBy: context.userInfo.data.name,
                  createdDate: DateTime.local().toString(),
                });
              // if the node was already present initially, populate it with the same data
              } else {
                newValues.push(currentValue);
              }
              setFieldValue(key, newValues, true);
            });
          };

          const setPagination = (
            key: string,
            paginationValue: string,
          ) => {
            // First set the pagination value
            setFieldValue(key, paginationValue, true);

            // Now we need to extract the first and last page from the pagination and act accordingly
            if (paginationValue !== undefined && paginationValue.length > 0) {
              // If there is a hyphen then try and extract the first page and last page, otherwise set the values of both to the one page listed if possible
              if (paginationValue.indexOf('-') > 0) {
                const fPage: string = paginationValue.split(/-(.+)/)[0];
                const lPage: string = paginationValue.split(/-(.+)/)[1];

                if (fPage !== undefined) {
                  setFieldValue('fPage', fPage.trim(), true);
                } else {
                  setFieldValue('fPage', '', true);
                }

                if (lPage !== undefined) {
                  setFieldValue('lPage', lPage.trim(), true);
                } else {
                  setFieldValue('lPage', '', true);
                }
              } else {
                const pageValue: string = paginationValue.trim();

                setFieldValue('fPage', pageValue, true);
                setFieldValue('lPage', pageValue, true);
              }
            }
          };

          const deleteArtifact = (): void => {
            context.showBlockUi();

            const data = {
              artifactId: props.initialDocumentData.artifactId,

            };

            axios.post(`${process.env.REACT_APP_API_URL}/api/ArticleIndexer/delete`, data)
              .then(() => {
                enqueueSnackbar('Artifact deleted successfully.', {
                  variant: 'success',
                });
                indexerContext.setHasChanges(false);
                indexerContext.updateArtifact<TextData>({ ...indexerContext.Artifact, isReadOnly: true } as TextData);
              })
              .catch(() => {
                enqueueSnackbar('An error occurred when trying to delete the artifact', {
                  variant: 'error',
                });
              })
              .finally(() => {
                context.hideBlockUi();
              });
          };

          const saveAndSubmitArtifact = (data: TextArtifact, action: string, validate: boolean) => {
            validateForm(data)
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              .then((formKeys: any) => {
                if (action !== '' && Object.keys(formKeys).length === 0) {
                  const warnings = IndexerValidationHelper.ValidateTextIndexerWarnings(data, false);
                  // If we have any warnings and the warning dialog is not already open then we want to open the warning dialog
                  if (!warningDialogData.isOpen && !warnings.isValid) {
                    const warningMessages = ResourceStringHelper.MapNumberListToStringList(TextIndexingWarningStrings, warnings.errors);

                    setWarningDialogData({
                      isOpen: true,
                      warnings: warningMessages,
                      action,
                    });
                  } else {
                    // proceed save and submit call here
                    // Check minimum requirements?
                    // eslint-disable-next-line @typescript-eslint/no-unused-vars
                    const request: SaveAndSubmitTextArtifactRequest = {
                      action,
                      documentData: data,
                      validateArtifact: validate,

                    };
                    context.showBlockUi();

                    axios.post(`${process.env.REACT_APP_API_URL}/api/ArticleIndexer/validate`, data)
                      .then(() => axios.post(`${process.env.REACT_APP_API_URL}/api/ArticleIndexer/saveandsubmitartifact`, request)).then(() => {
                        enqueueSnackbar('Artifact Saved', {
                          variant: 'success',
                        });
                        indexerContext.setHasChanges(false);
                        history.goBack();
                      }).catch((error) => {
                        if (error.response.status === 400 && error.response.data !== null && error.response.data !== undefined
                            && error.response.data.length > 0) {
                          props.updateValidationError([]);
                          const errorNumberList: number[] = error.response.data.map((x: {id: number}) => x.id);
                          setValidationDialogData((prevState) => ({
                            ...prevState,
                            isOpen: true,
                            errors: errorNumberList,
                            action,
                            isPublishing: false,
                          }));
                        } else {
                          enqueueSnackbar('An error occurred when trying to save the artifact', {
                            variant: 'error',
                          });
                        }
                      })
                      .finally(() => {
                        context.hideBlockUi();
                        setWarningDialogData({
                          isOpen: false,
                          warnings: [],
                          action: '',
                        });
                      });
                  }
                } else {
                  const element: Element = document.getElementsByClassName('Mui-error')[0];

                  if (element !== undefined) {
                    window.scrollBy({
                      top: element.getBoundingClientRect().top - 100,
                      behavior: 'smooth',
                    });
                  }
                }
              });
          };

          const saveAndPublishArtifact = (data: TextArtifact, validate: boolean) => {
            validateForm(values)
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              .then((formKeys: any) => {
                if (Object.keys(formKeys).length === 0) {
                  context.showBlockUi();

                  const requestData: SaveAndSubmitTextArtifactRequest = {
                    action: '',
                    documentData: data,
                    validateArtifact: validate,

                  };

                  axios.post(`${process.env.REACT_APP_API_URL}/api/articleindexer/saveandpublisharticleartifact`, requestData)
                    .then(() => {
                      enqueueSnackbar('Article published successfully');
                      indexerContext.setHasChanges(false);

                      if (history.length > 0) {
                        history.goBack();
                      } else {
                        history.push('/tasks/text');
                      }
                    })
                    .catch((error) => {
                      if (error.response.status === 400 && error.response.data !== null && error.response.data !== undefined
                            && error.response.data.length > 0) {
                        setValidationDialogData((prevState) => ({
                          ...prevState,
                          isOpen: true,
                          errors: error.response.data,
                          isPublishing: true,
                        }));
                      } else {
                        enqueueSnackbar('An error ocurred while trying to save and publish the artifact', { variant: 'error' });
                      }
                    })
                    .finally(() => {
                      context.hideBlockUi();
                    });
                } else {
                  const element: Element = document.getElementsByClassName('Mui-error')[0];

                  if (element !== undefined) {
                    window.scrollBy({
                      top: element.getBoundingClientRect().top - 100,
                      behavior: 'smooth',
                    });
                  }
                }
              });
          };

          const approveIssueQA = () => {
            validateForm(values)
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              .then((formKeys: any) => {
                if (Object.keys(formKeys).length === 0) {
                  context.showBlockUi();

                  props.approveIssueQA();
                } else {
                  const element: Element = document.getElementsByClassName('Mui-error')[0];

                  if (element !== undefined) {
                    window.scrollBy({
                      top: element.getBoundingClientRect().top - 100,
                      behavior: 'smooth',
                    });
                  }
                }
              });
          };

          const getNotes = () => (
            [
              ...values.publisherNotes.map((note) => ({ ...note, noteType: NoteCreatorType.Publisher })),
              ...values.resourceManagerNotes.map((note) => ({ ...note, noteType: NoteCreatorType.ResourceManager })),
              ...values.indexerNotes.map((note) => ({ ...note, noteType: NoteCreatorType.Indexer })),
            ].sort((a, b) => (compareDateTimes(DateTime.fromISO(a.createdDate), DateTime.fromISO(b.createdDate))))
          );

          const addIndexerNote = (newNoteText: string) => {
            const newNote: DocumentNote = {
              note: newNoteText,
              createdBy: context.userInfo.data.name,
              createdDate: DateTime.local().toString(),
              noteType: NoteCreatorType.Indexer,
            };

            setFieldValue('indexerNotes', [...values.indexerNotes, newNote]);
          };

          const removeIndexerNote = (toDelete: DocumentNote) => {
            const newIndexerNotes = values.indexerNotes.filter((note: DocumentNote) => (
              note.note !== toDelete.note
              || note.createdBy !== toDelete.createdBy
              || note.createdDate !== toDelete.createdDate
              || note.noteType !== toDelete.noteType
            ));

            setFieldValue('indexerNotes', newIndexerNotes);
          };

          // Change hasChanges flag so we know if there have been any unsaved changes
          React.useEffect(() => {
            if (indexerContext.hasChanges !== null) {
              if (!indexerContext.hasChanges) {
                indexerContext.setHasChanges(true);
              }
            } else {
              indexerContext.setHasChanges(false);
            }
          }, [values]);

          return (
            <div style={{ position: 'relative' }}>
              <StickyActionBar offset={props.readonly ? 1 : 0}>
                {/* <Button
                  size="small"
                  color="primary"
                  variant="outlined"
                  onClick={onBackButtonClick}
                  startIcon={<ArrowBackIcon />}
                  className={classes.button}
                >
                  Back
                </Button> */}
                <TextIndexerInputActionButtons
                  errorCodes={props.errorCodes}
                  submitTasks={props.submitTasks}
                  saveArtifact={() => props.saveArtifact(values)}
                  updateArtifactStatus={props.updateArtifactStatus}
                  artifactStatus={props.artifactStatusId}
                  saveAndSubmitArtifact={(action: string) => {
                    saveAndSubmitArtifact(values, action, true);
                  }}
                  saveAndPublishArtifact={() => saveAndPublishArtifact(values, true)}
                  artifactId={props.initialDocumentData.artifactId}
                  formHasChange={initialValues !== values}
                  readonly={props.readonly}
                  deleteArtifact={deleteArtifact}
                  workflowStatusId={props.workflowStatusId}
                  isAdmin={context.userInfo?.isInRole('InformitAdmin')}
                  approveIssueQA={approveIssueQA}
                  approveIssueQAReady={props.approveIssueQAReady}
                />
                <div style={{ float: 'right' }}>
                  <NotesButton
                    notes={getNotes()}
                    addNoteFunction={addIndexerNote}
                    removeNoteFunction={removeIndexerNote}
                    isReadOnly={props.readonly}
                    currentUser={context.userInfo.data.name}
                  />
                </div>
              </StickyActionBar>

              <Paper style={{ paddingLeft: '40px', paddingRight: '40px', paddingBottom: '40px' }}>
                <Grid item xs={12}>

                  <Tabs value={Tabvalue} onChange={handleTabChange} aria-label="styled tabs example">

                    <Tab label={<Badge badgeContent={(errors.title ? 1 : 0) + (errors.subtitle ? 1 : 0) + (errors.sectionName ? 1 : 0) + (errors.mediaTypes ? 1 : 0) + (errors.resourceType ? 1 : 0) + (errors.isMinor ? 1 : 0) + (errors.descriptionType ? 1 : 0) + (errors.description ? 1 : 0) + (errors.pagination ? 1 : 0) + (errors.eLocation ? 1 : 0) + (errors.articlePublishDate ? 1 : 0) + (errors.genre ? 1 : 0) + (errors.fPage ? 1 : 0) + (errors.lPage ? 1 : 0) + (errors.isPeerReviewedArticle ? 1 : 0)} color="error">Main Details</Badge>} />

                    <Tab label={<Badge badgeContent={(errors.authors ? 1 : 0) + (errors.corporateAuthors ? 1 : 0) + (errors.fast ? 1 : 0) + (errors.fastGeo ? 1 : 0) + (errors.identifiers ? 1 : 0)} color="error">Contributors & Subjects</Badge>} />

                    {props.indexingTypes.includes(IndexingTypes.Legal) && (

                    <Tab label={<Badge badgeContent={(errors.aglibsSubjects ? 1 : 0) + (errors.legalCase ? 1 : 0) + (errors.legislation ? 1 : 0) + (errors.jurisdiction ? 1 : 0) + (errors.treaty ? 1 : 0)} color="error">Advanced (Legal)</Badge>} />

                    )}

                    <Tab label={<Badge badgeContent={(errors.articleOrder ? 1 : 0) + (errors.persistentIdentifier ? 1 : 0) + (errors.doi ? 1 : 0) + (errors.urIs ? 1 : 0) + (errors.uRIIndicator ? 1 : 0) + (errors.languages ? 1 : 0) + (errors.articlePPVPrice ? 1 : 0) + (errors.articlePPVBlock ? 1 : 0) + (errors.publishArtifact ? 1 : 0) + (errors.accessRightId ? 1 : 0)} color="error">Additional</Badge>} />

                  </Tabs>

                  <TabPanel value={Tabvalue} index={0}>
                    <Grid item xs={12} style={{ marginBottom: 15 }} className={classes.dividerContainer}>
                      <Divider className={classes.divider} />
                      <Typography variant="overline" style={{ width: '100%' }}>Main Details</Typography>
                    </Grid>
                    <Grid item xs={9} className={classes.contentRow}>
                      {/* Title */}
                      <TextInputField
                        labelText="Title"
                        inputText={values.title}
                        keyName="title"
                        onChangeFunction={handleChange}
                        onBlur={handleBlur}
                        error={!!errors.title}
                        errorMessage={errors.title}
                        readOnly={props.readonly}
                      />
                    </Grid>

                    <Grid item xs={9} className={classes.contentRow}>
                      {/* Subtitle */}
                      <TextInputField
                        labelText="Subtitle"
                        inputText={values.subtitle}
                        keyName="subtitle"
                        onChangeFunction={handleChange}
                        onBlur={handleBlur}
                        error={!!errors.subtitle}
                        errorMessage={errors.subtitle}
                        readOnly={props.readonly}
                      />
                    </Grid>

                    <Grid item xs={9} className={classes.contentRow}>
                      {/* Section Name */}
                      <Autocomplete
                        freeSolo
                        autoSelect
                        options={props.sectionNameOptions}
                        onChange={handleChange}
                        value={values.sectionName}
                        id="sectionName"
                        onBlur={handleBlur}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Section Name"
                            margin="normal"
                            variant="outlined"
                            name="sectionName"
                            fullWidth
                          />
                        )}
                      />
                    </Grid>

                    <Grid item xs={4} className={classes.contentRow}>
                      {/* Media Types */}
                      <RepeatableDropdown
                        selectedOptions={values.mediaTypes}
                        allOptions={props.mediaTypeLookup}
                        initiallySelectedOptions={initialValues.mediaTypes}
                        currentUser={context.userInfo.data.name}
                        label="Media Types"
                        keyName="mediaTypes"
                        onChangeFunction={(key: string, value: DocumentItemNode[]) => setFieldValue(key, value, true)}
                        error={!!errors.mediaTypes}
                        errorMessage={Array.isArray(errors.mediaTypes) ? errors.mediaTypes.join(' ') : errors.mediaTypes}
                        disabled={props.readonly}
                      />
                    </Grid>

                    <Grid item xs={4} className={classes.contentRow}>
                      {/* Resource Type */}
                      <ResourceTypesDropdown
                        labelText="Resource Type"
                        options={ResourceTypesHelper.ConvertResourceTypes(props.resourceTypeLookup, props.issueResourceTypeId)}
                        id="ResourceTypeId"
                        selectedOption={values.resourceTypeId}
                        keyName="resourceTypeId"
                        onChangeFunction={(key: string, id: number) => setFieldValue(key, id, true)}
                        error={!!errors.resourceTypeId}
                        errorMessage={errors.resourceTypeId}
                        isReadOnly={props.readonly}
                      />
                    </Grid>

                    <Grid item xs={4} className={classes.contentRow} style={{ marginTop: 15 }}>
                      {/* Value Level */}
                      <RadioButtonGroup
                        readonly={props.readonly}
                        name="isMinor"
                        label="Value Level"
                        value={values.isMinor ? 'minor' : 'major'}
                        onBlur={handleBlur}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>, value: string) => setFieldValue('isMinor', value === 'minor', true)}
                        buttons={[
                          {
                            label: 'Major',
                            value: 'major',
                          },
                          {
                            label: 'Minor',
                            value: 'minor',
                          },
                        ]}
                      />
                    </Grid>

                    <Grid item xs={12} style={{ marginTop: 15 }} />

                    <Grid item xs={4} className={classes.contentRow}>
                      {/* Description Type */}
                      <Dropdown
                        id="DescriptionTypeId"
                        keyName="descriptionTypeID"
                        labelText="Description Type"
                        options={props.descriptionTypeLookup.map((o) => ({ display: o.value, value: o.key }))}
                        selectedOption={values.descriptionTypeID}
                        onChangeFunction={(keyName: string, value: number) => setFieldValue(keyName, value, true)}
                        value={values.descriptionTypeID ? values.descriptionTypeID : ''}
                        helperText={errors.descriptionType}
                        error={!!errors.descriptionType}
                      />
                    </Grid>

                    <Grid item xs={9} className={classes.contentRow}>
                      {/* Description */}
                      <LongTextInputField
                        labelText="Description"
                        inputText={values.description}
                        keyName="description"
                        onChangeFunction={handleChange}
                        onBlur={handleBlur}
                        error={!!errors.description}
                        errorMessage={errors.description}
                        readOnly={props.readonly}
                      />
                    </Grid>

                    <Grid item xs={4} className={classes.contentRow}>
                      {/* Pagination */}
                      <TextInputField
                        labelText="Pagination"
                        inputText={values.pagination}
                        keyName="pagination"
                        onChangeFunction={(key: string, value: string) => setPagination(key, value)}
                        onBlur={handleBlur}
                        error={!!errors.pagination}
                        errorMessage={errors.pagination}
                        readOnly={props.readonly}
                        customHandleChangeFunction
                      />
                    </Grid>

                    <Grid item xs={4} className={classes.contentRow}>
                      {/* First Page */}
                      <TextField
                        label="First Page"
                        value={values.fPage}
                        name="fPage"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        error={!!errors.fPage}
                        helperText={errors.fPage}
                        disabled={props.readonly}
                        margin="normal"
                        variant="outlined"
                        InputLabelProps={{
                          shrink: (values.fPage !== undefined && values.fPage !== null && values.fPage.length > 0),
                        }}
                      />
                    </Grid>

                    <Grid item xs={4} className={classes.contentRow}>
                      {/* Last Page */}
                      <TextField
                        label="Last Page"
                        value={values.lPage}
                        name="lPage"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        error={!!errors.lPage}
                        helperText={errors.lPage}
                        disabled={props.readonly}
                        margin="normal"
                        variant="outlined"
                        InputLabelProps={{
                          shrink: (values.lPage !== undefined && values.lPage !== null && values.lPage.length > 0),
                        }}
                      />
                    </Grid>

                    <Grid item xs={12} style={{ marginTop: 15 }} />

                    {/* eLocation */}
                    <TextField
                      label="eLocation"
                      value={values.eLocation}
                      name="eLocation"
                      type="text"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      error={!!errors.eLocation}
                      helperText={errors.eLocation}
                      disabled={props.readonly}
                      margin="normal"
                      variant="outlined"
                    />

                    <Grid item xs={12} style={{ marginTop: 15 }} />

                    <Grid item xs={4} className={classes.contentRow}>
                      {/* Peer Reviewed */}
                      <SingleCheckbox
                        label="Peer Reviewed"
                        checked={values.isPeerReviewedArticle}
                        keyName="isPeerReviewedArticle"
                        onBlur={handleBlur}
                        onChange={() => setFieldValue('isPeerReviewedArticle', !values.isPeerReviewedArticle, true)}
                        error={!!errors.isPeerReviewedArticle}
                        disabled={props.readonly}
                      />
                    </Grid>

                    <Grid item xs={12} style={{ marginTop: 15 }} />

                    <Grid item xs={4} className={classes.contentRow}>
                      {/* Article Publish Date */}
                      <MaskedInputField
                        value={values.articlePublishDate}
                        labelText="Article Publish Date"
                        name="articlePublishDate"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        error={!!errors.articlePublishDate}
                        helperText={errors.articlePublishDate}
                        disabled={props.readonly}
                        mask={DateMask}
                      />
                    </Grid>

                    <Grid item xs={4} className={classes.contentRow}>
                      {/* Genre */}
                      <Dropdown
                        labelText="Genre"
                        options={props.genreLookup}
                        id="Genre"
                        selectedOption={values.genreID ?? null}
                        keyName="genre"
                        onChangeFunction={(key: string, value: number) => setGenreFieldWithId(key, 'genreID', value, props.genreLookup)}
                        error={!!errors.genre}
                        errorMessage={errors.genre}
                        isReadOnly={props.readonly}
                        allowUnselect
                      />
                    </Grid>
                  </TabPanel>
                  <TabPanel value={Tabvalue} index={1}>
                    <Grid item xs={12} style={{ marginBottom: 15 }} className={classes.dividerContainer}>
                      <Divider className={classes.divider} />
                      <Typography variant="overline">Contributors</Typography>
                    </Grid>

                    <Grid item xs={10} className={classes.contentRow}>
                      {/* Author */}
                      <AuthorComponent
                        isLegal={props.indexingTypes.includes(IndexingTypes.Legal)}
                        artifactArticleId={props.artifactArticleId}
                        roleTypeLookup={props.authorRoleTypeLookup}
                        initialAuthors={initialValues.authors}
                        selectedAuthors={values.authors}
                        keyName="authors"
                        onChangeFunction={setFieldValue}
                      />
                    </Grid>

                    <Grid item xs={12} style={{ marginTop: 30 }} />

                    <Grid item xs={10} className={classes.contentRow}>
                      <CorporateAuthorTypedown
                        isLegal={props.indexingTypes.includes(IndexingTypes.Legal)}
                        userName={context.userInfo.data.name}
                        roleTypeLookup={props.authorRoleTypeLookup}
                        initialCorporateAuthors={initialValues.corporateAuthors}
                        selectedCorporateAuthors={values.corporateAuthors}
                        readonly={props.readonly}
                        onChangeMultiple={(data: CorporateAuthor[]) => setFieldValue('corporateAuthors', data, true)}
                      />
                    </Grid>

                    <Grid item xs={12} style={{ marginBottom: 15 }} className={classes.dividerContainer}>
                      <Divider className={classes.divider} />
                      <Typography variant="overline">Subjects</Typography>
                    </Grid>

                    <Grid item xs={12} className={classes.contentRow}>
                      {/* FAST Terms */}
                      <TermsTypedown
                        selectedTerms={values.fast}
                        topicSuggestions={[]}
                        keyName="fast"
                        onChangeFunction={(key: string, value: DocumentFastNode[]) => setDocumentFastNode(key, value)}
                        fastAndIdentifierCount={0}
                        fastAndIdentifierLimit={Constants.FastAndIndentifiersTypedownLimit}
                        error={!!errors.fast}
                        errorText={errors.fast?.toString()}
                        readOnly={props.readonly}
                        artifactTypeId={ArtifactType.Text}
                        disabled={values.isMinor}
                      />
                    </Grid>

                    <Grid item xs={12} style={{ marginTop: 30 }} />

                    <Grid item xs={12} className={classes.contentRow}>
                      {/* FAST Geolocations */}
                      <GeolocationsTypedown
                        selectedGeolocations={values.fastGeo}
                        locationSuggestions={[]}
                        keyName="fastGeo"
                        onChangeFunction={(key: string, value: DocumentFastNode[]) => setDocumentFastNode(key, value)}
                        error={!!errors.fastGeo}
                        errorText={errors.fastGeo?.toString()}
                        readOnly={props.readonly}
                        typedownLimit={6}
                        artifactTypeId={ArtifactType.Text}
                        disabled={values.isMinor}
                      />
                    </Grid>

                    <Grid item xs={12} style={{ marginTop: 30 }} />

                    <Grid item xs={12} className={classes.contentRow}>
                      {/* Identifiers */}
                      <Identifiers
                        selectedIdentifiers={values.identifiers}
                        keyName="identifiers"
                        onChangeFunction={
                        (key: string, value: DocumentItemNode[]) => setDocumentItemNodeArray(key, value, initialValues.identifiers)
                      }
                        fastAndIdentifierCount={0}
                        fastAndIdentifierLimit={6}
                        error={!!errors.identifiers}
                        errorText={errors.identifiers?.toString()}
                        readOnly={props.readonly}
                        errorSnackbarFunction={errorSnackbarFunction}
                        artifactType={ArtifactType.Text}
                        disabled={values.isMinor}
                      />
                    </Grid>
                  </TabPanel>

                  {props.indexingTypes.includes(IndexingTypes.Legal) && (
                    <>
                      <TabPanel value={Tabvalue} index={2}>
                        <Grid item xs={12} style={{ marginBottom: 15 }} className={classes.dividerContainer}>
                          <Divider className={classes.divider} />
                          <Typography variant="overline">ADVANCED (LEGAL)</Typography>
                        </Grid>

                        <Grid item xs={8} style={{ marginTop: 15 }} className={classes.contentRow}>
                          {/* Agis Subject */}
                          <TypedownDocumentItemNode
                            url={`${process.env.REACT_APP_API_URL}/api/indexing/searchagissubjects`}
                            label="AGLIBs"
                            selectedOptions={values.aglibsSubjects}
                            initiallySelectedOptions={initialValues.aglibsSubjects}
                            onChangeMultiple={(data) => setFieldValue('aglibsSubjects', data, true)}
                            disabled={values.isMinor}
                            error={!!errors.aglibsSubjects}
                            errorMessage={errors.aglibsSubjects?.toString()}
                            typedownLimit={Constants.AGISSubjectsTypedownLimit}
                          />
                        </Grid>

                        <Grid item xs={8} style={{ marginTop: 15 }} className={classes.contentRow}>
                          {/* Legislation */}
                          <TypedownDocumentItemNode
                            url={`${process.env.REACT_APP_API_URL}/indexing/searchlegislation`}
                            label="Legislation"
                            selectedOptions={values.legislation}
                            initiallySelectedOptions={initialValues.legislation}
                            onChangeMultiple={(data) => setFieldValue('legislation', data, true)}
                            disabled={values.isMinor}
                            error={!!errors.legislation}
                            errorMessage={errors.legislation?.toString()}
                            typedownLimit={Constants.LegislationTypedownLimit}
                          />
                        </Grid>

                        <Grid item xs={8} style={{ marginTop: 15 }} className={classes.contentRow}>
                          {/* Legal Case */}
                          <LegalCaseComponent
                            selectedLegalCases={values.legalCase}
                            initiallySelectedLegalCases={initialValues.legalCase}
                            onChangeMultiple={(data) => setFieldValue('legalCase', data)}
                            userName={context.userInfo.data.name}
                            disabled={values.isMinor}
                            error={!!errors.legalCase}
                            errorMessage={errors.legalCase?.toString()}
                            typedownLimit={Constants.LegalCaseTypedownLimit}
                          />
                        </Grid>

                        <Grid item xs={8} style={{ marginTop: 15 }} className={classes.contentRow}>
                          {/* Jurisdiction */}
                          <TypedownDocumentItemNode
                            url={`${process.env.REACT_APP_API_URL}/api/indexing/searchjurisdictions`}
                            label="Jurisdictions"
                            selectedOptions={values.jurisdiction}
                            initiallySelectedOptions={initialValues.jurisdiction}
                            onChangeMultiple={(data) => setFieldValue('jurisdiction', data, true)}
                            disabled={values.isMinor}
                            error={!!errors.jurisdiction}
                            errorMessage={errors.jurisdiction?.toString()}
                            typedownLimit={Constants.JurisdictionTypedownLimit}
                          />
                        </Grid>

                        <Grid item xs={8} style={{ marginTop: 15 }} className={classes.contentRow}>
                          {/* Treaty */}
                          <TypedownDocumentItemNode
                            url={`${process.env.REACT_APP_API_URL}/api/indexing/searchtreaties`}
                            label="Treaties"
                            selectedOptions={values.treaty}
                            initiallySelectedOptions={initialValues.treaty}
                            onChangeMultiple={(data) => setFieldValue('treaty', data, true)}
                            disabled={values.isMinor}
                            error={!!errors.treaty}
                            errorMessage={errors.treaty?.toString()}
                            typedownLimit={Constants.TreatyTypedownLimit}
                          />
                        </Grid>
                      </TabPanel>
                    </>
                  )}

                  <TabPanel value={Tabvalue} index={props.indexingTypes.includes(IndexingTypes.Legal) ? 3 : 2}>
                    <Grid item xs={12} style={{ marginBottom: 15 }} className={classes.dividerContainer}>
                      <Divider className={classes.divider} />
                      <Typography variant="overline">Assigned Details</Typography>
                    </Grid>

                    <Grid item xs={2} className={classes.contentRow}>
                      {/* Article Order */}
                      <TextInputField
                        labelText="Article Order"
                        inputText={values.articleOrder}
                        keyName="articleOrder"
                        onBlur={handleBlur}
                        error={!!errors.articleOrder}
                        errorMessage={errors.articleOrder}
                        type="number"
                        onChangeFunction={handleChange}
                        readOnly={props.readonly}
                      />
                    </Grid>

                    <Grid item xs={12} style={{ marginTop: 15 }} />

                    <Grid item xs={9} className={classes.contentRow}>
                      {/* DOI Identifier */}
                      <TextInputField
                        labelText="DOI Identifier"
                        inputText={values.doi}
                        keyName="doi"
                        onChangeFunction={handleChange}
                        onBlur={handleBlur}
                        error={!!errors.doi}
                        errorMessage={errors.doi}
                        readOnly={props.readonly}
                      />
                    </Grid>

                    <Grid item xs={9} className={classes.contentRow}>
                      {/* Persistence Identifier */}
                      <TextInputField
                        labelText="Persistence Identifier"
                        inputText={values.persistentIdentifier}
                        keyName="persistentIdentifier"
                        onChangeFunction={handleChange}
                        onBlur={handleBlur}
                        error={!!errors.persistentIdentifier}
                        errorMessage={errors.persistentIdentifier}
                        readOnly={props.readonly}
                      />
                    </Grid>

                    <Grid item xs={12} className={classes.contentRow}>
                      {/* URIs */}
                      <RepeatableTextInputField
                        labelText="URIs"
                        addedItems={values.urIs}
                        keyName="urIs"
                        onChangeFunction={setFieldValue}
                        onBlur={handleBlur}
                        error={!!errors.urIs}
                        errorMessage={Array.isArray(errors.urIs) ? errors.urIs.join(' ') : errors.urIs}
                        disabled={props.readonly}
                      />
                    </Grid>

                    <Grid item xs={12} className={classes.contentRow}>
                      {/* Language */}
                      <LanguageTypedown
                        selectedLanguages={values.languages}
                        languageLookup={props.languagesLookup}
                        keyName="languages"
                        onChangeFunction={(key: string, value: DocumentLangNode[]) => setFieldValue(key, value)}
                        error={!!errors.languages}
                        typedownLimit={Constants.LanguageTypedownLimit}
                        readOnly={props.readonly}
                        currentUser={context.userInfo.data.name}
                      />
                    </Grid>

                    {context.userInfo.isInRole('InformitAdmin') && (
                    <>
                      <Grid item xs={12} className={classes.dividerContainer} style={{ marginBottom: 15 }}>
                        <Divider className={classes.divider} />
                        <Typography variant="overline">Admin</Typography>
                      </Grid>

                      <Grid item xs={12} className={classes.contentRow}>
                        {/* Show on Web */}
                        <SingleCheckbox
                          label="Allow Publish Artifact"
                          checked={values.publishArtifact}
                          keyName="publishArtifact"
                          onBlur={handleBlur}
                          onChange={() => setFieldValue('publishArtifact', !values.publishArtifact, true)}
                          error={!!errors.publishArtifact}
                          disabled={props.readonly}
                        />
                      </Grid>

                      <Grid item xs={4} className={classes.contentRow}>
                        {/* Article PPV Block */}
                        <SingleCheckbox
                          label="PPV Access"
                          checked={values.articlePPVBlock}
                          keyName="articlePPVBlock"
                          onBlur={handleBlur}
                          onChange={() => setFieldValue('articlePPVBlock', !values.articlePPVBlock, true)}
                          error={!!errors.articlePPVBlock}
                          disabled={props.readonly}
                        />
                      </Grid>

                      <Grid item xs={4} className={classes.contentRow}>
                        {/* PPV Input */}
                        <TextInputField
                          labelText="PPV Price"
                          inputText={values.articlePPVPrice}
                          keyName="articlePPVPrice"
                          onChangeFunction={handleChange}
                          onBlur={handleBlur}
                          error={!!errors.articlePPVPrice}
                          errorMessage={errors.articlePPVPrice}
                          readOnly={props.readonly}
                          type="number"
                        />
                      </Grid>

                      <Grid item xs={4} className={classes.contentRow}>
                        {/* Access Rights */}
                        <Dropdown
                          labelText="Access Rights"
                          onChangeFunction={(keyName: string, value: number) => setFieldValue(keyName, value, true)}
                          onBlur={handleBlur}
                          value={values.accessRightId ? values.accessRightId : ''}
                          options={props.accessRightLookup.map((lo) => ({ display: lo.value, value: lo.key }))}
                          id="accessRights"
                          keyName="accessRightId"
                          error={!!errors.accessRightId}
                          errorMessage={errors.accessRightId}
                        />
                      </Grid>

                    </>
                    )}
                  </TabPanel>

                </Grid>

              </Paper>
              <ConfirmationDialogForList
                dialogTitle="Warning"
                dialogBodyText="There seem to be some issues with this artifact, please confirm the warnings below before continuing"
                dialogBodyList={warningDialogData.warnings}
                onProceed={() => saveAndSubmitArtifact(values, warningDialogData.action, true)}
                onReturn={() => setWarningDialogData({
                  isOpen: false,
                  warnings: [],
                  action: '',
                })}
                isOpen={warningDialogData.isOpen}
              />
              <TextValidationErrorDialog
                isOpen={validationDialogData.isOpen}
                onReturn={() => {
                  setValidationDialogData((prevState) => ({
                    ...prevState,
                    errors: [],
                    isOpen: false,
                    k2Action: '',
                    isPublishing: false,
                  }));
                }}
                errors={validationDialogData.errors}
                // eslint-disable-next-line @typescript-eslint/no-empty-function
                onProceed={() => {
                  if (validationDialogData.isPublishing) {
                    saveAndPublishArtifact(values, false);
                  } else {
                    saveAndSubmitArtifact(values, validationDialogData.action, false);
                  }
                }}
                allowSkip={context.userInfo.isInRole('InformitAdmin')}
              />
            </div>
          );
        }}
      </Formik>
    </>
  );
};
