import React from 'react';
import {
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  makeStyles,
  createStyles,
} from '@material-ui/core';
import Axios from 'axios';
import TickIcon from '@material-ui/icons/CheckCircle';
import { useSnackbar } from 'notistack';
import ResubmitFileRequest from '../../../interfaces/TextIndexer/ResubmitFileRequest';
import LoadingButton from '../../molecules/LoadingButton';

const useStyles = makeStyles(() => createStyles({
  SecondaryAction: {
    width: 60,
    textAlign: 'center',
    alignContent: 'center',
    right: '45%',
  },
}));

interface ResubmitFilesListItemProps {
  fileName: string;
  issuePath: string;
  issueId: number;
}

interface ResubmitFilesListItemState {
  submitting: boolean;
  submittedSuccessfully: boolean;
}

export const ResubmitFilesListItem = (props: ResubmitFilesListItemProps) => {
  const classes = useStyles();

  const [state, setState] = React.useState<ResubmitFilesListItemState>({
    submitting: false,
    submittedSuccessfully: false,
  });

  const { enqueueSnackbar } = useSnackbar();

  const ResubmitFile = () => {
    setState({
      ...state,
      submitting: true,
    });

    const data: ResubmitFileRequest = {
      issuePath: props.issuePath,
      fileName: props.fileName,
      issueId: props.issueId,
    };

    Axios.post(`${process.env.REACT_APP_API_URL}/api/articleindexer/resubmitfile`, data)
      .then(() => (
        setState({
          ...state,
          submitting: false,
          submittedSuccessfully: true,
        })
      ))
      .catch(() => {
        setState({
          ...state,
          submitting: false,
          submittedSuccessfully: false,
        });

        enqueueSnackbar(`Unexpected error when submitting ${props.fileName}`, {
          variant: 'error',
        });
      });
  };

  return (
    <ListItem dense disableGutters>
      <ListItemText
        primary={props.fileName}
      />
      <ListItemSecondaryAction className={classes.SecondaryAction}>
        {state.submittedSuccessfully ? (
          <TickIcon
            style={{ color: 'green' }}
          />
        ) : (
          <LoadingButton
            disabled={state.submitting}
            isLoading={state.submitting}
            onClick={ResubmitFile}
            color="primary"
          >
            Retry
          </LoadingButton>
        )}
      </ListItemSecondaryAction>
    </ListItem>
  );
};

interface ResubmitFilesListProps {
  fileNames: string[];
  issuePath: string;
  issueId: number;
}

const ResubmitFilesList = (props: ResubmitFilesListProps) => (
  <List dense disablePadding>
    {props.fileNames.map((fileName) => (
      <ResubmitFilesListItem
        issueId={props.issueId}
        fileName={fileName}
        issuePath={props.issuePath}
      />
    ))}
  </List>
);

export default ResubmitFilesList;
