import {
  Record, Number, String, Static,
} from 'runtypes';

export const DocumentItemNodeValidator = Record({
  id: Number,
  name: String,
  createdBy: String,
  createdDate: String,
});

type DocumentItemNode = Static<typeof DocumentItemNodeValidator>;

export default DocumentItemNode;
