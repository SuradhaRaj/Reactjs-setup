import LicenceTemplate from './LicenceTemplate';

interface SaveLicenceTemplateResponse {
  template: LicenceTemplate;
};

export default SaveLicenceTemplateResponse;
