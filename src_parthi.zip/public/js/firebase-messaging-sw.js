/* eslint-disable no-restricted-globals */
/* eslint-disable func-names */
/* eslint-disable no-undef */

// importScripts('https://www.gstatic.com/firebasejs/7.16.1/firebase-app.js');
// importScripts(
//  'https://www.gstatic.com/firebasejs/7.16.1/firebase-messaging.js',
// );
/// / For an optimal experience using Cloud Messaging, also add the Firebase SDK for Analytics.
// importScripts(
//  'https://www.gstatic.com/firebasejs/7.16.1/firebase-analytics.js',
// );

importScripts('https://www.gstatic.com/firebasejs/9.1.2/firebase-app-compat.js');
importScripts(
  'https://www.gstatic.com/firebasejs/9.1.2/firebase-messaging-compat.js',
);
console.info('service worker is loaded');

function eventHandler() {
  const urlParams = new URLSearchParams(location.search);
  self.firebaseConfig = Object.fromEntries(urlParams);

  // "Default" Firebase configuration (prevents errors)
  const defaultConfig = {
    apiKey: true,
    projectId: true,
    messagingSenderId: true,
    appId: true,
  };

  // Initialize the Firebase app in the service worker by passing in the
  // messagingSenderId.
  firebase.initializeApp(self.firebaseConfig || defaultConfig);

  // Retrieve an instance of Firebase Messaging so that it can handle background
  // messages.
  const messaging = firebase.messaging();
  console.info('service worker messaging', messaging);

  // firebase.getToken(messaging, { vapidKey: 'BAXru1DI4nZviolAAqBtlve7sKAdcRrp7l5c_IqKF-GgYaYQusDx_i_PGtWlXhw92_AdXQF6lQG0rki6t8kDrqM' })
  //    //getToken(messaging)
  //    .then((currentToken) => {
  //        // MsgElem.innerHTML = 'Notification permission granted.';
  //        if (currentToken) {

  //            console.log("currentToken:", currentToken);
  //            return currentToken;
  //        } else {
  //            console.log('No registration token available. Request permission to generate one.');
  //        }

  //    })

  //    .catch((err: any) => {
  //        console.log('No registration error', err);

  //    });

  // messaging.onBackgroundMessage((payload) => {

  //    // eslint-disable-next-line no-console
  //    console.log(
  //        '[firebase-messaging-sw.js] Received background message ',
  //        payload,
  //    );
  //    // Customize notification here
  //    //const notificationTitle = 'Background Message Title';
  //    //const notificationOptions = {
  //    //    body: 'Background Message body.',
  //    //    icon: '/itwonders-web-logo.png',
  //    //};

  //    // eslint-disable-next-line no-restricted-globals
  //    //return self.registration.showNotification(
  //    //    notificationTitle,
  //    //    notificationOptions,
  //    //);
  //    return payload;
  // });
}
eventHandler();
// self.addEventListener('activate', function (event) {
//    eventHandler();
//    console.log("activate");
// });
// self.addEventListener('install', function (event) {
//    eventHandler();
//    console.log("install");
// });

/// / eslint-disable-next-line @typescript-eslint/no-explicit-any
/// / declare let Notif: any;
/// / Set Firebase configuration, once available
// self.addEventListener('fetch', function (event) {
//    eventHandler();
//    console.log("fetch");
// });
