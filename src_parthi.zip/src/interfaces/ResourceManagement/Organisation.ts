import {
  Record, Static, String, Number,
} from 'runtypes';
import { NumberGreaterZero } from '../../runtypeTypes';

export const OrganisationValidator = Record({
  organisationName: String,
  organisationId: NumberGreaterZero,
  hubSpotOrgId: Number,
  organisationWebsite: String,
});

type ResourceReferenceData = Static<typeof OrganisationValidator>;
export default ResourceReferenceData;
