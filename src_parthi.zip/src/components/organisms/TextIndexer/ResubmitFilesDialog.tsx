import React from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  makeStyles,
  createStyles,
} from '@material-ui/core';
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';
import ResubmitFilesList from './ResubmitFilesList';

const useStyles = makeStyles(() => createStyles({
  Content: {
    paddingRight: '8px',
  },
}));

interface ResubmitFilesDialogProps {
  filenames: string[];
  open: boolean;
  handleClose(): void;
  issuePath: string;
  issueId: number;
};

const ResubmitFilesDialog = (props: ResubmitFilesDialogProps) => {
  const classes = useStyles();

  return (
    <Dialog
      open={props.open}
      onClose={props.handleClose}
      disableBackdropClick
      disableEscapeKeyDown
    >
      <DialogTitle>
        <ErrorOutlineIcon color="secondary" />
        {' An unexpected error occurred while submitting the following files'}
      </DialogTitle>
      <DialogContent className={classes.Content}>
        <ResubmitFilesList
          issueId={props.issueId}
          fileNames={props.filenames}
          issuePath={props.issuePath}
        />
      </DialogContent>
      <DialogActions>
        <Button
          onClick={props.handleClose}
          color="primary"
          variant="contained"
        >
          Done
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ResubmitFilesDialog;
