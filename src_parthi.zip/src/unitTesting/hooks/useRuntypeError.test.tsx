import React from 'react';
import { shallow } from 'enzyme';
import { Record, String } from 'runtypes';
import useRuntypeError from '../../components/hooks/useRuntypeError';
import HookWrapper from './HookWrapper';

type useRuntypeErrorReturn = ReturnType<typeof useRuntypeError>;

const TestValidator = Record({
  correctKey: String,
});

describe('useRuntypeError hook', () => {
  it('should set is valid false when there is a validation error', () => {
    const wrapper = shallow(<HookWrapper hook={() => useRuntypeError(TestValidator)} />);
    let hook = wrapper.find('div').prop('data-hook') as useRuntypeErrorReturn;

    hook.validate({ incorrectKey: 'value' });
    hook = wrapper.find('div').prop('data-hook') as useRuntypeErrorReturn;

    expect(hook.isValid).toBeFalsy();
  });
  it('should set is valid true when there is no validation error', () => {
    const wrapper = shallow(<HookWrapper hook={() => useRuntypeError(TestValidator)} />);
    let hook = wrapper.find('div').prop('data-hook') as useRuntypeErrorReturn;

    hook.validate({ correctKey: 'value' });
    hook = wrapper.find('div').prop('data-hook') as useRuntypeErrorReturn;

    expect(hook.isValid).toBeTruthy();
  });
  it('should set is valid to true before validation has been run', () => {
    const wrapper = shallow(<HookWrapper hook={() => useRuntypeError(TestValidator)} />);
    const hook = wrapper.find('div').prop('data-hook') as useRuntypeErrorReturn;
    expect(hook.isValid).toBeTruthy();
  });
  it('should return JSX when the error() funtion is invoked and there is an error', () => {
    const wrapper = shallow(<HookWrapper hook={() => useRuntypeError(TestValidator)} />);
    let hook = wrapper.find('div').prop('data-hook') as useRuntypeErrorReturn;

    hook.validate({ incorrectKey: 'value' });
    hook = wrapper.find('div').prop('data-hook') as useRuntypeErrorReturn;

    const error = hook.error();
    expect(error).toBeTruthy();
  });
  it('should return null when the error() funtion is invoked and there is no error', () => {
    const wrapper = shallow(<HookWrapper hook={() => useRuntypeError(TestValidator)} />);
    let hook = wrapper.find('div').prop('data-hook') as useRuntypeErrorReturn;

    hook.validate({ correctKey: 'value' });
    hook = wrapper.find('div').prop('data-hook') as useRuntypeErrorReturn;

    const error = hook.error();
    expect(error).toBeFalsy();
  });
});
