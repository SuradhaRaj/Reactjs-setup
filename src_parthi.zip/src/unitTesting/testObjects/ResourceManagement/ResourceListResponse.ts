import ResourceListResponse from '../../../interfaces/ResourceList/ResourceListResponse';
import TitleSearchResult from '../Search/TitleSearchResult';

const response: ResourceListResponse = {
  organisationName: 'Org 1',
  resources: [TitleSearchResult, TitleSearchResult, TitleSearchResult],
};

export default response;
