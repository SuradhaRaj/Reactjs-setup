enum ArticleStatus {
    Available = 1,
    Complete = 2,
    Locked = 3,
    Error = 4,
}

export default ArticleStatus;
