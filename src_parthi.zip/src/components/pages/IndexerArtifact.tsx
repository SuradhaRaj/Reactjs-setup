import React, { useEffect, useContext, useState } from 'react';
import { useLocation, useParams } from 'react-router-dom';
import Axios from 'axios';
import { CircularProgress } from '@material-ui/core';
import { IndexerArtifactContext, IndexerArtifactContextProvider } from '../contexts/IndexerArtifact';
import ErrorPaper from '../organisms/ErrorPaper';
import MediaData from '../../interfaces/MediaIndexer/MediaData';
import Artifact from '../../interfaces/Artifact';
import ArtifactType from '../../interfaces/enums/ArtifactType';
import TextData from '../../interfaces/TextIndexer/TextData';
import IssueData from '../../interfaces/TextIndexer/IssueData';

const MediaIndexerArtifact = React.lazy(() => import('./MediaIndexerArtifact'));
const TextIndexerArtifact = React.lazy(() => import('./TextIndexerArtifact'));
const IssueIndexerArtifact = React.lazy(() => import('./IssueIndexerArtifact'));

interface Props {
  artifact: Artifact;
}

const IndexerUiFactory = ({ artifact }: Props): JSX.Element => {
  switch (artifact.artifactType) {
    case ArtifactType.Media:
      return (<MediaIndexerArtifact artifact={artifact as MediaData} />);
    case ArtifactType.Text:
      return (<TextIndexerArtifact artifact={artifact as TextData} />);
    case ArtifactType.Issue:
      return (<IssueIndexerArtifact artifact={artifact as IssueData} />);
    case ArtifactType.None:
    default:
      return (<div>Unsupported artifact type found</div>);
  }
};

interface State {
  isLoading: boolean;
  errorCode: number;
}

const IndexerArtifactRetriever = (): JSX.Element => {
  const { artifactid } = useParams();
  const location = useLocation();
  const query = new URLSearchParams(location.search);

  const artifactId = query.get('artifactId') || artifactid;

  const context = useContext(IndexerArtifactContext);

  const [state, setState] = useState<State>({
    isLoading: true,
    errorCode: 0,
  });

  const doImplicitUnlock = React.useRef(false);

  const implicitUnlock = () => {
    if (doImplicitUnlock.current) {
      navigator.sendBeacon(`${process.env.REACT_APP_API_URL}/api/Artifact/implicitunlockartifact?artifactID=${artifactId}`);
    }
  };

  const getArtifact = () => {
    setState((prevState) => ({
      ...prevState,
      isLoading: true,
    }));
    Axios.get(`${process.env.REACT_APP_API_URL}/api/artifact/getartifact?artifactId=${artifactId}`)
      .then((response) => {
        context.updateArtifact(response.data);
        context.setDoImplicitUnlock(!response.data.isReadOnly);
        context.setHasChanges(false);
      }).catch((error) => {
        setState((prevState) => ({
          ...prevState,
          errorCode: error.response.status,
        }));
      })
      .finally(() => {
        setState((prevState) => ({
          ...prevState,
          isLoading: false,
        }));
      });
  };

  useEffect(() => {
    doImplicitUnlock.current = context.doImplicitUnlock;
  }, [context.doImplicitUnlock]);

  useEffect(() => {
    if (doImplicitUnlock.current) {
      window.addEventListener('beforeunload', implicitUnlock);
    } else {
      window.removeEventListener('beforeunload', implicitUnlock);
    }
  }, [doImplicitUnlock.current]);

  useEffect(() => () => {
    window.removeEventListener('beforeunload', implicitUnlock);
    implicitUnlock();
  }, []);

  useEffect(() => {
    // If we need to unlock the attempt unlock, when that has completed we get the new artifact
    if (doImplicitUnlock.current) {
      Axios.post(`${process.env.REACT_APP_API_URL}/api/Artifact/implicitunlockartifact?artifactID=${context.Artifact.artifactId}`)
        .finally(() => {
          getArtifact();
        });
    } else {
      getArtifact();
    }
  }, [location]);

  useEffect(() => {
    if (context.shouldRefreshArtifact) {
      getArtifact();
      context.setShouldRefreshArtifact(false);
    }
  }, [context.shouldRefreshArtifact]);

  if (state.errorCode > 0) {
    if (state.errorCode === 404) {
      return (<ErrorPaper text="This artifact could not be found." />);
    }

    return (<ErrorPaper text="Unable to retrieve artifact." />);
  }
  if (state.isLoading) {
    return (<CircularProgress />);
  }

  return (
    <IndexerUiFactory artifact={context.Artifact} />
  );
};

export default () => (
  <IndexerArtifactContextProvider>
    <IndexerArtifactRetriever />
  </IndexerArtifactContextProvider>
);
