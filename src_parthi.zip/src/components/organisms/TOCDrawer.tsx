import React from 'react';
import InfoIcon from '@material-ui/icons/InfoOutlined';
import {
  Drawer, Button, makeStyles, Typography,
} from '@material-ui/core';

const useStyles = makeStyles({
  root: {
    width: '300px',
    backgroundColor: '#f9f9fc',
    padding: '20px',
  },
  heading: {
    float: 'right',
  },
  workflowButton: {
    borderRadius: '50px',
    float: 'right',
    marginRight: '20px',
  },
});

interface Props {
    content: JSX.Element;
  }

export default function TOCDrawer(props: Props): JSX.Element {
  const classes = useStyles();
  const [state, setState] = React.useState({
    open: false,
  });

  const toggleDrawer = () => (
    event: React.KeyboardEvent | React.MouseEvent,
  ) => {
    if (
      event.type === 'keydown'
            && ((event as React.KeyboardEvent).key === 'Tab'
                || (event as React.KeyboardEvent).key === 'Shift')
    ) {
      return;
    }
    const isOpen = !state.open;

    setState({ open: isOpen });
  };

  return (
    <>
      <Button
        className={classes.workflowButton}
        onClick={toggleDrawer()}
        color="primary"
        variant="outlined"
        size="small"
        startIcon={<InfoIcon />}
      >
        ISSUE NAV
      </Button>
      <Drawer anchor="right" open={state.open} onClose={toggleDrawer()}>
        <div className={classes.root}>
          <Typography color="primary" className={classes.heading} variant="overline">Issue Nav</Typography>
          {props.content}
        </div>
      </Drawer>
    </>
  );
}
