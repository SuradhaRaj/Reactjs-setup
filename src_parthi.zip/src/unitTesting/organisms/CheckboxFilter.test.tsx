import React from 'react';
import { shallow } from 'enzyme';
import Skeleton from '@material-ui/lab/Skeleton';
import CheckboxFilter from '../../components/organisms/CheckboxFilter';

describe('Typedown filter', () => {
  it('should show the loading skeletons', () => {
    const wrapper = shallow(<CheckboxFilter
      isLoading
      onChange={() => undefined}
      options={['Item1', 'Item2', 'Item3']}
      selectedOptions={[]}
      title="Some filter title"
    />);

    expect(wrapper.find(Skeleton).length).toBeGreaterThan(0);
  });

  it('should render the correct number of options', () => {
    const wrapper = shallow(<CheckboxFilter
      isLoading={false}
      onChange={() => undefined}
      options={['Item1', 'Item2', 'Item3']}
      selectedOptions={[]}
      title="Some filter title"
    />);

    expect(wrapper.find('[checked]')).toHaveLength(3);
  });

  it('should show the correct selected options', () => {
    const wrapper = shallow(<CheckboxFilter
      isLoading={false}
      onChange={() => undefined}
      options={['Item1', 'Item2', 'Item3']}
      selectedOptions={['Item1']}
      title="Some filter title"
    />);
    expect(wrapper.find('[checked=false]')).toHaveLength(2);
    expect(wrapper.find('[checked=true]')).toHaveLength(1);
    expect(wrapper.find('[checked=true]').prop('label')).toBe('Item1');
  });
});
