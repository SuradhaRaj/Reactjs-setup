export const BroadSubjectTypedownLimit = 4;
export const NarrowSubjectTypedownLimit = 4;
export const FastAndIndentifiersTypedownLimit = 6;
export const GeolocationsTypedownLimit = 6;
