import MediaData from '../../../interfaces/MediaIndexer/MediaData';

class MediaDataHelper {
    readonly data: MediaData;

    constructor(data: MediaData) {
      this.data = data;
    }

    public isEduTV(): boolean {
      if (this.data.mediaArtifactDocument.siteId === '213') {
        return true;
      }
      return false;
    }
}

export default MediaDataHelper;
