import TitleResourceReferenceData from '../../interfaces/ResourceManagement/TitleInformation';

export const UPDATE_TITLE_REFERENCE_DATA = 'UPDATE_TITLE_REFERENCE_DATA';

interface UpdateResourceReferenceDataAction {
    type: typeof UPDATE_TITLE_REFERENCE_DATA;
  payload: TitleResourceReferenceData;
}

export type ActionTypes = UpdateResourceReferenceDataAction;

export function updateTitleReferenceData(data: TitleResourceReferenceData): ActionTypes {
  return {
    type: UPDATE_TITLE_REFERENCE_DATA,
    payload: data,
  };
}
