import {
  Record, Static, Array,
} from 'runtypes';
import { LookupOptionValidator } from '../../LookupOption';
import { DocumentBroadSubjectValidator } from '../DocumentBroadSubject';
import { ArtifactErrorCodeValidator } from '../ArtifactErrorCode';

export const MediaReferenceDataValidator = Record({
  genreLookup: Array(LookupOptionValidator).withConstraint((a) => a.length > 0),
  languageLookup: Array(LookupOptionValidator).withConstraint((a) => a.length > 0),
  classificationLookup: Array(LookupOptionValidator).withConstraint((a) => a.length > 0),
  contentTypeLookup: Array(LookupOptionValidator).withConstraint((a) => a.length > 0),
  resourceTypeLookup: Array(LookupOptionValidator).withConstraint((a) => a.length > 0),
  broadSubjectLookup: Array(DocumentBroadSubjectValidator).withConstraint((a) => a.length > 0),
  errorCodes: Array(ArtifactErrorCodeValidator).withConstraint((a) => a.length > 0),
});

type MediaReferenceData = Static<typeof MediaReferenceDataValidator>;
export default MediaReferenceData;
