import React from 'react';
import {
  Dialog,
  DialogTitle,
  DialogProps,
  DialogContent,
  DialogActions,
  Button,
  FormControl,
  FormLabel,
  FormHelperText,
  FormGroup,
  FormControlLabel,
  Switch,
  makeStyles,
  createStyles,
  Tooltip,
  Box,
  Theme,
} from '@material-ui/core';
import { Icon } from '@iconify/react';
import hubspotIcon from '@iconify/icons-simple-icons/hubspot';
import { isEqual } from 'lodash';
import LookupOption from '../../interfaces/LookupOption';
import LoadingButton from '../molecules/LoadingButton';
import ContactRole from '../../interfaces/Organisation/ContactRole';

const useStyles = makeStyles((theme: Theme) => createStyles({
  contactName: {
    fontWeight: 600,
    display: 'block',
    color: theme.palette.primary.light,
  },
}));

interface ContactRolesDialogProps extends DialogProps {
  contactRoleLookup: LookupOption[];
  initiallySelectedRoles: ContactRole[];
  contactName: string;
  loading: boolean;
  submitUpdatedRoles(roleIds: number[]): void;
  handleClose(): void;
};

interface ContactRolesDialogState {
  selectedRoles: ContactRole[];
}

const ContactRolesDialog: React.FC<ContactRolesDialogProps> = (props) => {
  const classes = useStyles();

  const [state, setState] = React.useState<ContactRolesDialogState>({
    selectedRoles: props.initiallySelectedRoles,
  });

  const handleSwitchChange = (e: React.ChangeEvent<HTMLInputElement>, checked: boolean, option: LookupOption) => {
    if (checked) {
      setState((prevState) => ({
        ...prevState,
        selectedRoles: [...prevState.selectedRoles, { name: option.value, contactRoleId: option.key, isCRM: false }],
      }));
    } else {
      setState((prevState) => ({
        ...prevState,
        selectedRoles: prevState.selectedRoles.filter((role) => role.contactRoleId !== option.key),
      }));
    }
  };

  const isCrm = (roleId: number): boolean => (
    !!state.selectedRoles.find((role) => role.contactRoleId === roleId && role.isCRM)
  );

  const formHasChange = () => {
    const initialRoleIds = props.initiallySelectedRoles.map((role) => role.contactRoleId);
    const currentRoleIds = state.selectedRoles.map((role) => role.contactRoleId);

    return !isEqual(initialRoleIds.sort(), currentRoleIds.sort());
  };

  return (
    <Dialog
      {...props}
    >
      <DialogTitle>
        Update contact roles for
        {' '}
        <span className={classes.contactName}>{props.contactName}</span>
      </DialogTitle>
      <DialogContent>
        <FormControl>
          <FormLabel>
            Assign Roles
          </FormLabel>
          <FormGroup>
            {props.contactRoleLookup.map((option) => (
              <FormControlLabel
                control={(
                  <Switch
                    key={option.key}
                    checked={!!state.selectedRoles.find((role) => role.contactRoleId === option.key)}
                    name={option.value}
                    color="primary"
                    disabled={isCrm(option.key)}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>, checked: boolean) => handleSwitchChange(e, checked, option)}
                  />
                )}
                label={isCrm(option.key)
                  ? (
                    <>
                      {option.value}
                      <Tooltip
                        title="This role has been assigned from HubSpot"
                        placement="top"
                        arrow
                      >
                        <Box
                          display="inline"
                          ml={1}
                          height={1}
                        >
                          <Icon
                            icon={hubspotIcon}
                          />
                        </Box>
                      </Tooltip>
                    </>
                  ) : (
                    option.value
                  )}
              />
            ))}
          </FormGroup>
          <FormHelperText>
            Roles will not be updated until the update button is clicked
          </FormHelperText>
        </FormControl>
      </DialogContent>
      <DialogActions>
        {!props.loading && (
          <Button
            onClick={props.handleClose}
            color="primary"
          >
            Cancel
          </Button>
        )}
        <LoadingButton
          isLoading={props.loading}
          onClick={() => props.submitUpdatedRoles(state.selectedRoles.map((role) => role.contactRoleId))}
          color="primary"
          disabled={!formHasChange()}
        >
          Update Roles
        </LoadingButton>
      </DialogActions>
    </Dialog>
  );
};

export default ContactRolesDialog;
