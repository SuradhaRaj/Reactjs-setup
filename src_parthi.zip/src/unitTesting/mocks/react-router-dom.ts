export default () => jest.mock('react-router-dom', () => ({
  useLocation: () => undefined,
  useParams: () => undefined,
  useHistory: () => ({
    push: jest.fn(),
  }),
}));
