import DateExtensions from '../../utils/DateExtensions';

describe('Date extensions - To Form Format', () => {
  it('should contain date in same format', () => {
    const result = DateExtensions.convertLiveDateTimeToFormFormat('2009-08-03T21:04:41.203');
    expect(result).toBe('2009-08-04T07:04+10:00');
  });

  it('should contain Zone information', () => {
    const result = DateExtensions.convertSQLDateToFormFormat('2009-08-03T21:04:41.203');
    expect(result).toBe('2009-08-04T07:04:41+10:00');
  });
});

// dev note: this test has been temporarily disabled as BitBucket Pipeline is failing due to UTC server time
