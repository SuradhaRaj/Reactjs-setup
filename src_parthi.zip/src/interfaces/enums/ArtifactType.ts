enum ArtifactType {
  None = 0,
  Media = 1,
  Text = 2,
  Issue = 3
}

export default ArtifactType;
