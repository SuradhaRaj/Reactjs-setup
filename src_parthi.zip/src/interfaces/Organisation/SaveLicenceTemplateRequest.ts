import LicenceTemplate from './LicenceTemplate';

interface SaveLicenceTemplateRequest {
  template: LicenceTemplate;
}

export default SaveLicenceTemplateRequest;
