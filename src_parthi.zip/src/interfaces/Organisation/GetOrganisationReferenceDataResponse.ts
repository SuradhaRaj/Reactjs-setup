import { Static, Record } from 'runtypes';
import { LookupOptionValidator } from '../LookupOption';
import { ArrayWithElements } from '../../runtypeTypes';

export const GetOrganisationReferenceDataResponseValidator = Record({
  clearanceStatus: ArrayWithElements(LookupOptionValidator),
  clearedBy: ArrayWithElements(LookupOptionValidator),
  accessType: ArrayWithElements(LookupOptionValidator),
  ccLicenceType: ArrayWithElements(LookupOptionValidator),
  accessRight: ArrayWithElements(LookupOptionValidator),
  contactRoleType: ArrayWithElements(LookupOptionValidator),
});

type GetOrganisationReferenceDataResponse = Static<typeof GetOrganisationReferenceDataResponseValidator>;

export default GetOrganisationReferenceDataResponse;
