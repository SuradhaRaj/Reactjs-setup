import {
  ActionTypes, UPDATE_ISSUE_REFERENCE_DATA,
} from '../actions/ActnIssueReferenceData';
import IssueReferenceData from '../../interfaces/IssueManagement/IssueReferenceData';

export interface IssueReferenceDataState {
    IssueReferenceData: IssueReferenceData;
  }

export const initialState: IssueReferenceDataState = {
  IssueReferenceData: {
    issueWorkflowStates: [],
    accessRights: [],
  },
};

export default (state = initialState, action: ActionTypes): IssueReferenceDataState => {
  switch (action.type) {
    case UPDATE_ISSUE_REFERENCE_DATA:
      return {
        ...state,
        IssueReferenceData: action.payload,
      };

    default:
      return state;
  }
};
