import React, { useEffect, useContext } from 'react';
import {
  makeStyles, Theme, createStyles, Grid, // , Paper, Typography,
} from '@material-ui/core';
import MediaTaskTile from '../organisms/DashboardTiles/MediaTaskTile';
import TextTaskTile from '../organisms/DashboardTiles/TextTaskTile';
import { AppContext } from '../Context';
import ErrorPaper from '../organisms/ErrorPaper';
// import DonutTileResourceByClearance from '../organisms/DashboardTiles/DonutTileResourceByClearance';
// import DonutTileResourceByWorkflow from '../organisms/DashboardTiles/DonutTileResourceByWorkflow';
// import DonutTileIssueByWorkflow from '../organisms/DashboardTiles/DonutTileIssueByWorkflow';
// import DonutTileMediaByWorkflow from '../organisms/DashboardTiles/DonutTileMediaByWorkflow';
// import DonutTileTextByWorkflow from '../organisms/DashboardTiles/DonutTileTextByWorkflow';
import { UserContext } from '../Layout';

const useStyles = makeStyles((theme: Theme) => createStyles({
  root: {
    paddingLeft: theme.spacing(2),
    paddingRight: theme.spacing(2),
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
    minHeight: '100px',
    width: '100%',
    '&:hover': {
      transform: 'scale(1.10)',
    },
    transition: 'all 0.2s',
  },
  tileTitle: {
    textAlign: 'left',
    color: 'grey',
    padding: theme.spacing(2),
    textTransform: 'uppercase',
    letterSpacing: '1px',
  },
  titleSizing: {
    fontSize: '0.85rem',
  },
  tileData: {
    float: 'right',
    backgroundColor: '#EEEEFF',
    color: theme.palette.primary.dark,
  },
}));

export default function Error404(): JSX.Element {
  const context = React.useContext(AppContext);
  const classes = useStyles();

  const canSeeMediaTile = (): boolean => context.userInfo.isInAnyRole(['MediaIndexer']);

  const canSeeTextTile = (): boolean => context.userInfo.isInAnyRole(['TextIndexer', 'IssueSplitter', 'TextEduIndexer', 'TextLgealIndexer']);

  // @ts-ignore
  const { navstate, setNavState } = useContext(UserContext);
  useEffect(() => {
    setNavState({ type: 'TEXT_TILE', payload: false });
  }, []);

  return (
    <>
      <Grid container justify="center" spacing={2}>
        <Grid item xs={11} md={10} xl={8}>
          <Grid container xs={12} spacing={3}>
            {(canSeeMediaTile() || canSeeTextTile()) ? (
              <>
                {canSeeMediaTile() && (
                <Grid item xs={5} md={5} className={classes.root}>
                  <MediaTaskTile />
                </Grid>
                )}
                {canSeeTextTile() && (
                <Grid item xs={5} md={5} className={classes.root}>
                  <TextTaskTile />
                </Grid>
                )}
                {/* <Grid item>
                  <Paper className={classes.root}>
                    <Grid container>
                      <Grid item className={classes.tileTitle}>
                        <Typography className={classes.titleSizing}>Resources By Clearance States</Typography>
                        <DonutTileResourceByClearance />
                      </Grid>
                    </Grid>
                  </Paper>
                </Grid>
                <Grid item>
                  <Paper className={classes.root}>
                    <Grid container>
                      <Grid item className={classes.tileTitle}>
                        <Typography className={classes.titleSizing}>Resources By Workflow States</Typography>
                        <DonutTileResourceByWorkflow />
                      </Grid>
                    </Grid>
                  </Paper>
                </Grid>
                <Grid item>
                  <Paper className={classes.root}>
                    <Grid container>
                      <Grid item className={classes.tileTitle}>
                        <Typography className={classes.titleSizing}>Issues By Workflow States</Typography>
                        <DonutTileIssueByWorkflow />
                      </Grid>
                    </Grid>
                  </Paper>
                </Grid>
                <Grid item>
                  <Paper className={classes.root}>
                    <Grid container>
                      <Grid item className={classes.tileTitle}>
                        <Typography className={classes.titleSizing}>Media By Workflow States</Typography>
                        <DonutTileMediaByWorkflow />
                      </Grid>
                    </Grid>
                  </Paper>
                </Grid>
                <Grid item>
                  <Paper className={classes.root}>
                    <Grid container>
                      <Grid item className={classes.tileTitle}>
                        <Typography className={classes.titleSizing}>Text By Workflow States</Typography>
                        <DonutTileTextByWorkflow />
                      </Grid>
                    </Grid>
                  </Paper>
                </Grid> */}
              </>
            ) : (
              <>
                <Grid item xs={3} />
                <Grid item xs={6}>
                  <ErrorPaper text="You do not have permissions to view any indexing tasks. Please contact your system administrator." />
                </Grid>
                <Grid item xs={3} />
              </>
            )}
          </Grid>
        </Grid>
      </Grid>
    </>
  );
}
