import {
  Static, Record, Number, String, Boolean, Null,
} from 'runtypes';
import { IsoDate } from '../../runtypeTypes';

export const LicenceValidator = Record({
  licenceId: Number,
  ielcopyright: String.Or(Null),
  clearanceStatusId: Number.Or(Null),
  contractStartDate: IsoDate.Or(Null),
  contractEndDate: IsoDate.Or(Null),
  ppvavailable: Boolean,
  agreementNumber: Number.Or(Null),
  embargoPeriod: Number.Or(Null),
  price: Number,
  royaltiesDue: Boolean.Or(Null),
  clearedById: Number.Or(Null),
  royaltyRate: Number.Or(Null),
  archiveRoyaltyRate: Number.Or(Null),
  noticePeriod: Number.Or(Null),
  archivalPeriod: Number.Or(Null),
  archivePeriodStartDate: IsoDate.Or(Null),
  terminationNote: String.Or(Null),
  noticeProvidedDate: IsoDate.Or(Null),
  individualSubscriptions: Boolean,
  cclicenceTypeId: Number.Or(Null),
  isOpenAccess: Boolean,
  accessRightId: Number.Or(Null),
  royaltyOrganisationName: String.Or(Null),
  perpetualAccess: Boolean,
  accessTypeId: Number.Or(Null),
});

type Licence = Static<typeof LicenceValidator>;

export default Licence;
