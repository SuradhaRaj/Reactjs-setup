/* eslint @typescript-eslint/no-explicit-any: 0 */
import React, { useEffect, useState } from 'react';
import {
  Typography, Grid, Divider, Box,
} from '@material-ui/core';
import Button from '@material-ui/core/Button';
import { useLocation, useHistory } from 'react-router-dom';
import Axios, { AxiosResponse } from 'axios';

import _ from 'lodash';

import TypedownFilter from '../TypedownFilter';
import WorkflowStatus from '../../../interfaces/enums/WorkflowStatus';
import { KeyValue } from '../../../interfaces/TaskManagementText/TextTaskManagementRequest';
import DateFromToFieldInput, { DateFromToField } from './DateFromToField';
import { SelectedOptionFilters } from './SelectedOptionFilters';
import TextInputField from '../../Shared/TextInputField';
import Dropdown from '../../Shared/Dropdown';

const FIELD_LAST_MODIFIED_DATE = 'LastModifiedDate';
export const ID_LAST_MODIFIED_DATE = 10001;
export const ID_ISSUE_FILES_RECEIVED = WorkflowStatus.IssueFilesReceived;
export const ID_READY_FOR_FILE_PREP = WorkflowStatus.ReadyForFilePrep;
export const ID_READY_FOR_ISSUE_SPLITTING = WorkflowStatus.ReadyForIssueSplitting;
export const ID_READY_FOR_LEGAL_INDEXING = WorkflowStatus.ReadyForLegalIndexing;
export const ID_READY_FOR_ADVANCED_INDEXING = WorkflowStatus.ReadyForAdvancedIndexing;
export const ID_READY_FOR_INDEXING = WorkflowStatus.ReadyForIndexing;
export const ID_INDEXING_COMPLETE = WorkflowStatus.IndexingComplete;
const BOOLEAN_OPTIONS = { ignore: '-', yes: 'Yes', no: 'No' };

interface ResponseIdInfoType {
    id: number;
    info: string;
}

interface ResponseResourceIdInfoType {
    resourceId: number;
    info: string;
}
interface LookupResponse {
    groupings: { info: string }[];
    publishers: { info: string }[];
    resourceManagers: ResponseIdInfoType[];
    titles: ResponseIdInfoType[];
    workflowStatus: ResponseIdInfoType[];

    organisations: ResponseIdInfoType[];
    contentTypes: ResponseIdInfoType[];
    issn: ResponseResourceIdInfoType[];
    isbn: ResponseResourceIdInfoType[];
    recordNumbers: ResponseResourceIdInfoType[];
    resources: ResponseResourceIdInfoType[];
    priority: ResponseIdInfoType[];
    indexingCompany: ResponseIdInfoType[];
}

export interface SelectedOptionState {
    grouping: string[];
    publisher: string[];
    manager: KeyValue[];
    title: string[];
    status: KeyValue[];

    organisation: KeyValue[];
    contentType: KeyValue[];
    issn: string[];
    isbn: string[];
    documentNumber: string[];
    resource: string[];

    dates: DateFromToField[];
    datesLog: DateFromToField[];
    priority: KeyValue[];
    indexingCompany: KeyValue[];
    hasIndexerNotes?: boolean;
    hasPublisherNotes?: boolean;
    includeRelated?: boolean;
}

type State = SelectedOptionState
interface FilterAreaState {
    isAdvanceView: boolean;
}

interface Props {
    isLoading: boolean;
    onApplyFilter: Function;
    onDownloadCSV: Function;
    isAdmin: boolean;
}

const SimpleFilters = (props: Props) => {
  const emptystate = SelectedOptionFilters.empty();
  const [state, setState] = useState<State>({ ...emptystate.data });
  const [filterAreaState, setFilterAreaState] = useState<FilterAreaState>({
    isAdvanceView: false,
  });
  const stateLastModifiedDate = _.find(state.dates, { id: ID_LAST_MODIFIED_DATE }) as DateFromToField;
  const stateIssueFilesReceivedDate = _.find(state.datesLog, { id: ID_ISSUE_FILES_RECEIVED }) as DateFromToField;
  const stateReadyForFilePrepDate = _.find(state.datesLog, { id: ID_READY_FOR_FILE_PREP }) as DateFromToField;
  const stateReadyForIssueSplittingDate = _.find(state.datesLog, { id: ID_READY_FOR_ISSUE_SPLITTING }) as DateFromToField;
  const stateReadyForLegalIndexingDate = _.find(state.datesLog, { id: ID_READY_FOR_LEGAL_INDEXING }) as DateFromToField;
  const stateReadyForAdvancedIndexingDate = _.find(state.datesLog, { id: ID_READY_FOR_ADVANCED_INDEXING }) as DateFromToField;
  const stateReadyForIndexingDate = _.find(state.datesLog, { id: ID_READY_FOR_INDEXING }) as DateFromToField;
  const stateIndexingCompleteDate = _.find(state.datesLog, { id: ID_INDEXING_COMPLETE }) as DateFromToField;

  const [filterList, setFilterList] = useState<SelectedOptionFilters>(SelectedOptionFilters.empty());

  const history = useHistory();
  const location = useLocation();
  const query = new URLSearchParams(location.search);

  // const updateUrl = () => {
  //  const queryString = filterList.getQueryString();
  //  if (queryString !== '') {
  //    query.set('filter', queryString);
  //    const queryToSet = query.toString();
  //    history.push(`${location.pathname}?${queryToSet}`);
  //  } else {
  //    history.push(location.pathname);
  //  }
  // };

  useEffect(() => {
    const filtersString = query.get('filter');
    if (filtersString != null) {
      const filters = JSON.parse(filtersString);
      setFilterList(new SelectedOptionFilters(filters));
      // console.log(filterList);
    }
  }, [location]);

  useEffect(() => {
    Axios.get(`${process.env.REACT_APP_API_URL}/api/taskmanagement/text/lookups`)
      .then((response: AxiosResponse<LookupResponse>) => {
        const publishersLookup: string[] = response.data.publishers.map((x) => x.info).filter((x) => typeof x === 'string');
        const resourceManagersLookup: KeyValue[] = response.data.resourceManagers
          .map((x) => ({ id: x.id, value: x.info }))
          .filter((x) => x !== null && x !== undefined);

        const workflowStatusLookup: KeyValue[] = response.data.workflowStatus
          .map((x) => ({ id: x.id, value: x.info }))
          .filter((x) => x !== null && x !== undefined)
          .filter((x) => x.value !== null);

        const organisationsLookup: KeyValue[] = response.data.organisations
          .map((x) => ({ id: x.id, value: x.info }))
          .filter((x) => x !== null && x !== undefined)
          .filter((x) => x.value !== null);
        const contentTypesLookup: KeyValue[] = response.data.contentTypes
          .map((x) => ({ id: x.id, value: x.info }))
          .filter((x) => x !== null && x !== undefined)
          .filter((x) => x.value !== null);

        const priorityLookup: KeyValue[] = response.data.priority
          .map((x) => ({ id: x.id, value: x.info }))
          .filter((x) => x !== null && x !== undefined)
          .filter((x) => x.value !== null);
        const indexingCompanyLookup: KeyValue[] = response.data.indexingCompany
          .map((x) => ({ id: x.id, value: x.info }))
          .filter((x) => x !== null && x !== undefined)
          .filter((x) => x.value !== null);

        setState((prevState) => ({
          ...prevState,
          // grouping: groupingsLookup,
          publisher: publishersLookup,
          // title: titlesLookup,
          status: workflowStatusLookup,
          manager: resourceManagersLookup,

          organisation: organisationsLookup,
          contentType: contentTypesLookup,

          // resource: resourcesLookup,
          priority: priorityLookup,
          indexingCompany: indexingCompanyLookup,
        }));
      })
      .catch((e) => {
        console.error(e);
      });
  }, []);

  const booleanLookup: string[] = [BOOLEAN_OPTIONS.ignore, BOOLEAN_OPTIONS.yes, BOOLEAN_OPTIONS.no];

  function changeFilter<T extends keyof SelectedOptionState>(filterName: T, value: SelectedOptionState[T]) {
    setFilterList(filterList.updateFilter<keyof SelectedOptionState>(filterName, value));
  }

  function changeBooleanFilter(field: 'hasIndexerNotes' | 'hasPublisherNotes' | 'includeRelated', value: string) {
    if (value === BOOLEAN_OPTIONS.yes) {
      changeFilter(field, true);
    } else if (value === BOOLEAN_OPTIONS.no) {
      changeFilter(field, false);
    } else {
      changeFilter(field, undefined);
    }
  }

  function getBooleanOption(field: 'hasIndexerNotes' | 'hasPublisherNotes' | 'includeRelated') {
    // console.log(filterList.data[field]);
    const value = filterList.data[field];
    if (value === true) {
      return BOOLEAN_OPTIONS.yes;
    } if (value === false) {
      return BOOLEAN_OPTIONS.no;
    }
    return BOOLEAN_OPTIONS.ignore;
  }

  function changeTextFilter(e: any, filterName: 'issn' | 'isbn' | 'documentNumber' | 'resource' |'grouping'|'title') {
    const fieldvalue = e.target.value;

    const filterVaule = fieldvalue === '' ? [] : [fieldvalue];
    // update state
    setState((pre) => {
      const newState = { ...pre };
      newState[filterName] = filterVaule;
      return newState;
    });
    // console.log(state);
    setFilterList(filterList.updateFilter<keyof SelectedOptionState>(filterName, filterVaule));
  }

  function changeDateFilter(value: DateFromToField, datefield: number) {
    setState((preState) => {
      let group;
      if (datefield === ID_LAST_MODIFIED_DATE) {
        group = preState.dates;
      } else {
        group = preState.datesLog;
      }

      const date = _.find(group, { id: datefield as number }) as DateFromToField;
      date.from = value.from;
      date.to = value.to;

      // console.log(date);
      return { ...preState };
    });
    const date = _.find(datefield === ID_LAST_MODIFIED_DATE ? filterList.data.dates : filterList.data.datesLog, { id: datefield }) as DateFromToField;
    // console.log(state.dates);

    date.from = value.from;
    date.to = value.to;
  }

  function submitFilter() {
    // console.log(state);
    // const queryString = filterList.getQueryString();
    const queryJSON = filterList.data;
    // console.log(queryJSON);

    // query.set('filter', queryString);
    // const queryToSet = query.toString();
    // console.log(decodeURI(queryToSet));

    props.onApplyFilter(queryJSON);
  }
  function exportResult() {
    const queryJSON = filterList.data;

    props.onDownloadCSV(queryJSON);
  }

  const clearAllFilters = (): void => {
    setFilterList(SelectedOptionFilters.empty());
    history.push(location.pathname);
    setState((preState) => {
      const emptyFilterState = SelectedOptionFilters.empty();
      return { ...preState, dates: emptyFilterState.data.dates, datesLog: emptyFilterState.data.datesLog };
    });

    // console.log(state.dates, state.datesLog);
  };

  const showFullFilter = (): void => {
    setFilterAreaState({
      isAdvanceView: !filterAreaState.isAdvanceView,
    });
  };

  return (
    <>
      <Grid container spacing={1} style={{ paddingLeft: 20, paddingRight: 20, marginTop: 0 }}>
        <Grid item xs={12} style={{ textAlign: 'right' }}>
          <Typography variant="overline">Filters</Typography>
        </Grid>
        {props.isAdmin ? (
          <Grid item xs={2}>
            <TypedownFilter
              id="resourceManager"
              isLoading={props.isLoading}
              title="Resource Manager"
              options={state.manager}
              selectedOptions={filterList.data.manager}
              onChange={(options) => { changeFilter('manager', options as KeyValue[]); }}
            />
          </Grid>
        ) : ''}

        {/* <Grid item xs={2}>
          <TypedownFilter
            isLoading={props.isLoading}
            title="Title"
            options={state.title}
            selectedOptions={filterList.data.title}
            onChange={(options) => { changeFilter('title', options as KeyValue[]); }}
          />

              </Grid>
              */}

        <Grid item xs={2}>
          {!props.isLoading && (
          <TextInputField
            keyName="title"
            labelText="Title"
            inputText={state.title[0] ?? ''}
            onChangeFunction={(e: any) => e}
            onBlur={(e: any) => { changeTextFilter(e, 'title'); }}
            error={false}
          />
          )}
        </Grid>

        <Grid item xs={2}>
          <TypedownFilter
            id="publisher"
            isLoading={props.isLoading}
            title="Publisher"
            options={state.publisher}
            selectedOptions={filterList.data.publisher}
            onChange={(options) => { changeFilter('publisher', options as string[]); }}
          />
        </Grid>

        {/* <Grid item xs={2}>
          <TypedownFilter
            isLoading={props.isLoading}
            title="Grouping"
            options={state.grouping}
            selectedOptions={filterList.data.grouping}
            onChange={(options) => { changeFilter('grouping', options as string[]); }}
          />
              </Grid> */}
        <Grid item xs={2}>
          {!props.isLoading && (
          <TextInputField
            keyName="grouping"
            labelText="Grouping"
            inputText={state.grouping[0] ?? ''}
            onChangeFunction={(e: any) => e}
            onBlur={(e: any) => { changeTextFilter(e, 'grouping'); }}
            error={false}
          />
          )}
        </Grid>

        <Grid item xs={2}>
          <TypedownFilter
            id="status"
            isLoading={props.isLoading}
            title="Status"
            options={state.status}
            selectedOptions={filterList.data.status}
            onChange={(options) => { changeFilter('status', options as KeyValue[]); }}
          />

        </Grid>
        <Grid item xs={2}>
          <TypedownFilter
            id="organisation"
            isLoading={props.isLoading}
            title="Organisation"
            options={state.organisation}
            selectedOptions={filterList.data.organisation}
            onChange={(options) => { changeFilter('organisation', options as KeyValue[]); }}
          />
        </Grid>
        <Grid item xs={2}>
          <TypedownFilter
            id="contentType"
            isLoading={props.isLoading}
            title="Content Type"
            options={state.contentType}
            selectedOptions={filterList.data.contentType}
            onChange={(options) => { changeFilter('contentType', options as KeyValue[]); }}
          />
        </Grid>
        <Grid item xs={2}>
          {!props.isLoading && (
          <TextInputField
            keyName="issn"
            labelText="ISSN"
            inputText={state.issn[0] ?? ''}
            onChangeFunction={(e: any) => e}
            onBlur={(e: any) => { changeTextFilter(e, 'issn'); }}
            error={false}
          />
          )}
        </Grid>
        <Grid item xs={2}>
          {!props.isLoading && (
          <TextInputField
            keyName="isbn"
            labelText="ISBN"
            inputText={state.isbn[0] ?? ''}
            onChangeFunction={(e: any) => e}
            onBlur={(e: any) => { changeTextFilter(e, 'isbn'); }}
            error={false}
          />
          )}
        </Grid>
        <Grid item xs={2}>
          {!props.isLoading && (
          <TextInputField
            keyName="documentNumber"
            labelText="Document Number"
            inputText={state.documentNumber[0] ?? ''}
            onChangeFunction={(e: any) => e}
            onBlur={(e: any) => { changeTextFilter(e, 'documentNumber'); }}
            error={false}
          />
          )}
        </Grid>
        <Grid item xs={2}>
          {!props.isLoading && (
          <TextInputField
            keyName="resource"
            labelText="Resource"
            inputText={state.resource[0] ?? ''}
            onChangeFunction={(e: any) => e}
            onBlur={(e: any) => { changeTextFilter(e, 'resource'); }}
            error={false}
          />
          )}
        </Grid>

        {/*
        <Grid item xs={2}>
          <TypedownFilter
            isLoading={props.isLoading}
            title="ISSN"
            options={state.issn}
            selectedOptions={filterList.data.issn}
            onChange={(options) => { changeFilter('issn', options as string[]); }}
          />
        </Grid>
        <Grid item xs={2}>
          <TypedownFilter
            isLoading={props.isLoading}
            title="ISBN"
            options={state.isbn}
            selectedOptions={filterList.data.isbn}
            onChange={(options) => { changeFilter('isbn', options as string[]); }}
          />
        </Grid>
        <Grid item xs={2}>
          <TypedownFilter
            isLoading={props.isLoading}
            title="Document Number"
            options={state.documentNumber}
            selectedOptions={filterList.data.documentNumber}
            onChange={(options) => { changeFilter('documentNumber', options as string[]); }}
          />
              </Grid>

        <Grid item xs={2}>
          <TypedownFilter
            isLoading={props.isLoading}
            title="Resource"
            options={state.resource}
            selectedOptions={filterList.data.resource}
            onChange={(options) => { changeFilter('resource', options as string[]); }}
          />
        </Grid>
*/}
        <Grid item xs={2}>
          <TypedownFilter
            id="priority"
            isLoading={props.isLoading}
            title="Priority"
            options={state.priority}
            selectedOptions={filterList.data.priority}
            onChange={(options) => { changeFilter('priority', options as KeyValue[]); }}
          />
        </Grid>
        {props.isAdmin ? (

          <Grid item xs={2}>
            <TypedownFilter
              id="indexingCompany"
              isLoading={props.isLoading}
              title="Indexing Company"
              options={state.indexingCompany}
              selectedOptions={filterList.data.indexingCompany}
              onChange={(options) => { changeFilter('indexingCompany', options as KeyValue[]); }}
            />
          </Grid>
        ) : ''}
        {!props.isLoading
                  && (
                  <>
                    <Grid item xs={2}>
                      <Dropdown
                        id="hasIndexerNotes"
                        keyName="hasIndexerNotes"
                        options={booleanLookup.map((o) => ({
                          display: o,
                          value: o,
                        }))}
                        value={getBooleanOption('hasIndexerNotes')}
                        labelText="Has Indexer Notes"
                        onChangeFunction={(key: string, value: string) => {
                          changeBooleanFilter('hasIndexerNotes', value);
                        }}
                      />
                    </Grid>
                      {props.isAdmin ? (

                        <Grid item xs={2}>
                          <Dropdown
                            id="hasPublisherNotes"
                            keyName="hasPublisherNotes"
                            options={booleanLookup.map((o) => ({
                              display: o,
                              value: o,
                            }))}
                            value={getBooleanOption('hasPublisherNotes')}
                            labelText="Has Publisher Notes"
                            onChangeFunction={(key: string, value: string) => {
                              changeBooleanFilter('hasPublisherNotes', value);
                            }}
                          />
                        </Grid>
                      ) : ''}

                    <Grid item xs={2}>
                      <Dropdown
                        id="includeRelated"
                        keyName="includeRelated"
                        options={booleanLookup.map((o) => ({
                          display: o,
                          value: o,
                        }))}
                        value={getBooleanOption('includeRelated')}
                        labelText="Include Related"
                        onChangeFunction={(key: string, value: string) => {
                          changeBooleanFilter('includeRelated', value);
                        }}
                      />
                    </Grid>
                  </>
                  )}
        <Grid item xs={4} />
        <Box width="100%" />
        {filterAreaState.isAdvanceView && (
        <>
          <Grid item xs={2}>
            <DateFromToFieldInput
              value={stateLastModifiedDate}
              keyName={FIELD_LAST_MODIFIED_DATE}
              label="Last Modified Date"
              isLoading={props.isLoading}
              onChange={(value) => {
                changeDateFilter(value, ID_LAST_MODIFIED_DATE);
              }}
              readonly={false}
            />
          </Grid>
          <Grid item xs={2}>
            <DateFromToFieldInput
              value={stateIssueFilesReceivedDate}
              keyName="stateIssueFilesReceivedDate "
              label="Issue Files Received Date "
              isLoading={props.isLoading}
              onChange={(value) => {
                changeDateFilter(value, ID_ISSUE_FILES_RECEIVED);
              }}
              readonly={false}
            />
          </Grid>
          <Grid item xs={2}>
            <DateFromToFieldInput
              value={stateReadyForFilePrepDate}
              keyName="ReadyForFilePrepDate"
              label="Ready For  File Prep Date"
              isLoading={props.isLoading}
              onChange={(value) => {
                changeDateFilter(value, ID_READY_FOR_FILE_PREP);
              }}
              readonly={false}
            />
          </Grid>

          <Grid item xs={2}>
            <DateFromToFieldInput
              value={stateReadyForIssueSplittingDate}
              keyName="stateReadyForIssueSplittingDate"
              label="Ready For Issue Splitting Date"
              isLoading={props.isLoading}
              onChange={(value) => {
                changeDateFilter(value, ID_READY_FOR_ISSUE_SPLITTING);
              }}
              readonly={false}
            />
          </Grid>

          <Grid item xs={2}>
            <DateFromToFieldInput
              value={stateReadyForLegalIndexingDate}
              keyName="stateReadyForLegalIndexingDate"
              label="Ready For Legal Indexing Date"
              isLoading={props.isLoading}
              onChange={(value) => {
                changeDateFilter(value, ID_READY_FOR_LEGAL_INDEXING);
              }}
              readonly={false}
            />
          </Grid>

          <Grid item xs={2}>
            <DateFromToFieldInput
              value={stateReadyForAdvancedIndexingDate}
              keyName="stateReadyForAdvancedIndexingDate"
              label="Ready For Advanced Indexing Date"
              isLoading={props.isLoading}
              onChange={(value) => {
                changeDateFilter(value, ID_READY_FOR_ADVANCED_INDEXING);
              }}
              readonly={false}
            />
          </Grid>

          <Grid item xs={2}>
            <DateFromToFieldInput
              value={stateReadyForIndexingDate}
              keyName="stateReadyForIndexingDate"
              label="Ready For Indexing Date "
              isLoading={props.isLoading}
              onChange={(value) => {
                changeDateFilter(value, ID_READY_FOR_INDEXING);
              }}
              readonly={false}
            />
          </Grid>

          <Grid item xs={2}>
            <DateFromToFieldInput
              value={stateIndexingCompleteDate}
              keyName="stateIndexingCompleteDate"
              label="Indexing Complete Date"
              isLoading={props.isLoading}
              onChange={(value) => {
                changeDateFilter(value, ID_INDEXING_COMPLETE);
              }}
              readonly={false}
            />
          </Grid>
        </>
        )}
        <Grid item xs={12}>
          <Divider />
        </Grid>
        <Grid item xs={12} style={{ textAlign: 'right' }} />

        <Grid item xs={12} style={{ textAlign: 'right' }}>

          <Button onClick={submitFilter}>Apply Filter</Button>
          <Button onClick={exportResult}>Export CSV</Button>
          {!props.isLoading && (<Button onClick={() => { clearAllFilters(); }}>Clear</Button>)}
          <Button onClick={showFullFilter}>
            Show
            {' '}
            {filterAreaState.isAdvanceView ? 'Simple' : 'Advanced'}
          </Button>

        </Grid>

      </Grid>
    </>
  );
};

export default SimpleFilters;
