import {
  Record, Static, Array, Number, String,
} from 'runtypes';
// import { LookupOptionValidator } from '../LookupOption';
import { custLookupOptionValidator } from '../ResourceManagement/customLookup';

export const DocumentBroadSubjectValidator = Record({
  broadSubjectID: Number,
  name: String,
  // narrowSubjects: Array(LookupOptionValidator),
  narrowSubjects: Array(custLookupOptionValidator),
});

type DocumentBroadSubject = Static<typeof DocumentBroadSubjectValidator>;
export default DocumentBroadSubject;
