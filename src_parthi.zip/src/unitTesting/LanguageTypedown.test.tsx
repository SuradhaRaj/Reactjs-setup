/* eslint-disable @typescript-eslint/no-empty-function */
import React from 'react';
import { mount } from 'enzyme';
import LanguageTypedown from '../components/molecules/MediaIndexer/LanguageTypedown';

describe('Terms Typedown Tests', () => {
  it('should display the number of remaining selections left', () => {
    const wp = mount((
      <LanguageTypedown
        selectedLanguages={[{
          name: 'Language 1', id: 'eng', createdBy: '', createdDate: '',
        }, {
          name: 'Language 2', id: 'afr', createdBy: '', createdDate: '',
        }]}
        languageLookup={[{ value: 'Language 1', key: 'eng' }, { value: 'Language 2', key: 'afr' }]}
        keyName="languages"
        onChangeFunction={() => {}}
        error={false}
        readOnly={false}
        typedownLimit={10}
      />
    ));

    // number of selections next to limit should be displayed
    expect(wp.find('[data-remaining]').text()).toBe('8');
  });
});
