export default interface ClassificationOption {
    id: number;
    name: string;
// eslint-disable-next-line semi
}
