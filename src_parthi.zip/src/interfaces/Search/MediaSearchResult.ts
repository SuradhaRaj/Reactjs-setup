import {
  Record, Null, String, Static,
} from 'runtypes';
import { SearchResultValidator } from './SearchResult';

export const MediaSearchResultValidator = Record({
  masId: String,
  channel: String,
  itemTitle: String,
  programTitle: String,
  indexer: String.Or(Null),
  broadcastDate: String,
  workflowState: String,
}).And(SearchResultValidator);

type MediaSearchResult = Static<typeof MediaSearchResultValidator>
export default MediaSearchResult;
