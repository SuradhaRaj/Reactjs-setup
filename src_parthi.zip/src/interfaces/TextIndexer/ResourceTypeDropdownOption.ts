interface ResourceTypeDropdownValue {
  id: number;
  stringValue: string;
}

export default interface ResourceTypeDropdownOption {
  display: string;
  value: ResourceTypeDropdownValue;
  // eslint-disable-next-line semi
};
