// zoom number storate.
const STORAGE_TTL_ZOOM = 'TTL_ZOOM';
const DEFAULT_ZOOM_PERCENTAGE = 100;
export function saveStorageZoomPercent(percent: number) {
  localStorage.setItem(STORAGE_TTL_ZOOM, JSON.stringify(percent));
}

export function getStorageZoomPercent(): number {
  const percent = localStorage.getItem(STORAGE_TTL_ZOOM);
  if (percent !== null) {
    return JSON.parse(percent);
  }

  return DEFAULT_ZOOM_PERCENTAGE;
}
