import React from 'react';
import { shallow, mount } from 'enzyme';
import { TextValidationErrorDialog } from '../../../components/organisms/TextIndexer/TextValidationErrorDialog';
import ResourceStringHelper from '../../../utils/ResourceStringHelper';
import TextIndexerValidationStrings from '../../../res/TextIndexerValidationStrings';

describe('Validation dialog', () => {
  it('should render the correct number of errors', () => {
    const wrapper = mount(<TextValidationErrorDialog
      isOpen
      onProceed={() => undefined}
      onReturn={() => undefined}
      errors={[1, 3]}
      allowSkip={false}
    />);

    let error1: string = ResourceStringHelper.MapNumberToString(TextIndexerValidationStrings, 1);
    expect(wrapper.contains(error1)).toBe(true);

    error1 = ResourceStringHelper.MapNumberToString(TextIndexerValidationStrings, 3);
    expect(wrapper.contains(error1)).toBe(true);
  });

  it('should render the skip button if provided with the correct prop', () => {
    let wrapper = shallow(<TextValidationErrorDialog isOpen onProceed={() => undefined} onReturn={() => undefined} errors={[1]} allowSkip={false} />);
    expect(wrapper.find('[data-skip-min-reqs-btn]')).toHaveLength(0);

    wrapper = shallow(<TextValidationErrorDialog isOpen onProceed={() => undefined} onReturn={() => undefined} errors={[]} allowSkip />);
    expect(wrapper.find('[data-skip-min-reqs-btn]')).toHaveLength(1);
  });

  it('should render the name of the failed artifact if provided', () => {
    const failedArtifactName = 'test artifact';

    let wrapper = mount(<TextValidationErrorDialog
      isOpen
      onProceed={() => undefined}
      onReturn={() => undefined}
      errors={[1, 3]}
      allowSkip={false}
      failedArtifactTitle={failedArtifactName}
    />);
    expect(wrapper.contains(failedArtifactName)).toBe(true);

    wrapper = mount(<TextValidationErrorDialog isOpen onProceed={() => undefined} onReturn={() => undefined} errors={[1, 3]} allowSkip={false} failedArtifactTitle="" />);
    expect(wrapper.contains(failedArtifactName)).toBe(false);
  });
});
