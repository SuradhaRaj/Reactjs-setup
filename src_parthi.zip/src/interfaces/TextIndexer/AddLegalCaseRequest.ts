interface AddLegalCaseRequest {
  isPrimary: boolean;
  newGroup: boolean;
  groupId: number | null;
  name: string;
};

export default AddLegalCaseRequest;
