import React from 'react';
import {
  FormControlLabel, Checkbox, FormControl, makeStyles, createStyles, Typography,
} from '@material-ui/core';

const useStyles = makeStyles(createStyles({
  root: {
    margin: 0,
    '& .MuiFormControlLabel-label': {
      fontSize: '0.8rem',
    },
    '&.MuiFormControlLabel-root': {
      margin: 0,
    },
    '& .MuiCheckbox-root': {
      padding: 0,
    },
  },
}));

interface SingleCheckboxProps {
  label: string;
  keyName: string;
  checked: boolean;
  disabled?: boolean;
  error?: boolean;
  onBlur?(event: React.FocusEvent<HTMLDivElement>): void;
  onChange(event: React.ChangeEvent<HTMLInputElement>): void;
  className?: string;
  helperText?: string;
  labelClassName?: string;
  labelPlacement: 'bottom' | 'top' | 'end' | 'start';
    isReadOnly?: boolean;
};

const SingleCheckbox = (props: SingleCheckboxProps) => {
  const classes = useStyles();

  return (
    <FormControl
      error={props.error}
      disabled={props.disabled}
      onBlur={props.onBlur}
      className={props.className}
      margin="normal"
    >
      <FormControlLabel
        classes={{
          label: props.labelClassName,
        }}
        className={classes.root}
        label={props.label}
        labelPlacement={props.labelPlacement}
        control={(
          <Checkbox
            style={{ paddingRight: 3 }}
            onChange={props.onChange}
            checked={props.checked}
            color="primary"
            disabled={props.isReadOnly}
          />
        )}
      />
      <Typography>{props.helperText}</Typography>
    </FormControl>
  );
};

SingleCheckbox.defaultProps = {
  labelPlacement: 'start',
};

export default SingleCheckbox;
