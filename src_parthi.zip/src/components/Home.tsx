import React from 'react'; // { useEffect, useState }
import { Button } from '@material-ui/core';

function navigateToLogin() {
  window.location.href = '/';
}
export default function HomeLogin() {
  return (
    <>
      <div>
        <span>
          You have been signed out of Informit MAESTRO.
        </span>
        <img alt="Informit Logo" src="/assets/informitlogo_rgb.png" width="109" height="64" />
        <Button variant="text" color="primary" onClick={navigateToLogin}>
          Log me in
        </Button>
      </div>
    </>
  );
}
