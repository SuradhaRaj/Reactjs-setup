import {
  Static, Array,
} from 'runtypes';
import { TextTaskManagementArtifactTaskValidator } from './TextTaskManagementArtifactTask';

export const TextTaskManagementTasksValidator = Array(TextTaskManagementArtifactTaskValidator);

type TextTaskManagementTasks = Static<typeof TextTaskManagementTasksValidator>
export default TextTaskManagementTasks;
