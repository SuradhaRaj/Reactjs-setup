import React from 'react';
import { ThemeProvider as MuiThemeProvider } from '@material-ui/core/styles';
import { SnackbarProvider } from 'notistack';
import { Provider } from 'react-redux';
import {
  MsalProvider, AuthenticatedTemplate, UnauthenticatedTemplate,
} from '@azure/msal-react'; // useMsal, useIsAuthenticated,
import Layout from './components/Layout';

import theme from './config/theme';
import { AppContextProvider } from './components/Context';
import AxiosErrorInterceptor from './components/molecules/AxiosErrorInterceptor';
import store from './store/store';
import Configuration from './components/organisms/Configuration';
import ApplicationInsights from './components/atoms/ApplicationInsights';
import Autologin from './components/Autologin';
// import Home from './components/Home';

export default function App({ msalInstance }) {
  return (
    <MsalProvider instance={msalInstance}>
      <AuthenticatedTemplate>
        <AxiosErrorInterceptor>
          <Provider store={store}>
            <AppContextProvider>
              <MuiThemeProvider theme={theme}>
                <SnackbarProvider maxSnack={1}>
                  <Configuration>
                    <ApplicationInsights />
                    <Layout />
                  </Configuration>
                </SnackbarProvider>
              </MuiThemeProvider>
            </AppContextProvider>
          </Provider>
        </AxiosErrorInterceptor>
      </AuthenticatedTemplate>
      <UnauthenticatedTemplate>
        <Autologin />
      </UnauthenticatedTemplate>
    </MsalProvider>
  );
};
