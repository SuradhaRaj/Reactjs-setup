import React from 'react';
import { makeStyles, createStyles } from '@material-ui/core';
import classnames from 'classnames';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
  className?: string;
}
const useStyles = makeStyles(() => createStyles({
  tabPanel: {
    minHeight: 200,
    display: 'flex',
    flexDirection: 'column',
    overflowY: 'auto',
  },
}));

export default (panelProps: TabPanelProps) => {
  const classes = useStyles();
  const {
    children, value, index, className,
  } = panelProps;

  return (
    <div className={classnames(className, classes.tabPanel)} hidden={value !== index}>
      {value === index && (
        <>{children}</>
      )}
    </div>
  );
};
