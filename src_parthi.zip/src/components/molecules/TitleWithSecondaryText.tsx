import React from 'react';
import { Typography } from '@material-ui/core';

interface TitleWithSecondaryTextProps {
  title: string;
  secondaryText: string;
}

const TitleWithSecondaryText = (props: TitleWithSecondaryTextProps) => (
  <>
    <Typography variant="h5">
      {props.title}
    </Typography>
    <Typography variant="body1" color="textSecondary">
      {props.secondaryText}
    </Typography>
  </>
);

export default TitleWithSecondaryText;
