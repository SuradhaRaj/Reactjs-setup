import {
  Record, Null, String, Static, Number, Boolean,
} from 'runtypes';

export const ResourceArticleValidator = Record({
  artifactId: Number,
  masId: String,
  sectionName: String.Or(Null),
  itemTitle: String.Or(Null),
  indexer: String.Or(Null),
  workflowState: String,
  articleOrder: Number,
  pagination: String.Or(Null),
  peerReviewedArticleIndicator: Boolean,
  publishArtefact: Boolean,
});

type ResourceArticleData = Static<typeof ResourceArticleValidator>
export default ResourceArticleData;

export interface ResourceArtifactExtendItem extends ResourceArticleData {
    grouping: string;
    publisher: string;
    resourceTitle: string;
    publicationYear: string;
    resourceType: string;
}
